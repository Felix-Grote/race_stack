# Remediation integration review

The existing runner gates flake8 and the three explicit test_route source suites, W0 numerical, installed ROS and installed W1 checks. Tests appended to those files need no runner change. Separate new test files require explicit runner coverage; colcon discovery alone is insufficient because all-mode records legacy failure status as a warning.

All-mode does not compare failure identities against W0. Retain a separate exact identity comparison before acceptance. Fresh verification output paths are enforced. setup initializes recursive pins; the initial new checkout has five uninitialized top-level submodules. No hardware Compose or runtime changes are required.

For hosted verification, prefer a push run whose checkout log is the exact final source SHA; PR head metadata alone is insufficient because actions/checkout defaults to a synthetic merge. Documentation is already in CI path filters, so the final documentation/evidence closeout must also receive exact-head verification.

Original isolated image, locks, Compose, interfaces, optimizer and seven recursive gitlinks should remain unchanged. Only repaired W1 modules, focused regressions and documented evidence require mutation.
