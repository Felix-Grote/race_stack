# Independent incremental review: F1 and F5

Inspected committed F5 5864423f4ac35998366f49e6529b4c751a85efbc and F1 74cebe0b6f34ee29a1f9a9db9dc4032056b8bc2d without changing source or docs.

F5 normalizes cross(gate, travel) by gate length, making its comparison to the metre EPS dimensionally consistent. Portal cap validation already excludes degenerate gate endpoints. Added collinear-subdivision tests cover twelve scale/width/rigid combinations; six fail against original source, full repaired A01 suite reports 60 passed. No new defect identified.

F1 merges positive-overlap normal interiors, retaining merely touching intervals as cuts. Only an explicitly declared shared-cap predicate permits a touching union. The actual public preparation-anchor counterexample now limits left width to the first boundary rather than 0.7m. Added exact/near-tangent transformed cases and declared-cap/unrelated-side tests include eight red failures with six red passes; full repaired A03 suite reports 32 passed. This repairs returned-interval semantics without claiming continuous swept certification. No new defect identified.

Read preserved red and green gzip logs and identity records; SHA256SUMS for both evidence directories pass. Green records are nonempty. These focused checks do not establish final combined acceptance or final exact-head CI, which remain pending.
