## Independent remediation validation

All validation remained in scratch. No production files, tracked tests, Git
branches, commits, hardware systems or PR state were changed by this validator.
The implementing agents owned the repairs and their tracked regressions.

Runtime image `project-a-humble:w0`:
`sha256:8c9c36d25927e34e03ab3e9978bd1a1a56ab4f60a7ec57ce90c17c053c7ab8d3`.
Actual runtime: ROS Humble, Python 3.10.12, NumPy 1.26.4, SciPy 1.11.4. Executed
isolation assertions establish UID 1000, CapEff 0, NoNewPrivs 1, loopback-only
networking and read-only root/source. Scratch output alone was writable.

Fresh W0 replay:

```bash
bash work/remediation/validation/run_w0_baseline.sh
python3 work/remediation/validation/compare_w0_legacy.py \
  work/remediation/validation/w0-current-replay \
  /workspace/work/w1-review/suites/w0-run
```

The W0 source archive is exactly
`6370d0436aabd011d1b885fe1f500644b957b536`; all 656 tracked non-gitlink blobs were
independently rehashed against that Git tree. The unchanged optimizer pin
`b1b38ecfefec7200d5bcb243f115af1d795b3766` was mounted read-only. Full functional
runner exit 0: **7 numerical + 4 ROS pass; 3 selected package builds pass**.
Legacy reports **12 aggregate tests / 0 errors / 10 failures / 2 skips**, exactly
matching the original W0 failing/skipped identities. Old review evidence remains
untouched. The exact Docker command is preserved in
`w0-current-replay/executed-runner.sh`, and source/dependency/runtime evidence is
retained in that output directory.

Independent repaired-kernel probe:

```bash
bash work/remediation/validation/run_focused.sh final-independent-02
```

All six groups pass, exit 0, with unchanged production source hashes before/after:

| Group | Independent coverage and result |
|---|---|
| Metric integration/inversion | 18 hidden-pocket, non-retracing, rotated/translated and reversed cubic cases; all resolve at unchanged default 100-panel budget; 90 inverse queries. Split fixed Gauss 256/512 agree within 2e-12 m; maximum length discrepancy 3.913536161803677e-15 m and inverse residual 9.900884279101518e-11 m. |
| Half-open endpoints | 24 fixed-seed random periodic curves; 408 exact endpoint and adjacent-nextafter checks, plus tiny negative and multiple-lap progress; all pass. |
| Tangent and micro-gap normal geometry | 32 rigid-motion cases; all return the component before the cut, maximum left width .749999999 m, rather than crossing the .75 m notch. |
| Exact semantic anchors | Warped legal S0 retains exact three caps separated by .4e-9 and 2.1e-9 m in q; cap values 1/3/2 remain correct; forged q/cap/owner samples reject. Original public one-cap preparation passes with 163 samples. |
| Cross-module ownership | 60 seam/occurrence-boundary exact and adjacent-nextafter queries across five directed routes; Curve and corridor agree in owner, source segment/t and half-open q, with no explicit rejections. |
| Directed gate scale | A valid .1 mm ribbon still accepts after collinear seed subdivision by 1 micrometre; seed length remains exactly unchanged. |

`final-independent-02/summary.json`, `run.log`, `runtime-identity.json`,
`numerical-runtime.json`, `dependencies.txt`, `image-id.txt` and
`source-hashes-before.txt` preserve the executed evidence. The source-head file
identifies the then-current commit; pending repair bytes are additionally
identified by the recorded SHA-256 values and source-status file.
`committed-source-map.json` verifies all four tested production files are exactly
the committed bytes at `becfe8fc46e7490e8857f630a37f0617f477da71`.

Final prescribed W1 replay (after the already successful `setup.sh`):

```bash
scripts/project_a/verify.sh all work/remediation/validation/w1-final
python3 work/remediation/validation/compare_w0_legacy.py \
  work/remediation/validation/w1-final
sha256sum -c work/remediation/validation/w1-final-source-hashes-before.txt
```

Exact source `becfe8fc46e7490e8857f630a37f0617f477da71` was clean before and after;
all seven recursive submodule pins matched. Functional exit **0**:
**60 A01 + 47 A02 + 38 A03 + 7 W0 numerical + 4 ROS + 1 installed test pass**,
three selected packages build/install successfully. Scoped flake8, pip check,
runtime isolation and actual non-symlink installed import checks pass.
The four installed production files independently hash-identically to source
(`w1-final/installed-source-map.json`). All nine recorded production/test/runner
hashes remain unchanged after execution.

The separately visible legacy run reports **157 aggregate tests / 0 errors /
10 failures / 2 skips**. Its failing and skipped identities match the fresh W0
baseline exactly (`w1-final/independent-w0-legacy-comparison.json`); no new route
module/helper diagnostics appear in the legacy report. Both legacy colcon exit
codes remain 1 and are not described as passing. The 145 added route tests pass
within that legacy aggregate. Raw command capture, runner log, JUnit, source and
runtime identities, inventories and numerical measurements are preserved under
`w1-final/` and `w1-final-command.log`.

Independent probing exposed an additional integration edge during repair:
`nextafter` below the first S0 occurrence boundary returned segment 31/t=1 but
corridor owner o1 while Curve owner was o0. This red result is preserved in
`f1-f3-boundary-independent-02/run.log`; the final independent boundary group now
passes after source-owner/half-open lineage guards.

Two intermediate harness events do not indicate production defects: the first
focused invocation stopped before tests because ROS setup is incompatible with
shell nounset; the runner was corrected to match the repository runner. An
expanded numerical run detected a concurrent F4 source change via the hash guard
and was superseded by the complete stable run above.

This coverage is numerical and topological software validation. It does not
implement or certify W2 optimization, continuous swept-footprint containment,
vehicle dynamics, real-course legality or hardware safety.
