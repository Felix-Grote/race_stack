#!/usr/bin/env bash
set -euo pipefail
validation_label=${1:?Provide fresh run label}
shift
case "$validation_label" in *[!a-zA-Z0-9_-]*) exit 2 ;; esac
validation_repo=/workspace/work/w1-remediation
validation_base="$validation_repo/work/remediation/validation"
validation_out="$validation_base/$validation_label"
if [ -e "$validation_out" ]; then echo 'Require a fresh run label' >&2; exit 2; fi
mkdir "$validation_out"
cp "$validation_base/focused_independent.py" "$validation_base/container_focused.sh" "$validation_out/"
git -C "$validation_repo" rev-parse HEAD > "$validation_out/source-head.txt"
git -C "$validation_repo" status --short > "$validation_out/source-status.txt"
sha256sum "$validation_repo/planner/global_planner/global_planner/route_reference.py" \
 "$validation_repo/planner/global_planner/global_planner/route_corridor.py" \
 "$validation_repo/planner/global_planner/global_planner/_route_geometry.py" \
 "$validation_repo/planner/global_planner/global_planner/route_input.py" \
 "$validation_out/focused_independent.py" > "$validation_out/source-hashes-before.txt"
unset DOCKER_HOST DOCKER_CONTEXT DOCKER_TLS DOCKER_TLS_VERIFY DOCKER_CERT_PATH
docker --host=unix:///var/run/docker.sock image inspect project-a-humble:w0 \
 --format '{{.Id}}' > "$validation_out/image-id.txt"
set +e
docker --host=unix:///var/run/docker.sock run --rm \
 --user "$(id -u):$(id -g)" --read-only --network none --ipc private \
 --cap-drop ALL --security-opt no-new-privileges:true --pids-limit 256 \
 --memory 4g --cpus 2 --workdir /validation \
 -e HOME=/validation -e PYTHONDONTWRITEBYTECODE=1 -e MPLBACKEND=Agg \
 -e OPENBLAS_NUM_THREADS=1 -e OMP_NUM_THREADS=1 \
 -e PYTHONPATH=/src/planner/global_planner \
 --mount "type=bind,src=$validation_repo,dst=/src,readonly" \
 --mount "type=bind,src=$validation_out,dst=/validation" \
 --tmpfs /tmp:rw,nosuid,nodev,size=256m,mode=1777 \
 project-a-humble:w0 /bin/bash /validation/container_focused.sh "$@" \
 > "$validation_out/run.log" 2> "$validation_out/stderr.log"
validation_rc=$?
set -e
printf '%s\n' "$validation_rc" > "$validation_out/exit-code.txt"
sha256sum -c "$validation_out/source-hashes-before.txt" > "$validation_out/source-unchanged.txt"
exit "$validation_rc"
