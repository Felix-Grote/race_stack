"""Require unchanged W0 failing/skipped identities after the full repaired build."""
import json
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

baseline = Path(sys.argv[2] if len(sys.argv) > 2 else
                '/workspace/work/w1-remediation/work/remediation/validation/w0-current-replay')
candidate = Path(sys.argv[1]).resolve()


def inspect(output):
    failing, skipped = [], []
    for path in sorted((output/'build').rglob('*.xml')):
        root = ET.parse(path).getroot()
        for node in root.iter('testcase'):
            identity = (str(path.relative_to(output/'build')),
                        node.get('classname'), node.get('name'))
            if node.find('failure') is not None or node.find('error') is not None:
                failing.append(identity)
            if node.find('skipped') is not None:
                skipped.append(identity)
    report = (output/'legacy-results.txt').read_text()
    summary = re.search(r'^Summary: .*$', report, re.M).group()
    return {'failing_leaf_testcases': failing, 'skipped_leaf_testcases': skipped,
            'summary': summary,
            'functional_exit_code': int((output/'exit-code.txt').read_text())}


old, new = inspect(baseline), inspect(candidate)
results = {'baseline': str(baseline), 'candidate': str(candidate),
           'w0': old, 'remediation': new,
           'failing_identities_equal': old['failing_leaf_testcases'] == new['failing_leaf_testcases'],
           'skipped_identities_equal': old['skipped_leaf_testcases'] == new['skipped_leaf_testcases']}
(candidate/'independent-w0-legacy-comparison.json').write_text(json.dumps(results, indent=2)+'\n')
print(json.dumps(results, indent=2))
assert new['functional_exit_code'] == 0
assert results['failing_identities_equal'] and results['skipped_identities_equal']
