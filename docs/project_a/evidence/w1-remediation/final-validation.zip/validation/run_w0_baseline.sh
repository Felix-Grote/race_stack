#!/usr/bin/env bash
set -euo pipefail
baseline_source=/workspace/work/w1-review/suites/w0-source
baseline_out=/workspace/work/w1-remediation/work/remediation/validation/w0-current-replay
if [ -e "$baseline_out" ]; then echo 'Require fresh baseline output' >&2; exit 2; fi
mkdir "$baseline_out"
printf '%s\n' 6370d0436aabd011d1b885fe1f500644b957b536 > "$baseline_out/source-head.txt"
git -C /workspace/race_stack rev-parse 6370d0436aabd011d1b885fe1f500644b957b536^{tree} \
 > "$baseline_out/source-tree.txt"
git -C /workspace/race_stack/planner/global_planner/global_planner/global_racetrajectory_optimization \
 rev-parse HEAD > "$baseline_out/optimizer-gitlink.txt"
cp "$0" "$baseline_out/executed-runner.sh"
unset DOCKER_HOST DOCKER_CONTEXT DOCKER_TLS DOCKER_TLS_VERIFY DOCKER_CERT_PATH
docker --host=unix:///var/run/docker.sock image inspect project-a-humble:w0 \
 --format '{{.Id}}' > "$baseline_out/image-id.txt"
set +e
docker --host=unix:///var/run/docker.sock run --rm \
 --name project-a-remediation-w0-baseline --user "$(id -u):$(id -g)" \
 --workdir /work --read-only --network none --ipc private \
 --cap-drop ALL --security-opt no-new-privileges:true --pids-limit 256 \
 --memory 4g --cpus 2 -e PYTHONDONTWRITEBYTECODE=1 -e MPLBACKEND=Agg \
 -e OPENBLAS_NUM_THREADS=1 -e OMP_NUM_THREADS=1 -e HOME=/work \
 --mount "type=bind,src=$baseline_source,dst=/src,readonly" \
 --mount type=bind,src=/workspace/race_stack/planner/global_planner/global_planner/global_racetrajectory_optimization,dst=/src/planner/global_planner/global_planner/global_racetrajectory_optimization,readonly \
 --mount "type=bind,src=$baseline_out,dst=/work" \
 --tmpfs /tmp:rw,nosuid,nodev,size=256m,mode=1777 \
 project-a-humble:w0 /bin/bash /src/scripts/project_a/container_verify.sh all \
 > "$baseline_out/run.log" 2>&1
baseline_rc=$?
set -e
printf '%s\n' "$baseline_rc" > "$baseline_out/exit-code.txt"
exit "$baseline_rc"
