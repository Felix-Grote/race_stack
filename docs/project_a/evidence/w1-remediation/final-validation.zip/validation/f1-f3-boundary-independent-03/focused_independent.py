"""Independent bounded falsification probes for the five W1 repairs.

This file is scratch validation, outside tracked implementation and tests.
"""
import copy
from dataclasses import replace
import json
import math
from pathlib import Path
import sys

import numpy as np

from global_planner.route_input import Occurrence, load_route, validate_route
from global_planner.route_reference import Curve, CubicSegment, GeometryError, NumericPolicy
from global_planner.route_corridor import (
    CorridorError, OrderedCurve, _normal_geometry, normal_interval,
    prepare_route, resample_ordered, seed_curve, _sample,
)

SOURCE = Path('/src')
records = []
failures = []


def check(name, function):
    try:
        result = function()
        records.append({'name': name, 'status': 'PASS', 'details': result})
    except Exception as error:
        records.append({'name': name, 'status': 'FAIL',
                        'exception': type(error).__name__, 'message': str(error)})
        failures.append(name)


def gauss_arc(coefficients, t=1., order=256):
    # Independent differentiated polynomial and fixed Gaussian quadrature. Split
    # at component derivative roots and speed extrema to expose hidden pockets.
    c = np.asarray(coefficients, dtype=float)
    d = np.array([c[:, 1], 2*c[:, 2], 3*c[:, 3]]).T
    square = sum((np.polynomial.polynomial.polymul(row, row) for row in d),
                 start=np.zeros(5))
    breaks = [0., t]
    for polynomial in (*d, np.polynomial.polynomial.polyder(square)):
        for z in np.polynomial.polynomial.polyroots(polynomial):
            if abs(z.imag) < 1e-10 and 0 < z.real < t:
                breaks.append(float(z.real))
    nodes, weights = np.polynomial.legendre.leggauss(order)
    values = []
    for a, b in zip(sorted(set(breaks)), sorted(set(breaks))[1:]):
        u = a+(b-a)*(nodes+1)/2
        speed = np.hypot(*(np.polynomial.polynomial.polyval(u, row) for row in d))
        values.append(float((b-a)/2*np.dot(weights, speed)))
    return math.fsum(values)


def arc_pockets():
    rows = []
    cases = [((0., .0899, -.3, 1/3), (0., 2e-7, 0., 0.))]
    for center in (.173, .3, 17/32, .7071):
        for width in (.0005, .002, .01):
            cases.append(((0., center**2-width**2, -center, 1/3),
                          (0., 2e-7, 0., 0.)))
    cases.append(((0., .75*(17/32)**2+1e-12, -.75*17/32, .25),
                  (0., 4e-6, 0., 0.)))
    original = np.asarray(cases[0])
    for angle in (.713, 1.1, math.pi/2):
        ca, sa = math.cos(angle), math.sin(angle)
        rotated = np.asarray(((ca, -sa), (sa, ca)))@original
        rotated[:, 0] = (99980., -99980.)
        cases.append(tuple(tuple(float(x) for x in row) for row in rotated))
    reversed_coefficients = np.stack((original.sum(axis=1),
        -original[:, 1]-2*original[:, 2]-3*original[:, 3],
        original[:, 2]+3*original[:, 3], -original[:, 3]), axis=1)
    cases.append(tuple(tuple(float(x) for x in row) for row in reversed_coefficients))
    for coefficients in cases:
        oracle = gauss_arc(coefficients, order=512)
        coarse = gauss_arc(coefficients, order=256)
        assert abs(oracle-coarse) < 2e-12, (oracle, coarse)
        attempts = []
        for budget in (100, 256):
            try:
                segment = CubicSegment(coefficients, NumericPolicy(quad_limit=budget))
                error = abs(segment.length-oracle)
                assert error <= segment.policy.arc_abs+2e-12, (coefficients, error)
                residual = 0.
                for fraction in (.1, .25, .5, .75, .9):
                    target = fraction*segment.length
                    t = segment.parameter(target)
                    fine = gauss_arc(coefficients, t, 512)
                    check_coarse = gauss_arc(coefficients, t, 256)
                    assert abs(fine-check_coarse) < 2e-12
                    residual = max(residual, abs(fine-target))
                    assert abs(fine-target) <= segment.policy.station_abs+2e-12
            except GeometryError as error:
                attempts.append({'budget': budget, 'accepted': False, 'reason': str(error)})
                continue
            attempts.append({'budget': budget, 'accepted': True, 'length_error_m': error,
                             'maximum_station_error_m': residual})
            break
        rows.append({'attempts': attempts})
    assert any(row['attempts'][-1]['accepted'] for row in rows)
    return rows


def endpoint_semantics():
    rng = np.random.default_rng(1631)
    count = 0
    for _ in range(24):
        angle = np.linspace(0, 2*np.pi, 17, endpoint=False)
        angle += rng.uniform(-.07, .07, len(angle))
        owners = tuple((f'o{i}', 'ground') for i in range(len(angle)))
        curve = Curve.interpolate(np.c_[6*np.cos(angle), 3*np.sin(angle)], owners=owners)
        for i in range(len(curve.segments)):
            station = curve.station(i, 1.)
            assert station == curve.cumulative[i+1], (i, station, curve.cumulative[i+1])
            owner = curve.sample(station).occurrence_id
            assert owner == owners[(i+1) % len(owners)][0], (i, owner)
            if i+1 < len(curve.segments):
                assert curve.locate(math.nextafter(station, -math.inf))[0] == i
                assert curve.locate(math.nextafter(station, math.inf))[0] == i+1
            count += 1
        for s in (-1e-20, -np.finfo(float).tiny, -math.ulp(0.),
                  -curve.length, curve.length, -2*curve.length, 2*curve.length):
            sample = curve.sample(s)
            assert 0 <= sample.s < curve.length, (s, sample.s)
    return {'exact_endpoint_and_adjacent_checks': count, 'curves': 24}


def tangent_normals():
    rows = []
    for dx in (0., -5e-9, -1e-9, -1e-6):
        for angle in (0., .37, 1.1, 2.9):
            for offset in ((0., 0.), (10000., -20000.)):
                ca, sa = math.cos(angle), math.sin(angle)
                def point(p):
                    return (ca*p[0]-sa*p[1]+offset[0],
                            sa*p[0]+ca*p[1]+offset[1])
                seed = ((0., 0.), (10., 0.))
                left = ((0., 2.), (10., 2.), (10., 1.),
                        (5.+dx, .75), (10., .5), (10., .1))
                right = ((0., -1.), (10., -1.))
                owner = Occurrence('strip', 'ground', tuple(map(point, seed)),
                                   tuple(map(point, left)), tuple(map(point, right)),
                                   ((0., 4.),))
                try:
                    lo, hi = _normal_geometry((owner,), point((5., 0.)), (ca, sa))
                except CorridorError as error:
                    rows.append({'accepted': False, 'reason': str(error)})
                    continue
                # The original notch separates the legal open normal interval;
                # excluding its tip by an outer-boundary inset cannot repair it.
                assert hi < .75, (dx, angle, offset, hi)
                assert lo < 0 < hi
                rows.append({'accepted': True, 'upper_m': hi})
    return rows


def semantic_anchors():
    original = load_route(SOURCE/'planner/global_planner/test/fixtures/project_a/s0_route.json')
    base = seed_curve(original)
    points = []
    for i, q in enumerate(base.q[:-1]):
        angle = math.atan2(*base.curve.segments[i].evaluate(0)[::-1])
        if i < 32:
            u = q/original.occurrences[0].length
            angle = math.pi/2*(u+.99/(2*math.pi)*math.sin(2*math.pi*u))
        points.append((6*math.cos(angle), 6*math.sin(angle)))
    curve = Curve.interpolate(points, base.q, base.curve.owners)
    cap_q = 4.805954193927142
    raw = original.payload
    events = [(cap_q, 1.), (cap_q+.4e-9, 3.), (cap_q+2.1e-9, 2.)]
    raw['occurrences'][0]['caps'].extend(
        {'at_m': q, 'max_speed_mps': cap} for q, cap in events)
    route = validate_route(raw)
    ordered = OrderedCurve(route, curve, base.q)
    samples = resample_ordered(ordered, .25)
    rows = []
    for q, cap in events:
        found = [v for v in samples if v.q == q]
        assert len(found) == 1, (q, [(v.q, v.cap_mps) for v in samples if abs(v.q-q)<1e-8])
        sample = found[0]
        assert sample.cap_mps == cap, (q, cap, sample.cap_mps)
        normal_interval(ordered, sample)
        for forged in (replace(sample, q=sample.q+1e-6),
                       replace(sample, cap_mps=99.),
                       replace(sample, occurrence_id='wrong-owner')):
            try:
                normal_interval(ordered, forged)
            except CorridorError:
                pass
            else:
                raise AssertionError('accepted forged semantic anchor')
        rows.append({'q': q, 'cap_mps': sample.cap_mps})
    # The original single-event complete public case must still prepare.
    single = original.payload
    single['occurrences'][0]['caps'].append({'at_m': cap_q, 'max_speed_mps': 1.})
    single = validate_route(single)
    prepared = prepare_route(single, spacing=.25,
                             ordered=OrderedCurve(single, curve, base.q))
    found = [v for v in prepared.samples if v.q == cap_q]
    assert len(found) == 1 and found[0].cap_mps == 1.
    return {'nearby_events': rows, 'public_prepare_samples': len(prepared.samples)}


def boundary_coherence():
    rows = []
    for name in ('s0_route', 's0_reverse_route', 's2_upper_route', 's2_lower_route',
                 's3_surfaces_route'):
        route = load_route(SOURCE/'planner/global_planner/test/fixtures/project_a'/(name+'.json'))
        ordered = seed_curve(route)
        ends = [0.]
        for occurrence in route.occurrences:
            ends.append(ends[-1]+occurrence.length)
        for boundary in ends[:-1]:
            station = ordered.station_at_q(boundary)
            for s in (math.nextafter(station, -math.inf), station,
                      math.nextafter(station, math.inf)):
                try:
                    v = _sample(ordered, s)
                    ref = ordered.curve.sample(s)
                except (GeometryError, CorridorError) as error:
                    rows.append({'fixture': name, 's': s, 'explicit_rejection': str(error)})
                    continue
                assert (v.occurrence_id, v.surface_id) == (ref.occurrence_id, ref.surface_id), (
                    name, s, v, ref)
                assert (v.segment, v.t) == (ref.segment, ref.t)
                owner = next(i for i, occurrence in enumerate(route.occurrences)
                             if occurrence.id == v.occurrence_id)
                assert ends[owner] <= v.q < ends[owner+1], (name, s, v, ends)
                rows.append({'fixture': name, 's': s, 'segment': v.segment,
                             't': v.t, 'q': v.q, 'owner': v.occurrence_id})
    return rows


selection = set(sys.argv[1:])
for name, function in (('independent_arc_pockets', arc_pockets),
                       ('half_open_endpoint_semantics', endpoint_semantics),
                       ('tangent_and_microgap_normals', tangent_normals),
                       ('exact_semantic_anchor_lineage', semantic_anchors),
                       ('cross_module_boundary_coherence', boundary_coherence)):
    if not selection or name in selection:
        check(name, function)
print(json.dumps({'results': records, 'failures': failures}, indent=2))
sys.exit(bool(failures))
