#!/usr/bin/env bash
set -eo pipefail
source /opt/ros/humble/setup.bash
python /src/scripts/project_a/identity.py > /validation/runtime-identity.json
python -m pip freeze --all > /validation/dependencies.txt
python - <<'PY'
import json,platform,numpy,scipy
from pathlib import Path
Path('/validation/numerical-runtime.json').write_text(json.dumps({
 'python':platform.python_version(),'numpy':numpy.__version__,
 'scipy':scipy.__version__},indent=2)+'\n')
PY
python /validation/focused_independent.py "$@"
