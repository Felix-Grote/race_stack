from pathlib import Path
import json,hashlib
b=Path('/workspace/forza-audit-records/final-runtime-b961d20');v=Path('/workspace/forza-audit-records/fresh-b961d20-complete/verification')
r=json.loads((b/'actual-sourcefree-inspect.json').read_text());h=r['HostConfig'];ns=json.loads((b/'actual-sourcefree-namespace-closure.json').read_text());manifest=json.loads((v/'build-identity.json').read_text())
assert h['ReadonlyRootfs'] and h['NetworkMode']=='none' and h['IpcMode']=='private'
assert h['CapDrop']==['ALL'] and 'no-new-privileges' in h['SecurityOpt']
assert h['PidsLimit']==256 and h['Memory']==4*1024**3 and h['NanoCpus']==2*10**9
assert h['Tmpfs']=={'/tmp':'rw,nosuid,nodev,size=256m,mode=1777'}
assert r['Config']['User']=='1000:1000' and r['Config']['WorkingDir']=='/results'
expected={'/work/install':v/'install','/work/python':v/'python','/runtime-harness':v/'source-free/harness','/results':v/'source-free/results'}
assert {m['Destination'] for m in r['Mounts']}==set(expected)
for m in r['Mounts']:
 assert m['Type']=='bind' and Path(m['Source']).resolve()==expected[m['Destination']].resolve() and m['RW']==(m['Destination']=='/results')
assert r['Image']==(v/'image-id.txt').read_text().strip()
assert ns['status']=='PASS' and ns['source_free'] and ns['uid']==1000 and ns['implementation_module_count']==11 and len(ns['modules'])==12 and len(ns['resources'])==21
assert ns['manifest_sha256']==hashlib.sha256((v/'build-identity.json').read_bytes()).hexdigest()
for row in ns['modules']:assert row['sha256']==manifest['source_hashes']['planner/global_planner/global_planner/'+Path(row['origin']).name]
result=dict(status='PASS',actual_container=r['Id'],image_id=r['Image'],source_free=True,read_only_root=True,network='none',ipc='private',uid=1000,pid_limit=256,memory_bytes=h['Memory'],cpus=2,capabilities='ALL dropped',no_new_privileges=True,tmpfs_bytes=256*1024**2,mount_count=4,implementation_module_count=11,actual_legacy_reader_count=1,actual_resources=21,source_paths_absent=ns['absent_source_paths'],scope='Independent actual running namespace and Docker-control snapshot only; tests still in progress')
(b/'live-sourcefree-controls-audit.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
