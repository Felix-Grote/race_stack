from pathlib import Path
import hashlib,json,shutil,subprocess
b=Path('/workspace/forza-audit-records/final-runtime-b961d20');fresh=Path('/workspace/forza-audit-records/fresh-b961d20-complete');v=fresh/'verification';repo=fresh/'checkout';commit='b961d20ce4a803e55336fb5590c30574e23b2fad'
assert json.loads((b/'complete-audit.json').read_text())['status']=='PASS'
before=v/'source-hashes-before.json';after=v/'source-hashes-after.json';assert before.read_bytes()==after.read_bytes();snapshot=json.loads(before.read_text());manifest=json.loads((v/'build-identity.json').read_text())
for name,expected in snapshot.items():
 prefixes=[p for p in manifest['gitlinks'] if name.startswith(p+'/')]
 if prefixes:
  prefix=max(prefixes,key=len);gitroot=repo/prefix;revision=manifest['gitlinks'][prefix];relative=name[len(prefix)+1:]
 else:gitroot=repo;revision=commit;relative=name
 data=subprocess.check_output(['git','-C',str(gitroot),'show',revision+':'+relative]);assert hashlib.sha256(data).hexdigest()==expected,name
copies={'source-hashes-before.json':before,'source-hashes-after.json':after,'build-identity.json':v/'build-identity.json','source-identity.txt':v/'source-identity.txt','image-id.txt':v/'image-id.txt','summary.json':v/'summary.json','fresh-exit-code.txt':fresh/'fresh-exit-code.txt','verification-exit-code.txt':v/'exit-code.txt','sourcefree-exit-code.txt':v/'source-free/exit-code.txt','sourcefree-launch.json':v/'source-free/launch.json','sourcefree-runtime-identity.json':v/'source-free/results/runtime-identity.json','sourcefree-build-identity.json':v/'source-free/results/build-identity.json','sourcefree-tests.xml':v/'source-free/results/w3-source-free.xml','sourcefree-runtime-dependencies.txt':v/'source-free/results/runtime-dependencies.txt'}
records=[]
for name,p in copies.items():
 target=b/('complete-'+name);shutil.copyfile(p,target);records.append(dict(path=target.name,original_path=str(p),sha256=hashlib.sha256(target.read_bytes()).hexdigest(),bytes=target.stat().st_size))
result=dict(status='PASS',source_commit=commit,snapshot_before_after_byte_identical=True,snapshot_file_count=len(snapshot),snapshot_all_hashes_equal_literal_git_objects=True,manifest_source_file_count=len(manifest['source_hashes']),manifest_resource_count=len(manifest['installed_resource_hashes']),gitlink_count=len(manifest['gitlinks']),dependency_lock_count=len(manifest['dependency_lock_hashes']),records=records,scope='Frozen metadata copies and source-hash ledger from completed clean final same-host reference; no new runtime/QP work')
(b/'source-hash-ledger.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:value for k,value in result.items() if k!='records'}))
