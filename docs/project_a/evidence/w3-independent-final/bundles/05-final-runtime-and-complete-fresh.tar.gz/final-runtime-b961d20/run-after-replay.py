import json,subprocess,time
from pathlib import Path
b=Path('/workspace/forza-audit-records/final-runtime-b961d20')
for attempt in range(240):
 p=b/'hosted-replay/saved-replay.json'
 if p.exists() and len(json.loads(p.read_text()))==9:break
 time.sleep(5)
else:raise RuntimeError('Hosted replay not completed')
cmd=['docker','--host=unix:///var/run/docker.sock','exec','forza-independent-probes','bash','/records/final-runtime-b961d20/run-installed-numerical.sh']
r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
(b/'installed-numerical-console.log').write_text(r.stdout)
(b/'installed-numerical-exit-code.txt').write_text(str(r.returncode)+'\n')
raise SystemExit(r.returncode)
