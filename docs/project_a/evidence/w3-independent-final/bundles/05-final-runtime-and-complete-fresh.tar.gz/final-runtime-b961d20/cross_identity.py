import hashlib,json,subprocess
from pathlib import Path
from global_planner import route_artifact as a
from global_planner.route_compile import load_policy
output=Path('/records/final-runtime-b961d20')
_,context,_=load_policy('/records/fresh-b961d20/verification/install/global_planner/share/global_planner/project_a/policies/synthetic_policy.json')
rows=[]
def forbidden(*args,**kwargs):raise AssertionError('cross-implementation artifact reached validators')
a.validate_geometry=forbidden;a.validate_dynamics=forbidden
sources=[('17e4ec4e8fedfa736467d02f6204b04e8552decb',Path('/records/evidence/replay/final/catalog.json'),Path('/records/evidence/replay/final/incoming')),('67fbcc8283e59649d38dc9318291634089df3741',Path('/records/resume-evidence/controlled-hosted67-catalog.json'),Path('/records/resume-evidence/hosted67-inputs'))]
for commit,catalog,incoming in sources:
 c=json.loads(catalog.read_text())[0];p=incoming/c['relative_artifact'];raw=p.read_bytes();payload=json.loads(raw)['payload'];sha=hashlib.sha256(subprocess.check_output(['git','-C','/records/final-checkout','show',commit+':planner/global_planner/global_planner/route_artifact.py'])).hexdigest()
 assert sha==payload['implementation']['module_sha256']['route_artifact'] and payload['implementation']!=a.implementation_identity()
 if 'artifact_sha256'in c:assert hashlib.sha256(raw).hexdigest()==c['artifact_sha256']
 try:
  a.load_reference(p,expected_H=c['H'],validation_context=context)
  raise AssertionError('cross-implementation artifact accepted')
 except a.ArtifactError as exc:
  assert exc.status=='UNSUPPORTED' and str(exc)=='unsupported or changed kernel/checker/dependency identity'
  assert p.read_bytes()==raw
  rows.append(dict(source_commit=commit,status='PASS',rejection=str(exc),artifact_sha256=hashlib.sha256(raw).hexdigest(),route_artifact_sha256=sha,validator_calls=0,unchanged_input=True))
(output/'cross-implementation-negatives.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows))
