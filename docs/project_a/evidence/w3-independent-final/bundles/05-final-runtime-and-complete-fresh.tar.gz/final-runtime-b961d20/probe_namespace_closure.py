from pathlib import Path
import hashlib,importlib,json,os,sys
from ament_index_python.packages import get_package_share_directory
from global_planner.route_artifact import implementation_identity
prefix=Path(sys.argv[1]);source_free=sys.argv[2]=='1'
share=Path(get_package_share_directory('global_planner'))/'project_a';manifest=json.loads((share/'build_identity.json').read_text());assert manifest['source_commit']=='b961d20ce4a803e55336fb5590c30574e23b2fad' and manifest['source_dirty'] is False
identity=implementation_identity();rows=[]
for name in ('_route_geometry','route_input','route_reference','route_corridor','iqp_route_adapter','route_validate','route_validate_dynamics','cyclic_retime','route_artifact','route_compile','route_legacy_export','readwrite_global_waypoints'):
 m=importlib.import_module('global_planner.'+name);p=Path(m.__file__);sha=hashlib.sha256(p.read_bytes()).hexdigest();assert p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(prefix.resolve());assert sha==manifest['source_hashes']['planner/global_planner/global_planner/'+p.name]
 if name in identity['module_sha256']:assert sha==identity['module_sha256'][name]
 rows.append(dict(module=m.__name__,origin=str(p),sha256=sha,not_symlink=True))
resources=[]
for name,expected in manifest['installed_resource_hashes'].items():
 p=share/name;assert p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(prefix.resolve());sha=hashlib.sha256(p.read_bytes()).hexdigest();assert sha==expected;resources.append(dict(path=str(p),sha256=sha,not_symlink=True))
assert len(identity['module_sha256'])==11 and len(resources)==21
assert not any(p.startswith(('/src','/frozen','/workspace','/work/src','/work/build')) for p in sys.path)
absent=('/workspace','/src','/frozen','/work/src','/work/build','/work/optimizer','/records')
if source_free:assert not any(Path(p).exists() for p in absent)
assert os.getuid()==1000
print(json.dumps(dict(status='PASS',source_commit=manifest['source_commit'],source_free=source_free,uid=os.getuid(),implementation_module_count=11,modules=rows,resources=resources,manifest_sha256=hashlib.sha256((share/'build_identity.json').read_bytes()).hexdigest(),sys_path=sys.path,absent_source_paths=list(absent) if source_free else [],scope='Actual namespace import and resource-byte probe; 11 implementation modules plus actual legacy reader')))
