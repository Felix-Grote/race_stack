from pathlib import Path
import json,subprocess,time
b=Path('/workspace/forza-audit-records/final-runtime-b961d20');p=b/'actual-sourcefree-inspect.json'
for attempt in range(2160):
 if p.exists():break
 time.sleep(5)
else:raise RuntimeError('Actual source-free container not observed')
container=json.loads(p.read_text())['Id'];code=(b/'probe_namespace_closure.py').read_text()
shell='source /opt/ros/humble/setup.bash\nexport PYTHONPATH=/work/python\nsource /work/install/setup.bash\nexec /opt/project-a/bin/python3 - /work/install 1'
r=subprocess.run(['docker','--host=unix:///var/run/docker.sock','exec','-i','-e','PYTHONDONTWRITEBYTECODE=1',container,'bash','-c',shell],input=code,capture_output=True,text=True)
(b/'actual-sourcefree-namespace-closure.stdout').write_text(r.stdout);(b/'actual-sourcefree-namespace-closure.stderr').write_text(r.stderr)
assert r.returncode==0,(r.returncode,r.stderr)
value=json.loads(r.stdout);assert value['source_free'] and len(value['modules'])==12 and len(value['resources'])==21
(b/'actual-sourcefree-namespace-closure.json').write_text(json.dumps(value,indent=2));print(json.dumps(dict(status='PASS',container=container,implementation_modules=11,legacy_reader=1,resources=21)))
