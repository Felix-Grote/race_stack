from pathlib import Path
import hashlib,json,shutil,struct
b=Path('/workspace/forza-audit-records/final-runtime-b961d20');v=Path('/workspace/forza-audit-records/fresh-b961d20-complete/verification');root=v/'source-free/results'
assert (Path('/workspace/forza-audit-records/fresh-b961d20-complete')/'fresh-exit-code.txt').read_text().strip()=='0'
assert json.loads((b/'complete-audit.json').read_text())['status']=='PASS'
campaign=json.loads((root/'w3-scenario-campaign.json').read_text());assert len(campaign['outcomes'])==9
hosted={r['case']:r for r in json.loads(Path('/workspace/forza-audit-records/final-evidence-b961d20/controlled-hosted-catalog.json').read_text())};times={r['case']:r for r in json.loads((b/'trusted-frozen-main-times.json').read_text())}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=[];comparisons=[];archive=b/'fresh-sourcefree-products';archive.mkdir(exist_ok=True)
for case in campaign['outcomes']:
 name=case['case'];base=root/'w3-scenarios'/name
 compile_path=base/'compile.json';validate_path=base/'validate.json';compile_receipt=json.loads(compile_path.read_text());validate_receipt=json.loads(validate_path.read_text())
 p=Path(case['artifact_path']);assert p.parts[:2]==('/','results');p=root.joinpath(*p.parts[2:]);raw=p.read_bytes();envelope=json.loads(raw);payload=envelope['payload'];t=payload['validation']['dynamics']['lap_time_s'];t32=struct.unpack('!f',struct.pack('!f',t))[0]
 assert case['H']==compile_receipt['H']==validate_receipt['H']==envelope['H']
 assert case['curve_digest']==compile_receipt['geometry']['curve_digest']==compile_receipt['dynamics']['curve_digest']==validate_receipt['geometry']['curve_digest']==validate_receipt['dynamics']['curve_digest']==payload['approved_curve_digest']
 assert t==case['lap_time_s']==compile_receipt['dynamics']['lap_time_s']
 assert hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()==case['H']
 row=dict(case=name,H=case['H'],curve_digest=case['curve_digest'],relative_artifact=str(p.relative_to(root)),artifact_sha256=sha(p),bytes=len(raw),main_T=t,main_T_binary64_hex=t.hex(),legacy_main_float32=t32,compile_receipt=str(compile_path.relative_to(root)),compile_receipt_sha256=sha(compile_path),validate_receipt=str(validate_path.relative_to(root)),validate_receipt_sha256=sha(validate_path),authority_source='Actual final clean same-host b961 source-free compile/validate receipts and campaign; independent runtime audit PASS')
 for source in (p,compile_path,validate_path):
  destination=archive/source.relative_to(root);destination.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,destination);assert sha(destination)==sha(source)
 row['archived_root_relative']='fresh-sourcefree-products'
 rows.append(row)
 old=hosted[name];old_t=times[name]['main_T'];comparisons.append(dict(case=name,fresh_H=row['H'],hosted_H=old['H'],fresh_C=row['curve_digest'],hosted_C=old['curve_digest'],H_equal=row['H']==old['H'],C_equal=row['curve_digest']==old['curve_digest'],fresh_main_T=t,hosted_main_T=old_t,fresh_minus_hosted_T_s=t-old_t,absolute_T_delta_s=abs(t-old_t),relative_T_delta=abs(t-old_t)/old_t,fresh_float32_T=t32,hosted_float32_T=times[name]['legacy_main_float32'],fresh_artifact_sha256=row['artifact_sha256'],hosted_artifact_sha256=old['artifact_sha256']))
result=dict(status='INFORMATIONAL',source_commit='b961d20ce4a803e55336fb5590c30574e23b2fad',cases=9,max_absolute_T_delta_s=max(r['absolute_T_delta_s'] for r in comparisons),max_absolute_T_delta_case=max(comparisons,key=lambda r:r['absolute_T_delta_s'])['case'],max_relative_T_delta=max(r['relative_T_delta'] for r in comparisons),same_C_count=sum(r['C_equal'] for r in comparisons),same_H_count=sum(r['H_equal'] for r in comparisons),scope='Fresh compiler outputs are separate from unchanged hosted-artifact replay. Same candidate code/runtime identity does not require byte-identical optimizer output across hosts. Each artifact freezes its own producer main T. No additional QP or baseline run.',comparisons=comparisons)
shutil.copyfile(root/'w3-scenario-campaign.json',archive/'w3-scenario-campaign.json')
(b/'controlled-fresh-sourcefree-catalog.json').write_text(json.dumps(rows,indent=2));(b/'fresh-vs-hosted-products.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:value for k,value in result.items() if k!='comparisons'}))
