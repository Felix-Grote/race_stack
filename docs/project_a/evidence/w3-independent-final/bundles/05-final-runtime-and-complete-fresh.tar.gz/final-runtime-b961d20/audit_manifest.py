"""Compare the actual build manifest's authority with Git object contents."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

repository = Path(sys.argv[1])
manifest_path = Path(sys.argv[2])
destination = Path(sys.argv[3])
manifest = json.loads(manifest_path.read_text())
commit = 'b961d20ce4a803e55336fb5590c30574e23b2fad'
assert manifest['source_commit'] == commit
assert manifest['source_dirty'] is False
records = []
for name, expected in manifest['source_hashes'].items():
    prefixes = [prefix for prefix in manifest['gitlinks'] if name.startswith(prefix + '/')]
    if prefixes:
        prefix = max(prefixes, key=len)
        gitroot, revision, relative = repository / prefix, manifest['gitlinks'][prefix], name[len(prefix) + 1:]
    else:
        gitroot, revision, relative = repository, commit, name
    data = subprocess.check_output(['git', '-C', str(gitroot), 'show', revision + ':' + relative])
    observed = hashlib.sha256(data).hexdigest()
    assert observed == expected, (name, expected, observed)
    records.append({'path': name, 'sha256': observed, 'git_revision': revision})
for name, expected in manifest['installed_resource_hashes'].items():
    source = 'planner/global_planner/config/project_a/' + name
    data = subprocess.check_output(['git', '-C', str(repository), 'show', commit + ':' + source])
    assert hashlib.sha256(data).hexdigest() == expected
for name, expected in manifest['dependency_lock_hashes'].items():
    data = subprocess.check_output(['git', '-C', str(repository), 'show', commit + ':scripts/project_a/' + name])
    assert hashlib.sha256(data).hexdigest() == expected
result = {'status': 'PASS', 'source_commit': commit, 'source_dirty': False,
          'source_file_count': len(records), 'installed_resource_count': len(manifest['installed_resource_hashes']),
          'lock_count': len(manifest['dependency_lock_hashes']), 'files': records,
          'manifest_sha256': hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
          'scope': 'Manifest authority compared independently to Git objects; installed bytes need separate comparison.'}
destination.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key != 'files'}))
