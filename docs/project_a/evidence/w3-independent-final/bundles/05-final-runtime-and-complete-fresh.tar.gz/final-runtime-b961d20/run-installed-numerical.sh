#!/bin/bash
set -eo pipefail
source /opt/ros/humble/setup.bash
export PYTHONPATH=/records/fresh-b961d20/verification/python
source /records/fresh-b961d20/verification/install/setup.bash
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
cd /records/final-runtime-b961d20/numerical
/opt/project-a/bin/python3 ordinary_oracle.py > ordinary-oracle.log 2>&1
/opt/project-a/bin/python3 interior_profile_oracle.py > interior-profile-oracle.log 2>&1
/opt/project-a/bin/python3 public_query_boundaries.py --repo /records/final-checkout --output /records/final-runtime-b961d20/numerical/coefficient-publication --publish > public-query-boundaries.log 2>&1
/opt/project-a/bin/python3 public_interior_boundaries.py --repo /records/final-checkout --output /records/final-runtime-b961d20/numerical/interior-publication --publish > public-interior-boundaries.log 2>&1
