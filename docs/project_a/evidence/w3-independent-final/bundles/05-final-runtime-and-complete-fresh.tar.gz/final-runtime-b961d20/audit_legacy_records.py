"""Independent check of ten inherited failures, two skip identities and diagnostics."""
from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

baseline_path, actual_path, build, destination = map(Path, sys.argv[1:])
baseline = gzip.decompress(baseline_path.read_bytes()).decode()
actual = actual_path.read_text()
labels = lambda text: re.findall(r'^- ([^\n]+)\n  <<< failure message', text, re.MULTILINE)
before, after = labels(baseline), labels(actual)
assert len(before) == 10 and after == before
summary = re.findall(r'^Summary: (\d+) tests?, (\d+) errors?, (\d+) failures?, (\d+) skipped\s*$', actual, re.MULTILINE)
assert len(summary) == 1 and tuple(map(int, summary[0][1:])) == (0, 10, 2)
skips = []
for package in ('global_planner', 'frenet_conversion'):
    for case in ET.parse(build / package / 'pytest.xml').iter('testcase'):
        if (skipped := case.find('skipped')) is not None:
            skips.append({'identity': case.get('classname') + ' ' + case.get('name'), 'reason': skipped.get('message')})
assert sorted(item['identity'] for item in skips) == [
    'frenet_conversion.test.test_copyright test_copyright',
    'global_planner.test.test_copyright test_copyright']
assert all(item['reason'] == 'No copyright header has been placed in the generated source file.' for item in skips)
# Compare exact emitted Python style lines and multiplicities, including repeated
# aggregate report copies; separately retain their count instead of guessing1173.
diagnostics = lambda text: Counter(line.strip() for line in text.splitlines()
                                  if re.match(r'^\s*\./[^\n]+\.py:\d+', line))
old_diagnostics, new_diagnostics = diagnostics(baseline), diagnostics(actual)
assert old_diagnostics == new_diagnostics, {'new': list((new_diagnostics - old_diagnostics).elements()),
                                         'removed': list((old_diagnostics - new_diagnostics).elements())}
result = {'status': 'PASS', 'failure_identities': after, 'skips': skips, 'summary': summary,
          'exact_style_lines_including_repeats': sum(new_diagnostics.values()),
          'no_added_or_removed_style_diagnostics': True,
          'unique_style_diagnostics': len(new_diagnostics),
          'exact_style_diagnostic_counter': dict(sorted(new_diagnostics.items())),
          'baseline_sha256': hashlib.sha256(baseline_path.read_bytes()).hexdigest(),
          'actual_sha256': hashlib.sha256(actual_path.read_bytes()).hexdigest()}
destination.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
