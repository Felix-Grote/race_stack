# Final runtime audit — b961d20

Candidate: `b961d20ce4a803e55336fb5590c30574e23b2fad`.

**Runtime scope PASS.** The new complete clean run exited 0; all 612 functional checks in 27 groups passed with zero functional errors, failures or skips. This is a runtime evidence audit, not an overall W3 acceptance verdict.

## Actual source-free gate

All five source-free tests passed. Its nine-scenario campaign passed 1,488 public API queries and all 36 scenario command receipts. `complete-audit.json` and `sourcefree-record-audit.json` bind completion to the actual final run; `complete-sourcefree-tests.xml` preserves the native report.

`actual-sourcefree-inspect.json` and `live-sourcefree-controls-audit.json` capture the running container `1ae75d577c33fb90a0af6ebc9bdcae2147346b25192411f6cd21d63f80a5d577`. The verified controls are UID 1000, read-only root, network none, private IPC, all capabilities dropped, no-new-privileges, PID limit 256, 4 GiB memory, two CPUs, and a 256 MiB tmpfs with nosuid/nodev. Exactly four bind mounts match the final verification paths: installed packages, installed dependency Python and test harness read-only; results writable. No source or build tree is mounted.

`actual-sourcefree-namespace-closure.json` independently verifies all 11 implementation modules plus the actual legacy reader (12 imported files), every file non-symlink and resolved under `/work/install`, and all 21 actual installed resource hashes. Repository, source, build, optimizer and `/records` paths are absent. The suite also recorded zero effective capabilities, no-new-privileges and loopback as the only interface.

## Intended rejection controls and legacy baseline

`complete-15-controls.json` and `sourcefree-15-controls.json` independently audit all 15 rejection reasons in each environment: 30 negative-control instances, within 21 ordinary and 21 source-free CLI receipts. Each mutation is an actual `reference.json`, with the intended stage/layout; accepted authority bytes remain unchanged. No OS path error is accepted as the intended rejection.

`complete-legacy.json` confirms the exact ten baseline failure identities and exact two copyright skip identities/reasons: 597 legacy checks, zero errors, ten inherited failures and two skips. The full diagnostic Counter is identical to baseline: 1,173 distinct emitted diagnostic lines, each with multiplicity one. The raw Counter is retained in that JSON.

## Unchanged authenticated hosted replay

`hosted-replay-audit.json` records all nine unchanged authenticated original final hosted products passing nine genuine geometry and nine genuine dynamics validator calls, under actual ordinary installed b961 modules. Trusted H/C came from the final artifact auditor’s authenticated original-push compile/validate/campaign catalog. Incoming SHA256 and unchanged bytes were checked explicitly.

This replay ran in the existing forensic container and is **source-visible**. It is distinct from the actual source-free gate above. The container was restarted after the daemon interruption; this audit created no containers or images. Installed module paths and bytes, including the shared geometry module and actual reader, were checked in `ordinary-installed-namespace-closure.json`. All 21 installed resources matched their Git-bound hashes.

The unchanged hosted replay passed 7,722 boundary, adjacent-float, negative and multiple-lap station/ownership queries, plus 7,722 supplied-occurrence queries. Every case used the actual nine-group legacy reader and actual ROS CDR serialization/deserialization. Producer main T remained exact in binary64 and in the legacy Float32 value. `trusted-frozen-main-times.json` retains independent original compile receipt hashes, exact binary64 hex and Float32 values. Actual terminal stations also matched.

`cross-implementation-negatives.json` maps earlier 17e4ec4 and authenticated hosted 67fbcc artifacts to literal Git module hashes. Both were rejected as UNSUPPORTED before validator execution. No identity bypass occurred.

## Fresh same-host products and hosted distinction

`controlled-fresh-sourcefree-catalog.json` freezes the nine newly compiled same-host source-free products as separate controlled references, with H/C, artifact SHA256, compile/validate receipt hashes, and exact producer binary64/Float32 T. Copies of the actual unchanged fresh artifact bytes and raw producer receipts are preserved under `fresh-sourcefree-products/`.

All nine fresh H/C pairs differ from the original hosted pairs despite matching candidate implementation identity. These are new optimizer outputs, not the unchanged hosted replay inputs. The maximum absolute producer T delta is **2.1296958330196958e-06 s** (s4_repeated_route); the maximum relative delta is **8.9972514302480261e-08**. Each artifact freezes its own producer T. `fresh-vs-hosted-products.json` retains the full H/C and exact T/Float32 comparison.

| Case | Hosted producer T (s) | Fresh producer T (s) | Fresh minus hosted (s) |
| --- | ---: | ---: | ---: |
| s0_route | 11.456316732461396 | 11.456316732459191 | -2.20445884e-12 |
| s0_reverse_route | 11.45631673245572 | 11.456316732478291 | 2.257039e-11 |
| s0_rotated_route | 11.45631673246738 | 11.456316732467387 | 7.10542736e-15 |
| s2_upper_route | 11.072362772989473 | 11.072362619256827 | -1.53732646e-07 |
| s2_lower_route | 10.36834011777969 | 10.368340117778848 | -8.41993142e-13 |
| s3_surfaces_route | 17.564217325770205 | 17.56421732578578 | 1.55750968e-11 |
| s3_notch_route | 17.564177176522971 | 17.564177176515784 | -7.18713977e-12 |
| s4_repeated_route | 23.67051592956302 | 23.670513799867187 | -2.12969583e-06 |
| s6_competition_route | 68.009787875961464 | 68.00978787594029 | -2.11741735e-11 |

## Source and hash closure

`source-hash-ledger.json` preserves exact before/after snapshots and frozen raw exit/XML/identity metadata. Both source snapshots are byte-identical; all 138 hashes independently equal literal candidate/recursive Gitlink objects. The build authority covers 138 source files, 21 resources, two locks and seven Gitlinks. `complete-manifest-vs-git.json` and `complete-installed-resources.json` retain the separate manifest and actual installed-byte checks.

The earlier `/workspace/forza-audit-records/fresh-b961d20` run remains preserved as incomplete in its source-free stage; no completion was inferred from it.

## Stopped redundant numerical work

The parent requested cancellation of the additional numerical matrix. Three completed ordinary oracle cases (1,008 queries) were preserved in `numerical/ordinary-oracle-started-partial.json`; that matrix is explicitly interrupted and supplies no completion claim. None of the queued interior/public oracle commands started. Existing exact-byte 4,442-query / 496-endpoint evidence mapped to b961 remains the earlier numerical authority. No additional QP or baseline run was performed.
