import sys,json,gzip,math,platform,bisect
from pathlib import Path
sys.path.insert(0,'/records/resume-numerical/vendor')
import mpmath as mp
from global_planner.route_input import load_route
from global_planner.route_reference import Curve
from global_planner.route_corridor import OrderedCurve,_layout
from global_planner.cyclic_retime import *
from global_planner.route_validate import Footprint,GeometryValidationPolicy,validate_geometry
from global_planner.route_validate_dynamics import DynamicsValidationPolicy,validate_dynamics
from global_planner.route_artifact import _reference,PolicySet
from global_planner.iqp_route_adapter import SolverPolicy
ROOT=Path('/records/final-checkout'); OUT=Path('/records/final-runtime-b961d20/numerical')
mp.mp.dps=65
fixtures=json.loads(gzip.decompress((ROOT/'planner/global_planner/test/fixtures/project_a/w2_a04_candidates.json.gz').read_bytes()))['candidates']
results=[]
for name in ['s0_route','s0_reverse_route','s0_rotated_route','s3_surfaces_route']:
    f=fixtures[name]; route=load_route(ROOT/('planner/global_planner/test/fixtures/project_a/'+name+'.json'))
    ends=_layout(route)
    q=tuple(f['q'])  # Exact original archived q: no host-runtime rebase
    ordered=OrderedCurve(route,Curve(f['coefficients'],f['owners']),q)
    limits=RegionLimits(.05,3.,2.,3.,4.,2.5,0.,'Explicit synthetic ordinary oracle model')
    model=DynamicsModel(tuple(ModelRegion(o.id,o.surface_id,limits) for o in route.occurrences),'Synthetic independent ordinary query model')
    knots=tuple(SpeedKnot(i,0.,1.+.2*math.cos(2*math.pi*ordered.curve.cumulative[i]/ordered.curve.length)) for i in range(len(ordered.curve.segments)))
    profile=SpeedProfile(knots,curve_digest(ordered),model_digest(model),math.fsum(2*s.length/(math.sqrt(knots[i].u)+math.sqrt(knots[(i+1)%len(knots)].u)) for i,s in enumerate(ordered.curve.segments)))
    fp=Footprint(.1,.1,.12,.01); gp,dp=GeometryValidationPolicy(),DynamicsValidationPolicy()
    geom=validate_geometry(ordered,route,fp,gp,expected_curve_digest=curve_digest(ordered))
    dyn=validate_dynamics(ordered,profile,model,dp,expected_curve_digest=curve_digest(ordered))
    assert geom.status=='PASS' and dyn.status=='PASS',(name,geom.reason,dyn.reason)
    ref=_reference('f'*64,None,ordered,profile,model,fp,PolicySet(ordered.curve.policy,SolverPolicy(),RetimePolicy(),gp,dp),geom,dyn,{'validation':{'dynamics':{'lap_time_s':dyn.lap_time_s}}})
    allcoef=[[[mp.mpf(x) for x in axis] for axis in seg.coefficients] for seg in ordered.curve.segments]
    def deriv(i,t,order):
        return tuple(sum(axis[k]*math.factorial(k)/math.factorial(k-order)*t**(k-order) for k in range(order,4)) for axis in allcoef[i])
    def speed(i,t): return mp.sqrt(sum(v*v for v in deriv(i,t,1)))
    def arc(i,a,b): return mp.quad(lambda t:speed(i,t),[a,b])
    truelengths=[arc(i,0,1) for i in range(len(allcoef))]
    truecum=[mp.mpf(0)]
    for x in truelengths: truecum.append(truecum[-1]+x)
    edges=[]; times=[mp.mpf(0)]
    for i,k in enumerate(profile.knots):
        following=profile.knots[(i+1)%len(profile.knots)]
        finish=following.t if following.segment==k.segment and i+1<len(profile.knots) else 1.
        length=arc(k.segment,mp.mpf(k.t),mp.mpf(finish)); edges.append(length)
        times.append(times[-1]+2*length/(mp.sqrt(k.u)+mp.sqrt(following.u)))
    queries={0.,-.01,ref.length,2*ref.length,-ref.length,-math.ulp(0.)}
    boundaries=set(ref._stations)|set(ordered.curve.cumulative)
    for x in boundaries:
        queries.update([x,math.nextafter(x,-math.inf),math.nextafter(x,math.inf)])
    queries.update(i*ref.length/37 for i in range(37))
    maxima={key:0. for key in ['station_error_m','speed_error_mps','acceleration_error_mps2','elapsed_error_s','curvature_error_per_m','unit_tangent_error']}
    wrong=[]
    for s in sorted(queries):
        row=ref.sample(s)
        expected_segment=min(bisect.bisect_right(ordered.curve.cumulative,row.s)-1,len(allcoef)-1)
        if row.segment!=expected_segment or (row.occurrence_id,row.surface_id)!=ordered.curve.owners[expected_segment]: wrong.append([s,'owner'])
        i=row.segment;t=mp.mpf(row.t)
        true_station=truecum[i]+arc(i,0,t)
        # W1 permits bounded endpoint t rounding, compare actual stored-coefficient arc.
        maxima['station_error_m']=max(maxima['station_error_m'],float(abs(true_station-mp.mpf(row.s))))
        kindex=bisect.bisect_right(ref._stations,row.s)-1;k=profile.knots[kindex];following=profile.knots[(kindex+1)%len(profile.knots)]
        partial=arc(i,mp.mpf(k.t),t)
        ratio=partial/edges[kindex]
        trueu=(1-ratio)*mp.mpf(k.u)+ratio*mp.mpf(following.u)
        truev=mp.sqrt(trueu)
        truea=(mp.mpf(following.u)-mp.mpf(k.u))/(2*edges[kindex])
        truetime=times[kindex]+2*partial/(mp.sqrt(k.u)+truev)
        d,dd=deriv(i,t,1),deriv(i,t,2);v=speed(i,t)
        curvature=(d[0]*dd[1]-d[1]*dd[0])/v**3
        maxima['speed_error_mps']=max(maxima['speed_error_mps'],float(abs(truev-row.speed_mps)))
        maxima['acceleration_error_mps2']=max(maxima['acceleration_error_mps2'],float(abs(truea-row.acceleration_mps2)))
        maxima['elapsed_error_s']=max(maxima['elapsed_error_s'],float(abs(truetime-row.time_s)))
        maxima['curvature_error_per_m']=max(maxima['curvature_error_per_m'],float(abs(curvature-row.curvature)))
        maxima['unit_tangent_error']=max(maxima['unit_tangent_error'],float(mp.sqrt(sum((d[j]/v-mp.mpf(row.tangent[j]))**2 for j in [0,1]))))
    result=dict(name=name,runtime=platform.python_version(),queries=len(queries),geometry=geom.status,dynamics=dyn.status,ownership_failures=wrong,maxima=maxima,independent_true_lap_time=str(times[-1]),reported_time=dyn.lap_time_s,time_enclosure=[dyn.lap_time_lower_s,dyn.lap_time_upper_s],oracle_time_inside_enclosure=mp.mpf(dyn.lap_time_lower_s)<=times[-1]<=mp.mpf(dyn.lap_time_upper_s),arc_length_error_m=float(abs(truecum[-1]-ordered.curve.length)))
    assert not wrong, wrong
    assert maxima['station_error_m'] <= ordered.curve.policy.station_abs, maxima
    assert maxima['speed_error_mps'] <= 1e-9, maxima
    assert maxima['acceleration_error_mps2'] <= 1e-12, maxima
    assert maxima['elapsed_error_s'] <= 1e-8, maxima
    assert maxima['curvature_error_per_m'] <= 1e-12, maxima
    assert maxima['unit_tangent_error'] <= 1e-12, maxima
    assert result['oracle_time_inside_enclosure'], result
    results.append(result);print(json.dumps(result),flush=True)
(OUT/'ordinary-oracle.json').write_text(json.dumps(results,indent=2))
