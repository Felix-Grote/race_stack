from pathlib import Path
import hashlib,json,subprocess,time,xml.etree.ElementTree as ET
b=Path('/workspace/forza-audit-records/final-runtime-b961d20');fresh=Path('/workspace/forza-audit-records/fresh-b961d20-complete');v=fresh/'verification'
for attempt in range(1800):
 if (fresh/'fresh-exit-code.txt').exists():break
 time.sleep(5)
else:raise RuntimeError('Complete fresh run did not finish')
assert (fresh/'fresh-exit-code.txt').read_text().strip()=='0'
assert (v/'source-free/exit-code.txt').read_text().strip()=='0'
assert (b/'actual-sourcefree-imports.json').exists()
assert (b/'actual-sourcefree-namespace-closure.json').exists()
assert (v/'exit-code.txt').read_text().strip()=='0'
assert (v/'source-hashes-before.json').read_bytes()==(v/'source-hashes-after.json').read_bytes()
commands=[['audit_manifest.py',str(fresh/'checkout'),str(v/'build-identity.json'),str(b/'complete-manifest-vs-git.json')],['audit_recorded_controls.py',str(v),str(b/'complete-15-controls.json')],['audit_legacy_records.py',str(fresh/'checkout/docs/project_a/evidence/w2-baseline/legacy-results.txt.gz'),str(v/'legacy-results.txt'),str(v/'build'),str(b/'complete-legacy.json')],['audit_sourcefree_records.py',str(v),str(b)]]
for args in commands:subprocess.run(['python3',str(b/args[0]),*args[1:]],check=True)
summary=json.loads((v/'summary.json').read_text());groups={k:d for k,d in summary.items() if isinstance(d,dict) and 'tests'in d}
assert len(groups)==27 and sum(int(d['tests']) for d in groups.values())==612
for name,d in groups.items():
 report=v/'source-free/results/w3-source-free.xml' if name=='w3-source-free' else v/(name+'.xml')
 suites=list(ET.parse(report).getroot().iter('testsuite'))
 for key in ['tests','failures','errors','skipped']:assert sum(int(s.get(key,0)) for s in suites)==int(d[key])
 assert all(d[key]=='0' for key in ['failures','errors','skipped'])
probe=json.loads((b/'actual-sourcefree-imports.json').read_text());assert probe['source_free'] and len(probe['modules'])==11
namespace=json.loads((b/'actual-sourcefree-namespace-closure.json').read_text());assert namespace['source_free'] and len(namespace['modules'])==12 and len(namespace['resources'])==21
assert namespace['implementation_module_count']==11
assert namespace['manifest_sha256']==hashlib.sha256((v/'build-identity.json').read_bytes()).hexdigest()
manifest=json.loads((v/'build-identity.json').read_text());prefix=v/'install/global_planner/share/global_planner/project_a';resources=[]
for name,expected in manifest['installed_resource_hashes'].items():
 p=prefix/name;assert p.is_file() and not p.is_symlink();assert hashlib.sha256(p.read_bytes()).hexdigest()==expected;resources.append(dict(path=str(p),sha256=expected,not_symlink=True))
(b/'complete-installed-resources.json').write_text(json.dumps(resources,indent=2))
assert subprocess.check_output(['git','-C',str(fresh/'checkout'),'status','--porcelain','--untracked-files=all'],text=True)==''
result=dict(status='PASS',source_commit='b961d20ce4a803e55336fb5590c30574e23b2fad',fresh_exit=0,source_free_exit=0,functional_tests=612,functional_groups=27,all_functional_failure_error_skip_counts=0,independent_actual_sourcefree_origins=12,implementation_module_origins=11,legacy_reader_origins=1,installed_resources=21,ordinary_negative_controls=15,legacy_failure_identity_count=10,legacy_skip_identity_count=2,exact_legacy_diagnostic_line_multiplicity=1173,previous_fresh_b961d20='Preserved incomplete source-free run; no completion inferred',scope='Independent runtime evidence audit only; no overall W3 acceptance verdict')
(b/'complete-audit.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
