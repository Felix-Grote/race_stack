#!/bin/bash
set -eo pipefail
source /opt/ros/humble/setup.bash
mkdir -p /work/retry-src
cp -a /frozen/planner/global_planner /work/retry-src/
cp -a /frozen/utilities/libraries/f110_msgs /frozen/utilities/libraries/frenet_conversion /work/retry-src/
python /frozen/scripts/project_a/source_manifest.py --repository /frozen --build-identity /work/retry-src/global_planner/config/project_a/build_identity.json
python /usr/bin/colcon --log-base /work/retry-log build --base-paths /work/retry-src --build-base /work/retry-build --install-base /work/retry-install --packages-select f110_msgs frenet_conversion global_planner --parallel-workers 2
(cd /work/retry-src/global_planner/global_planner/global_racetrajectory_optimization && python setup.py bdist_wheel --dist-dir /work/retry-wheels) > /work/retry-optimizer-wheel.log 2>&1
python -m pip install --no-index --no-deps --target /work/retry-python /work/retry-wheels/*.whl
