"""Independently bind final source-free receipts, unchanged products and runtime records."""
from pathlib import Path
import hashlib,json,struct,sys,xml.etree.ElementTree as ET
verification, review=map(Path,sys.argv[1:])
root=verification/'source-free/results';commit='b961d20ce4a803e55336fb5590c30574e23b2fad'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
canon=lambda v:json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
assert (verification/'source-free/exit-code.txt').read_text().strip()=='0'
inspect=json.loads((review/'actual-sourcefree-inspect.json').read_text())
assert inspect['Image']==(verification/'image-id.txt').read_text().strip()
launch=json.loads((verification/'source-free/launch.json').read_text())
assert launch['expected_commit']==commit and launch['image_id']==inspect['Image'] and launch['source_or_build_mounts']==[]
identity=json.loads((root/'runtime-identity.json').read_text());manifest=json.loads((root/'build-identity.json').read_text())
assert identity['source_commit']==manifest['source_commit']==commit
assert identity['source_dirty'] is manifest['source_dirty'] is False
assert identity['uid']==1000 and int(identity['cap_eff'],16)==0 and identity['no_new_privileges']=='1'
assert identity['interfaces']==[[1,'lo']]
assert len(identity['modules'])==10
for module,row in identity['modules'].items():
    assert row['path'].startswith('/work/install/')
    assert row['sha256']==manifest['source_hashes']['planner/global_planner/global_planner/'+Path(row['path']).name]
assert identity['installed_resource_hashes']==manifest['installed_resource_hashes']
assert len(identity['installed_resource_hashes'])==21
suites=list(ET.parse(root/'w3-source-free.xml').getroot().iter('testsuite'))
assert sum(int(s.get('tests',0)) for s in suites)==5
assert all(int(s.get(k,0))==0 for s in suites for k in ['errors','failures','skipped'])
campaign=json.loads((root/'w3-scenario-campaign.json').read_text());assert campaign['source_commit']==commit
expected={'s0_route','s0_reverse_route','s0_rotated_route','s2_upper_route','s2_lower_route','s3_surfaces_route','s3_notch_route','s4_repeated_route','s6_competition_route'}
assert {v['case'] for v in campaign['outcomes']}==expected and len(campaign['outcomes'])==9

def local(name):
    p=Path(name);assert p.parts[:2]==('/','results'),str(p)
    return root.joinpath(*p.parts[2:])
rows=[]
for case in campaign['outcomes']:
    assert case['status']==case['geometry']==case['dynamics']=='PASS'
    p=local(case['artifact_path']);assert p.is_file() and p.name=='reference.json' and p.parent.name==case['H']
    envelope=json.loads(p.read_bytes());payload=envelope['payload']
    assert envelope['H']==case['H']==hashlib.sha256(canon(payload)).hexdigest()
    assert payload['approved_curve_digest']==case['curve_digest']
    assert len(case['commands'])==4
    for command in case['commands']:
        assert command['returncode']==0 and command['status']=='PASS'
        value=json.loads(local(command['stdout']).read_text());assert value['status']=='PASS'
        if command['report']:assert json.loads(local(command['report']).read_text())==value
        if '--expected-h' in command['command']:
            assert command['command'][command['command'].index('--expected-h')+1]==case['H']
        if command['command'][1] in ('compile','validate'):
            for proof in ('geometry','dynamics'):
                assert value[proof]['status']=='PASS' and value[proof]['curve_digest']==case['curve_digest']
    folder=root/'w3-scenarios'/case['case']
    producer=payload['validation']['dynamics']['lap_time_s']
    exported=json.loads((folder/'export.json').read_text());api=json.loads((folder/'public-api.stdout.txt').read_text());legacy=json.loads((folder/'legacy/global_waypoints.json').read_text())
    assert exported['lap_time_s']==api['lap_time_s']==case['lap_time_s']==producer
    expected32=struct.unpack('!f',struct.pack('!f',producer))[0]
    assert exported['legacy_lap_time_float32_s']==legacy['est_lap_time']['data']==expected32
    assert exported['reason']=='Existing nine-group reader and ROS CDR roundtrip passed'
    assert list(legacy)==['map_info_str','est_lap_time','centerline_markers','centerline_waypoints','global_traj_markers_iqp','global_traj_wpnts_iqp','global_traj_markers_sp','global_traj_wpnts_sp','trackbounds_markers']
    assert legacy['global_traj_wpnts_iqp']['wpnts'][-1]['s_m']==case['length_m']
    assert api['status']=='PASS' and api['H']==case['H'] and api['samples']==case['query_count']
    assert api['owner_samples']==case['owner_samples']
    for owner,sample in api['owner_samples'].items():
        assert sample['occurrence_id']==owner and sample['H']==case['H'] and sample['speed_mps']>0
    rows.append(dict(case=case['case'],H=case['H'],C=case['curve_digest'],status='PASS',artifact_sha256=sha(p),queries=api['samples'],main_T=producer,legacy_float32_T=expected32,actual_reader_CDR_receipt=True))
result=dict(status='PASS',source_commit=commit,source_free=True,actual_inspect_id=inspect['Id'],image_id=inspect['Image'],runtime_module_count=10,resource_count=21,scenario_count=len(rows),query_count=sum(r['queries'] for r in rows),command_count=36,scenarios=rows,scope='Independent audit of final actual source-free records; real runtime probes and separate matching-version replay are retained separately; no overall W3 verdict.')
(review/'sourcefree-record-audit.json').write_text(json.dumps(result,indent=2))
print(json.dumps({k:v for k,v in result.items() if k!='scenarios'}))
