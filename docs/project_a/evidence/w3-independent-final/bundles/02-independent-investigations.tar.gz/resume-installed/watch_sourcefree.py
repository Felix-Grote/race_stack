"""Capture the actual final fresh source-free namespace; read-only Docker operations."""
from pathlib import Path
import subprocess,json,time
base=Path('/workspace/forza-audit-records/resume-installed')
commit='b961d20ce4a803e55336fb5590c30574e23b2fad'
docker=['docker','--host=unix:///var/run/docker.sock']
for attempt in range(2160):
    ids=subprocess.check_output(docker+['ps','-q'],text=True).split()
    if ids:
        records=json.loads(subprocess.check_output(docker+['inspect',*ids],text=True))
        for row in records:
            mounts=row['Mounts']
            matching=any(m['Destination']=='/runtime-harness' and '/fresh-b961d20/' in m['Source'] for m in mounts)
            if not matching: continue
            config=row['Config'];host=row['HostConfig']
            result={'Id':row['Id'],'Image':row['Image'],'State':row['State'],'Mounts':mounts,'Config':{k:config[k] for k in ['User','WorkingDir','Entrypoint','Cmd']},'ExpectedEnvironment':[x for x in config.get('Env',[]) if x.startswith(('PROJECT_A_','PYTHONDONTWRITEBYTECODE=','OPENBLAS_NUM_THREADS=','OMP_NUM_THREADS='))],'HostConfig':{k:host[k] for k in ['ReadonlyRootfs','NetworkMode','IpcMode','CapDrop','SecurityOpt','PidsLimit','Memory','NanoCpus','Tmpfs']},'NetworkSettings':row['NetworkSettings']['Networks'],'scope':'Actual independent docker inspect of running final fresh source-free container; no source/build mounted.'}
            assert row['State']['Running']
            assert result['Config']['User']=='1000:1000'
            assert result['Config']['WorkingDir']=='/results'
            assert host['ReadonlyRootfs'] and host['NetworkMode']=='none'
            assert host['CapDrop']==['ALL'] and 'no-new-privileges' in host['SecurityOpt']
            assert host['Memory']==4*1024**3 and host['NanoCpus']==2*10**9
            assert {m['Destination'] for m in mounts}=={'/work/install','/work/python','/runtime-harness','/results'}
            assert all(not m['RW'] for m in mounts if m['Destination']!='/results')
            assert next(m for m in mounts if m['Destination']=='/results')['RW']
            assert 'PROJECT_A_EXPECTED_COMMIT='+commit in result['ExpectedEnvironment']
            assert 'PROJECT_A_EXPECTED_CLEAN=1' in result['ExpectedEnvironment']
            (base/'actual-sourcefree-inspect.json').write_text(json.dumps(result,indent=2))
            print(json.dumps({'status':'PASS','actual_running_sourcefree_id':row['Id'],'mount_count':len(mounts),'source_commit':commit}),flush=True)
            code='''import sys,json,os,hashlib; from pathlib import Path; import global_planner.route_artifact as a; import global_planner.route_compile as c; import global_planner.route_legacy_export as e; from ament_index_python.packages import get_package_share_directory; modules=[a,c,e]; manifest=json.loads((Path(get_package_share_directory('global_planner'))/'project_a/build_identity.json').read_text()); rows=[]
for m in modules:
 p=Path(m.__file__); assert p.is_file() and not p.is_symlink() and str(p.resolve()).startswith('/work/install/'); rows.append({'module':m.__name__,'origin':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'not_symlink':True})
assert manifest['source_commit']=='b961d20ce4a803e55336fb5590c30574e23b2fad' and manifest['source_dirty'] is False
absent=['/workspace','/src','/frozen','/work/src','/work/build','/work/optimizer']; assert not any(Path(p).exists() for p in absent)
assert not any(p.startswith(('/src','/frozen','/workspace','/work/src','/work/build')) for p in sys.path)
assert os.getuid()==1000
print(json.dumps({'status':'PASS','source_free':True,'source_commit':manifest['source_commit'],'modules':rows,'sys_path':sys.path,'absent_source_build_paths':absent,'uid':os.getuid()}))'''
            shell='source /opt/ros/humble/setup.bash\nexport PYTHONPATH=/work/python\nsource /work/install/setup.bash\nexec /opt/project-a/bin/python3 -c '+__import__('shlex').quote(code)
            probe=subprocess.run(docker+['exec','-e','PYTHONDONTWRITEBYTECODE=1',row['Id'],'/bin/bash','-c',shell],text=True,capture_output=True)
            (base/'actual-sourcefree-imports.stdout').write_text(probe.stdout);(base/'actual-sourcefree-imports.stderr').write_text(probe.stderr)
            assert probe.returncode==0,(probe.returncode,probe.stderr)
            value=json.loads(probe.stdout);(base/'actual-sourcefree-imports.json').write_text(json.dumps(value,indent=2))
            print(json.dumps({'actual_import_probe':'PASS','modules':len(value['modules'])}),flush=True)
            raise SystemExit(0)
    time.sleep(5)
raise RuntimeError('Final source-free runtime not observed within three hours')
