#!/bin/bash
set -eo pipefail
source /opt/ros/humble/setup.bash
export PYTHONPATH=/records/fresh-b961d20/verification/python
source /records/fresh-b961d20/verification/install/setup.bash
export REPLAY_ROOT=/records/final-evidence-b961d20
export REPLAY_CATALOG_PATH=/records/final-evidence-b961d20/controlled-hosted-catalog.json
export REPLAY_INCOMING_ROOT=/records/final-evidence-b961d20/hosted-inputs
export REPLAY_OUTPUT=/records/resume-installed/hosted-replay
export REPLAY_POLICY_ROOT=/records/fresh-b961d20/verification/install/global_planner/share/global_planner/project_a/policies
export EXPECTED_INSTALL_PREFIX=/records/fresh-b961d20/verification/install
export REPLAY_EXPORT_ROS=1
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
mkdir -p "$REPLAY_OUTPUT"
exec /opt/project-a/bin/python3 /records/resume-installed/verify_saved_final.py
