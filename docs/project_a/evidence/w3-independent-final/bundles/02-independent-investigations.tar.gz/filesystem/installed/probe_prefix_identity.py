"""Additional independent installation identity checks against the Git-backed manifest."""
import hashlib
import importlib.metadata
import json
from pathlib import Path
import sys
from ament_index_python.packages import get_package_prefix, get_package_share_directory

root = Path(__file__).parent
share = Path(get_package_share_directory('global_planner')) / 'project_a'
actual = share / 'build_identity.json'
expected = json.loads((root / 'staged-manifest-vs-git.json').read_text())
assert hashlib.sha256(actual.read_bytes()).hexdigest() == expected['manifest_sha256']
entries = {entry.name: entry.value for entry in importlib.metadata.distribution('global_planner').entry_points}
assert entries == {'global_planner': 'global_planner.global_planner_node:main',
                   'mapping_node': 'global_planner.mapping_node:main',
                   'global_trajectory_publisher': 'global_planner.global_trajectory_publisher:main',
                   'compile_route': 'global_planner.route_compile:main'}
executable = Path(get_package_prefix('global_planner')) / 'lib/global_planner/compile_route'
assert executable.is_file() and not executable.is_symlink()
assert str(executable.resolve()).startswith('/work/retry-install/')
assert not any(item.startswith('/src') or item.startswith('/frozen') for item in sys.path)
result = {'status': 'PASS', 'source_free': False, 'source_visible': True,
          'entry_points': entries, 'executable': str(executable),
          'installed_manifest_matches_Git_verified_manifest': expected['manifest_sha256'],
          'sys_path_has_no_source_checkout': True}
(root / 'prefix-identity.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
