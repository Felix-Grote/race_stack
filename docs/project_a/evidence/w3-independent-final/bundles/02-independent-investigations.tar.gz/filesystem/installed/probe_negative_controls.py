"""Independently run all 15 installed content/trust controls; source is visible."""
import copy
import hashlib
import json
from pathlib import Path
import subprocess

from ament_index_python.packages import get_package_prefix, get_package_share_directory
from global_planner import route_artifact as a

ROOT = Path(__file__).parent
output = ROOT / 'negative-controls'
output.mkdir()
identity = json.loads((ROOT.parent / 'real_authority_identity.json').read_text())
trusted_h = identity['H']
artifact = ROOT / 'authority' / trusted_h / 'reference.json'
original_bytes = artifact.read_bytes()
envelope = json.loads(original_bytes)
assert envelope['H'] == trusted_h == a.artifact_identity(envelope['payload'])
share = Path(get_package_share_directory('global_planner')) / 'project_a'
policy = share / 'policies/synthetic_policy.json'
command = Path(get_package_prefix('global_planner')) / 'lib/global_planner/compile_route'
assert str(command).startswith('/work/retry-install/')
assert str(Path(a.__file__).resolve()).startswith('/work/retry-install/')
results = []


def reject(label, path, reason, expected=trusted_h, selected=policy, query=False):
    arguments = [str(command), 'query' if query else 'validate', '--artifact', str(path),
                 '--expected-h', expected, '--policy', str(selected)]
    report = output / (label + '.json')
    if query:
        arguments += ['--s-m', '.5', '--occurrence-id', 'unapproved-occurrence']
    else:
        arguments += ['--report', str(report)]
    completed = subprocess.run(arguments, capture_output=True, text=True, timeout=240)
    (output / (label + '.stdout')).write_text(completed.stdout)
    (output / (label + '.stderr')).write_text(completed.stderr)
    value = json.loads(completed.stdout if query else report.read_text())
    assert value['schema_version'] == 1 and value['status'] != 'PASS'
    assert completed.returncode != 0 and not value.get('artifact_path')
    assert reason in value['reason'] and 'Not a directory' not in value['reason'], value
    results.append({'case': label, 'status': 'PASS', 'command': arguments,
                    'returncode': completed.returncode, 'actual_status': value['status'],
                    'reason': value['reason'], 'expected_reason_substring': reason,
                    'artifact_sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
    print('PASS actual-installed-control/' + label + ': ' + value['reason'], flush=True)


def write_case(label, data):
    folder = output / label
    folder.mkdir()
    path = folder / 'reference.json'
    path.write_bytes(data)
    assert list(folder.iterdir()) == [path]
    return path


wrong = ('1' if trusted_h[0] == '0' else '0') + trusted_h[1:]
reject('wrong-expected-h', artifact, 'H mismatch', wrong)
for label in ('approval', 'model', 'policy', 'coefficient', 'implementation'):
    changed = copy.deepcopy(envelope)
    payload = changed['payload']
    if label == 'approval':
        payload['approved_curve_digest'] = '0' * 64
        payload['speed_profile']['curve_digest'] = '0' * 64
        for kind in ('geometry', 'dynamics'):
            payload['validation'][kind]['curve_digest'] = '0' * 64
    elif label == 'model':
        payload['model']['regions'][0]['limits']['speed_max_mps'] = 3.25
    elif label == 'policy':
        payload['policies']['numeric']['arc_abs'] = 2e-10
        for kind in ('geometry', 'dynamics'):
            payload['policies'][kind]['numeric_policy']['arc_abs'] = 2e-10
    elif label == 'coefficient':
        payload['curve']['coefficients'][0][0][0] = 1.25
    else:
        payload['implementation']['contract_id'] = 'unsupported.v99'
    changed['H'] = a.artifact_identity(payload)
    assert changed['H'] != trusted_h
    path = write_case('mutated-' + label, a.canonical_bytes(changed))
    reject(label + '-old-h', path, 'H mismatch')
    reasons = {'approval': 'geometry replay FAIL', 'model': 'dynamics replay FAIL',
               'policy': 'independent acceptance policy',
               'implementation': 'changed kernel/checker/dependency identity'}
    if label in reasons:
        reject(label + '-new-h', path, reasons[label], changed['H'])
reject('incomplete-stage', write_case('.tmp-incomplete', original_bytes[:200]), 'private staging')
reject('truncated-content', write_case('truncated', original_bytes[:200]), 'invalid bounded UTF-8 JSON')
reject('corrupt-bytes', write_case('corrupt', original_bytes + b'\x00'), 'invalid bounded UTF-8 JSON')
unsupported = json.loads(policy.read_text())
unsupported['required_geometry_coverage'] = ['three_dimensional_clearance']
unsupported_path = output / 'unsupported-policy.json'
unsupported_path.write_bytes(a.canonical_bytes(unsupported))
reject('unsupported-coverage', artifact, 'unsupported independently required coverage', selected=unsupported_path)
reject('wrong-supplied-occurrence', artifact, 'supplied occurrence', query=True)
assert artifact.read_bytes() == original_bytes
assert len(results) == 15
(ROOT / 'negative-control-results.json').write_text(json.dumps({
    'source_free': False, 'source_visible': True, 'trusted_H': trusted_h,
    'scope': 'Actual installed CLI, controlled retained authority, content-specific negative reasons.',
    'results': results}, indent=2) + '\n')
print('PASS all 15 installed content/trust controls', flush=True)
