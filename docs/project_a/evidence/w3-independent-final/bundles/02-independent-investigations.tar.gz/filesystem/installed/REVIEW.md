# Independent installed-runtime review at 17e4ec4

Completed checks found no confirmed P0–P3 defect. These probes use the genuine
independently built installed prefix in the parent's shared container. **Source
is visible** at `/src` and `/frozen`; this evidence is not source-free acceptance.
Production source, committed tests, branches and fixture authority are unchanged.

## Completed execution

- `actual-ROS-console.log` / `actual-ROS-results.json`: **10/10 PASS, exit 0**.
  Actual installed Reference loading, waypoint projection, existing nine-group
  JSON writer/reader and generated ROS CDR all execute. There are no numerical,
  projection, ROS message or serializer stubs. Cases cover successful export,
  partial writer ENOSPC, each of five fsync calls, rename EXDEV, an existing target
  and eight cooperative concurrent writers. Only selected fault boundaries are
  injected. Every expected complete product is read back and CDR-roundtripped;
  prepublication errors leave no target or stage; post-rename parent-fsync error
  leaves a complete usable product while returning failure.
- `negative-control-console.log` / `negative-control-results.json`: **15/15 PASS,
  exit 0**, through the genuine installed compile_route executable. Tests verify
  the intended H/policy/validator/content reason, nonzero exit and absence of a
  usable artifact path. Mutations are ordinary directories containing exactly
  `reference.json`; private-stage rejection is a separate intentional control.
  An accidental `Not a directory` rejection cannot satisfy these assertions.
- `staged-manifest-vs-git-final.log` / `staged-manifest-vs-git.json`: **PASS**,
  independently comparing **138 source-file hashes, 21 installed-resource
  authorities and two dependency locks** to exact Git object contents at
  `17e4ec4e8fedfa736467d02f6204b04e8552decb`, including recursive gitlink contents.
  The manifest records `source_dirty=false`.
- `installed-runtime-identity.json` / `prefix-identity.json`: **PASS**. Eleven
  imported installed module files match manifest bytes, all 21 installed resources
  match, both unchanged Wpnt message definitions match, and precisely four
  expected console entries remain. The installed build manifest exactly matches
  the Git-verified manifest (SHA-256
  `6eafd47cf3c5bbacacb22ac706ddd00e975a5f5c6ebc75bf25f46334fdfedf87`).
  Planner imports and executable resolve within `/work/retry-install/`; the
  helper wheel is in `/work/retry-python`; sys.path contains no `/src` or `/frozen`
  checkout entry. Source remains physically visible and is explicitly recorded.

The independent probes reuse the earlier controlled producer's retained exact
artifact bytes under separately retained external H
`f503669fe30892966562ef4f4a3b3373ee8b0c1e12a48bf66d0d84488a4f58e2`
and C. Actual installed loading regenerates both independent proofs. This is not
a claim to have run a new compiler optimization in these probes; the parent's
full fresh and source-free campaigns own that separate validation.

The first manifest/Git check attempted the audit worktree whose optimizer
submodule objects were unavailable. Its raw error is retained in
`staged-manifest-vs-git.log`; rerunning against the initialized exact frozen
checkout passed. This is an audit-environment limitation, not a product failure.

## Installed harness inspection

`test_w3_installed.py` has four tests; the separate nine-scenario campaign is a
fifth test. All 15 intended negative controls check content-specific reasons.
They include the wrong external H; five mutations under the original H; four
mutations under separately controlled new H values; private-stage rejection;
ordinary-directory truncated and NUL-corrupt content; unsupported externally
selected coverage; and a supplied wrong occurrence. The original accepted
artifact is hashed again at the end. The report-variation test invokes both real
validators before modifying conservative report values, so its injected drift
is not claimed as naturally observed cross-host variation.

The isolated runner mounts only installed products/helper wheel, runtime harness
and explicit results, using an immutable image ID and no network. Its runtime
test asserts nonroot identity, zero effective capabilities, no-new-privileges,
loopback-only networking, read-only installed/root paths, and known absent source
and build paths. `launch.json` describes intent; the parent's actual Docker
inspection plus fresh runtime identity and JUnit records must establish the
executed configuration. The image Dockerfile copies only dependency locks,
without baking the planner checkout into the image.

## Pending independent record review

The parent's full fresh original suite and true source-free campaign are still
running. Their final legacy failure/skip identities and actual source-free
records have not yet been independently credited by this review.

`audit_recorded_controls.py` is prepared to independently check all original
21 CLI receipts, their stdout/report equality, all 15 reason-specific negative
controls, actual mutation file paths and retained controlled artifact H/hash.

`audit_legacy_records.py` is prepared to compare the ten inherited failure
identities, exact two skip identities/reasons, zero-error aggregate and all
1,173 emitted Python style diagnostic lines (including repeated report copies)
against W0. It must be run on the completed fresh result and actual build JUnit
files; its presence alone is not a PASS.
