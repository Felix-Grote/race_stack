"""Audit actual original installed-suite command receipts and mutation file paths."""
import hashlib
import json
from pathlib import Path
import sys

root, destination = Path(sys.argv[1]), Path(sys.argv[2])
evidence = json.loads((root / 'w3-installed.json').read_text())
assert evidence['source_commit'] == '17e4ec4e8fedfa736467d02f6204b04e8552decb'
assert evidence['source_dirty'] is False


def local(name):
    parts = Path(name).parts
    index = parts.index('w3-installed')
    return root.joinpath(*parts[index:])


expected = {'wrong-expected-h': 'H mismatch',
            'incomplete-stage': 'private staging',
            'truncated-content': 'invalid bounded UTF-8 JSON',
            'corrupt-bytes': 'invalid bounded UTF-8 JSON',
            'unsupported-coverage': 'unsupported independently required coverage',
            'wrong-supplied-occurrence': 'supplied occurrence'}
for label in ('approval', 'model', 'policy', 'coefficient', 'implementation'):
    expected['reject-' + label + '-old-h'] = 'H mismatch'
for label, reason in {'approval': 'geometry replay FAIL', 'model': 'dynamics replay FAIL',
                      'policy': 'independent acceptance policy',
                      'implementation': 'changed kernel/checker/dependency identity'}.items():
    expected['reject-' + label + '-new-h'] = reason
assert len(expected) == 15
seen, records = set(), []
for command in evidence['commands']:
    stdout = local(command['stdout'])
    value = json.loads(stdout.read_text())
    if command['report']:
        report = local(command['report'])
        assert json.loads(report.read_text()) == value
        label = report.stem
    else:
        label = stdout.name.removesuffix('.stdout.txt')
    assert value['status'] == command['status']
    if label in expected:
        seen.add(label)
        assert command['returncode'] != 0 and value['status'] != 'PASS'
        assert not value.get('artifact_path')
        assert expected[label] in value['reason'] and 'Not a directory' not in value['reason']
        path = local(command['command'][command['command'].index('--artifact') + 1])
        assert path.is_file() and path.name == 'reference.json'
        assert list(path.parent.iterdir()) == [path]
        if label == 'incomplete-stage':
            assert path.parent.name.startswith('.tmp-')
        elif label.startswith('reject-') or label in ('truncated-content', 'corrupt-bytes'):
            assert not path.parent.name.startswith(('.tmp-', '.lock-'))
        records.append({'case': label, 'status': 'PASS', 'actual_reason': value['reason'],
                        'artifact_path': str(path), 'artifact_sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
    else:
        assert command['returncode'] == 0 and value['status'] == 'PASS', label
assert seen == set(expected), (set(expected) - seen, seen - set(expected))
artifact = local(evidence['artifact_path'])
raw = artifact.read_bytes()
document = json.loads(raw)
canonical = json.dumps(document['payload'], sort_keys=True, separators=(',', ':'),
                       ensure_ascii=False, allow_nan=False).encode()
assert document['H'] == evidence['H'] == hashlib.sha256(canonical).hexdigest()
assert hashlib.sha256(raw).hexdigest() == evidence['artifact_sha256']
assert json.loads((root / 'w3-installed/compile.json').read_text())['H'] == evidence['H']
result = {'status': 'PASS', 'source_commit': evidence['source_commit'],
          'source_free': evidence['source_free'], 'command_count': len(evidence['commands']),
          'negative_controls_checked': len(records), 'controls': records,
          'controlled_compile_H': evidence['H'], 'accepted_artifact_unchanged': True}
destination.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key != 'controls'}))
