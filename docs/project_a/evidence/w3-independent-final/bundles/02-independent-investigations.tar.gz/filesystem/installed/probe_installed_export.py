"""Actual installed ROS filesystem matrix; source remains visible in this probe."""
from concurrent.futures import ThreadPoolExecutor
from contextlib import ExitStack, redirect_stdout
import errno
import hashlib
import importlib
import io
import json
import os
from pathlib import Path
import sys
import tempfile
from unittest.mock import patch

from ament_index_python.packages import get_package_prefix, get_package_share_directory
from global_planner import route_artifact as a
from global_planner import route_legacy_export as e
from global_planner import readwrite_global_waypoints as rw
from rclpy.serialization import deserialize_message, serialize_message
from rosidl_runtime_py.convert import message_to_ordereddict

ROOT = Path(__file__).parent
share = Path(get_package_share_directory('global_planner')) / 'project_a'
manifest = json.loads((share / 'build_identity.json').read_text())
assert manifest['source_commit'] == '17e4ec4e8fedfa736467d02f6204b04e8552decb'
assert manifest['source_dirty'] is False
origins = {}
for name in ('route_input', 'route_reference', 'route_corridor', 'iqp_route_adapter',
             'route_validate', 'route_validate_dynamics', 'cyclic_retime',
             'route_artifact', 'route_compile', 'route_legacy_export', 'readwrite_global_waypoints'):
    module = importlib.import_module('global_planner.' + name)
    path = Path(module.__file__)
    assert str(path.resolve()).startswith('/work/retry-install/')
    assert not path.is_symlink()
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    assert digest == manifest['source_hashes']['planner/global_planner/global_planner/' + path.name]
    origins[name] = {'path': str(path), 'sha256': digest}
for name, expected in manifest['installed_resource_hashes'].items():
    path = share / name
    assert not path.is_symlink() and hashlib.sha256(path.read_bytes()).hexdigest() == expected
for name in ('Wpnt.msg', 'WpntArray.msg'):
    path = Path(get_package_share_directory('f110_msgs')) / 'msg' / name
    assert hashlib.sha256(path.read_bytes()).hexdigest() == manifest['source_hashes']['utilities/libraries/f110_msgs/msg/' + name]
identity = json.loads((ROOT.parent / 'real_authority_identity.json').read_text())
envelope = a.read_json(ROOT.parent / 'retained-authority-envelope.json')
assert envelope['H'] == identity['H'] == a.artifact_identity(envelope['payload'])
authority = ROOT / 'authority' / identity['H']
authority.mkdir(parents=True)
(authority / 'reference.json').write_bytes(a.canonical_bytes(envelope))
reference = a.load_reference(authority, expected_H=identity['H'], validation_context=a.ValidationContext())
print('Actual installed reference accepted', reference.H, flush=True)
runtime = {'source_commit': manifest['source_commit'], 'source_free': False,
           'source_visible': {'/src': Path('/src').exists(), '/frozen': Path('/frozen').exists()},
           'sys_path': sys.path, 'origins': origins, 'resources_verified': len(manifest['installed_resource_hashes']),
           'build_manifest_sha256': hashlib.sha256((share / 'build_identity.json').read_bytes()).hexdigest(),
           'reference_H': reference.H, 'scope': 'Installed imports and genuine ROS, source-visible shared container.'}
(ROOT / 'installed-runtime-identity.json').write_text(json.dumps(runtime, indent=2) + '\n')
results = []
real_fsync = os.fsync


def verify_product(target):
    with redirect_stdout(io.StringIO()):
        groups = rw.read_global_waypoints(str(target))
    assert len(groups) == 9
    for message in groups:
        restored = deserialize_message(serialize_message(message), type(message))
        assert message_to_ordereddict(restored) == message_to_ordereddict(message)
    assert groups[5].wpnts[0].s_m == 0.
    assert groups[5].wpnts[-1].s_m == reference.length
    assert groups[1].data == e.waypoint_view(reference, step_m=1.).legacy_lap_time_float32_s
    assert all(not groups[index].wpnts for index in (3, 7))
    assert json.loads((target / 'export.json').read_text())['H'] == reference.H
    assert sorted(path.name for path in target.iterdir()) == ['export.json', 'global_waypoints.json']


def one(case):
    with tempfile.TemporaryDirectory(prefix='actual-ros-', dir=ROOT) as scratch:
        target = Path(scratch) / 'export'
        with ExitStack() as faults:
            if case.startswith('fsync-'):
                calls, selected = [0], int(case.split('-')[1])
                def sync(fd):
                    calls[0] += 1
                    if calls[0] == selected:
                        raise OSError(errno.EIO, 'injected real-ROS export fsync failure')
                    return real_fsync(fd)
                faults.enter_context(patch.object(e.os, 'fsync', sync))
            elif case == 'partial-writer-error':
                def partial(path, *arguments):
                    (Path(path) / 'global_waypoints.json').write_text('{')
                    raise OSError(errno.ENOSPC, 'injected real-ROS writer full disk')
                faults.enter_context(patch.object(rw, 'write_global_waypoints', partial))
            elif case == 'rename-error':
                def rename(*arguments):
                    raise OSError(errno.EXDEV, 'injected real-ROS export rename error')
                faults.enter_context(patch.object(a, '_rename_noreplace', rename))
            elif case == 'existing':
                target.mkdir()
                (target / 'sentinel').write_text('original')
            try:
                receipt = e.export_waypoints(reference, step_m=1., output_dir=target)
                outcome, reason = 'PASS', receipt.reason
            except e.ExportError as exc:
                outcome, reason = 'FAIL', str(exc)
        if case in ('success', 'fsync-5'):
            verify_product(target)
            assert outcome == ('PASS' if case == 'success' else 'FAIL')
        elif case == 'existing':
            assert (target / 'sentinel').read_text() == 'original'
            assert outcome == 'FAIL'
        else:
            assert not target.exists()
            assert outcome == 'FAIL'
        assert not list(Path(scratch).glob('.tmp-*'))
        results.append({'case': case, 'status': 'PASS', 'API_outcome': outcome, 'reason': reason})
        print('PASS actual-installed-ROS/' + case, flush=True)


for case in ('success', 'partial-writer-error', 'fsync-1', 'fsync-2', 'fsync-3', 'fsync-4', 'fsync-5', 'rename-error', 'existing'):
    one(case)
with tempfile.TemporaryDirectory(prefix='actual-ros-concurrent-', dir=ROOT) as scratch:
    target = Path(scratch) / 'export'
    def writer(_):
        try:
            e.export_waypoints(reference, step_m=1., output_dir=target)
            return 'PASS'
        except e.ExportError:
            return 'FAIL'
    with ThreadPoolExecutor(max_workers=8) as executor:
        outcomes = list(executor.map(writer, range(8)))
    assert outcomes.count('PASS') == 1 and outcomes.count('FAIL') == 7, outcomes
    verify_product(target)
    assert not list(Path(scratch).glob('.tmp-*'))
    results.append({'case': 'eight-concurrent-writers', 'status': 'PASS', 'outcomes': outcomes})
    print('PASS actual-installed-ROS/eight-concurrent-writers', flush=True)
(ROOT / 'actual-ROS-results.json').write_text(json.dumps(results, indent=2) + '\n')
print('PASS actual installed ROS export matrix', len(results), flush=True)
