"""Independent Linux filesystem state-machine tests; numerical/ROS seams stubbed.

These probes exercise real file writes, fsync, flock and renameat2. They do not
claim validation of numerics, the Reference decoder, or ROS serialization.
Run with PYTHONPATH pointing at the audited global_planner source package.
"""
from concurrent.futures import ThreadPoolExecutor
from contextlib import ExitStack
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import errno
import json
import os
import stat
import tempfile
import gzip

from global_planner import route_artifact as a
from global_planner import route_legacy_export as e

ROOT = Path(__file__).parent
payload = {'filesystem_probe': 'exact independently retained bytes', 'n': 1.25}
H = a.artifact_identity(payload)
C = '1' * 64
original_write, original_fsync, original_rename = os.write, os.fsync, a._rename_noreplace
results = []
REAL_NUMERICS = os.environ.get('REAL_NUMERICS') == '1'
print('Reference numerical validators:', 'REAL' if REAL_NUMERICS else 'STUBBED',
      '; export projection and ROS writer: STUBBED; Linux filesystem operations: REAL', flush=True)


def numerical_authority():
    from global_planner.cyclic_retime import DynamicsModel, ModelRegion, RegionLimits, RetimePolicy, curve_digest, retime
    from global_planner.iqp_route_adapter import SolverPolicy
    from global_planner.route_corridor import OrderedCurve
    from global_planner.route_input import load_route
    from global_planner.route_reference import Curve
    from global_planner.route_validate import Footprint, GeometryValidationPolicy, validate_geometry
    from global_planner.route_validate_dynamics import DynamicsValidationPolicy, validate_dynamics
    fixtures = Path(a.__file__).parent.parent / 'test/fixtures/project_a'
    candidate = json.loads(gzip.decompress((fixtures / 'w2_a04_candidates.json.gz').read_bytes()))['candidates']['s0_route']
    route = load_route(fixtures / 's0_route.json')
    ordered = OrderedCurve(route, Curve(candidate['coefficients'], candidate['owners']), candidate['q'])
    approval = curve_digest(ordered)
    limits = RegionLimits(.05, 3., 2., 3., 4., 2.5, .0, 'Synthetic filesystem reliability probe')
    model = DynamicsModel(tuple(ModelRegion(o.id, o.surface_id, limits) for o in route.occurrences), 'Synthetic audit')
    footprint = Footprint(.1, .1, .12, .01)
    geometry = validate_geometry(ordered, route, footprint, expected_curve_digest=approval)
    timed = retime(ordered, model)
    dynamics = validate_dynamics(ordered, timed.profile, model, metadata=timed.metadata, expected_curve_digest=approval)
    assert geometry.status == dynamics.status == 'PASS'
    body = a.build_payload(ordered, timed.profile, model, footprint,
        solver_policy=SolverPolicy(), retime_policy=RetimePolicy(),
        geometry_policy=GeometryValidationPolicy(), dynamics_policy=DynamicsValidationPolicy(),
        approved_curve_digest=approval, geometry_report=geometry, dynamics_report=dynamics,
        provenance={'scope': 'Independent filesystem audit synthetic archive reference'})
    return body, approval


if REAL_NUMERICS:
    payload, C = numerical_authority()
    H = a.artifact_identity(payload)
    (ROOT / 'real_authority_identity.json').write_text(json.dumps({
        'H': H, 'C': C, 'implementation': a.implementation_identity()}, indent=2) + '\n')
    print('Actual numerical authority built and independently certified', H, flush=True)


def decoded(raw, expected, context, path, curve=None):
    doc = a._parse_json(raw)
    assert doc['H'] == expected == a.artifact_identity(doc['payload'])
    assert doc['payload'] == payload
    return SimpleNamespace(H=expected, path=path)


def publish(where):
    return a.publish_reference(payload, where, expected_H=H, expected_curve_digest=C)


def verify_saved(path):
    if REAL_NUMERICS:
        loaded = a.load_reference(path, expected_H=H, validation_context=a.ValidationContext())
        assert loaded.H == H
    else:
        decoded(path.read_bytes(), H, None, None)


def check(label, function):
    try:
        function()
        results.append({'case': label, 'status': 'PASS'})
        print('PASS', label, flush=True)
    except Exception as exc:
        results.append({'case': label, 'status': 'FAIL', 'exception': repr(exc)})
        print('FAIL', label, repr(exc), flush=True)


def reference_case(case):
    with tempfile.TemporaryDirectory(prefix='ref-', dir=ROOT) as scratch:
        output = Path(scratch) / 'new-parents' / 'references'
        with ExitStack() as stack:
            if case == 'short-writes':
                stack.enter_context(patch.object(a.os, 'write', lambda fd, data: original_write(fd, data[:7])))
            elif case == 'zero-write':
                stack.enter_context(patch.object(a.os, 'write', lambda fd, data: 0))
            elif case == 'partial-then-error':
                calls = [0]
                def interrupted(fd, data):
                    calls[0] += 1
                    if calls[0] > 1:
                        raise OSError(errno.ENOSPC, 'injected full disk')
                    return original_write(fd, data[:7])
                stack.enter_context(patch.object(a.os, 'write', interrupted))
            elif case.startswith('fsync-'):
                calls = [0]
                index = int(case.split('-')[1])
                def sync(fd):
                    calls[0] += 1
                    if calls[0] == index:
                        raise OSError(errno.EIO, 'injected fsync')
                    return original_fsync(fd)
                stack.enter_context(patch.object(a.os, 'fsync', sync))
            elif case == 'rename-error':
                def rename(*args):
                    raise OSError(errno.EXDEV, 'injected rename')
                stack.enter_context(patch.object(a, '_rename_noreplace', rename))
            elif case == 'existing':
                (output / H).mkdir(parents=True)
                (output / H / 'sentinel').write_text('original')
            try:
                reference = publish(output)
                outcome = 'PASS'
            except a.ArtifactError as exc:
                outcome = 'FAIL'
                print('expected rejection:', case, str(exc), flush=True)
        accepted = output / H
        if case in ('short-writes', 'fsync-3'):
            assert accepted.is_dir()
            verify_saved(accepted / 'reference.json')
            assert stat.S_IMODE(accepted.stat().st_mode) == 0o555
            assert stat.S_IMODE((accepted / 'reference.json').stat().st_mode) == 0o444
            assert outcome == ('PASS' if case == 'short-writes' else 'FAIL')
        elif case == 'existing':
            assert (accepted / 'sentinel').read_text() == 'original'
            assert sorted(p.name for p in accepted.iterdir()) == ['sentinel']
            assert outcome == 'FAIL'
        else:
            assert not accepted.exists()
            assert outcome == 'FAIL'
        assert not list(output.glob('.tmp-*'))


def concurrent_reference():
    with tempfile.TemporaryDirectory(prefix='concurrent-ref-', dir=ROOT) as scratch:
        output = Path(scratch) / 'references'
        def writer(_):
            try:
                publish(output)
                return 'PASS'
            except a.ArtifactError:
                return 'FAIL'
        with ThreadPoolExecutor(max_workers=8) as executor:
            outcomes = list(executor.map(writer, range(8)))
        assert outcomes.count('PASS') == 1, outcomes
        assert outcomes.count('FAIL') == 7, outcomes
        verify_saved(output / H / 'reference.json')
        assert not list(output.glob('.tmp-*'))


view = SimpleNamespace(H=H, frame_id='probe', waypoints=(1, 2), length_m=1.,
                       lap_time_s=1., legacy_lap_time_float32_s=1.)


def stage_ros(view, path):
    (path / 'global_waypoints.json').write_text('{"local-filesystem-probe":true}')


def export_case(case):
    with tempfile.TemporaryDirectory(prefix='export-', dir=ROOT) as scratch:
        target = Path(scratch) / 'export'
        with ExitStack() as stack:
            if case.startswith('fsync-'):
                index, calls = int(case.split('-')[1]), [0]
                def sync(fd):
                    calls[0] += 1
                    if calls[0] == index:
                        raise OSError(errno.EIO, 'injected fsync')
                    return original_fsync(fd)
                stack.enter_context(patch.object(e.os, 'fsync', sync))
            elif case == 'partial-then-error':
                def partial(view, path):
                    (path / 'global_waypoints.json').write_text('{')
                    raise OSError(errno.ENOSPC, 'injected full disk')
                stack.enter_context(patch.object(e, '_write_ros_product', partial))
            elif case == 'rename-error':
                def rename(*args):
                    raise OSError(errno.EXDEV, 'injected rename')
                stack.enter_context(patch.object(a, '_rename_noreplace', rename))
            elif case == 'existing':
                target.mkdir()
                (target / 'sentinel').write_text('original')
            try:
                e.export_waypoints(None, step_m=1., output_dir=target)
                outcome = 'PASS'
            except e.ExportError as exc:
                outcome = 'FAIL'
                print('expected rejection:', case, str(exc), flush=True)
        if case in ('success', 'fsync-5'):
            assert target.is_dir()
            assert sorted(p.name for p in target.iterdir()) == ['export.json', 'global_waypoints.json']
            assert json.loads((target / 'export.json').read_text())['H'] == H
            assert outcome == ('PASS' if case == 'success' else 'FAIL')
        elif case == 'existing':
            assert (target / 'sentinel').read_text() == 'original'
            assert outcome == 'FAIL'
        else:
            assert not target.exists(), (case, list(target.iterdir()))
            assert outcome == 'FAIL'
        assert not list(Path(scratch).glob('.tmp-*'))


def concurrent_export():
    with tempfile.TemporaryDirectory(prefix='concurrent-export-', dir=ROOT) as scratch:
        target = Path(scratch) / 'export'
        def writer(_):
            try:
                e.export_waypoints(None, step_m=1., output_dir=target)
                return 'PASS'
            except e.ExportError:
                return 'FAIL'
        with ThreadPoolExecutor(max_workers=8) as executor:
            outcomes = list(executor.map(writer, range(8)))
        assert outcomes.count('PASS') == 1, outcomes
        assert not list(Path(scratch).glob('.tmp-*'))


with ExitStack() as seams:
    if not REAL_NUMERICS:
        seams.enter_context(patch.object(a, '_supported_context', lambda context: None))
        seams.enter_context(patch.object(a, '_load_bytes', decoded))
    for case in ('short-writes', 'zero-write', 'partial-then-error', 'fsync-1', 'fsync-2',
                 'fsync-3', 'rename-error', 'existing'):
        check('reference/' + case, lambda case=case: reference_case(case))
    check('reference/eight-concurrent-writers', concurrent_reference)
with patch.object(e, 'waypoint_view', lambda *args, **kwargs: view), patch.object(e, '_write_ros_product', stage_ros):
    for case in ('success', 'partial-then-error', 'fsync-1', 'fsync-2', 'fsync-3', 'fsync-4',
                 'fsync-5', 'rename-error', 'existing'):
        check('export/' + case, lambda case=case: export_case(case))
    check('export/eight-concurrent-writers', concurrent_export)
(ROOT / ('probe_real_results.json' if REAL_NUMERICS else 'probe_results.json')).write_text(json.dumps(results, indent=2) + '\n')
raise SystemExit(0 if all(item['status'] == 'PASS' for item in results) else 1)
