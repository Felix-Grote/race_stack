"""Reuse only fixture-authority construction, then execute the SIGTERM probes."""
import ast
import gzip
import json
from pathlib import Path
from global_planner import route_artifact as a
from probe_termination import run

root = Path(__file__).parent
tree = ast.parse((root / 'probe_filesystem.py').read_text())
definition = next(node for node in tree.body if isinstance(node, ast.FunctionDef)
                  and node.name == 'numerical_authority')
namespace = {'Path': Path, 'a': a, 'json': json, 'gzip': gzip}
exec(compile(ast.Module(body=[definition], type_ignores=[]), __file__, 'exec'), namespace)
if (root / 'retained-authority-envelope.json').exists():
    authority = a.read_json(root / 'retained-authority-envelope.json')
    expected = json.loads((root / 'real_authority_identity.json').read_text())
    payload, C = authority['payload'], expected['C']
    H = a.artifact_identity(payload)
    assert H == expected['H'] == authority['H']
else:
    payload, C = namespace['numerical_authority']()
    H = a.artifact_identity(payload)
print('Actual certified authority for termination probes:', H, flush=True)
run(a, payload, H, C, root)
