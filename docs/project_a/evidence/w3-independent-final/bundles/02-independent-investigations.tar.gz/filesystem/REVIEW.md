# Independent filesystem reliability review

Audited source: `17e4ec4e8fedfa736467d02f6204b04e8552decb`.
Production, committed tests, branches and fixtures were not edited.

Final result: no confirmed P0–P3 finding. The pinned matrix passed 19/19 (exit 0),
and both real-reference SIGTERM phases passed. The host filesystem-only matrix
also passed 19/19. Interrupted or timed-out harness attempts are retained and
excluded from these counts.

This scope examines ordinary local Linux publication/export correctness. It
does not establish power-loss/hardware durability or distributed filesystem
semantics. It does not audit third-party systems.

## Evidence and boundaries

`probe_filesystem.py` directly exercises production `publish_reference`,
`export_waypoints`, `_write_all`, `flock`, `fsync`, and Linux
`renameat2(RENAME_NOREPLACE)` in private temporary directories. The host run
(`probe_filesystem.log`, `probe_results.json`) passed all 19 cases, with
explicitly stubbed numerical authority decoding and ROS serialization.

`probe_real_filesystem.log` / `probe_real_results.json` record the completed
19/19 PASS pinned Linux/Python 3.10.12 rerun (exit 0). In this mode reference input is constructed
directly from the frozen S0 coefficient archive, with genuine geometry validation,
retiming, dynamics validation, publication decoding and subsequent fresh loading.
No numerical validator, runtime/context check, implementation identity or
reference decoder is stubbed in that mode. Its export projection and ROS writer
remain explicitly stubbed: those export checks certify filesystem behavior only.

`real_authority_identity.json` records the separately frozen H/C and current
implementation identity. Source/fixture and harness hashes are retained alongside
the exact image ID.

Nine reference cases cover 7-byte successful short writes, zero writes,
partial write followed by ENOSPC, failure at each of the three fsync boundaries,
rename EXDEV, an existing immutable target, and eight cooperative concurrent
writers. Assertions inspect exact saved bytes, replay accepted targets, check
0444/0555 publication modes and verify private-stage cleanup. Prepublication
failure must leave no accepted target; parent-fsync failure must leave a complete
loadable target while returning failure.

Ten export cases cover success, partial writer failure, each of five fsync calls,
rename EXDEV, an existing target and eight cooperative concurrent writers.
They inspect complete directory products and stage cleanup, including failure
after rename. Actual ROS reader/CDR correctness belongs to the separate installed
integration verification.

## Termination probes

`probe_termination.py` and `run_termination.py` use actual reference publication
and replay. SIGTERM during a partial file write passed in
`probe_termination_first.log`: the accepted target is absent and the private
orphan stage is explicitly rejected by the loader.

The initial post-rename rendezvous was bounded to 60 seconds and timed out while
the child was still replaying under concurrent CPU load. The original script and
raw log are retained as `probe_termination_first.py` /
`probe_termination_first.log`. This is an audit-harness timeout, not an observed
product correctness failure. The revised harness prints progress every ten
seconds and bounds this rendezvous at 240 seconds; only the unfinished
post-rename phase is retried in `probe_termination_shared.log`. An intermediate
exec-based retry (`probe_termination_second.log`) was cancelled before reaching
its barrier because its containing matrix process could exit first; the final
retry initially had its own container lifecycle, but was removed at the parent's
request during shared Docker VFS disk exhaustion (`probe_termination_final.log`,
container exit 137); it is not counted as a product failure or PASS. The current
retry uses the parent's single shared probe container, adding no image copy.
None of the interrupted intermediate attempts is counted as a product PASS or
failure.

Final post-rename result: `probe_termination_shared.log` ends in
`PASS termination/after-rename-before-parent-fsync`; the shared exec returned 0.
The accepted directory survived SIGTERM at the exact post-rename/pre-parent-fsync
barrier and subsequently passed genuine fresh loader geometry/dynamics replay.
`termination_results.json` records this phase; the partial-write phase's PASS is
retained separately in `probe_termination_first.log`.

The final termination runner may reuse `retained-authority-envelope.json`, an
exact persisted producer snapshot whose H is checked against the separately
retained H/C in `real_authority_identity.json`. This avoids repeating retiming;
publication and post-termination loading still run the actual independent
validators. The retained envelope is test input, not a claimed accepted path.

## Source assessment

No confirmed P0–P3 reliability defect was found in the reviewed ordinary
publication/export state machines. `_write_all` handles short writes and rejects
zero progress. A lock is retained across target inspection, staging/replay and
publication. The final no-replace rename independently protects the target, and
the successful rename state is recorded before the final parent fsync. This
allows error reporting after rename without deleting a complete accepted target.

Automatic creation of new output ancestors does not individually fsync every
ancestor's containing directory. This is not reported as a confirmed contract
defect: the documented guarantee explicitly excludes a general power-loss or
hardware persistence guarantee. No actual power-loss test was performed.

This review does not claim whole-W3 acceptance. Final executed counts and
limitations must be read with the raw logs/JSON rather than inferred from a
script's presence.

Reviewed implementation anchors are `route_artifact.py:200` (fd directory
traversal), `:905` (Linux no-replace rename), `:918` (short-write loop), `:927`
(publication), and `route_legacy_export.py:232` (export publication).
