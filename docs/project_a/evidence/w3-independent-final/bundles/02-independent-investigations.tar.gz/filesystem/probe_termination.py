"""Real Linux SIGTERM checks, invoked with an already-certified parent authority."""
from pathlib import Path
from unittest.mock import patch
import json
import multiprocessing
import os
import signal
import tempfile
import time


def run(a, payload, H, C, root):
    results = []
    for phase in ('during-partial-write', 'after-rename-before-parent-fsync'):
        if os.environ.get('TERMINATION_PHASE') and os.environ['TERMINATION_PHASE'] != phase:
            continue
        with tempfile.TemporaryDirectory(prefix='termination-', dir=root) as scratch:
            output = Path(scratch) / 'references'
            ready_read, ready_write = multiprocessing.Pipe(duplex=False)
            original_write, original_fsync = a._write_all, os.fsync

            def child():
                def paused_write(fd, data):
                    os.write(fd, data[:17])
                    ready_write.send('partial-written')
                    signal.pause()

                sync_calls = [0]
                def paused_sync(fd):
                    sync_calls[0] += 1
                    if sync_calls[0] == 3:
                        ready_write.send('renamed')
                        signal.pause()
                    return original_fsync(fd)

                seam = patch.object(a, '_write_all', paused_write) if phase == 'during-partial-write' else patch.object(a.os, 'fsync', paused_sync)
                with seam:
                    a.publish_reference(payload, output, expected_H=H, expected_curve_digest=C)

            process = multiprocessing.get_context('fork').Process(target=child)
            process.start()
            try:
                deadline = time.monotonic() + 240
                while not ready_read.poll(10):
                    print('Waiting for filesystem barrier:', phase, flush=True)
                    assert time.monotonic() < deadline, 'child did not reach selected filesystem barrier'
                barrier = ready_read.recv()
                os.kill(process.pid, signal.SIGTERM)
                process.join(10)
                assert process.exitcode == -signal.SIGTERM, process.exitcode
                target = output / H
                if phase == 'during-partial-write':
                    assert not target.exists()
                    stages = list(output.glob('.tmp-*'))
                    assert len(stages) == 1
                    try:
                        a.load_reference(stages[0], expected_H=H, validation_context=a.ValidationContext())
                    except a.ArtifactError as exc:
                        assert 'private staging' in str(exc)
                    else:
                        raise AssertionError('orphan stage accepted')
                else:
                    reference = a.load_reference(target, expected_H=H, validation_context=a.ValidationContext())
                    assert reference.H == H
                    assert not list(output.glob('.tmp-*'))
                results.append({'case': phase, 'barrier': barrier, 'status': 'PASS'})
                print('PASS termination/' + phase, flush=True)
            finally:
                if process.is_alive():
                    process.kill()
                    process.join()
                ready_read.close()
                ready_write.close()
    (root / 'termination_results.json').write_text(json.dumps(results, indent=2) + '\n')
