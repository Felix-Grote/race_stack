"""Independent byte/provenance audit; no product-module imports or numerical claims."""
import collections
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile
import zipfile

ROOT = Path('/workspace/forza-evidence-review')
P = ROOT / 'docs/project_a/evidence/w3-final-verification'
OUT = Path('/workspace/forza-audit-records/evidence')
results = {}
errors = []


def sha(data):
    return hashlib.sha256(data).hexdigest()


def canonical(value, ascii=False):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=ascii, allow_nan=False).encode()


def check(ok, label):
    if not ok:
        errors.append(label)


def manifest(base, file):
    obj = json.loads(file.read_text())
    entries = obj.get('files', obj)
    for name, record in entries.items():
        data = (base / name).read_bytes()
        check(sha(data) == (record['sha256'] if isinstance(record, dict) else record),
              'manifest hash ' + str(file) + ':' + name)
        if isinstance(record, dict) and 'bytes' in record:
            check(len(data) == record['bytes'], 'manifest size ' + name)
    return len(entries)


results['publication_manifest_files'] = manifest(P, P / 'files-sha256.json')
results['historical_portability_manifest_files'] = manifest(
    ROOT / 'docs/project_a/evidence/w3-report-portability',
    ROOT / 'docs/project_a/evidence/w3-report-portability/files-sha256.json')
index = json.loads((P / 'publication-index.json').read_text())
for name, rec in index['files'].items():
    data = (P / name).read_bytes()
    check(len(data) == rec['bytes'] and sha(data) == rec['sha256'], 'publication ' + name)
results['publication_index_files'] = len(index['files'])

archives = {}
for filename, metadata, prefix, ledger_name in [
        ('fresh-17e4ec4e.tar.gz', 'fresh-archive.json', '', None),
        ('portability-17e4ec4e.tar.gz', 'portability-archive.json',
         'postfix-portability-evidence/', 'files.json'),
        ('benchmarks/final-functional-17e4ec4e.tar.gz', 'benchmarks/archive.json',
         'postfix-benchmarks/', 'files.json')]:
    meta = json.loads((P / metadata).read_text())
    data = (P / filename).read_bytes()
    check(len(data) == meta['archive_bytes'] and sha(data) == meta['archive_sha256'],
          'archive bytes ' + filename)
    with tarfile.open(P / filename) as archive:
        members = archive.getmembers()
        names = [m.name for m in members]
        check(len(set(names)) == len(names), 'duplicate archive paths ' + filename)
        check(all(not m.issym() and not m.islnk() and not m.name.startswith('/')
                  and '..' not in Path(m.name).parts for m in members),
              'unsafe archive paths ' + filename)
        files = {m.name: archive.extractfile(m).read() for m in members if m.isfile()}
    archives[filename] = files
    for field in ('candidate', 'source_commit', 'source_sha'):
        if field in meta:
            check(meta[field] == '17e4ec4e8fedfa736467d02f6204b04e8552decb',
                  'archive candidate ' + filename)
    for count_key in ('files', 'raw_files'):
        if count_key in meta:
            check(meta[count_key] == len(files), 'archive file count ' + filename)
    for size_key in ('uncompressed_bytes', 'raw_bytes'):
        if size_key in meta:
            check(meta[size_key] == sum(map(len, files.values())), 'archive raw size ' + filename)
    if 'file_ledger_sha256' in meta:
        check(meta['file_ledger_sha256'] == sha(files[prefix + 'files.json']),
              'archive ledger binding ' + filename)
    if 'sha256sum_inventory_sha256' in meta:
        check(meta['sha256sum_inventory_sha256'] == sha(files[prefix + 'SHA256SUMS']),
              'archive SHA256SUMS binding ' + filename)
    ledger = (json.loads(files[prefix + ledger_name]) if ledger_name else meta['members'])
    entries = ({r['path']: r for r in ledger} if isinstance(ledger, list) else ledger)
    for name, rec in entries.items():
        value = files[prefix + name]
        check(len(value) == rec['bytes'] and sha(value) == rec['sha256'],
              'archive ledger ' + filename + ':' + name)
    excluded = set(files) - {prefix + name for name in entries}
    if ledger_name:
        check(excluded <= {prefix + 'files.json', prefix + 'SHA256SUMS'},
              'archive unlisted ' + filename + ':' + str(excluded))
    else:
        check(not excluded, 'fresh unlisted members')
    if prefix + 'SHA256SUMS' in files:
        lines = files[prefix + 'SHA256SUMS'].decode().splitlines()
        for line in lines:
            digest, name = line.split(maxsplit=1)
            name = name.lstrip('*')
            check(sha(files[prefix + name]) == digest, 'archive SHA256SUMS ' + name)
    results[filename] = {'files': len(files), 'ledger_entries': len(entries),
                         'ledger_exclusions': sorted(excluded),
                         'uncompressed_bytes': sum(map(len, files.values())),
                         'archive_sha256': sha(data), 'archive_bytes': len(data)}

zipfiles = {}
for label, path in [('final', P / 'ci/original-push-artifact.zip'),
                    ('old', ROOT / 'docs/project_a/evidence/w3-report-portability/red/hosted-original-ci.zip')]:
    api = json.loads((OUT / (label + '-artifact-api.json')).read_text())
    run = json.loads((OUT / (label + '-push-run-api.json')).read_text())
    data = path.read_bytes()
    check(api['digest'] == 'sha256:' + sha(data) and api['size_in_bytes'] == len(data),
          label + ' GitHub digest/size')
    check(run['head_sha'] == api['workflow_run']['head_sha'] and run['event'] == 'push'
          and run['status'] == 'completed' and run['conclusion'] == 'success',
          label + ' successful literal push')
    with zipfile.ZipFile(path) as archive:
        check(archive.testzip() is None, label + ' ZIP CRC')
        check(len(set(archive.namelist())) == len(archive.namelist()), label + ' ZIP duplicate')
        check(all(not name.startswith('/') and '..' not in Path(name).parts
                  for name in archive.namelist()), label + ' ZIP unsafe paths')
        check(all(((info.external_attr >> 16) & 0o170000) != 0o120000
                  for info in archive.infolist()), label + ' ZIP symlinks')
        files = {name: archive.read(name) for name in archive.namelist() if not name.endswith('/')}
    zipfiles[label] = files
    results[label + '_original_CI'] = {'sha256': sha(data), 'bytes': len(data),
                                     'files': len(files), 'head_sha': run['head_sha'],
                                     'artifact_id': api['id'], 'run_id': run['id'],
                                     'API_verified': True}

hosted = zipfiles['final']
catalog = json.loads((P / 'ci/controlled-hosted-catalog.json').read_text())
campaign = json.loads(hosted['source-free/results/w3-scenario-campaign.json'])
outcomes = {r['case']: r for r in campaign['outcomes']}
rows = []
for rec in catalog:
    case = rec['case']
    raw = hosted['source-free/results/' + rec['relative_artifact']]
    envelope = json.loads(raw)
    payload = envelope['payload']
    compile = json.loads(hosted['source-free/results/w3-scenarios/' + case + '/compile.json'])
    validate = json.loads(hosted['source-free/results/w3-scenarios/' + case + '/validate.json'])
    curve = dict(payload['curve'])
    route = payload['approved_route']
    # Route canonical authority uses its A01 declared digest.
    route_digest = sha(canonical(route, True))
    curve.update(route_digest=route_digest, numeric_policy=payload['policies']['numeric'])
    C = sha(canonical(curve, True))
    H = sha(canonical(payload))
    check(H == rec['H'] == envelope['H'] == compile['H'] == validate['H'] == outcomes[case]['H'],
          case + ' controlled H')
    check(C == rec['curve_digest'] == payload['approved_curve_digest']
          == compile['geometry']['curve_digest'] == compile['dynamics']['curve_digest'],
          case + ' controlled C')
    check(compile['status'] == validate['status'] == 'PASS', case + ' receipts PASS')
    rows.append({'case': case, 'H': H, 'C': C, 'artifact_sha256': sha(raw), 'bytes': len(raw)})
results['controlled_hosted_catalog'] = rows

portable = archives['portability-17e4ec4e.tar.gz']
for name, value in portable.items():
    if name.startswith('postfix-portability-evidence/incoming/'):
        suffix = name.removeprefix('postfix-portability-evidence/incoming/')
        candidates = ([suffix] if suffix in hosted else
                      [n for n in hosted if n.endswith('/' + suffix)])
        check(len(candidates) == 1 and value == hosted[candidates[0]], 'portable original ' + suffix)
check(json.loads(portable['postfix-portability-evidence/runtime/trusted-catalog.json']) == catalog,
      'portable trusted catalog')
results['portable_incoming_original_files'] = sum('/incoming/' in n for n in portable)

bench = archives['benchmarks/final-functional-17e4ec4e.tar.gz']
bcatalog = json.loads((P / 'benchmarks/controlled-artifact-catalog.json').read_text())
check(bcatalog == json.loads(bench['postfix-benchmarks/controlled-artifact-catalog.json']),
      'benchmark catalog published == archived')
for rec in bcatalog:
    raw = bench['postfix-benchmarks/' + rec['artifact_relative_path']]
    payload = json.loads(raw)['payload']
    check(sha(raw) == rec['artifact_file_sha256'] and sha(canonical(payload)) == rec['H'],
          'benchmark H ' + rec['id'])
    check(payload['approved_curve_digest'] == rec['expected_curve_digest'],
          'benchmark C ' + rec['id'])
    job = json.loads(gzip.decompress(bench['postfix-benchmarks/' + rec['run'] + '/' + rec['id'] + '.json.gz']))
    check(job['H'] == rec['H'] and job['expected_curve_digest'] == rec['expected_curve_digest']
          and job['status'] == 'PASS', 'benchmark receipt ' + rec['id'])
results['benchmark_catalog_accepted_bindings'] = len(bcatalog)
results['errors'] = errors
results['PASS'] = not errors
(OUT / 'integrity-audit.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps({'PASS': not errors, 'errors': errors, 'report': str(OUT / 'integrity-audit.json')}))
