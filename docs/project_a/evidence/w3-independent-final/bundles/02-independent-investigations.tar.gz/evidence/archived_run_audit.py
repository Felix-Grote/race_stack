"""Check raw archived JUnit/identity records against published summaries and Git."""
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile
import xml.etree.ElementTree as ET
import zipfile

p = Path('/workspace/forza-evidence-review/docs/project_a/evidence/w3-final-verification')
repo = '/workspace/forza-w3-audit'
sha = '17e4ec4e8fedfa736467d02f6204b04e8552decb'
with tarfile.open(p / 'fresh-17e4ec4e.tar.gz') as archive:
    fresh = {m.name.removeprefix('verification/'): archive.extractfile(m).read()
             for m in archive.getmembers() if m.isfile() and m.name.startswith('verification/')}
with zipfile.ZipFile(p / 'ci/original-push-artifact.zip') as archive:
    hosted = {n: archive.read(n) for n in archive.namelist()}
rows = []
for label, files in [('local_original', fresh), ('hosted_original', hosted)]:
    summary = json.loads(files['summary.json'])
    groups = {k:v for k,v in summary.items() if isinstance(v, dict) and 'tests' in v}
    raw = []
    for name, expected in groups.items():
        filename = 'source-free/results/w3-source-free.xml' if name == 'w3-source-free' else name + '.xml'
        tree = ET.fromstring(files[filename])
        suite = tree if tree.tag == 'testsuite' else tree.find('testsuite')
        actual = {k:int(suite.attrib[k]) for k in ['tests', 'failures', 'errors', 'skipped']}
        assert all(actual[k] == int(expected[k]) for k in actual), (label, name)
        testcases = list(suite.iter('testcase'))
        assert actual['tests'] == len(testcases)
        assert actual['failures'] == actual['errors'] == actual['skipped'] == 0
        assert not any(node.tag in ('failure', 'error', 'skipped') for node in suite.iter())
        raw.append(dict(group=name, **actual))
    before = json.loads(files['source-hashes-before.json'])
    after = json.loads(files['source-hashes-after.json'])
    assert before == after and len(before) == 138
    for path, digest in before.items():
        prefix = 'planner/global_planner/global_planner/global_racetrajectory_optimization/'
        if path.startswith(prefix):
            value = subprocess.check_output(['git', '-C',
                '/workspace/forza-audit-records/fresh-17e4ec4/checkout/' + prefix,
                'show', 'b1b38ecfefec7200d5bcb243f115af1d795b3766:' + path.removeprefix(prefix)])
        else:
            value = subprocess.check_output(['git', '-C', repo, 'show', sha + ':' + path])
        assert hashlib.sha256(value).hexdigest() == digest, (label, path)
    identity = json.loads(files['build-identity.json'])
    assert str(identity).find(sha) >= 0
    rows.append(dict(label=label, groups=len(raw), tests=sum(r['tests'] for r in raw),
                     functional_JUnit=raw, source_hashes_exact_Git=len(before),
                     source_hashes_before_after_identical=True))
    assert rows[-1]['groups'] == 27 and rows[-1]['tests'] == 591
result = dict(PASS=True, runs=rows,
              scope='Read-only raw archived execution records; numerical tests were not rerun by this script.')
Path('/workspace/forza-audit-records/evidence/archived-run-audit.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'PASS': True, 'runs': [{k:v for k,v in r.items() if k != 'functional_JUnit'} for r in rows]}))
