"""Audit all published SHA256SUMS and files-sha256.json inventories."""
import hashlib
import json
from pathlib import Path
import re
import tarfile

repo = Path('/workspace/forza-evidence-review')
root = repo / 'docs/project_a/evidence'
rows = []
with tarfile.open(root / 'w3-final-verification/benchmarks/final-functional-17e4ec4e.tar.gz') as archive:
    archived_benchmark = {m.name.removeprefix('postfix-benchmarks/'): archive.extractfile(m).read()
                          for m in archive.getmembers() if m.isfile()}
for ledger in sorted([*root.rglob('SHA256SUMS'), *root.rglob('files-sha256.json')]):
    if ledger.name == 'SHA256SUMS':
        entries = []
        for line in ledger.read_text().splitlines():
            match = re.fullmatch(r'([0-9a-f]{64}) [ *](.+)', line)
            assert match, (ledger, line)
            digest, name = match.groups()
            entries.append((name, digest))
    else:
        data = json.loads(ledger.read_text())
        data = data.get('files', data)
        entries = [(name, rec if isinstance(rec, str) else rec['sha256'])
                   for name, rec in data.items()]
    bad = []
    for name, digest in entries:
        path = repo / name if name.startswith('docs/') else ledger.parent / name
        if ledger == root / 'w3-final-verification/benchmarks/SHA256SUMS':
            if name not in archived_benchmark or hashlib.sha256(archived_benchmark[name]).hexdigest() != digest:
                bad.append(dict(path=name, error='archived SHA256 mismatch or missing'))
        elif not path.is_file():
            bad.append(dict(path=name, error='missing'))
        elif hashlib.sha256(path.read_bytes()).hexdigest() != digest:
            bad.append(dict(path=name, error='sha256 mismatch'))
    rows.append(dict(ledger=str(ledger.relative_to(root)), entries=len(entries), errors=bad))
result = dict(ledger_count=len(rows), checked_entries=sum(r['entries'] for r in rows),
              PASS=not any(r['errors'] for r in rows), ledgers=rows,
              path_resolution='docs/ entries are repository-relative; final benchmark entries resolve in its published tar; others ledger-relative')
out = Path('/workspace/forza-audit-records/evidence/all-evidence-ledgers.json')
out.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k:v for k,v in result.items() if k != 'ledgers'}))
print(json.dumps([r for r in rows if r['errors']])[:4000])
