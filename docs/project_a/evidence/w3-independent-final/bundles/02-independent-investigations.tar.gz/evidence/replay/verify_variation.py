"""Reproduce report-comparison defect after genuine unchanged-policy proof execution."""
from dataclasses import asdict, replace
from fractions import Fraction
import hashlib
import json
import math
import os
from pathlib import Path
import time

from global_planner import route_artifact as artifact
from global_planner import route_validate as geometry_checker
from global_planner.route_compile import load_policy

root = Path(os.environ['REPLAY_ROOT'])
output = Path(os.environ['REPLAY_OUTPUT'])
version = os.environ['REPLAY_VERSION']
case = next(x for x in json.loads((root / 'catalog.json').read_text()) if x['case'] == 's0_route')
path = root / 'incoming' / case['relative_artifact']
raw = path.read_bytes()
payload = json.loads(raw)['payload']
assert payload['implementation'] == artifact.implementation_identity()
policy_root = Path(os.environ.get('REPLAY_POLICY_ROOT', str(root / 'policies')))
_, context, _ = load_policy(policy_root / 'synthetic_policy.json')
original_geometry = artifact.validate_geometry
original_dynamics = artifact.validate_dynamics
original_bounds = geometry_checker.interval_bounds
rows = []
for mode in ('outward_dynamics_ulp', 'genuine_geometry_refinement'):
    start = time.monotonic()
    calls = []
    changed = []

    def geometry(*args, **kwargs):
        if mode == 'genuine_geometry_refinement':
            leaf = payload['validation']['geometry']['intervals'][0]
            target_coeff = tuple(tuple(float(x) for x in row)
                                 for row in payload['curve']['coefficients'][leaf['segment']])
            low = Fraction(*leaf['exact_t0'])
            high = Fraction(*leaf['exact_t1'])

            def uncertain_once(coefficients, left, right):
                result = original_bounds(coefficients, left, right)
                given = tuple(tuple(float(x) for x in row) for row in coefficients)
                if not changed and given == target_coeff and left == low and right == high:
                    changed.append('genuine adaptive subdivision')
                    raise geometry_checker.BoundUncertain('independent conservative refinement')
                return result

            geometry_checker.interval_bounds = uncertain_once
        try:
            report = original_geometry(*args, **kwargs)
        finally:
            geometry_checker.interval_bounds = original_bounds
        assert report.status == 'PASS' and report.curve_digest == case['curve_digest']
        calls.append(dict(validator='geometry', actual_status=report.status,
                          intervals=len(report.intervals)))
        if mode == 'genuine_geometry_refinement':
            assert changed and len(report.intervals) > len(payload['validation']['geometry']['intervals'])
        return report

    def dynamics(*args, **kwargs):
        report = original_dynamics(*args, **kwargs)
        assert report.status == 'PASS' and report.curve_digest == case['curve_digest']
        calls.append(dict(validator='dynamics', actual_status=report.status))
        if mode == 'outward_dynamics_ulp':
            upper = math.nextafter(report.lap_time_upper_s, math.inf)
            report = replace(report, lap_time_upper_s=upper,
                             lap_time_error_s=max(report.lap_time_s - report.lap_time_lower_s,
                                                  upper - report.lap_time_s))
            changed.append('one ULP outward upper time enclosure')
        return report

    artifact.validate_geometry = geometry
    artifact.validate_dynamics = dynamics
    row = dict(mode=mode, version=version, H=case['H'], C=case['curve_digest'],
               input_sha256=hashlib.sha256(raw).hexdigest(), identity_exact=True)
    try:
        reference = artifact.load_reference(path, expected_H=case['H'], validation_context=context)
        row.update(status='PASS', producer_T_exact=reference.lap_time_s == payload['validation']['dynamics']['lap_time_s'])
        assert version == 'final' and row['producer_T_exact']
    except artifact.ArtifactError as exc:
        row.update(status='REJECTED', reason=str(exc))
        expected = ('dynamics' if mode == 'outward_dynamics_ulp' else 'geometry') + ' stored proof differs from independent replay'
        assert version == 'old' and str(exc) == expected
    assert [x['validator'] for x in calls] == ['geometry', 'dynamics']
    assert path.read_bytes() == raw and changed
    row.update(actual_validator_calls=calls, variation=changed,
               unchanged_authority=True, wall_s=time.monotonic() - start)
    rows.append(row)
    (output / 'deterministic-variation.json').write_text(json.dumps(rows, indent=2) + '\n')
    print(json.dumps(row), flush=True)
