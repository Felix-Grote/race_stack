#!/bin/bash
set -eo pipefail
source /opt/ros/humble/setup.bash
export PYTHONPATH=/work/retry-python
source /work/retry-install/setup.bash
export REPLAY_ROOT=/records/evidence/replay/final
export REPLAY_OUTPUT=/records/evidence/replay/final/results
export REPLAY_POLICY_ROOT=/work/retry-install/global_planner/share/global_planner/project_a/policies
export REPLAY_VERSION=final
exec /opt/project-a/bin/python3 /records/evidence/replay/verify_variation.py
