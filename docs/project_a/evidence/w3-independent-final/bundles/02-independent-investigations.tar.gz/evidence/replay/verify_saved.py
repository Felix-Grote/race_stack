"""Independent actual saved-artifact revalidation under literal Git module bytes."""
from dataclasses import asdict
import hashlib
import json
import math
import os
from pathlib import Path
import struct
import time

from global_planner.route_artifact import ArtifactError, implementation_identity, load_reference
import global_planner.route_artifact as artifact_module
from global_planner.route_compile import load_policy
from global_planner.cyclic_retime import curve_digest

root = Path(os.environ.get('REPLAY_ROOT', '/review'))
output = Path(os.environ.get('REPLAY_OUTPUT', '/results'))
policy_root = Path(os.environ.get('REPLAY_POLICY_ROOT', str(root / 'policies')))
assert os.getuid() == 1000
visible_sources = [p for p in ('/workspace', '/src', '/work/src', '/work/build', '/work/optimizer')
                   if Path(p).exists()]
if os.environ.get('SOURCE_FREE_REQUIRED') == '1':
    assert not visible_sources, visible_sources
catalog = json.loads((root / 'catalog.json').read_text())
identity = implementation_identity()
rows = []
calls = []
def observe(name, actual):
    def wrapper(*args, **kwargs):
        report = actual(*args, **kwargs)
        calls.append(dict(validator=name, status=report.status,
                          curve_digest=report.curve_digest,
                          report_sha256=hashlib.sha256(json.dumps(asdict(report), sort_keys=True,
                              separators=(',', ':')).encode()).hexdigest()))
        return report
    return wrapper
artifact_module.validate_geometry = observe('geometry', artifact_module.validate_geometry)
artifact_module.validate_dynamics = observe('dynamics', artifact_module.validate_dynamics)
for case in catalog:
    start = time.monotonic()
    path = root / 'incoming' / case['relative_artifact']
    raw = path.read_bytes()
    payload = json.loads(raw)['payload']
    # Required matching exact implementation, independent H and installed-policy selection.
    assert payload['implementation'] == identity
    policy = 's6_coarse_policy.json' if case['case'] == 's6_competition_route' else 'synthetic_policy.json'
    selected_policy = policy_root / policy
    _, context, _ = load_policy(selected_policy)
    row = dict(case=case['case'], H=case['H'], C=case['curve_digest'],
               incoming_sha256=hashlib.sha256(raw).hexdigest(), identity_exact=True,
               module_origin=str(artifact_module.__file__), visible_source_paths=visible_sources,
               independent_policy_path=str(selected_policy),
               independent_policy_sha256=hashlib.sha256(selected_policy.read_bytes()).hexdigest())
    calls.clear()
    try:
        ref = load_reference(path, expected_H=case['H'], validation_context=context)
        assert ref.H == case['H'] and curve_digest(ref.ordered) == case['curve_digest']
        assert ref.geometry_report.status == ref.dynamics_report.status == 'PASS'
        for station in (-.137, 0., ref.length, 2 * ref.length + .137):
            sample = ref.sample(station)
            assert math.isfinite(sample.curvature) and sample.speed_mps > 0
        assert ref.lap_time_s == payload['validation']['dynamics']['lap_time_s']
        row.update(status='PASS', geometry='PASS', dynamics='PASS', main_T=ref.lap_time_s,
                   producer_T_exact=True,
                   fresh_geometry_equals_history=json.loads(json.dumps(asdict(ref.geometry_report))) == payload['validation']['geometry'],
                   fresh_dynamics_equals_history=json.loads(json.dumps(asdict(ref.dynamics_report))) == payload['validation']['dynamics'])
        if os.environ.get('REPLAY_EXPORT_ROS') == '1':
            from global_planner.route_legacy_export import export_waypoints
            from global_planner.readwrite_global_waypoints import read_global_waypoints
            from rclpy.serialization import deserialize_message, serialize_message
            from rosidl_runtime_py.convert import message_to_ordereddict
            parent = output / 'exports'
            parent.mkdir(exist_ok=True)
            result = export_waypoints(ref, step_m=.5, output_dir=parent / case['case'])
            assert result.status == 'PASS'
            groups = read_global_waypoints(str(parent / case['case']))
            assert len(groups) == 9
            cdr_bytes = []
            for message in groups:
                data = serialize_message(message)
                restored = deserialize_message(data, type(message))
                assert message_to_ordereddict(restored) == message_to_ordereddict(message)
                cdr_bytes.append(len(data))
            expected_float32 = struct.unpack('!f', struct.pack('!f', ref.lap_time_s))[0]
            assert groups[1].data == expected_float32
            assert groups[5].wpnts[-1].s_m == ref.length
            row.update(ROS_export='PASS', actual_reader_groups=9, actual_CDR_bytes=cdr_bytes,
                       legacy_main_float32=groups[1].data,
                       terminal_station=groups[5].wpnts[-1].s_m)
    except ArtifactError as exc:
        row.update(status='REJECTED', reason=str(exc))
    assert raw == path.read_bytes()
    row['actual_validator_calls'] = list(calls)
    assert [call['validator'] for call in calls] == ['geometry', 'dynamics']
    assert all(call['status'] == 'PASS' and call['curve_digest'] == case['curve_digest']
               for call in calls)
    row['unchanged_input'] = True
    row['wall_s'] = time.monotonic() - start
    rows.append(row)
    (output / 'saved-replay.json').write_text(json.dumps(rows, indent=2) + '\n')
    print(json.dumps(row), flush=True)
    if row['status'] == 'REJECTED':
        break

if os.environ.get('FINAL_CROSS_ID') == '1':
    oldroot = root.parent / 'old'
    old = json.loads((oldroot / 'catalog.json').read_text())[0]
    oldpath = oldroot / 'incoming' / old['relative_artifact']
    before = oldpath.read_bytes()
    calls.clear()
    try:
        load_reference(oldpath, expected_H=old['H'], validation_context=context)
        raise AssertionError('old implementation accepted by final loader')
    except ArtifactError as exc:
        assert exc.status == 'UNSUPPORTED'
        assert str(exc) == 'unsupported or changed kernel/checker/dependency identity'
        assert not calls and oldpath.read_bytes() == before
        (output / 'implementation-identity-negative.json').write_text(json.dumps(dict(
            status='PASS', old_artifact_H=old['H'], rejection=str(exc),
            actual_validator_calls=0, unchanged_input=True), indent=2) + '\n')
