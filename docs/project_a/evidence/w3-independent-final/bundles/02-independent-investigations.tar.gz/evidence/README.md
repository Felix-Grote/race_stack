# Independent evidence and provenance audit

Implementation audited: `17e4ec4e8fedfa736467d02f6204b04e8552decb`.
Companion evidence: `326aa3783ac2d757b6e714eadd14fdba96f595fd`.
This directory contains independent read-only audit output. No product branches,
source, or historical evidence have been modified by this audit.

## Completed checks

- `integrity-audit.json`: all 29 publication hashes, all six archive publication
  entries, all 186 historical portability hashes, and every final archive member
  match. Fresh bundle: 405 files; portability: 64 files; final benchmark: 1,056
  files. Archive paths are unique and contain no symlink/hardlink traversal.
- `final-artifact-api.json`, `final-push-run-api.json`, and old counterparts:
  live GitHub API confirms original ZIP digest, size, artifact/run association,
  literal implementation head, successful completed push, and non-expiration.
  Final ZIP: artifact 12067848728, run 38945204845, 9,327,825 bytes, SHA256
  `5ba01962bd2cd39ce8f9742d3a2464d1f5d086cd42ad06448c6bf5bb7fe4a180`.
  Old ZIP: artifact 12063605159, run 38934109447, 9,280,836 bytes, SHA256
  `05bc2b23b3e5f71bdea3cc9d729f779549af66e0cfe8674de59c1d6c2fb0b3d9`.
- All nine controlled hosted H values were recomputed from canonical payloads;
  C values were recomputed from coefficient/owner/q/route/numeric authority.
  They match original compile and validation receipts, campaign, envelope,
  externally retained catalog, and unchanged portability input bytes. All 58
  final benchmark accepted artifacts match catalog bytes/H/C and worker receipts.
- `all-evidence-ledgers.json`: 40 ledgers and 3,412 entries PASS, including W1/W2
  independent red findings, original A08 campaign, A09, and final bundles.
  Repository-relative and archive-relative inventories are resolved explicitly.
- `archived-run-audit.json`: both original local and hosted raw JUnit contain
  exactly 591 cases across 27 groups, no failure/error/skipped nodes, and 138
  source identities equal before/after and exact literal Git/submodule objects.
- `source-provenance-audit.json`: accepted W2 is an ancestor of actual W2 merge,
  whose complete tree equals accepted W2. Final implementation descends from it;
  evidence descends from final implementation. All 95 protected entries and
  gitlinks remain byte/object identical. The exact research diff is 1,826 files,
  716,864 added lines and 47 deleted lines. Byte categories are recorded.
- `research-duplication-inventory.json`: 2,384 evidence paths total 196,450,614
  bytes, comprising 1,573 distinct Git blobs totaling 183,351,306 bytes. There
  are 172 groups of duplicate whole-file blobs and 13,099,308 repeated tree bytes.
  This is uncompressed content size, not actual Git pack storage. Internal
  archive duplication requires separate interpretation; no evidence was deleted.
- `original-crosshost-comparison.json`: all nine original local/hosted H/C
  pairs differ. Maximum coefficient delta 2.789873582587782e-9; maximum producer
  time delta 6.014596927172988e-7 s. Static authority inputs match. CPU/BLAS cause
  remains unproven.

## Replay status

`replay/` has exact module bytes exported independently from literal old and
final Git commits, original hosted artifacts, separately retained controlled
H/C catalogs, and independent policy selections. The harness requires exact
payload implementation identity before calling the loader; it observes both
actual validators without changing their arguments or return values. The actual
old 811bd708 catalog completed 9/9 PASS on this machine, with byte-identical fresh
reports. The original retained machine-dependent rejection is therefore not
claimed universally reproducible on the current host. Deterministic conservative
numeric/refinement controls will independently test the underlying comparator.
The final nine-case campaign is running under the actual ordinary install and
independently installed policy resources, with reader/CDR checks on every case.
The shared probe container has source mounts visible; this process campaign is
not represented as source-free. The separate fresh source-free release suite
provides that additional installation-closure evidence.

Two preparation errors selected system Python instead of the pinned virtualenv;
both failed at SciPy import before any numerical execution. Their logs and
description are preserved under `replay/`. The correct interpreter is
`/opt/project-a/bin/python3`.

This integrity audit establishes retained bytes and provenance. It is not an
independent numerical W3 acceptance verdict or physical vehicle certification.
