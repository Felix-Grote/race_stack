"""Read-only Git tree, ancestry and size audit."""
import collections
import json
from pathlib import Path
import subprocess

REPO = '/workspace/forza-w3-audit'
OUT = Path('/workspace/forza-audit-records/evidence')
W2 = 'fe53365f86d660b4f6d4389925f9810cf33d41b3'
MERGE = '9fae5faed6ca62e0c943b6290babc50638477d9b'
W3 = '17e4ec4e8fedfa736467d02f6204b04e8552decb'
EVIDENCE = '326aa3783ac2d757b6e714eadd14fdba96f595fd'
FRESH = '/workspace/forza-audit-records/fresh-17e4ec4/checkout'


def git(*args):
    return subprocess.check_output(['git', '-C', REPO, *args])


def tree(sha):
    out = {}
    for entry in git('ls-tree', '-r', '-z', '--long', sha).split(b'\0'):
        if not entry:
            continue
        info, name = entry.split(b'\t', 1)
        mode, kind, blob, size = info.decode().split()
        out[name.decode()] = dict(mode=mode, kind=kind, blob=blob,
                                  bytes=None if size == '-' else int(size))
    return out


trees = {s: tree(s) for s in [W2, MERGE, W3, EVIDENCE]}
a = json.loads(Path('/workspace/forza-evidence-review/docs/project_a/evidence/'
                    'w3-final-verification/audits/postfix-committed-audit.json').read_text())
protected = []
for row in a['protected_paths']:
    path = row['path']
    protected.append(dict(path=path, accepted=trees[W2].get(path),
                          final=trees[W3].get(path),
                          exact=trees[W2].get(path) == trees[W3].get(path)))
changed = sorted(p for p in set(trees[MERGE]) | set(trees[W3])
                 if trees[MERGE].get(p) != trees[W3].get(p))
groups = collections.defaultdict(lambda: dict(files=0, final_bytes=0, added_lines=0,
                                             deleted_lines=0, binary_files=0))


def category(path):
    if '/evidence/' in path:
        if path.endswith(('.zip', '.tar.gz', '.gz')):
            return 'research_evidence_compressed'
        if path.endswith(('.json', '.jsonl')):
            return 'research_evidence_json'
        if path.endswith(('.xml', '.log', '.txt')):
            return 'research_evidence_logs_junit_text'
        return 'research_evidence_other'
    if '/test/' in path or '/tests/' in path:
        return 'tests_and_test_fixtures'
    if path.startswith('scripts/') or path.startswith('.github/') or path.startswith('docker'):
        return 'verification_harness_CI_container'
    if path.startswith('docs/'):
        return 'research_documentation'
    return 'planner_runtime_packaging_resources'


numstat = {}
for line in git('diff', '--numstat', MERGE, W3).decode().splitlines():
    added, removed, path = line.split('\t', 2)
    numstat[path] = (added, removed)
for path in changed:
    cat = groups[category(path)]
    cat['files'] += 1
    cat['final_bytes'] += trees[W3].get(path, {}).get('bytes') or 0
    added, removed = numstat[path]
    if added == '-':
        cat['binary_files'] += 1
    else:
        cat['added_lines'] += int(added)
        cat['deleted_lines'] += int(removed)

ancestry = {}
for older, newer in [(W2, MERGE), (MERGE, W3), (W3, EVIDENCE)]:
    ancestry[older + ' -> ' + newer] = subprocess.call(
        ['git', '-C', REPO, 'merge-base', '--is-ancestor', older, newer]) == 0
pins = {s: {p: r['blob'] for p, r in trees[s].items() if r['mode'] == '160000'}
        for s in trees}
recursive_status = subprocess.check_output(['git', '-C', FRESH, 'submodule', 'status', '--recursive']).decode()
recursive_rows = []
for line in recursive_status.splitlines():
    marker = line[0]
    commit, path = line[1:].split()[:2]
    parent_path = max((p for p in pins[W2] if path.startswith(p + '/')),
                      key=len, default=None)
    if path in pins[W2]:
        expected = pins[W2][path]
    else:
        assert parent_path
        nested = path.removeprefix(parent_path + '/')
        parent_commit = pins[W2][parent_path]
        expected = subprocess.check_output(['git', '-C', FRESH + '/' + parent_path,
                                            'rev-parse', parent_commit + ':' + nested]).decode().strip()
    recursive_rows.append(dict(path=path, actual=commit, accepted_W2_expected=expected,
                               exact=marker == ' ' and commit == expected))
all_unique = {row['blob']: row['bytes'] for s in [W3, EVIDENCE]
              for row in trees[s].values() if row['kind'] == 'blob'}
result = dict(implementation=W3, evidence=EVIDENCE, accepted_W2=W2,
              actual_W2_merge=MERGE, ancestry=ancestry,
              W2_merge_tree_identical_accepted=trees[W2] == trees[MERGE],
              W2_merge_parents=git('show', '-s', '--format=%P', MERGE).decode().strip().split(),
              protected_count=len(protected), protected=protected,
              protected_all_exact=all(p['exact'] for p in protected),
              top_level_gitlinks=pins,
              gitlinks_exact=all(pins[W2] == p for p in pins.values()),
              recursive_pin_status=recursive_status,
              recursive_pins=recursive_rows,
              all_seven_recursive_pins_exact=len(recursive_rows) == 7 and all(r['exact'] for r in recursive_rows),
              initial_research_diff=dict(files=len(changed), categories=dict(groups),
                                         added_lines=sum(x['added_lines'] for x in groups.values()),
                                         deleted_lines=sum(x['deleted_lines'] for x in groups.values()),
                                         summed_final_changed_file_bytes=sum(x['final_bytes'] for x in groups.values())),
              W3_and_evidence_unique_tree_blob_bytes=sum(all_unique.values()),
              W3_and_evidence_unique_tree_blobs=len(all_unique),
              scope='Tree-byte sizes are uncompressed Git object content; no claim of packfile storage size.')
result['PASS'] = all(ancestry.values()) and result['W2_merge_tree_identical_accepted'] and result['protected_all_exact'] and result['gitlinks_exact'] and result['all_seven_recursive_pins_exact']
(OUT / 'source-provenance-audit.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['protected','top_level_gitlinks','recursive_pin_status']}))
