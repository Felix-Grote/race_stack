# Independent benchmark/numerical review of 17e4ec4

Scope: read-only review of the A08 benchmark harness, retained authority and numerical/resource evidence. This is not an overall W3 acceptance verdict.

## Completed independent checks

- `sha256sum -c SHA256SUMS` passed all 966 listed benchmark evidence paths. `sha256-check.log` retains output.
- `python /workspace/forza-audit-records/benchmarks/check_integrity.py` independently checked seven numerical campaigns: frozen job count/identity/policy, ledger equality to summary, compressed result hashes/statuses, every `files.json` original and stored hash/size, PASS report presence and approved fixture-byte identities. A separate check included seven failed collector-probe originals. All 939 indexed original files verify, with all 117 numerical planner attempts plus two separate CPU replays accounted for.
- Final primary 92 + separately declared matched-mesh 4 = 96: 58 PASS, 28 stock-preparation failures, eight resource rejections and two condition rejections. Original exploratory 21 attempts are preserved separately. Their changed helper/worker identities are explicitly documented; their timings are not controlled performance evidence.
- `OPENBLAS_NUM_THREADS=1 python /workspace/forza-audit-records/benchmarks/check_numeric.py` independently evaluated all 58 accepted actual coefficient sets with Gaussian96 quadrature, verified every saved per-edge distance/time enclosure against independently evaluated values, and recomposed all 30 repaired raw→adapted authorities with exact rational arithmetic. Max length discrepancy 2.8422e-14 m, model-time 9.9476e-14 s, energy 4.4409e-16 1/m. Every composition satisfies its recorded per-piece error bound; maximum exact rational coordinate-sum error 2.7988e-15 m. This arithmetic run used host NumPy 2.3.5 and is a diagnostic, not independent continuous recertification.

## Fairness and authority findings

The comparator's explicit preparation scalarization is confined to an authenticated isolated namespace; pinned source files remain untouched. The bounded IQP driver preserves source equations and original `create_raceline` coefficients, with actual segment/t/q history. Both variants use the same declared legal geometry, numerical width .30 m, physical body .10/.10/.12 m plus .01 m margin, curvature/resource policy and surface-specific synthetic model. Legacy smoothing, transported widths and native parameterization remain substantive method differences; same-input equation parity isolates equations only. Matched .52/.53 legacy runs exist separately, so .50 legacy need never be presented as a matched comparison to .52 new.

Certificates apply only to the declared algebraically subdivided/reseamed binary64 repaired output. Raw legacy geometry and native continuous speed recovery are explicitly UNSUPPORTED. Common retimer model time is not a native legacy lap time. This is properly distinguished in actual result records and current documentation. Raw→adapted error is extremely small but identities and certificates must remain separate.

Measured quality does not demonstrate a universally better numerical objective: S0 circle final actual curvature energies increase about 11.04% new / 10.09% repaired from the seed; S2 upper repaired also increases actual energy. Convergence is TUM surrogate convergence, not minimum curvature/time or global optimality. Current documentation says so. No lap-time-benefit or real-car conclusion follows.

## Resource/conditioning findings and limitations

The retained .50 m S6 new failure is a severe condition(A) rejection with no candidate, whereas .52 and .53 are accepted separately under unchanged resource/proof limits. .53's about 3.895e10 condition is six orders larger than .52's about 2.145e4, even though both meet the explicit 1e12 guard. Default .40 m and finer meshes exceed the unchanged 512-point budget; .52 success establishes this fixture's feasibility under an explicit mesh policy, not general competition-course scalability. Origin controls in the retained campaign are only S0 controls; the retained record establishes no general S6 origin/seed sensitivity claim. Additional predeclared initial-fit diagnostics are stored alongside this report.

Peak RSS records are largest-process high-water marks, not simultaneous total descendant memory or exclusive per-phase allocations. Nested phases must not be summed. External wait4 CPU replays correctly include reaped numerical descendants and were calibrated; their concurrent wall times are not isolated performance evidence. The usual primary/matched wall timings are the controlled historical wall observations, with only two repeats.

Wording precision: `benchmark_w3.py` campaign bootstrap sets RLIMIT_CPU=240 on the worker process. This is not an aggregate descendant CPU watchdog; numerical children have separate 20 s CPU bounds. The external process-group wall watchdog is 240 s, and observed one-thread sequential execution produces total CPU near wall time. Report the enforced CPU scope precisely; no measured bound violation is present.

Historical A08 immutable outputs belong to the A07 implementation identity, whereas current head changes `route_artifact.py` for portable proof replay. Their H/C are frozen historical products. Fresh current-head publication/load execution must use newly produced current-identity references; reinterpreting old A08 artifacts as current-identity accepted artifacts is unsupported. Numerical solver/model/validator source bytes remain unchanged, so saved polynomial arithmetic and original algorithm comparisons remain meaningful.

All three tracked map archives retain original controls' hashes, nine groups, duplicated terminal XY and stored-station/linear-u arithmetic. GLC_smile_small closing main acceleration remains -19.5200234232 m/s². These archives carry no approved physical/legal/model authority and are compatibility diagnostics only.

## Fresh pinned diagnostics

The unchanged saved-output oracle was independently executed in the rebuilt pinned image against literal 17e4ec4 source: primary141/141 and matched10/10 PASS (`pinned-primary-audit.json`, `pinned-matched-audit.json`). This rechecks A04 trace/periodic-fit authority and saved metric/energy/time arithmetic. It is not a fresh artifact load under the changed implementation identity.

Twenty predeclared initial-fit sensitivity controls completed across four cyclic occurrence origins and five requested spacings; all original legal sides, seeds, surface identities and per-occurrence caps remain fixed. Results are initial-fit diagnostics only:

| Spacing | Initial N | cond(A) range across four origins | Smallest metric interval range (m) | Guard accepts |
| --- | ---: | ---: | ---: | ---: |
| .50 |490|9.7238e18–9.7272e18|2.82895797e-7–2.82895812e-7|0/4|
| .51 |482|8194–8224|.045234–.045277|4/4|
| .52 |472|12818–12869|.040271–.040314|4/4|
| .53 |464|21364–21461|.035110–.035153|4/4|
| .54 |456|36159–36345|.030348–.030391|4/4|

The .50 near-coincident semantic/uniform nodes therefore reproduce across these cyclic origins. Coarse initial fits remain well below the unchanged guard. This does not establish full-solve sensitivity or arbitrary seed robustness: historical .53's maximum3.895e10 occurs later in optimization. Original frozen manifest, script, raw results and summary are retained. At18 completed jobs the original fit container was deliberately stopped when concurrent vfs container copies exhausted disk; the remaining two predeclared jobs ran unchanged numerical equations in the shared pinned container. No attempts were discarded or reclassified. All timings are contended and descriptive.

A seven-job current-identity functional replay was frozen before launch: S0 new/stock/repaired.4 and S6 new.5/.52/.53 plus repaired.52. Numerical/resource/proof policies and archived fixture/model bytes remain fixed; artifact publication, dual independent replay and fine queries are enabled, ROS export disabled. Before any worker launched, output/input mount prefixes were amended solely to reuse the parent-created shared container. Both original unexecuted queued manifest and amendment provenance survive. Shared cgroup aggregate limits are6GiB/512PIDs with2CPUs, versus historical isolated4GiB/256; per-worker3GiB address-space/240s wall+processCPU and per-child2GiB/20s remain unchanged. This run is functional evidence, not a matched performance/resource replay. Actual isolation is retained in `shared-runtime-isolation.json`.

The initial seven-job functional replay completed with two PASS (new/adapted repaired S0), the required stock shape failure, the required S6.50 condition rejection, and three coarse-S6 QP wall resource rejections. None of the latter is promoted to a successful current-head full path: .52 new fails its first bounded QP, .53 new reaches a later retained-input condition about3.894758e10 before QP wall exhaustion, and repaired.52 also hits the20s QP wall bound. Their consumed child CPU is below the20CPU allowance while concurrent numerical work shares the CPUs. No condition guard or proof/resource bound was raised; failures, partial traces and phase progress remain retained. `fresh-campaign-audit.json` provides exact IDs/statuses and new controlled S0 H/C identities. A separate three-job second-repeat retry manifest is prepared under `fresh-retry/` for launch after contention clears; it has not yet run. ROS was not executed by this replay.
