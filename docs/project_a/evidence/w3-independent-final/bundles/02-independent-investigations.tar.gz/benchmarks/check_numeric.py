import gzip,json,math,sys
from fractions import Fraction as F
from pathlib import Path
import numpy as np
root=Path('/workspace/forza-w3-audit/docs/project_a/evidence/w3-benchmarks')
x,w=np.polynomial.legendre.leggauss(96); t=(x+1)/2; w=w/2
out={'scope':'Independent saved-polynomial arithmetic, host NumPy '+np.__version__+'; not continuous-validator acceptance','rows':[],'maxima':{}}
for run in ('primary','matched-coarse'):
 p=root/run
 for row in json.loads((p/'summary.json').read_bytes())['attempts']:
  if row['status']!='PASS': continue
  d=json.loads(gzip.decompress((p/row['result_file']).read_bytes())); c=np.array(d['coefficients']);
  v=c[:,:,1,None]+2*c[:,:,2,None]*t+3*c[:,:,3,None]*t*t; a=2*c[:,:,2,None]+6*c[:,:,3,None]*t
  lengths=np.sqrt(np.sum(v*v,axis=1))@w
  energy=math.fsum(((v[:,0]*a[:,1]-v[:,1]*a[:,0])**2/np.sum(v*v,axis=1)**2.5)@w)
  lengths_sum=math.fsum(lengths)
  knots=d['retime']['profile']['knots']; distances=[]; times=[]
  for i,k in enumerate(knots):
   nxt=knots[(i+1)%len(knots)]; end=nxt['t'] if nxt['segment']==k['segment'] else 1.; tt=k['t']+(end-k['t'])*t; cc=c[k['segment']]
   vv=cc[:,1,None]+2*cc[:,2,None]*tt+3*cc[:,3,None]*tt*tt
   ds=float(np.sqrt(np.sum(vv*vv,axis=0))@w)*(end-k['t']); e=d['dynamics']['edges'][i]
   assert e['distance_lower_m']<=ds<=e['distance_upper_m']
   distances.append(ds); times.append(2*ds/(math.sqrt(k['u'])+math.sqrt(nxt['u'])))
  lap=math.fsum(times); assert d['dynamics']['lap_time_lower_s']<=lap<=d['dynamics']['lap_time_upper_s']
  e={'length_error_m':abs(lengths_sum-d['length_m']),'energy_error_per_m':abs(energy-d['curvature_energy_final_per_m']),'lap_time_error_s':abs(lap-d['lap_time_s']),'profile_distance_error_m':abs(math.fsum(distances)-lengths_sum)}
  if row['variant']=='repaired':
   l=d['legacy']; q=l['actual_final_q']; raw=l['actual_final_coefficients']; period=q[-1]-q[0]; records=l['algebraic_subdivision']
   records=sorted(records,key=lambda z:z['source_q_interval'][0]-math.floor(sum(z['source_q_interval'])/(2*period))*period)
   assert len(records)==len(c)
   maximum=0.
   for cc,z in zip(c,records):
    i=z['source_segment']; first,last=z['source_q_interval']; start=(F(first)-F(q[i]))/(F(q[i+1])-F(q[i])); step=(F(last)-F(first))/(F(q[i+1])-F(q[i])); error=F(0)
    for axis in (0,1):
     for j in range(4):
      exact=sum(F(raw[i][axis][k])*math.comb(k,j)*start**(k-j)*step**j for k in range(j,4)); error+=abs(F(float(cc[axis,j]))-exact)
    assert error<=F(z['coordinate_composition_roundoff_bound_m']), (row['id'],i)
    maximum=max(maximum,float(error))
   e['verified_exact_rational_composition_error_m']=maximum
  assert max(e.values())<1e-8,(row['id'],e)
  out['rows'].append({'id':row['id'],**e})
  for k,v in e.items(): out['maxima'][k]=max(out['maxima'].get(k,0),v)
Path('/workspace/forza-audit-records/benchmarks/independent-numeric.json').write_text(json.dumps(out,indent=2))
print(json.dumps({'rows':len(out['rows']),'maxima':out['maxima']},indent=2))
