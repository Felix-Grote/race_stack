import json,time,hashlib,sys
from pathlib import Path
import numpy as np
from global_planner.route_input import validate_route
from global_planner.route_corridor import seed_curve,resample_ordered,portal_crossings
from global_planner import iqp_route_adapter as a
root=Path('/records/benchmarks'); manifest=json.loads((root/'s6-condition-resume-manifest.json').read_bytes()); assert hashlib.sha256(Path(__file__).read_bytes()).hexdigest()==manifest['script_sha256']
for job in manifest['jobs']:
 start=time.monotonic(); row=dict(job)
 try:
  p=json.loads(Path('/frozen/docs/project_a/evidence/w3-benchmarks/primary/inputs/S6-240m.json').read_bytes()); i=job['origin_occurrence_shift']; p['occurrences']=p['occurrences'][i:]+p['occurrences'][:i]; p['transitions']=p['transitions'][i:]+p['transitions'][:i]; p['gate_sequence']=[z['id'] for z in p['transitions']];p['finish']=p['gate_sequence'][-1];p['initialization']['occurrence_id']=p['occurrences'][0]['id']; p['initialization']['zone']=p['transitions'][-1]['support'];p['route_id']+='-audit-origin-'+str(i)
  route=validate_route(p); seed=seed_curve(route); portal_crossings(seed); line=resample_ordered(seed,job['spacing_m']); q=tuple(v.q for v in line)+(seed.period,); owners=tuple((v.occurrence_id,v.surface_id) for v in line); policy=a.SolverPolicy(spacing_m=job['spacing_m'])
  ordered,matrix,normals,usage=a._fit(route,[v.xy for v in line],q,owners,seed.curve.policy,policy,policy.qp_wall_seconds)
  condition=float(np.linalg.cond(matrix)); stations=[v.s for v in line]+[seed.curve.length]; delta=np.diff(stations); dq=np.diff(q)
  row.update(status='INITIAL_FIT_DIAGNOSTIC_ONLY',route_sha256=route.digest,seed_length_m=seed.curve.length,n=len(line),condition_A=condition,condition_guard_accepts=condition<=policy.max_condition,min_metric_interval_m=float(min(delta)),max_metric_interval_m=float(max(delta)),min_q_interval=float(min(dq)),max_q_interval=float(max(dq)),fit_resources=usage)
 except Exception as exc: row.update(status='PROBE_FAILURE',reason=repr(exc))
 row['wall_seconds']=time.monotonic()-start
 with (root/'s6-condition-results.jsonl').open('a') as f:f.write(json.dumps(row,sort_keys=True)+'\n');f.flush()
 print(json.dumps(row),flush=True)
