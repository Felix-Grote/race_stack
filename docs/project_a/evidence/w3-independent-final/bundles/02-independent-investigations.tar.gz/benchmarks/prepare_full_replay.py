"""Freeze a fresh full 92+4 replay of saved legal routes and unchanged job policies."""
import argparse,copy,hashlib,json,subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--output',required=True);p.add_argument('--container-output',default='/audit/full-replay');p.add_argument('--without-ros',action='store_true');args=p.parse_args()
repo=Path(args.repo).resolve();out=Path(args.output).resolve();out.mkdir(parents=True,exist_ok=False);ev=repo/'docs/project_a/evidence/w3-benchmarks';sha=lambda b:hashlib.sha256(b).hexdigest();source=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip();status=subprocess.check_output(['git','-C',str(repo),'status','--short'],text=True);gitlinks=subprocess.check_output(['git','-C',str(repo),'submodule','status','--recursive'],text=True).splitlines();expected={}
for name in ('primary','matched-coarse'):
 target=out/name;(target/'inputs').mkdir(parents=True);m=json.loads((ev/name/'manifest.json').read_bytes());historical_source=m['source_sha']; originalsha=sha((ev/name/'manifest.json').read_bytes());oldsummary=json.loads((ev/name/'summary.json').read_bytes())['attempts'];expected[name]={z['id']:z['status'] for z in oldsummary}
 for j in m['jobs']:
  route_name=j['scenario']+'.json';(target/'inputs'/route_name).write_bytes((ev/name/'inputs'/route_name).read_bytes());j.update(output=args.container_output+'/'+name,route=args.container_output+'/'+name+'/inputs/'+route_name)
  if args.without_ros:j['export_ros']=False
 m.update(source_sha=source,source_status=status,gitlinks=gitlinks,independent_replay_of_manifest_sha256=originalsha,historical_producer_source_sha=historical_source,independent_replay_scope='fresh exact-source numerical/artifact replay; old frozen routes/models/limits; no claim of matching historical H or isolated wall time')
 for filename,key in (('benchmark_w3.py','script_sha256'),('w3_benchmark_support.py','support_sha256')):
  current=sha((repo/'scripts/project_a'/filename).read_bytes());assert current==m[key], 'worker/support changed; review replay protocol before execution'
 if name=='matched-coarse':m['independent_replay_paired_primary_manifest_sha256']=sha((out/'primary/manifest.json').read_bytes())
 (target/'manifest.json').write_text(json.dumps(m,sort_keys=True,separators=(',',':')));(target/'run_manifest.py').write_bytes((ev/'matched-coarse/run_manifest.py').read_bytes())
(out/'expected-statuses.json').write_text(json.dumps(expected,indent=2));print(json.dumps({'source_sha':source,'source_status':status,'jobs':sum(len(v) for v in expected.values()),'output':str(out)},indent=2))
