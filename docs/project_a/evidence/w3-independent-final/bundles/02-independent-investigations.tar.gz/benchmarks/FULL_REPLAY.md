A full current-head numerical/artifact/ROS replay, preserving all 92+4 cases and failures, can use the unchanged bounded supplement runner for each separately frozen corpus. Use a recursive clean final-head checkout and a fresh writable output. `prepare_full_replay.py` refuses changed worker/support bytes, captures current source/gitlinks, retains each original parent manifest hash, rewrites only execution paths and optional ROS flag, and copies the exact archived route bytes. It does not substitute historical H/C for freshly generated authority. Review the fresh manifests before launch.

Example preparation (replace `FINAL_RECURSIVE_CHECKOUT` with the final checkout):

```bash
python /workspace/forza-audit-records/benchmarks/prepare_full_replay.py \
  --repo FINAL_RECURSIVE_CHECKOUT \
  --output /workspace/forza-audit-records/benchmarks/full-replay \
  --container-output /audit/full-replay
```

Example execution after a separately verified ordinary ROS install at `ROS_INSTALL_PREFIX` visible inside the source mount:

```bash
docker --host=unix:///var/run/docker.sock run --rm \
  --network none --read-only --cap-drop ALL --security-opt no-new-privileges \
  --pids-limit 256 --memory 4g --cpus 2 --user 1000:1000 \
  --tmpfs /tmp:rw,nosuid,nodev,size=256m,mode=1777 \
  -e PYTHONDONTWRITEBYTECODE=1 -e OPENBLAS_NUM_THREADS=1 -e OMP_NUM_THREADS=1 \
  --mount type=bind,src=FINAL_RECURSIVE_CHECKOUT,dst=/src,readonly \
  --mount type=bind,src=/workspace/forza-audit-records/benchmarks,dst=/audit \
  project-a-humble:w0 /bin/bash -c '
    source /opt/ros/humble/setup.bash &&
    source ROS_INSTALL_PREFIX/setup.bash &&
    export PYTHONPATH=/src/planner/global_planner:/src/scripts/project_a:$PYTHONPATH &&
    python /audit/full-replay/primary/run_manifest.py \
      --manifest /audit/full-replay/primary/manifest.json \
      --worker /src/scripts/project_a/benchmark_w3.py &&
    python /audit/full-replay/matched-coarse/run_manifest.py \
      --manifest /audit/full-replay/matched-coarse/manifest.json \
      --worker /src/scripts/project_a/benchmark_w3.py'
```

If only numerical/artifact reproduction is desired, use `--without-ros` in preparation and omit install sourcing; report ROS as unexecuted in that run. Fresh primary+matched results must be compared by job ID to `expected-statuses.json`, not merely by runner exit zero. Original negative outcomes are required and must not disappear. Repeat source-free installed/ROS acceptance separately for any final source change; the replay imports planner modules from explicit source.

For exact original historical primary generator protocol, see `/workspace/forza-w3-audit/docs/project_a/evidence/w3-benchmarks/REPRODUCE.md`; it runs the fixture generator and all initial controls as well. The saved-corpus runner above replays all 96 planner attempts but does not rerun those campaign-level controls. The 13 benchmark regression tests include same-input equation parity, checker shape repair, original archive arithmetic and fixture preflight and should be included in the final acceptance suite.

Concrete numerical/artifact-only replay in the currently running shared environment (new output must not exist; this command is prepared, not executed):

```bash
python /workspace/forza-audit-records/benchmarks/prepare_full_replay.py \
  --repo /workspace/forza-audit-records/fresh-17e4ec4/checkout \
  --output /workspace/forza-audit-records/benchmarks/reproduction-96 \
  --container-output /records/benchmarks/reproduction-96 --without-ros

docker --host=unix:///var/run/docker.sock exec \
  -e PYTHONPATH=/frozen/planner/global_planner:/frozen/scripts/project_a \
  -e OPENBLAS_NUM_THREADS=1 -e OMP_NUM_THREADS=1 forza-independent-probes \
  /bin/bash -c '
    python /records/benchmarks/reproduction-96/primary/run_manifest.py \
      --manifest /records/benchmarks/reproduction-96/primary/manifest.json \
      --worker /frozen/scripts/project_a/benchmark_w3.py &&
    python /records/benchmarks/reproduction-96/matched-coarse/run_manifest.py \
      --manifest /records/benchmarks/reproduction-96/matched-coarse/manifest.json \
      --worker /frozen/scripts/project_a/benchmark_w3.py'
```

This concrete command selects the frozen initial17e4 audit head. To test a remediated final head, change both `--repo` and the container's PYTHONPATH/worker source mount to the final recursive checkout, freeze its literal committed SHA, and retain a separate fresh output. No current-run H may be promoted into a different implementation identity.
