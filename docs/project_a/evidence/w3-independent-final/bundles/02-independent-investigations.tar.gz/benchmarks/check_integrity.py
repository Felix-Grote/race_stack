import gzip,hashlib,json,collections
from pathlib import Path
root=Path('/workspace/forza-w3-audit')
ev=root/'docs/project_a/evidence/w3-benchmarks'
sha=lambda b:hashlib.sha256(b).hexdigest()
result={'source': '17e4ec4e8fedfa736467d02f6204b04e8552decb','runs':{},'issues':[]}
for run in ('primary','matched-coarse','pilot','coarse-retry','ros-probe','s4-probe','cpu-replay'):
 p=ev/run; m=json.loads((p/'manifest.json').read_bytes()); summary=json.loads((p/'summary.json').read_bytes())['attempts']; ledger=[json.loads(x) for x in (p/'attempts.jsonl').read_text().splitlines()]
 assert ledger==summary,run
 jobs={j['id']:j for j in m['jobs']}; assert len(jobs)==len(m['jobs'])==len(summary)
 sources={}
 for name,key in (('benchmark_w3.py','script_sha256'),('w3_benchmark_support.py','support_sha256')):
  sources[name]=sha((root/'scripts/project_a'/name).read_bytes())==m[key]
 index=json.loads((p/'files.json').read_bytes()); n=0; raw_bytes=0
 for f in index:
  stored=(p/f['evidence_relative_path']).read_bytes(); assert len(stored)==f['stored_bytes']; assert sha(stored)==f['evidence_sha256']
  raw=gzip.decompress(stored) if f['compression']=='gzip-mtime0' else stored
  assert len(raw)==f['original_bytes']; assert sha(raw)==f['original_sha256']; n+=1; raw_bytes+=len(raw)
 for row in summary:
  job=jobs[row['id']]; data=json.loads(gzip.decompress((p/row['result_file']).read_bytes())); assert sha((p/row['result_file']).read_bytes())==row['result_sha256']
  assert data['id']==row['id']; assert data['status']==row['status']; assert job['solver_policy']==data['solver_policy']
  if row['status']=='PASS':
   assert data['geometry']['status']==data['dynamics']['status']=='PASS'; assert data['route_sha256']==sha((p/'inputs'/(row['scenario']+'.json')).read_bytes())
   if row['variant']=='repaired': assert data['legacy']['raw_legacy_geometry_authorization']['status']=='UNSUPPORTED'; assert data['legacy']['legacy_velocity']['status']=='UNSUPPORTED'
 result['runs'][run]={'jobs':len(jobs),'statuses':dict(collections.Counter(r['status'] for r in summary)),'indexed_files':n,'original_bytes':raw_bytes,'current_source_hash_matches_manifest':sources,'manifest_sha256':sha((p/'manifest.json').read_bytes())}
p=ev/'cpu-collector-probe'; index=json.loads((p/'files.json').read_bytes())
for f in index:
 stored=(p/f['evidence_relative_path']).read_bytes(); assert len(stored)==f['stored_bytes']; assert sha(stored)==f['evidence_sha256']
 raw=gzip.decompress(stored) if f['compression']=='gzip-mtime0' else stored
 assert len(raw)==f['original_bytes']; assert sha(raw)==f['original_sha256']
result['failed_collector_probe']={'original_files_verified':len(index),'planner_attempts':0}
result['total_indexed_original_files_verified']=len(index)+sum(z['indexed_files'] for z in result['runs'].values())
result['global_sha256sum_paths_verified']=sum(x.endswith(': OK') for x in Path('/workspace/forza-audit-records/benchmarks/sha256-check.log').read_text().splitlines())
print(json.dumps(result,indent=2))
(ev/'primary/controls.json').read_bytes()
for name,row in json.loads((ev/'primary/controls.json').read_bytes())['archival_software_assets'].items(): assert sha((root/'stack_master/maps'/name/'global_waypoints.json').read_bytes())==row['file_sha256']
Path('/workspace/forza-audit-records/benchmarks/independent-integrity.json').write_text(json.dumps(result,indent=2))
