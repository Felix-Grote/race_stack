"""Validate companion Git archive and measure research diff/new objects."""
import collections,hashlib,io,json,pathlib,subprocess,tarfile,time
P=pathlib.Path('/workspace/forza-audit-records/resume-evidence');R='/workspace/forza-w3-audit'
S='67fbcc8283e59649d38dc9318291634089df3741'; INITIAL='17e4ec4e8fedfa736467d02f6204b04e8552decb';BASE='9fae5faed6ca62e0c943b6290babc50638477d9b';COMP='676e59ab101e8209840e566e36c5daf0fd624381'; PREFIX='docs/project_a/evidence/w3-independent-review/'
def git(*args):return subprocess.check_output(['git','-C',R,*args])
def sha(x):return hashlib.sha256(x).hexdigest()
def obj(p):return git('show',COMP+':'+PREFIX+p)
ledger=json.loads(obj('files-sha256.json'));assert all(sha(obj(p))==h for p,h in ledger.items())
archive_rows=[]
for filename,manifestfile in [('initial-independent.tar.gz','MANIFEST.json'),('dirty-source-attempt/dirtyall-attempt-independent.tar.gz','dirty-source-attempt/MANIFEST.json')]:
 raw=obj(filename); manifest=json.loads(obj(manifestfile)); members=[]
 with tarfile.open(fileobj=io.BytesIO(raw)) as tar:
  for m in tar.getmembers():
   assert m.isfile() and not m.name.startswith('/') and '..' not in pathlib.PurePosixPath(m.name).parts,m.name
   data=tar.extractfile(m).read();members.append((m.name,len(data),sha(data)))
 assert len(members)==len({x[0] for x in members})
 expected={x['path']:(x['size_bytes'],x['sha256']) for x in manifest['files']}
 actual={p:(n,h) for p,n,h in members if p!='MANIFEST.json'}
 assert actual==expected
 assert dict((p,h) for p,n,h in members)['MANIFEST.json']==sha(obj(manifestfile))
 archive_rows.append(dict(archive=filename,sha256=sha(raw),stored_bytes=len(raw),payload_files=len(actual),payload_bytes=sum(n for n,h in actual.values()),regular_safe_unique_members=len(members),all_member_hashes_exact=True))
receipt=json.loads(obj('final-publication.json'));pr=json.loads((P/'pr3.json').read_bytes())
report=dict(PASS=True,companion_sha=COMP,ledger_entries=len(ledger),archives=archive_rows,publication_receipt=receipt,PR3_state=pr['state'],PR3_merged=pr['merged'],head_sha=pr['head']['sha'],base_sha=pr['base']['sha'],scope='Preservation integrity only; companion pending receipt must be updated after final accepted source gates.')
(P/'archive-audit.json').write_text(json.dumps(report,indent=2)+'\n')

def category(p):
 if '/evidence/' in p:return 'generated_or_retained_research_evidence'
 if '/test/' in p or '/tests/' in p:return 'tests_and_test_fixtures'
 if p.startswith(('scripts/','.github/','docker')):return 'verification_harness_CI_container'
 if p.startswith('docs/'):return 'research_documentation'
 return 'planner_runtime_packaging_resources'
measure=[]
for label,s,b in [('original_W3',INITIAL,BASE),('corrected67_W3',S,BASE),('companion_increment',COMP,S)]:
 cats=collections.defaultdict(lambda:dict(files=0,added_lines=0,deleted_lines=0,binary_files=0))
 for line in git('diff','--numstat','--no-renames',b,s).decode().splitlines():
  a,d,p=line.split('\t',2);x=cats[category(p)];x['files']+=1
  if a=='-':x['binary_files']+=1
  else:x['added_lines']+=int(a);x['deleted_lines']+=int(d)
 rev=(s+'\n^'+b+'\n').encode(); objects=git('rev-list','--objects',s,'^'+b).decode().splitlines();ids=[line.split()[0] for line in objects]
 check=subprocess.check_output(['git','-C',R,'cat-file','--batch-check=%(objecttype) %(objectsize)'],input=('\n'.join(ids)+'\n').encode()).decode().splitlines()
 bytype=collections.defaultdict(lambda:dict(objects=0,uncompressed_bytes=0))
 for line in check:
  typ,n=line.split();bytype[typ]['objects']+=1;bytype[typ]['uncompressed_bytes']+=int(n)
 start=time.monotonic();proc=subprocess.Popen(['git','-C',R,'-c','pack.threads=1','-c','core.compression=6','pack-objects','--stdout','--revs'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE);proc.stdin.write(rev);proc.stdin.close();h=hashlib.sha256();count=0
 while True:
  data=proc.stdout.read(1024*1024)
  if not data:break
  h.update(data);count+=len(data)
 err=proc.stderr.read().decode();assert proc.wait()==0,err
 measure.append(dict(label=label,base=b,head=s,categories=dict(cats),changed_files=sum(x['files'] for x in cats.values()),added_lines=sum(x['added_lines'] for x in cats.values()),deleted_lines=sum(x['deleted_lines'] for x in cats.values()),new_objects=dict(bytype),new_object_count=len(ids),standalone_incremental_pack_bytes=count,standalone_incremental_pack_sha256=h.hexdigest(),pack_elapsed_s=time.monotonic()-start))
result=dict(measurements=measure,git_version=git('--version').decode().strip(),pack_method='git -c pack.threads=1 -c core.compression=6 pack-objects --stdout --revs with HEAD and ^BASE, non-thin standalone incremental object pack. Measured compressed bytes are reproducible method-specific estimates, not a claim of hosted repository storage reduction.',scope='All research history is retained. File categories are path-based; runtime category includes packaging/resources and cannot be interpreted as pure executable LOC.')
(P/'research-size-measurements.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(archive_PASS=True,archives=archive_rows,size_measurements=[dict(label=r['label'],files=r['changed_files'],added_lines=r['added_lines'],new_objects=r['new_object_count'],pack_bytes=r['standalone_incremental_pack_bytes']) for r in measure])))
