# Resumed independent evidence audit

This read-only audit continues the preserved initial independent audit in
`../evidence/`. It does not make an acceptance decision or modify/push source.

## Immutable identities

- Initially reviewed implementation: `17e4ec4e8fedfa736467d02f6204b04e8552decb`.
- Historical final evidence: `326aa3783ac2d757b6e714eadd14fdba96f595fd`.
- Current pre-positive-speed-fix implementation examined here:
  `67fbcc8283e59649d38dc9318291634089df3741`.
- Independent companion archive examined here:
  `676e59ab101e8209840e566e36c5daf0fd624381`.
- W2 merge/development target: `9fae5faed6ca62e0c943b6290babc50638477d9b`.

## Completed provenance and preservation checks

`audit_hosted67.py` → `hosted67-audit.json` verifies the ORIGINAL literal-67 push
run 39038300516 and artifact 12104048523 through live GitHub API metadata. The ZIP
was retrieved through the connected GitHub download_workflow_artifact tool, after
ordinary CLI downloads encountered proxy CONNECT denial on the Azure blob host.
No network settings or TLS checks were changed. Native returned file ID:
`file_000000009678820a8cd45ccbc20383b6`.

`original-push-67fbcc.zip`: 9,328,342 bytes, SHA256
`a17354ea04b7005ee860e3b47c3a90e8cac05a2311e6c8f031978d4eef383210`, exactly matching
the authenticated artifact digest/size. ZIP CRC/path/unique-name/symlink checks
pass; 295 regular file records. Raw functional JUnit is 610 tests in 27 groups,
zero failure/error/skipped nodes. All 138 before/after source hashes are identical
and equal literal Git/submodule objects. The actual source-free launch has no
source/build mounts; runtime records verify source/build/optimizer absent and ten
installed planner module hashes equal literal 67 Git objects. All ten inherited
legacy failure identities match the baseline exactly.

`controlled-hosted67-catalog.json` retains nine H/C values anchored in the
separate original compile/validation command receipts and campaign. Independent
canonical recomputation binds exact payload, approved route, coefficients,
ownership/q and numeric policy. Artifacts were copied byte-for-byte into
`hosted67-inputs/`. This is byte/provenance checking, not another numerical replay.
The initial-17 catalog/artifacts were never substituted for this newer run.

`audit_archive.py` → `archive-audit.json` verifies all 22 companion manifest
entries plus every archive member's full bytes/type/path/uniqueness/hash/size:

- Initial evidence: 350 payload files, 30,995,245 uncompressed payload bytes;
  19,274,976 archive bytes, SHA256
  `05cb942671a3ffb758541e72aa92281725902b270ad60b5fa66daa0165f90ad4`.
- Dirty-source attempt: 230 payload files, 21,385,519 uncompressed payload bytes;
  3,490,634 archive bytes, SHA256
  `d77118613055fd17179b63b3e2a917490e6ecc8422b82b949c15a9c6e965cd18`.

`research-size-measurements.json` measures actual Git diffs, new reachable
objects by type, and standalone incremental non-thin packs using recorded
compression/thread settings. Visible line reductions from lossless compression
do not remove retained historical Git objects. Initial research diff versus W2:
1,826 changed files / 716,864 added lines / 1,598 new objects / 55,152,693 pack
bytes. Corrected67 diff: 1,836 files / 295,237 added lines / 1,667 objects /
57,276,280 pack bytes. Path-based categories distinguish runtime/packaging,
tests/fixtures, harness/CI, docs and evidence. These are method-specific pack
estimates, not measurements of GitHub's physical storage. Production comparison
must be added after an actual clean upstream-derived branch exists.

## Earlier completed numerical replay, correctly scoped

`../evidence/replay/old/results/saved-replay.json`: all nine OLD unchanged hosted
artifacts loaded under exact old implementation on this machine; actual geometry
and dynamics validators executed and passed. The previously retained native
cross-host rejection is not universally reproduced on this current host.

`../evidence/replay/final/results/saved-replay.json`: all nine INITIAL-17 unchanged
hosted artifacts loaded under the separately installed exact initial-17 source;
actual dual validators, immutable producer time, existing nine-group reader/CDR
and Float32 lap-time projection passed. Source mounts were visible in this shared
probe context: it is not claimed source-free and is not a final-67/new-fix replay.

## Remaining release gates

The companion's final-publication.json at 676e is still
PENDING_FINAL_COMMITTED_GATES, despite completed green 67 push CI. A new positive
squared-speed cancellation correction is owned by the root agent; that correction
supersedes 67 for final acceptance. Its final committed source requires its own
full fresh functional/install/source-free verification, exact-head push CI,
authenticated CI ZIP source/receipt audit and same-version unchanged hosted-artifact
replay in the matching installed runtime. Initial17/67 results cannot prove those
new-source gates. The final manifest/report must bind the accepted premerge SHA.

PR3 remains open at the API snapshot recorded here. No W3 acceptance is asserted.
Research merge/archive finalization is gated on acceptance. Fresh upstream-based
production extraction, current optimizer/ROS compatibility, curated tests,
equivalence/source-free proof, independent integration challenge, exact-head CI,
Git ancestry/object-size comparison and final fork-to-upstream PR publication
remain subsequent requirements. Physical vehicle operation remains unvalidated.

## Completed deterministic proof-portability reproduction

`old-deterministic-variation.log` and `initial17-deterministic-variation.log`
record four actual S0 load executions. On old source, both geometry and dynamics
validators pass, but the loader rejects (a) one ULP outward widening of the fresh
dynamics time enclosure and (b) genuine conservative geometry subdivision from
224 to 225 leaves. On initial17 source, both corresponding unchanged-artifact
loads pass and preserve the producer's main lap time exactly. The second control
raises BoundUncertain once in actual interval-bound evaluation, causing genuine
adaptive subdivision; it does not fabricate a PASS report or change authoritative
coefficients/policy. This reproduces the comparator failure deterministically
without claiming the native CPU-dependent historical mismatch recurred here.
The scripts and detailed outputs remain under `../evidence/replay/`.
