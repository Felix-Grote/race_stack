import sys,os,json,gzip,math,platform
from pathlib import Path
from dataclasses import asdict
sys.path.insert(0,'/workspace/forza-w3-audit/planner/global_planner')
sys.path.append('/opt/codex/runtimes/codex-primary-runtime/dependencies/python/lib/python3.12/site-packages')
import mpmath as mp
from global_planner.route_input import validate_route
from global_planner.route_reference import Curve
from global_planner.route_corridor import OrderedCurve
from global_planner.cyclic_retime import *
from global_planner.route_validate import Footprint,GeometryValidationPolicy,validate_geometry
from global_planner.route_validate_dynamics import DynamicsValidationPolicy,validate_dynamics
from global_planner.route_artifact import _reference,PolicySet
from global_planner.iqp_route_adapter import SolverPolicy
ROOT=Path('/workspace/forza-w3-audit')
OUT=Path('/workspace/forza-audit-records/numerical')
mp.mp.dps=70
raw=json.loads((ROOT/'planner/global_planner/test/fixtures/project_a/s0_route.json').read_text())
for o in raw['occurrences']:
    for cap in o['caps']: cap['max_speed_mps']=1e7
route=validate_route(raw)
fixture=json.loads(gzip.decompress((ROOT/'planner/global_planner/test/fixtures/project_a/w2_a04_candidates.json.gz').read_bytes()))['candidates']['s0_route']
ordered=OrderedCurve(route,Curve(fixture['coefficients'],fixture['owners']),fixture['q'])
limits=RegionLimits(0.,1e7,1e30,1e30,1e30,1e30,0.,'Explicit synthetic high dynamic range')
model=DynamicsModel(tuple(ModelRegion(o.id,o.surface_id,limits) for o in route.occurrences),'synthetic query numerical probe')
knots=tuple(SpeedKnot(i,0.,1e12 if i%2==0 else 1e-12) for i in range(len(ordered.curve.segments)))
edge_times=[2*s.length/(math.sqrt(knots[i].u)+math.sqrt(knots[(i+1)%len(knots)].u)) for i,s in enumerate(ordered.curve.segments)]
profile=SpeedProfile(knots,curve_digest(ordered),model_digest(model),math.fsum(edge_times))
fp=Footprint(.1,.1,.12,.01)
gp,dp=GeometryValidationPolicy(),DynamicsValidationPolicy()
g=validate_geometry(ordered,route,fp,gp,expected_curve_digest=curve_digest(ordered))
d=validate_dynamics(ordered,profile,model,dp,expected_curve_digest=curve_digest(ordered))
print('runtime',platform.python_version())
print('geometry',g.status,g.reason)
print('dynamics',d.status,d.reason)
if g.status!='PASS' or d.status!='PASS': sys.exit(2)
payload={'validation':{'dynamics':{'lap_time_s':d.lap_time_s}}}
ref=_reference('f'*64,None,ordered,profile,model,fp,PolicySet(ordered.curve.policy,SolverPolicy(),RetimePolicy(),gp,dp),g,d,payload)
rows=[]
for i,knot in enumerate(knots):
    if knot.u<1: continue
    boundary=ordered.curve.cumulative[i+1]
    s=math.nextafter(boundary,0.)
    row=ref.sample(s)
    coef=ordered.curve.segments[i].coefficients
    def speed(t):
        vals=[sum(mp.mpf(v)*(j)*t**(j-1) for j,v in enumerate(axis) if j) for axis in coef]
        return mp.sqrt(sum(v*v for v in vals))
    true_ds=mp.quad(speed,[0,1])
    # Canonical query metric coordinate relative to canonical segment prefix.
    local=mp.mpf(s)-mp.mpf(ordered.curve.cumulative[i])
    true_u=(mp.mpf(knots[i].u)*(true_ds-local)+mp.mpf(knots[(i+1)%len(knots)].u)*local)/true_ds
    geom_t_u=mp.mpf(knots[i].u)+(mp.mpf(knots[(i+1)%len(knots)].u)-mp.mpf(knots[i].u))*(mp.quad(speed,[0,mp.mpf(row.t)])/true_ds)
    entry=dict(i=i,s=s,boundary=boundary,t=row.t,returned_speed=row.speed_mps,oracle_speed_for_metric_s=str(mp.sqrt(true_u)) if true_u>=0 else 'negative metric offset '+str(true_u),oracle_speed_at_returned_t=str(mp.sqrt(geom_t_u)) if geom_t_u>=0 else str(geom_t_u),distance=ref._edge_lengths[i])
    rows.append(entry)
print(json.dumps(rows,indent=2))
(OUT/'query-high-dynamic.json').write_text(json.dumps({'runtime':platform.python_version(),'geometry':g.status,'dynamics':d.status,'rows':rows},indent=2))
