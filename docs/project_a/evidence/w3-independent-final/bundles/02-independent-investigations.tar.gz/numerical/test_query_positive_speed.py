"""Independent failing-first public-reference query regression; pinned runtime only."""
import gzip
import json
import math
import os
from pathlib import Path

from global_planner.cyclic_retime import (
    DynamicsModel, ModelRegion, RegionLimits, RetimePolicy, SpeedKnot, SpeedProfile,
    curve_digest, model_digest)
from global_planner.iqp_route_adapter import SolverPolicy
from global_planner.route_artifact import (
    ValidationContext, artifact_identity, build_payload, load_reference, publish_reference)
from global_planner.route_corridor import OrderedCurve
from global_planner.route_input import validate_route
from global_planner.route_reference import Curve
from global_planner.route_validate import Footprint, GeometryValidationPolicy, validate_geometry
from global_planner.route_validate_dynamics import DynamicsValidationPolicy, validate_dynamics


def test_loaded_positive_profile_never_queries_zero_before_boundary(tmp_path):
    """Certified positive endpoints remain positive at a rounded inverse endpoint."""
    root = Path(os.environ.get('FORZA_AUDIT_REPO', '/src'))
    fixture_dir = root / 'planner/global_planner/test/fixtures/project_a'
    payload = json.loads((fixture_dir / 's0_route.json').read_text())
    for occurrence in payload['occurrences']:
        for cap in occurrence['caps']:
            cap['max_speed_mps'] = 1e7
    route = validate_route(payload)
    archived = json.loads(gzip.decompress(
        (fixture_dir / 'w2_a04_candidates.json.gz').read_bytes()))['candidates']['s0_route']
    ordered = OrderedCurve(route, Curve(archived['coefficients'], archived['owners']),
                           archived['q'])
    expected_curve = curve_digest(ordered)
    limits = RegionLimits(0., 1e7, 1e30, 1e30, 1e30, 1e30, 0.,
                          'Explicit synthetic numerical dynamic range')
    model = DynamicsModel(tuple(ModelRegion(o.id, o.surface_id, limits)
                                for o in route.occurrences), 'Independent numerical regression')
    knots = tuple(SpeedKnot(i, 0., 1e12 if i % 2 == 0 else 1e-12)
                  for i in range(len(ordered.curve.segments)))
    lap_time = math.fsum(2 * segment.length /
                         (math.sqrt(knots[i].u) + math.sqrt(knots[(i+1) % len(knots)].u))
                         for i, segment in enumerate(ordered.curve.segments))
    profile = SpeedProfile(knots, expected_curve, model_digest(model), lap_time)
    footprint = Footprint(.1, .1, .12, .01)
    gp, dp = GeometryValidationPolicy(), DynamicsValidationPolicy()
    geometry = validate_geometry(ordered, route, footprint, gp,
                                 expected_curve_digest=expected_curve)
    dynamics = validate_dynamics(ordered, profile, model, dp,
                                 expected_curve_digest=expected_curve)
    assert geometry.status == dynamics.status == 'PASS'
    product = build_payload(
        ordered, profile, model, footprint, solver_policy=SolverPolicy(),
        retime_policy=RetimePolicy(), geometry_policy=gp, dynamics_policy=dp,
        approved_curve_digest=expected_curve, geometry_report=geometry,
        dynamics_report=dynamics, provenance={'purpose': 'Independent numerical regression'})
    expected_h = artifact_identity(product)
    produced = publish_reference(product, tmp_path / 'references', expected_H=expected_h,
                                 expected_curve_digest=expected_curve,
                                 validation_context=ValidationContext())
    loaded = load_reference(produced.path, expected_H=expected_h,
                            validation_context=ValidationContext())
    station = math.nextafter(loaded.ordered.curve.cumulative[1], 0.)
    sample = loaded.sample(station)
    assert sample.segment == 0  # Keep preceding half-open owner at nextafter.
    assert sample.speed_mps >= min(math.sqrt(knots[0].u), math.sqrt(knots[1].u))
