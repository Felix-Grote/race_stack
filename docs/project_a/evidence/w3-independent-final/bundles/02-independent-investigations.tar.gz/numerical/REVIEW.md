# Independent numerical W3 review (original source)

Reviewed HEAD: `17e4ec4e8fedfa736467d02f6204b04e8552decb`.
Read-only production/tests/branch review; scripts and results live only here.

## Confirmed original-source finding: P2 positive speed lost in query interpolation

Location: `planner/global_planner/global_planner/route_artifact.py:568`.

`Reference.sample` computes `ui + (uj-ui)*(local/distance)`. For supported positive binary64 endpoints with large ratio, subtraction discards `uj`. A near-boundary inverse may correctly return `t=1` under W1's station allowance while retaining the preceding segment. This makes `local/distance=1`, and the interpolation returns exactly zero instead of the positive terminal `uj`. Accepted moving profile authority can therefore query as a stationary reference. The correct preceding occurrence/edge selection is not the defect.

Host failing-first command:

```
/workspace/race_stack_setup/venv/bin/python /workspace/forza-audit-records/numerical/query_zero_repro.py
```

Observed Python3.12.14 host results: real geometry PASS, real independent dynamics PASS; query `s=0.2760027237149405`, before boundary `0.27600272371494056`, returns segment0/t1, `speed_mps=0.0`. Both profile endpoints are strictly positive (`u=1e12`, `1e-12`); endpoint speed is `1e-6`. Decimal80 shows the exact positive binary64 endpoint square root. Original assertion fails. Host-only construction uses `_reference` because public artifacts enforce pinned Python3.10.12/SciPy1.11.4. Host occurrence q endpoints are explicitly rebased to its Python3.12 sum result. Thus this host output is not represented as pinned public artifact acceptance. Pinned Python3.10.12 public confirmation now completed against original source: `geometry=PASS`, `dynamics=PASS`, `q_rebased_for_runtime=false`, `public_publish=PASS`, subsequent public `load_reference=PASS` with separately retained H `66ab322e8626ba1baed81a6074dc4351f4a5af4ed2c41d32a53ba1676c901597`. The same query returns exactly zero speed and the final positive-speed assertion fails. No q substitutions occur in pinned execution. Exact output: `query_zero_repro.pinned.log`. Public immutable artifact: `pinned-publication/66ab322e8626ba1baed81a6074dc4351f4a5af4ed2c41d32a53ba1676c901597/reference.json`.

Exact original failing-first pinned command (existing shared container):

```
docker --host=unix:///var/run/docker.sock exec -e PYTHONPATH=/src/planner/global_planner forza-independent-probes /opt/project-a/bin/python3 /records/numerical/query_zero_repro.py --repo /src --output /records/numerical/pinned-publication --publish
```

Focused isolated pytest regression: `test_query_positive_speed.py`. Original `/frozen` pinned execution completed with **1 failed in126.55s**, reaching precisely the final expected `0.0 >= 1e-6` assertion after real validators/public publish/load; JUnit `query-positive-red.xml` and full `query-positive-red.log` preserve this second red evidence. It preserves original archive q, executes real geometry/dynamics and public publish+reload, then requires sampled speed to stay within the positive endpoint range. Root owns source/test integration and focused repair. No constraints, tolerances or production files were changed by this reviewer.

The model and route caps are explicitly approved synthetic high-dynamic-range inputs, not vehicle parameters. No global speed/model magnitude ceiling in the supported record schema excludes them. Existing W2 coefficients and owners are retained. Both independent validators run without mocks and agree on the underlying valid positive profile; their correct authority is then evaluated incorrectly by the W3 query.

Proposed bounded fix: exact endpoints plus numerically stable positive interpolation (for example a convex weighted sum of the positive endpoints, or endpoint-centered interpolation chosen by fraction). Retain W1 station/ownership behavior. Add public publish/load followed by nextafter coefficient/profile-boundary query regression, with endpoint speed ratios covering the declared moving floor. Preserve the failing-first evidence.

A wider 70-digit mpmath probe confirms 49 such zero-speed results; original coefficient-based metric-coordinate speed can differ by more than endpoint speed because W1 permits up to1e-8m inverse residual. That positional tolerance is pre-existing and should not be mislabeled as a second finding. `query_probe.py`, `query_probe.log`, `query-high-dynamic.json` hold this exploratory evidence.

## Independent ordinary-case numerical controls

`ordinary_oracle.py`: 65-digit mpmath directly differentiates/integrates binary64 coefficient authority and independently computes arc-affine squared speed, edge acceleration, analytic elapsed time, tangent and signed curvature. S0, reversed S0, rotated S0 and disconnected-surface S3 all receive real geometry/dynamics PASS. Profiles are independently declared smooth positive synthetic profiles with each coefficient start as a knot. This is a kernel/query oracle, not a claim to have rerun the whole IQP pipeline.

1452 queries include every exact coefficient/profile boundary and both neighboring floats, zero, tiny negative subnormal, negative progress, positive/negative full laps, and interior samples. All occurrence/surface owners agree with independently bisected half-open canonical stations. Maximum observed errors:

- Metric station residual: 1.502e-10m, below declared1e-8m.
- Speed: 1.471e-16m/s.
- Edge acceleration: 3.362e-18m/s².
- Signed curvature: 1.573e-16/m.
- Unit tangent: 1.456e-16.
- Elapsed time at returned parameter: 6.511e-15s.
- Integrated whole-lap length: 3.015e-15m.

All four independently integrated true lap times lie inside the actual independent dynamics time enclosures. Results: `ordinary-oracle.json`, `ordinary-oracle.log`.

`interior_profile_oracle.py` adds a separate profile knot at t=.37 on every S0 coefficient, exact portal-support and cap stations and their neighbors. 632 queries pass both validators and have no ownership errors. Max station error1.527e-10m, speed2.243e-12m/s, acceleration3.574e-18m/s², elapsed1.526e-10s, curvature9.613e-17/m. Independent lap time is enclosed. Results: `interior-profile-oracle.json`, `interior-profile-oracle.log`.

Both host oracle scripts explicitly adjust only occurrence q endpoints to the unsupported host's `sum` runtime. No public-loader implementation/pinning bypass is attempted. These provide independent mathematical regression evidence, not installed ROS or pinned release acceptance.

## Verified source contracts / remaining scope

- `Curve` retains actual normalized cubic coefficients, controlled arc integration/inversion, exact canonical endpoint stations and half-open owners. Tiny negative modulo rounding is directed to predecessor of L.
- `Reference.sample` bisects true metric profile stations, derives local arc on original coefficient authority, uses cyclic next knot and right-hand edge acceleration, accumulates analytic moving-edge time, and transports portal support through q.
- Both retimer/checker include the closing edge. Independent dynamics reconstructs authority, all local distance-error intervals, exact rational endpoint inequalities and time enclosures. It does not trust LP rows or stored metadata. Shared metric/exact-bound kernels remain a correlated assumption.
- ROS projection source preserves true stations and adds terminal duplicate s=L with seam geometry/dynamics and frozen producer main time. Float32 main T uses explicit IEEE conversion; optional centerline/SP groups are empty and declared absent. Pure `waypoint_view` side distances re-intersect original owned legal geometry. Actual generated ROS reader/CDR validation is root-owned in the pinned image.
- No P0/P1 finding confirmed in this delegated scope. Pinned public publish/load acceptance and the subsequent zero-speed P2 failure are confirmed above; this is a query projection defect after valid acceptance, not a false dynamics certificate.
