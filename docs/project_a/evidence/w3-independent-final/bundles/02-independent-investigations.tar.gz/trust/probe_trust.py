from pathlib import Path
from dataclasses import asdict, replace
import copy,gzip,json,hashlib,math,traceback
import global_planner.route_artifact as a
from global_planner.cyclic_retime import DynamicsModel,ModelRegion,RegionLimits,RetimePolicy,curve_digest,retime
from global_planner.route_input import load_route
from global_planner.route_reference import Curve
from global_planner.route_corridor import OrderedCurve
from global_planner.iqp_route_adapter import SolverPolicy
from global_planner.route_validate import Footprint,GeometryValidationPolicy,validate_geometry
from global_planner.route_validate_dynamics import DynamicsValidationPolicy,validate_dynamics
ROOT=Path('/records/trust'); FIX=Path('/src/planner/global_planner/test/fixtures/project_a')
results=[]
def result(name,ok,detail):
    item={'name':name,'pass':bool(ok),'detail':detail};results.append(item);print(json.dumps(item),flush=True)
def rejects(name,call,contains=None):
    try: call()
    except Exception as exc:
        ok=isinstance(exc,a.ArtifactError) and (contains is None or contains in str(exc));result(name,ok,type(exc).__name__+': '+str(exc));return
    result(name,False,'unexpected acceptance')
# Independent parser matrix: actual persisted files and public reader.
cases={
'duplicate_nested':b'{"m":{"x":1,"x":2}}',
'invalid_utf8':b'{"x":"\xff"}',
'nonfinite':b'{"x":NaN}',
'overflow':b'{"x":1e10000}',
'depth':b'{"x":'+b'['*33+b']'*33+b'}',
'oversized_integer':b'{"x":'+b'9'*311+b'}',
'surrogate':b'{"x":"\\ud800"}',
'not_object':b'[]',
}
for name,raw in cases.items():
    path=ROOT/(name+'.json');path.write_bytes(raw);rejects('codec_'+name,lambda p=path:a.read_json(p))
for field,value in [('front_m',True),('width_m',[.2])]:
    data=asdict(Footprint(.1,.1,.12,.01));data[field]=value
    rejects('typed_body_'+field,lambda d=data:a.decode_record(Footprint,d))
encoded=a.canonical_bytes({'a':1,'b':1.,'c':-0.})
result('exact_numeric_spelling',encoded==b'{"a":1,"b":1.0,"c":-0.0}',encoded.decode())
# Reconstruct actual retained A04 coefficients independently of implementation tests.
frozen=(FIX/'w2_a04_candidates.json.gz').read_bytes();row=json.loads(gzip.decompress(frozen))['candidates']['s0_route']
route=load_route(FIX/'s0_route.json');ordered=OrderedCurve(route,Curve(row['coefficients'],row['owners']),row['q']);C=curve_digest(ordered)
model=DynamicsModel(tuple(ModelRegion(o.id,o.surface_id,RegionLimits(.05,3.,2.,3.,4.,2.5,0.,'Independent audit synthetic explicit model')) for o in route.occurrences),'Independent audit, offline planar only')
body=Footprint(.1,.1,.12,.01);gp=GeometryValidationPolicy();dp=DynamicsValidationPolicy()
g=validate_geometry(ordered,route,body,gp,expected_curve_digest=C);timed=retime(ordered,model);d=validate_dynamics(ordered,timed.profile,model,dp,expected_curve_digest=C)
result('independent_fixture_initial_validation',g.status=='PASS' and timed.status=='CANDIDATE' and d.status=='PASS',{'geometry':g.status,'retime':timed.status,'dynamics':d.status,'C':C,'fixture_sha256':hashlib.sha256(frozen).hexdigest()})
payload=a.build_payload(ordered,timed.profile,model,body,solver_policy=SolverPolicy(),retime_policy=RetimePolicy(),geometry_policy=gp,dynamics_policy=dp,approved_curve_digest=C,geometry_report=g,dynamics_report=d,provenance={'scope':'Independent local offline audit'})
H=a.artifact_identity(payload);context=a.ValidationContext()
def write(name,p,Hvalue=None,version=1):
    directory=ROOT/name;directory.mkdir(exist_ok=True);path=directory/'reference.json';path.write_bytes(a.canonical_bytes({'schema_version':version,'H':Hvalue or a.artifact_identity(p),'payload':p}));return path
base=write('valid',payload)
realg,reald=a.validate_geometry,a.validate_dynamics
calls=[]
def logg(*args,**kwargs): calls.append(['geometry',kwargs['expected_curve_digest']]);return realg(*args,**kwargs)
def logd(*args,**kwargs): calls.append(['dynamics',kwargs['expected_curve_digest']]);return reald(*args,**kwargs)
a.validate_geometry,a.validate_dynamics=logg,logd
loaded=a.load_reference(base,expected_H=H,validation_context=context)
result('valid_saved_bytes_calls_both_actual_validators',calls==[['geometry',C],['dynamics',C]],calls)
result('loaded_exact_authorities',a.canonical_bytes(loaded.payload)==a.canonical_bytes(payload) and curve_digest(loaded.ordered)==C,{'H':H,'C':C,'length':loaded.length,'T':loaded.lap_time_s})
a.validate_geometry,a.validate_dynamics=realg,reald
for name in ['coefficient','q','model','profile','footprint','policy']:
    changed=copy.deepcopy(payload)
    if name=='coefficient':changed['curve']['coefficients'][0][0][0]+=.001
    elif name=='q':changed['curve']['q'][2]+=.001
    elif name=='model':changed['model']['regions'][0]['limits']['speed_max_mps']*=2
    elif name=='profile':changed['speed_profile']['knots'][0]['u']*=1.1
    elif name=='footprint':changed['footprint']['width_m']*=.5
    elif name=='policy':changed['policies']['geometry']['max_curvature']*=2
    path=write('changed_'+name,changed)
    rejects('retained_external_H_rejects_'+name,lambda p=path:a.load_reference(p,expected_H=H,validation_context=context),'H mismatch')
# New controlled H is an explicit new approval; malformed shape/version still reject.
changed=copy.deepcopy(payload);changed['curve']['coefficients'][0][0].pop();path=write('bad_shape',changed)
rejects('new_H_wrong_coefficient_dimensions',lambda:a.load_reference(path,expected_H=a.artifact_identity(changed),validation_context=context),'coefficient powers')
path=write('bad_version',payload,version=True)
rejects('bool_schema_version',lambda:a.load_reference(path,expected_H=H,validation_context=context),'schema version')
changed=copy.deepcopy(payload);changed['policies']['geometry']['max_curvature']*=2;path=write('unsupported_policy',changed)
rejects('new_H_changed_independent_policy',lambda:a.load_reference(path,expected_H=a.artifact_identity(changed),validation_context=context),'acceptance policy')
# Staging enforces independently retained A04 approval even with separately supplied changed H.
changed=copy.deepcopy(payload);changed['curve']['q'][2]+=.001;changed['approved_curve_digest']='0'*64
rejects('publication_retained_C',lambda:a.publish_reference(changed,ROOT/'stage_new_H',expected_H=a.artifact_identity(changed),expected_curve_digest=C,validation_context=context),'retained A04 approval')
# Genuine two-checker replay with outward display differences preserves original immutable bytes.
calls=[]
def outwardg(*args,**kwargs):
    calls.append('geometry');report=realg(*args,**kwargs);assert report.status=='PASS';leaf=report.intervals[-1];return replace(report,intervals=report.intervals[:-1]+(replace(leaf,displacement_upper_m=math.nextafter(leaf.displacement_upper_m,math.inf)),))
def outwardd(*args,**kwargs):
    calls.append('dynamics');report=reald(*args,**kwargs);assert report.status=='PASS';return replace(report,lap_time_upper_s=math.nextafter(report.lap_time_upper_s,math.inf),lap_time_error_s=math.nextafter(report.lap_time_error_s,math.inf))
a.validate_geometry,a.validate_dynamics=outwardg,outwardd
original=base.read_bytes();replayed=a.load_reference(base,expected_H=H,validation_context=context)
result('outward_historical_replay_preserves_authority',calls==['geometry','dynamics'] and base.read_bytes()==original and replayed.lap_time_s==loaded.lap_time_s,{'calls':calls,'T_unchanged':replayed.lap_time_s==loaded.lap_time_s})
a.validate_geometry,a.validate_dynamics=realg,reald
# A historical PASS must never override actual fresh failure: real checks still run.
calls=[]
def failg(*args,**kwargs):
    calls.append('geometry');report=realg(*args,**kwargs);assert report.status=='PASS';return replace(report,status='FAIL',reason='independent local fault injection after real proof')
def passd(*args,**kwargs):calls.append('dynamics');return reald(*args,**kwargs)
a.validate_geometry,a.validate_dynamics=failg,passd
rejects('historical_PASS_fresh_geometry_FAIL',lambda:a.load_reference(base,expected_H=H,validation_context=context),'geometry replay FAIL')
result('fresh_failure_still_executed_both',calls==['geometry','dynamics'],calls)
a.validate_geometry,a.validate_dynamics=realg,reald
(ROOT/'results.json').write_text(json.dumps({'source_commit':'17e4ec4','results':results,'failures':sum(not x['pass'] for x in results)},indent=2)+'\n')
assert all(x['pass'] for x in results),'Independent expected behavior failed; inspect results'
