from pathlib import Path
import json
from global_planner.route_artifact import read_json,MAX_ARTIFACT_BYTES,MAX_JSON_STRING_BYTES,ArtifactError
from global_planner.route_compile import load_policy
r=Path('/records/trust');out=[]
for name,size,reader in [('artifact_file',MAX_ARTIFACT_BYTES+1,read_json),('config_file',2*1024**2+1,load_policy)]:
    p=r/(name+'.json')
    with p.open('wb') as f:f.truncate(size)
    try:reader(p);status='unexpected acceptance'
    except ArtifactError as e:status=str(e)
    out.append({'name':name,'status':status,'pass':'bounded regular JSON file' in status});p.unlink()
p=r/'text_budget.json';p.write_text(json.dumps({'text':'a'*(MAX_JSON_STRING_BYTES+1)}))
try:read_json(p);status='unexpected acceptance'
except ArtifactError as e:status=str(e)
out.append({'name':'text_budget','status':status,'pass':'text budget exhausted' in status})
(r/'codec_budget_results.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out));assert all(x['pass'] for x in out)
