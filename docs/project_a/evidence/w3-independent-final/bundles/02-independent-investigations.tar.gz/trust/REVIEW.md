# Independent local trust/codec review

Reviewed source: `17e4ec4e8fedfa736467d02f6204b04e8552decb`, checkout `/workspace/forza-w3-audit` (no production edits).

No P0–P3 correctness defect was confirmed in this assigned trust/codec scope. This is a bounded review, not acceptance of the complete W3 product.

## Executed evidence

`probe_trust.py` independently reconstructs the real archived A04 S0 coefficient/q record from fixture SHA256 `2a506953026b75fc5be4defb1b018577faa46cebdbdfcd767c0103e733b2279b`; it does not import implementation test helpers or run optimization. It supplies its own explicit synthetic model/body and runs both production validators and actual retimer before encoding. The independently retained curve authority is `f77eb66f8058dea5f99f3cfc85d580f664da853e4b0a455ca0c562b5786e8599`. The resulting external artifact H is `1926185d5c2fee75b3ef33cf7af6675dff408064762da26ac78643c78fa15a62`.

The script exercises nested duplicate keys, invalid UTF8, NaN, overflow, depth, oversized integers, escaped unpaired surrogate, wrong top-level document type, bool/wrong-dimensional body values, exact int/float/signed-zero spelling, normal saved-byte loading with actual geometry and dynamics calls, original-H coefficient/q/model/profile/body/policy changes, newly approved malformed dimensions/schema/policy, and staged publication's separate retained-C check. It also checks legitimate outward fresh witness differences against unchanged historical bytes and checks that historical PASS cannot override a fresh FAIL after the actual geometry proof ran.

Each mutated artifact is an actual `reference.json` in a directory containing only that file. The rejection helper records exception classes/messages, so filename or directory rejection cannot masquerade as a content-integrity check.

`probe_codec_budgets.py` tests artifact >64 MiB, config >2 MiB (sparse bounded regular-file tests without reading/allocating these sizes), and a >65536-byte JSON string. All three pass. `codec_budget_results.json` retains exact rejection reasons. The main matrix completed 27 checks, zero failures, exit 0; `results.json` retains every check. `probe_outward_coherent.py` separately repeats the outward replay while recomputing the fresh error summary from the widened enclosure, making the full changed report internally coherent. This supplements the first display-variation probe, which moved the error display itself outward by one ULP.

Command pattern (shared existing container only):

```
docker --host=unix:///var/run/docker.sock exec \
  -e PYTHONPATH=/src/planner/global_planner \
  -e PYTHONDONTWRITEBYTECODE=1 -e OPENBLAS_NUM_THREADS=1 -e OMP_NUM_THREADS=1 \
  forza-independent-probes /opt/project-a/bin/python3 /records/trust/probe_trust.py
```

## Source conclusions

`route_compile.py:162–166` freezes route/model/body/policies/provenance before downstream operations. Lines 191–202 retain final A04 C and exact coefficients/owners/q. Line 223 retains the retimer profile. Lines 241–253 check serialized authority and both retained reports before deriving H, then supply H and C separately to persisted-byte publication.

`route_artifact.py:777–803` validates external H before adopting embedded C, enforces exact supported implementation and independent proof policies, and separately compares the producer's retained C during publication. Lines 811–839 strictly reconstruct dimensions and typed coefficient/q/model/profile data. Lines 852–866 rerun both actual validators, require fresh PASS and required coverage, then check historical snapshot coherence. Consequently historical display variation does not authorize a fresh non-PASS artifact.

The external-H channel remains explicitly trusted. Supplying a new controlled H is a new approval; acceptance of a legal altered body under such an approval is not a self-hash bypass. An external C is not cryptographic reconstruction of A04 ancestry.

## Documentation read

Read scoped AGENTS, execution plan and W3_REVIEW; relevant current sections of STATUS and DECISIONS; W3_ARTIFACT contract; W3_RUNTIME and W3_BENCHMARKS protocol sections; W2_NUMERICS and independent W2 F1/F2 findings/remediation discussion; canonical architecture/roadmap representation, identity and checkpoint contracts. Read route_artifact.py and route_compile.py deeply, including parser, typed codec, compiler freeze, context/implementation identity, publication, loader, historical checks, reference query construction, and CLI receipts.

## Limits

These probes use the pinned local container, not a second CPU/host. Actual cross-host transport, installation/ROS/CDR, filesystem crash/race behavior, numerical enclosure correctness, complete A04 histories and benchmarks belong to separate review work. This script does not independently regenerate a full coordinated q/profile attack; it verifies the corresponding separately retained external H/C boundaries and source freeze checks. The validators share W1 primitives; calling both does not make those primitives mathematically independent. No vehicle, physical-clearance or real-course claim follows.
