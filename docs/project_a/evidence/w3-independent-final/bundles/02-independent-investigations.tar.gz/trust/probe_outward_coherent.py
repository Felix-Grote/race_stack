from pathlib import Path
from dataclasses import replace
import math,json
import global_planner.route_artifact as a
p=Path('/records/trust/valid/reference.json'); H='1926185d5c2fee75b3ef33cf7af6675dff408064762da26ac78643c78fa15a62'; before=p.read_bytes();g,d=a.validate_geometry,a.validate_dynamics;calls=[]
def fresh_geometry(*args,**kwargs):
    r=g(*args,**kwargs);assert r.status=='PASS';calls.append('geometry');leaf=r.intervals[-1];return replace(r,intervals=r.intervals[:-1]+(replace(leaf,displacement_upper_m=math.nextafter(leaf.displacement_upper_m,math.inf)),))
def fresh_dynamics(*args,**kwargs):
    r=d(*args,**kwargs);assert r.status=='PASS';calls.append('dynamics');high=math.nextafter(r.lap_time_upper_s,math.inf);error=max(r.lap_time_s-r.lap_time_lower_s,high-r.lap_time_s,0.);return replace(r,lap_time_upper_s=high,lap_time_error_s=error)
a.validate_geometry,a.validate_dynamics=fresh_geometry,fresh_dynamics
r=a.load_reference(p,expected_H=H,validation_context=a.ValidationContext())
assert calls==['geometry','dynamics'] and p.read_bytes()==before
assert r.dynamics_report.lap_time_error_s>=r.dynamics_report.lap_time_upper_s-r.dynamics_report.lap_time_s
out={'pass':True,'calls':calls,'H':r.H,'frozen_T':r.lap_time_s,'fresh_lap_error_covers_changed_enclosure':True,'bytes_unchanged':True}
Path('/records/trust/outward_coherent_results.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
