"""Independently audit native GitHub artifact bytes and immutable Git source binding."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile

root = Path(__file__).resolve().parent
records = root / 'artifact'
repo = Path('/workspace/forza-w3-audit')
load = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
source = '6a2900ac06de2a767f1d1b818a8dec8f8b9c59aa'
harness = 'b961d20ce4a803e55336fb5590c30574e23b2fad'
tooling = 'a31886ba539a7feebd97731403108efa52af76ef'
run = load(root / 'run.json')
artifact = load(root / 'artifacts.json')['artifacts'][0]
assert run['id'] == 39215679295 and run['event'] == 'push'
assert run['conclusion'] == 'success' and run['head_sha'] == tooling
assert artifact['id'] == 12169317178 and artifact['workflow_run']['id'] == run['id']
assert artifact['workflow_run']['head_sha'] == tooling
zip_path = root / 'original-upstream-baseline.zip'
assert artifact['digest'] == 'sha256:' + sha(zip_path)
assert artifact['size_in_bytes'] == zip_path.stat().st_size
with zipfile.ZipFile(zip_path) as archive:
    assert archive.testzip() is None
    assert all(archive.read(n) == (records / n).read_bytes()
               for n in archive.namelist() if not n.endswith('/'))
provenance = load(records / 'provenance.json')
assert (provenance['source_sha'], provenance['harness_sha'], provenance['tooling_sha']) == (source, harness, tooling)
before = load(records / 'upstream-files-before.json')
assert before == load(records / 'upstream-files-after.json')
assert load(records / 'copied-source-before.json') == load(records / 'copied-source-after.json')


def blob_hashes(commit, wanted):
    raw = subprocess.check_output(['git', '-C', str(repo), 'ls-tree', '-rz', commit])
    count = 0
    gitlinks = {}
    batch = subprocess.Popen(['git', '-C', str(repo), 'cat-file', '--batch'],
                             stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    for record in raw.split(b'\0'):
        if not record:
            continue
        metadata, pathname = record.split(b'\t', 1)
        mode, kind, oid = metadata.decode().split()
        name = pathname.decode()
        if kind == 'commit':
            gitlinks[name] = oid
        if name not in wanted:
            continue
        batch.stdin.write(oid.encode() + b'\n')
        batch.stdin.flush()
        header = batch.stdout.readline().decode().split()
        size = int(header[2])
        data = batch.stdout.read(size)
        assert batch.stdout.read(1) == b'\n'
        actual = 'symlink:' + data.decode() if mode == '120000' else hashlib.sha256(data).hexdigest()
        assert actual == wanted[name], name
        count += 1
    batch.stdin.close()
    assert batch.wait() == 0
    return count, gitlinks


root_bound_files, gitlinks = blob_hashes(source, before)
assert gitlinks['planner/global_planner/global_planner/global_racetrajectory_optimization'] == 'ace99a48e324234579b1d905a55c7b2bbf6c1ece'
harness_bound_files, _ = blob_hashes(harness, provenance['harness_file_hashes'])
assert harness_bound_files == len(provenance['harness_file_hashes'])
identity = load(records / 'runtime-identity.json')
assert identity['uid'] != 0 and identity['cap_eff'] == '0000000000000000'
assert identity['no_new_privs'] == '1' and identity['interfaces'] == [[1, 'lo']]
assert identity['root_and_source_readonly'] and identity['ros_distro'] == 'humble'
config = load(records / 'container-host-config.json')
assert config['ReadonlyRootfs'] and not config['Privileged'] and config['Devices'] == []
assert config['NetworkMode'] == 'none' and config['IpcMode'] == 'private'
assert config['CapDrop'] == ['ALL'] and config['SecurityOpt'] == ['no-new-privileges:true']
assert config['Memory'] == 4 * 1024**3 and config['NanoCpus'] == 2_000_000_000
assert config['PidsLimit'] == 256
mounts = {m['Destination']: m for m in load(records / 'container-mounts.json')}
assert all(not mounts[p]['RW'] for p in ('/src', '/harness', '/audit'))
assert mounts['/work']['RW']
installed = load(records / 'normal-install.json')
assert not installed['symlink_install'] and installed['symlinks'] == []
assert installed['global_planner_package_origin'].startswith('/work/install/')
assert (records / 'build-exit-code.txt').read_text().strip() == '0'
assert 'Summary: 3 packages finished' in (records / 'container.log').read_text()
text = (records / 'legacy-results.txt').read_text()
manifest = load(records / 'expected-failure-manifest.json')
failures = re.findall(r'^- ([^\n]+)\n  <<< failure message', text, re.MULTILINE)
diagnostics = Counter(line.strip() for line in text.splitlines()
                      if re.match(r'^\s*\./[^\n]+\.py:\d+', line))
assert failures == manifest['raw_failure_ids_ordered'] and len(failures) == 10
assert dict(diagnostics) == manifest['exact_style_diagnostic_counter']
assert dict(Counter(text.splitlines())) == manifest['raw_line_counter']
assert re.findall(r'^Summary: .*$', text, re.MULTILINE) == ['Summary: 12 tests, 0 errors, 10 failures, 2 skipped']
assert manifest['raw_legacy_results_sha256'] == sha(records / 'legacy-results.txt')
assert (records / 'legacy-exit-codes.txt').read_text() == 'colcon_test=1\ncolcon_test_result=1\n'
for name, expected in manifest['junit_sha256'].items():
    assert sha(records / name) == expected
skips = []
for package in ('global_planner', 'frenet_conversion'):
    for case in ET.parse(records / 'build' / package / 'pytest.xml').iter('testcase'):
        for skip in case.findall('skipped'):
            skips.append({'identity': case.get('classname') + ' ' + case.get('name'),
                          'reason': skip.get('message')})
assert sorted(s['identity'] for s in skips) == [
    'frenet_conversion.test.test_copyright test_copyright',
    'global_planner.test.test_copyright test_copyright']
assert all(s['reason'] == 'No copyright header has been placed in the generated source file.' for s in skips)
historical = load(root.parent / 'final-runtime-b961d20/prior-ordinary-legacy.json')
assert failures == historical['failure_identities']
old_counter = Counter(historical['exact_style_diagnostic_counter'])
added = diagnostics - old_counter
removed = old_counter - diagnostics
by_file = lambda counter: dict(sorted(Counter({filename: sum(n for line, n in counter.items()
                        if line.split(':', 1)[0] == filename)
                        for filename in {line.split(':', 1)[0] for line in counter}}).items()))
comparison = {'historical_1173_is_not_current_upstream_baseline': True,
              'historical_total': sum(old_counter.values()),
              'current_total': sum(diagnostics.values()),
              'same_failure_ids': True, 'same_skip_ids': True,
              'added_exact_lines': dict(sorted(added.items())),
              'removed_exact_lines': dict(sorted(removed.items())),
              'added_total': sum(added.values()), 'removed_total': sum(removed.values()),
              'added_by_file': by_file(added), 'removed_by_file': by_file(removed),
              'note': 'Exact-line changes include expected upstream source edits and line-number shifts; no tests were relaxed.'}
(root / 'historical-diagnostic-delta.json').write_text(json.dumps(comparison, indent=2) + '\n')
result = {'status': 'UPSTREAM_BASELINE_COLLECTED_AND_AUTHENTICATED',
          'acceptance': 'NOT_W3_OR_PRODUCTION_ACCEPTANCE',
          'source_sha': source, 'harness_sha': harness, 'tooling_sha': tooling,
          'github_run_id': run['id'], 'artifact_id': artifact['id'],
          'artifact_sha256': sha(zip_path), 'artifact_bytes': zip_path.stat().st_size,
          'immutable_root_git_blobs_matched': root_bound_files,
          'immutable_harness_git_blobs_matched': harness_bound_files,
          'all_source_files_unchanged': len(before),
          'ordinary_non_symlink_build': True, 'readonly_original_source': True,
          'all_required_container_isolation_verified': True,
          'raw_failure_ids_ordered': failures, 'skips': skips,
          'summary': '12 tests, 0 errors, 10 failures, 2 skipped',
          'legacy_exit_codes': {'colcon_test': 1, 'colcon_test_result': 1},
          'exact_style_diagnostic_total': sum(diagnostics.values()),
          'exact_style_diagnostic_unique': len(diagnostics),
          'optimizer_gitlink': gitlinks['planner/global_planner/global_planner/global_racetrajectory_optimization'],
          'optimizer_wheel_sha256': (records / 'optimizer-wheel-sha256.txt').read_text().split()[0],
          'historical_diagnostics_added': sum(added.values()),
          'historical_diagnostics_removed': sum(removed.values())}
(root / 'authentic-baseline-audit.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
