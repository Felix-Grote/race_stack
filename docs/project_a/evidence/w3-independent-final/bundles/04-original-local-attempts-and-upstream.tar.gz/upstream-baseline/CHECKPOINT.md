# Current upstream baseline collection (separate runner)

This is a read-only compatibility baseline before production extraction, not W3 or production acceptance.

- Actual official branch HEAD rechecked through GitHub API 2026-10-19: `6a2900ac06de2a767f1d1b818a8dec8f8b9c59aa`.
- Exact upstream optimizer gitlink: `ace99a48e324234579b1d905a55c7b2bbf6c1ece`.
- Fork-only CI branch: `audit/upstream-baseline-6a2900a`.
- Collection tooling commit: `a31886ba539a7feebd97731403108efa52af76ef`, based directly on upstream6a2900a with only3toolingfiles; never a production branch.
- Literal independent research Dockerfile/hashed locks/identity tooling: `b961d20ce4a803e55336fb5590c30574e23b2fad` in separately checked out harness.
- GitHub Actions exact push run: https://github.com/Felix-Grote/race_stack/actions/runs/39215679295 (currently active).
- Selected source packages `global_planner`, `f110_msgs`, `frenet_conversion`; ordinary `colcon build` without `--symlink-install`, optimizer wheel built but no live ROS planner imported/run.
- Test container nonroot, readonly root/source/harness/tooling, networknone, dropallcaps, no-newprivileges,2CPU/4GiB/256PIDs. No local Docker/QP started by this agent.
- Retains every raw XML/legacy results/log, failure identities, skips with reasons, all raw result lines Counter, full style diagnostic Counter using exact runtime_final regex; no assumption old1173count applies to current upstream.

Pending: wait for run, inspect actual build/test/sourceintegrity evidence, retrieve authentic artifact ZIP and independently hash/audit it. Workflow green only means baseline collected; failures remain failures. No production extraction, production PR or acceptance authorized at this stage.

## Completion

Run succeeded; authentic artifact retrieved and verified; independent audit `authentic-baseline-audit.json` PASS as collection only. Current baseline12tests/0errors/10failures/2skips, bothlegacyexit1, exactstyleCounter1182unique/1182total. See README.md and full raw artifact. No production extraction or PR created.
