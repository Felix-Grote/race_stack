# Literal b961d20 independent release evidence

Candidate implementation `b961d20ce4a803e55336fb5590c30574e23b2fad` is separate
from initial17 and pre-final67. No acceptance is inferred from those older runs.

- Push run: https://github.com/Felix-Grote/race_stack/actions/runs/39110306747
- PR run: https://github.com/Felix-Grote/race_stack/actions/runs/39110310707
- Clean local fresh verification: ../fresh-b961d20 and
  ../fresh-b961d20-launch.log, owned by root agent.

Hosted evidence audit is complete: literal push 39110306747 and PR 39110310707
both succeeded on b961d20, attempt 1. The original push artifact was retrieved
with the authenticated native GitHub `download_workflow_artifact` connector;
its returned reusable file URL supplied the original ZIP bytes, with no
proxy/TLS changes. API digest/size are exact: 9,328,625 bytes, SHA256
`e78d8f386b898e573d4a1f61834e3ced7879e3878fc8fceaab456691d49f3e9d`.

`hosted-audit.json` is PASS: 612 functional tests across 27 groups, zero failures,
errors or skips; 138 literal source hashes unchanged before/after; 21 installed
resources; 2 dependency locks; 7 exact recursive gitlinks. `raw-hosted-audit.json`
also independently checks raw inherited legacy failures against the literal Git
baseline, including raw digest and exact ten identities. The inherited summary
is 597 tests, 0 errors, 10 failures, 2 copyright skips. Those remain expected failures,
not functional PASS results. All 27 archived functional XML files are covered.

Reproduce the read-only audit:

```
python3 audit_hosted.py --directory /workspace/forza-audit-records/final-evidence-b961d20 --sha b961d20ce4a803e55336fb5590c30574e23b2fad
python3 audit_raw_hosted.py
```

It checks authenticated original ZIP digest/size/run/head, raw functional JUnit,
138 source hashes against literal Git/submodule objects, source-free launch and
installed module origins/hashes, source-free build identity, 21 installed
resource hashes, two dependency locks, all seven recursive gitlinks and exact ten
legacy failure identities. It retains compile/validate/campaign-anchored trusted
H/C and unchanged artifacts under controlled-hosted-catalog.json + hosted-inputs/.
The separate runtime_final agent owns real matching-version nine-case
installed replay with dual validators, independent boundary queries, immutable
producer time and existing reader/CDR. No duplicate heavy replay is started here.
The complete final96 original hosted replay has a separate independent audit at
`../final-benchmarks/README.md`; its harness commit differs from the checked-out
literal b961d20 numerical source. Original ZIP/API/logs and every 96 row remain.

Completed before hosted/fresh results:

- audit_git_evidence.py → git-evidence-audit.json: 39 literal final-tree ledgers,
  2,342 entries PASS; all 95 protected accepted-W2 paths unchanged. Retained final
  evidence tree: 2,378 file paths, 139,547,636 bytes; 1,567 unique blobs,
  126,448,328 bytes; 172 whole-file duplicate groups, 13,099,308 repeated bytes.
  Historical326/independent676e companion checks remain separately indexed in
  ../evidence and ../resume-evidence; no history/evidence was deleted.
- measure_research_size.py → research-size-measurements.json: W3 diff versus
  development target9fae has1,852 changed files,295,772 added/49 deleted text lines;
  1,700 new Git objects,110,608,309 uncompressed object bytes; standalone incremental
  non-thin pack57,284,423 bytes, SHA256
  d3cbaae530ffda7775795b53d49df1bfe869cd1bb045dcd6da12ec4d21c564ee.
  Exact compression/thread settings are recorded; this is method-specific pack
  measurement, not claimed GitHub physical storage.
- source-module-inventory.json: exact11 production modules at b961 total
  5,425 LOC/259,137 bytes, all absent from current official upstream6a2900a.

package_records.py preserves a specifically selected completed evidence set with
an explicit exclusion inventory, deterministic archive, full member/source
readback and duplicate-byte accounting. Run only after relevant writers finish;
output must be outside selected roots and existing archives are never overwritten.
It makes no acceptance decision and never deletes evidence.

The final verdict is owned by the coordinating root agent after every W3 gate.
Production extraction remains gated on ACCEPT. Research preservation/merge,
upstream-based production branch, integration verification/challenge and final
upstream PR remain subsequent obligations. Physical vehicle is not validated.
