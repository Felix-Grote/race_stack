import collections,hashlib,json,pathlib,subprocess,time
P=pathlib.Path('/workspace/forza-audit-records/final-evidence-b961d20');R='/workspace/forza-w3-audit';S='b961d20ce4a803e55336fb5590c30574e23b2fad';BASE='9fae5faed6ca62e0c943b6290babc50638477d9b'
def git(*args):return subprocess.check_output(['git','-C',R,*args])
def category(p):
 if '/evidence/' in p:return 'generated_or_retained_research_evidence'
 if '/test/' in p or '/tests/' in p:return 'tests_and_test_fixtures'
 if p.startswith(('scripts/','.github/','docker')):return 'verification_harness_CI_container'
 if p.startswith('docs/'):return 'research_documentation'
 return 'planner_runtime_packaging_resources'
measure=[]
for label,s,b in [('final_b961_W3',S,BASE)]:
 cats=collections.defaultdict(lambda:dict(files=0,added_lines=0,deleted_lines=0,binary_files=0))
 for line in git('diff','--numstat','--no-renames',b,s).decode().splitlines():
  a,d,p=line.split('\t',2);x=cats[category(p)];x['files']+=1
  if a=='-':x['binary_files']+=1
  else:x['added_lines']+=int(a);x['deleted_lines']+=int(d)
 rev=(s+'\n^'+b+'\n').encode(); objects=git('rev-list','--objects',s,'^'+b).decode().splitlines();ids=[line.split()[0] for line in objects]
 check=subprocess.check_output(['git','-C',R,'cat-file','--batch-check=%(objecttype) %(objectsize)'],input=('\n'.join(ids)+'\n').encode()).decode().splitlines()
 bytype=collections.defaultdict(lambda:dict(objects=0,uncompressed_bytes=0))
 for line in check:
  typ,n=line.split();bytype[typ]['objects']+=1;bytype[typ]['uncompressed_bytes']+=int(n)
 start=time.monotonic();proc=subprocess.Popen(['git','-C',R,'-c','pack.threads=1','-c','core.compression=6','pack-objects','--stdout','--revs'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE);proc.stdin.write(rev);proc.stdin.close();h=hashlib.sha256();count=0
 while True:
  data=proc.stdout.read(1024*1024)
  if not data:break
  h.update(data);count+=len(data)
 err=proc.stderr.read().decode();assert proc.wait()==0,err
 measure.append(dict(label=label,base=b,head=s,categories=dict(cats),changed_files=sum(x['files'] for x in cats.values()),added_lines=sum(x['added_lines'] for x in cats.values()),deleted_lines=sum(x['deleted_lines'] for x in cats.values()),new_objects=dict(bytype),new_object_count=len(ids),standalone_incremental_pack_bytes=count,standalone_incremental_pack_sha256=h.hexdigest(),pack_elapsed_s=time.monotonic()-start))
result=dict(measurements=measure,git_version=git('--version').decode().strip(),pack_method='git -c pack.threads=1 -c core.compression=6 pack-objects --stdout --revs with HEAD and ^BASE, non-thin standalone incremental object pack. Measured compressed bytes are reproducible method-specific estimates, not a claim of hosted repository storage reduction.',scope='All research history is retained. File categories are path-based; runtime category includes packaging/resources and cannot be interpreted as pure executable LOC.')
(P/'research-size-measurements.json').write_text(json.dumps(result,indent=2)+'\n')
