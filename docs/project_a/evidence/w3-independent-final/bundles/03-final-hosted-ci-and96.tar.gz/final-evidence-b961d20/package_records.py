"""Deterministically preserve an explicit evidence selection after writers finish.

Example (select desired completed directories explicitly; output outside selected roots):
python package_records.py --output /workspace/final-audit.tar.gz \
 --include evidence --include resume-evidence --include final-evidence-b961d20 \
 --include fresh-b961d20 --exclude fresh-b961d20/checkout \
 --exclude fresh-b961d20/verification/build --exclude fresh-b961d20/verification/src \
 --exclude fresh-b961d20/verification/install --exclude fresh-b961d20/verification/python \
 --exclude fresh-b961d20/verification/wheels --exclude fresh-b961d20/verification/log \
 --exclude fresh-b961d20/verification/a09-harness-tmp

No evidence deletion, git mutation, network operation or acceptance assertion.
"""
import argparse,collections,gzip,hashlib,io,json,os,pathlib,tarfile,tempfile
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=pathlib.Path,default=pathlib.Path('/workspace/forza-audit-records'));p.add_argument('--output',required=True,type=pathlib.Path);p.add_argument('--include',action='append',required=True);p.add_argument('--exclude',action='append',default=[]);a=p.parse_args();root=a.root.resolve();output=a.output.resolve()
def checked(x):
 p=pathlib.PurePosixPath(x)
 if p.is_absolute() or '..' in p.parts:raise ValueError('unsafe relative selection: '+x)
 return p
includes=[checked(x) for x in a.include];excludes=[checked(x) for x in a.exclude]
def excluded(rel):return any(rel==e or e in rel.parents for e in excludes) or '__pycache__' in rel.parts
files={}
for inc in includes:
 base=root/pathlib.Path(inc)
 if not base.exists():raise FileNotFoundError(base)
 paths=[base] if base.is_file() else sorted(base.rglob('*'))
 for f in paths:
  rel=pathlib.PurePosixPath(f.relative_to(root).as_posix())
  if excluded(rel):continue
  if f.is_symlink():raise ValueError('selected symlink, explicitly exclude reconstructible path: '+str(rel))
  if f.is_dir():continue
  if not f.is_file():raise ValueError('selected special file: '+str(rel))
  if f.resolve()==output:raise ValueError('output intersects selection')
  raw=f.read_bytes();files[str(rel)]=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
groups=collections.defaultdict(list)
for name,r in files.items():groups[(r['sha256'],r['bytes'])].append(name)
duplicates=[dict(sha256=h,bytes=n,paths=names,repeated_bytes=(len(names)-1)*n) for (h,n),names in groups.items() if len(names)>1]
manifest=dict(schema_version=1,scope='Retained independent audit evidence; consult source-specific acceptance report for verdict. Archive existence/integrity is not acceptance.',included_paths=[str(x) for x in includes],explicit_excluded_reconstructible_paths=[str(x) for x in excludes],automatic_exclusions=['__pycache__'],files=files,payload_files=len(files),payload_bytes=sum(r['bytes'] for r in files.values()),duplicate_file_groups=duplicates,duplicate_repeated_bytes=sum(r['repeated_bytes'] for r in duplicates),reproduction='Each source-specific README and preserved script/command record inside is authoritative. Retrieve exact Git source/submodules and pinned numerical/ROS tooling; never substitute embedded H or historical PASS for externally retained authority.')
manifest_raw=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode()
output.parent.mkdir(parents=True,exist_ok=True)
fd,tmp=tempfile.mkstemp(prefix=output.name+'.',dir=output.parent);os.close(fd)
try:
 with open(tmp,'wb') as sink:
  with gzip.GzipFile(filename='',mode='wb',fileobj=sink,mtime=0,compresslevel=6) as zipped:
   with tarfile.open(fileobj=zipped,mode='w',format=tarfile.USTAR_FORMAT) as tar:
    def put(name,raw):
     info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;info.uid=info.gid=info.mtime=0;info.uname=info.gname='';tar.addfile(info,io.BytesIO(raw))
    put('MANIFEST.json',manifest_raw)
    for name,r in sorted(files.items()):
     raw=(root/name).read_bytes();assert len(raw)==r['bytes'] and hashlib.sha256(raw).hexdigest()==r['sha256'],('changed during packaging',name);put(name,raw)
 raw=pathlib.Path(tmp).read_bytes();archive_sha=hashlib.sha256(raw).hexdigest()
 with tarfile.open(tmp) as tar:
  members=tar.getmembers();assert len(members)==len(files)+1 and len({m.name for m in members})==len(members)
  for m in members:
   assert m.isfile() and not m.name.startswith('/') and '..' not in pathlib.PurePosixPath(m.name).parts
   b=tar.extractfile(m).read()
   if m.name=='MANIFEST.json':assert b==manifest_raw
   else:assert len(b)==files[m.name]['bytes'] and hashlib.sha256(b).hexdigest()==files[m.name]['sha256'],m.name
 for name,r in files.items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==r['sha256'],('changed after packaging',name)
 if output.exists():raise FileExistsError('never overwrite an earlier archive: '+str(output))
 os.link(tmp,output);os.unlink(tmp)
 output.with_suffix(output.suffix+'.manifest.json').write_bytes(manifest_raw)
 receipt=dict(archive=output.name,archive_sha256=archive_sha,archive_bytes=len(raw),manifest_sha256=hashlib.sha256(manifest_raw).hexdigest(),payload_files=len(files),payload_bytes=manifest['payload_bytes'],verified_regular_safe_unique_members=len(members),readback='PASS every member size/hash, then every selected source file rehashed unchanged',duplicate_groups=len(duplicates),repeated_payload_bytes=manifest['duplicate_repeated_bytes'],scope=manifest['scope'])
 output.with_suffix(output.suffix+'.receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
finally:
 if os.path.exists(tmp):os.unlink(tmp)
