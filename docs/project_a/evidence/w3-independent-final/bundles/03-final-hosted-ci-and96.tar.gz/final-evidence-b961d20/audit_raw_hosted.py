"""Supplement the original hosted audit with raw legacy and exact group coverage."""
import gzip,hashlib,json,pathlib,re,subprocess,zipfile,xml.etree.ElementTree as E
P=pathlib.Path(__file__).parent;S='b961d20ce4a803e55336fb5590c30574e23b2fad'
sha=lambda b:hashlib.sha256(b).hexdigest()
with zipfile.ZipFile(P/'original-push.zip') as z:
 s=json.loads(z.read('summary.json'));a=json.loads(z.read('legacy-identity-comparison.json'));raw=z.read('legacy-results.txt')
 baseline=subprocess.check_output(['git','-C','/workspace/forza-w3-audit','show',S+':docs/project_a/evidence/pinned-run/legacy-results.txt.gz'])
 assert sha(raw)==a['actual_sha256'] and sha(baseline)==a['baseline_sha256']
 failures=lambda b:re.findall(r'^- ([^\n]+)\n  <<< failure message',b.decode(),re.MULTILINE)
 assert failures(raw)==failures(gzip.decompress(baseline))==a['actual']==a['baseline'] and len(a['actual'])==10
 assert re.findall(r'^Summary: (\d+) tests?, (\d+) errors?, (\d+) failures?, (\d+) skipped\s*$',raw.decode(),re.MULTILINE)==[('597','0','10','2')]
 assert z.read('legacy-exit-codes.txt')==b'colcon_test=1\ncolcon_test_result=1\n'
 groups={k:('source-free/results/w3-source-free.xml' if k=='w3-source-free' else k+'.xml') for k,v in s.items() if isinstance(v,dict) and 'tests' in v}
 assert set(groups.values())=={n for n in z.namelist() if n.endswith('.xml')} and len(groups)==27
 total=0
 for k,name in groups.items():
  root=E.fromstring(z.read(name));tests=list(root.iter('testcase'));assert len(tests)==int(s[k]['tests']) and not any(x.tag in ('failure','error','skipped') for x in root.iter());total+=len(tests)
 assert total==612
 for filename,event in (('push-run.json','push'),('pr-run.json','pull_request')):
  run=json.loads((P/filename).read_text());assert run['head_sha']==S and run['status']=='completed' and run['conclusion']=='success' and run['event']==event and run['run_attempt']==1
 report=dict(PASS=True,implementation=S,functional_tests=total,functional_groups=len(groups),raw_legacy_failures_exact=a['actual'],inherited_legacy_failures=10,inherited_copyright_skips=2,raw_legacy_summary=[597,0,10,2],legacy_status='EXPECTED_FAILURES_RETAINED',baseline_matches_literal_git=True,push_and_pr_exact_source_success=True,scope='Raw inherited legacy failures remain failures; only the27 declared functional groups are all passing. Final acceptance is separate.')
 (P/'raw-hosted-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
