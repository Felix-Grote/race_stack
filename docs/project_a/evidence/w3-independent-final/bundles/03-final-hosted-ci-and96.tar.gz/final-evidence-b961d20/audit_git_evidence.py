"""Hash every retained evidence ledger against literal final Git tree objects."""
import collections,gzip,hashlib,io,json,pathlib,posixpath,re,subprocess,tarfile
R='/workspace/forza-w3-audit';S='b961d20ce4a803e55336fb5590c30574e23b2fad';P=pathlib.Path('/workspace/forza-audit-records/final-evidence-b961d20');PREFIX='docs/project_a/evidence/'
def git(*args):return subprocess.check_output(['git','-C',R,*args])
tree={}
for row in git('ls-tree','-r','-z','--long',S).split(b'\0'):
 if not row:continue
 info,name=row.split(b'\t',1);mode,kind,oid,size=info.decode().split();tree[name.decode()]=dict(mode=mode,kind=kind,oid=oid,bytes=None if size=='-' else int(size))
cache={};proc=subprocess.Popen(['git','-C',R,'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
def read(path):
 rec=tree[path];oid=rec['oid'];assert rec['kind']=='blob'
 if oid not in cache:
  proc.stdin.write((oid+'\n').encode());proc.stdin.flush();header=proc.stdout.readline().decode().split();assert header[0]==oid and header[1]=='blob';b=proc.stdout.read(int(header[2]));assert proc.stdout.read(1)==b'\n';cache[oid]=b
 return cache[oid]
rows=[];archive_cache={}
try:
 for ledger in sorted(p for p in tree if p.startswith(PREFIX) and pathlib.PurePosixPath(p).name in ('SHA256SUMS','files-sha256.json')):
  raw=read(ledger);entries=[]
  if ledger.endswith('/SHA256SUMS'):
   for line in raw.decode().splitlines():
    m=re.fullmatch(r'([0-9a-f]{64}) [ *](.+)',line);assert m,(ledger,line);digest,name=m.groups();entries.append((name,digest))
  else:
   x=json.loads(raw);x=x.get('files',x);entries=[(name,r if isinstance(r,str) else r['sha256']) for name,r in x.items()]
  errors=[]
  for name,digest in entries:
   path=posixpath.normpath(name if name.startswith('docs/') else posixpath.join(posixpath.dirname(ledger),name))
   if path in tree:b=read(path)
   elif ledger.endswith('w3-final-verification/benchmarks/SHA256SUMS'):
    arc=PREFIX+'w3-final-verification/benchmarks/final-functional-17e4ec4e.tar.gz'
    if arc not in archive_cache:
     with tarfile.open(fileobj=io.BytesIO(read(arc))) as tar:archive_cache[arc]={m.name.removeprefix('postfix-benchmarks/'):tar.extractfile(m).read() for m in tar.getmembers() if m.isfile()}
    b=archive_cache[arc].get(name)
   else:b=None
   if b is None:errors.append(dict(path=path,error='missing literal Git file'))
   elif hashlib.sha256(b).hexdigest()!=digest:errors.append(dict(path=path,error='SHA256 mismatch'))
  rows.append(dict(ledger=ledger,entries=len(entries),errors=errors))
 old=json.loads(pathlib.Path('/workspace/forza-audit-records/evidence/source-provenance-audit.json').read_bytes());protected=[]
 for r in old['protected']:
  p=r['path'];accepted=r['accepted'];actual=tree.get(p);equal=(actual is None and accepted is None) or (actual is not None and accepted is not None and actual['oid']==accepted['blob'] and actual['mode']==accepted['mode']);protected.append(dict(path=p,exact_accepted_W2=equal))
 evidence={p:r for p,r in tree.items() if p.startswith(PREFIX) and r['kind']=='blob'};groups=collections.defaultdict(list)
 for p,r in evidence.items():groups[r['oid']].append(p)
 duplicates=[dict(blob=oid,bytes=tree[ps[0]]['bytes'],paths=ps,repeated_bytes=(len(ps)-1)*tree[ps[0]]['bytes']) for oid,ps in groups.items() if len(ps)>1]
 report=dict(implementation=S,ledger_count=len(rows),checked_entries=sum(r['entries'] for r in rows),ledgers=rows,protected_W2=protected,protected_W2_all_exact=all(r['exact_accepted_W2'] for r in protected),evidence_path_count=len(evidence),evidence_tree_bytes=sum(r['bytes'] for r in evidence.values()),evidence_unique_blobs=len(groups),evidence_unique_blob_bytes=sum(tree[ps[0]]['bytes'] for ps in groups.values()),whole_file_duplicate_groups=len(duplicates),whole_file_repeated_tree_bytes=sum(r['repeated_bytes'] for r in duplicates),duplicates=duplicates,path_resolution='Repository-relative docs/ entries; otherwise ledger-relative. Published final benchmark ledger, if present, resolves in its named tar archive.',scope='Literal Git retained-file integrity and duplicate tree-byte measurement, not Git pack size or mathematical acceptance.')
 report['PASS']=not any(r['errors'] for r in rows) and report['protected_W2_all_exact'];(P/'git-evidence-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ('ledgers','protected_W2','duplicates')}));print(json.dumps([r for r in rows if r['errors']])[:4000]);assert report['PASS']
finally:
 proc.stdin.close();proc.stdout.close();proc.wait()
