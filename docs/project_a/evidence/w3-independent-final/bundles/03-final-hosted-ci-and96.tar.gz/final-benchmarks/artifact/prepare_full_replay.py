"""Freeze a fresh full 92+4 replay of saved legal routes and unchanged job policies."""
import argparse,copy,hashlib,json,subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--output',required=True);p.add_argument('--container-output',default='/audit/full-replay');p.add_argument('--without-ros',action='store_true');args=p.parse_args()
repo=Path(args.repo).resolve();out=Path(args.output).resolve();out.mkdir(parents=True,exist_ok=False);ev=repo/'docs/project_a/evidence/w3-benchmarks';sha=lambda b:hashlib.sha256(b).hexdigest();source=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip();status=subprocess.check_output(['git','-C',str(repo),'status','--short'],text=True);assert source=='b961d20ce4a803e55336fb5590c30574e23b2fad', source;assert not status, status;gitlinks=subprocess.check_output(['git','-C',str(repo),'submodule','status','--recursive'],text=True).splitlines();expected={}
for name in ('primary','matched-coarse'):
 target=out/name;(target/'inputs').mkdir(parents=True);m=json.loads((ev/name/'manifest.json').read_bytes());historical_source=m['source_sha']; originalsha=sha((ev/name/'manifest.json').read_bytes());oldsummary=json.loads((ev/name/'summary.json').read_bytes())['attempts'];expected[name]={z['id']:z['status'] for z in oldsummary}
 for j in m['jobs']:
  route_name=j['scenario']+'.json';(target/'inputs'/route_name).write_bytes((ev/name/'inputs'/route_name).read_bytes());j.update(output=args.container_output+'/'+name,route=args.container_output+'/'+name+'/inputs/'+route_name)
  if args.without_ros:j['export_ros']=False
 m.update(source_sha=source,source_status=status,gitlinks=gitlinks,independent_replay_of_manifest_sha256=originalsha,historical_producer_source_sha=historical_source,independent_replay_scope='fresh exact-source numerical/artifact/ROS replay; frozen route/model bytes and original job policies/limits; current worker/support; no reuse of historical H/C approvals; serial execution on independent GitHub runner')
 (target/'original-manifest.json').write_bytes((ev/name/'manifest.json').read_bytes())
 (target/'historical-summary.json').write_bytes((ev/name/'summary.json').read_bytes())
 m['historical_summary_sha256']=sha((ev/name/'summary.json').read_bytes())
 m['historical_summary_scope']='Original outcome and input/model provenance only; its H/C fields are not current approvals'
 for filename,key in (('benchmark_w3.py','script_sha256'),('w3_benchmark_support.py','support_sha256')):
  current=sha((repo/'scripts/project_a'/filename).read_bytes())
  original=m[key]
  if filename=='benchmark_w3.py':assert current==original, 'benchmark worker changed'
  else:
   assert original=='29a25360fc2ee4411fb6483ae70dffda30335cbebec1d02a0218ec3a9ae50f59', 'unexpected original support'
   assert current=='6ba5f671f1152a46eaff3e25cec4979c2c2bfbf8b1b825425a2dc5d27223622b', 'unreviewed final support'
   m['independent_reviewed_support_amendment']={'original_sha256':original,'current_sha256':current,'commit':'abdbc4ab232ebe850ec1b8c096fc89a2480c29b9','review':'Initial legacy fit moved inside existing numerical rejection exception boundary; fit, equations, budgets, policies and negative statuses unchanged.'}
  m[key]=current
 if name=='matched-coarse':m['independent_replay_paired_primary_manifest_sha256']=sha((out/'primary/manifest.json').read_bytes())
 (target/'manifest.json').write_text(json.dumps(m,sort_keys=True,separators=(',',':')));(target/'run_manifest.py').write_bytes((ev/'matched-coarse/run_manifest.py').read_bytes())
(out/'expected-statuses.json').write_text(json.dumps(expected,indent=2));print(json.dumps({'source_sha':source,'source_status':status,'jobs':sum(len(v) for v in expected.values()),'output':str(out)},indent=2))
