"""Check IDs, exact original outcomes and fresh current-head artifact/ROS products."""
import collections
import gzip
import hashlib
import json
from pathlib import Path
import sys

repo, output = map(Path, sys.argv[1:])
sha = lambda b: hashlib.sha256(b).hexdigest()
expected = json.loads((output/'expected-statuses.json').read_text())
result = {'source_sha':'b961d20ce4a803e55336fb5590c30574e23b2fad','runs':{},'issues':[]}
counts = collections.Counter()
for run in ('primary','matched-coarse'):
    p=output/run
    m=json.loads((p/'manifest.json').read_text())
    original=json.loads((p/'original-manifest.json').read_text())
    historical=json.loads((p/'historical-summary.json').read_text())['attempts']
    assert sha((p/'historical-summary.json').read_bytes())==m['historical_summary_sha256']
    model_by_scenario={r['scenario']:r['model_sha256'] for r in historical if 'model_sha256' in r}
    assert sha((p/'original-manifest.json').read_bytes())==m['independent_replay_of_manifest_sha256']
    assert m['source_sha']==result['source_sha'] and not m['source_status']
    assert m['outer_policy_predeclared']==original['outer_policy_predeclared']
    jobs={j['id']:j for j in m['jobs']}
    oldjobs={j['id']:j for j in original['jobs']}
    assert len(jobs)==len(m['jobs'])==len(expected[run])
    for identifier,j in jobs.items():
        old=oldjobs[identifier]
        assert {k:v for k,v in j.items() if k not in ('route','output')}=={k:v for k,v in old.items() if k not in ('route','output')}
        assert j['export_ros'] and j['artifacts']
        route=p/'inputs'/(j['scenario']+'.json')
        assert route.read_bytes()==(repo/'docs/project_a/evidence/w3-benchmarks'/run/'inputs'/route.name).read_bytes()
    for filename,key in (('benchmark_w3.py','script_sha256'),('w3_benchmark_support.py','support_sha256')):
        assert sha((repo/'scripts/project_a'/filename).read_bytes())==m[key]
    rows=json.loads((p/'summary.json').read_text())['attempts']
    ledger=[json.loads(x) for x in (p/'attempts.jsonl').read_text().splitlines()]
    assert rows==ledger and len(rows)==len(jobs)
    assert set(r['id'] for r in rows)==set(jobs)
    observed={}
    published=[]
    for row in rows:
        identifier=row['id']; j=jobs[identifier]
        assert identifier not in observed
        observed[identifier]=row['status']; counts[row['status']]+=1
        data_bytes=(p/row['result_file']).read_bytes()
        assert sha(data_bytes)==row['result_sha256']
        d=json.loads(gzip.decompress(data_bytes))
        assert d['id']==identifier and d['status']==row['status'] and d['solver_policy']==j['solver_policy']
        assert d.get('worker_script_sha256')==m['script_sha256']
        assert d.get('worker_support_sha256')==m['support_sha256']
        if row['status']!=expected[run][identifier]:
            result['issues'].append({'id':identifier,'expected':expected[run][identifier],'actual':row['status'],'reason':d.get('reason'),'worker_exit_code':row['worker_exit_code']})
        if row['worker_exit_code']!=0:
            result['issues'].append({'id':identifier,'worker_exit_code':row['worker_exit_code'],'reason':'Worker did not complete normally; no expected-status relabeling'})
        if 'model_sha256' in d:
            assert d['model_sha256']==model_by_scenario[j['scenario']]
        if row['status']=='PASS':
            assert d['geometry']['status']==d['dynamics']['status']=='PASS'
            assert d['fine_query_count']>0 and len(d['H'])==64 and len(d['expected_curve_digest'])==64
            assert d['route_sha256']==sha((p/'inputs'/(j['scenario']+'.json')).read_bytes())
            phase_names={v['name'] for v in d['phases']}
            assert {'encode_stage_reload_dual_validation_atomic_publish','fine_true_metric_queries_without_refit','legacy_ros_export_without_refit'}<=phase_names
            artifact=p/'artifacts'/identifier/'reference.json'
            # The product path is determined by the current publisher and recorded explicitly.
            artifact=Path(d['artifact_path'])
            assert artifact.is_file()
            receipt=json.loads((p/'legacy'/identifier/'export.json').read_text())
            assert receipt['status']=='PASS' and receipt['H']==d['H'] and receipt['waypoint_count']>0
            assert (p/'legacy'/identifier/'global_waypoints.json').is_file()
            published.append({'id':identifier,'H':d['H'],'curve_digest':d['expected_curve_digest'],'fine_query_count':d['fine_query_count'],'artifact_sha256':sha(artifact.read_bytes()),'export_receipt':receipt})
    result['runs'][run]={'attempts':len(rows),'statuses':dict(collections.Counter(observed.values())),'manifest_sha256':sha((p/'manifest.json').read_bytes()),'published':published}
result['status_counts']=dict(counts)
result['status']='PASS' if not result['issues'] else 'FAIL'
(output/'independent-replay-check.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'counts':result['status_counts'],'issues':result['issues']},indent=2))
sys.exit(bool(result['issues']))
