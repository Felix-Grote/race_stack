#!/bin/bash
set -eo pipefail
source /opt/ros/humble/setup.bash
mkdir -p /records/install-work/src
cp -a /src/planner/global_planner /records/install-work/src/
cp -a /src/utilities/libraries/f110_msgs /src/utilities/libraries/frenet_conversion /records/install-work/src/
python /src/scripts/project_a/source_manifest.py --repository /src --build-identity /records/install-work/src/global_planner/config/project_a/build_identity.json
python /usr/bin/colcon --log-base /records/install-work/log build --base-paths /records/install-work/src --build-base /records/install-work/build --install-base /records/install-work/install --packages-select f110_msgs frenet_conversion global_planner --parallel-workers 2 2>&1 | tee /records/ros-build.log
source /records/install-work/install/setup.bash
export PYTHONPATH=/src/planner/global_planner:/src/scripts/project_a:$PYTHONPATH
python -m pip freeze > /records/pip-freeze.txt
python - <<'PY'
import json, platform
import numpy, scipy, quadprog, trajectory_planning_helpers, rclpy
from f110_msgs.msg import Wpnt, WpntArray
from rclpy.serialization import deserialize_message, serialize_message
msg=WpntArray(wpnts=[Wpnt(id=1,x_m=2.)]); assert deserialize_message(serialize_message(msg),WpntArray)==msg
print(json.dumps({'numpy':numpy.__version__,'scipy':scipy.__version__,'python':platform.python_version(),'ROS_CDR_preflight':'PASS'}))
PY
# Both corpora execute serially with their original frozen job policies and outer limits.
set +e
python /records/full-replay/primary/run_manifest.py --manifest /records/full-replay/primary/manifest.json --worker /src/scripts/project_a/benchmark_w3.py 2>&1 | tee /records/primary-console.log
primary_rc=${PIPESTATUS[0]}
python /records/full-replay/matched-coarse/run_manifest.py --manifest /records/full-replay/matched-coarse/manifest.json --worker /src/scripts/project_a/benchmark_w3.py 2>&1 | tee /records/matched-console.log
matched_rc=${PIPESTATUS[0]}
set -e
printf 'primary=%s\nmatched_coarse=%s\n' "$primary_rc" "$matched_rc" > /records/runner-exit-codes.txt
# Exact status/identity/artifact checks decide success; runner exit zero alone is insufficient.
python /harness/scripts/project_a/independent_benchmarks/check_replay.py /src /records/full-replay
