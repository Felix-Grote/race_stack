# Literal b961d20 full 96 original hosted evidence

The read-only independent audit is PASS for the original hosted full 96 replay.
This is one evidence gate; it does not declare W3 ACCEPT or production readiness.

Run [39110811058](https://github.com/Felix-Grote/race_stack/actions/runs/39110811058)
is SUCCESS, attempt 1, job 117626360707. The workflow harness is
`7fcecd9330a153b8656033e821f23a1f59b32fc2`. Authenticated original job logs,
literal workflow bytes, runner manifest, source identity and 138 source hashes
prove that the numerical checkout was separately the literal candidate
`b961d20ce4a803e55336fb5590c30574e23b2fad`, clean before and after execution.
The SHA in the workflow run API belongs to the harness, not the numerical source.

`original-final96.zip` is the native authenticated GitHub connector download of
artifact 12131293704. Its API byte size 24,320,530 and SHA256
`825f3fa1906c6e51088db277cdbf399a46af4bf57f9abf961470db18f2a33a7c`
match exactly. No proxy/TLS overrides were used. All 848 members are unique,
safe ordinary file paths;847 payload files match the original `files.json`.
Original API snapshots, decoded authenticated job log and original ZIP remain.

`audit_final96.py` imports no planner module and runs no QP or container. It
checks frozen originals directly against literal Git objects, unchanged routes,
all 96 job IDs, original policies/limits, reviewed helper change, source hashes,
append-only ledger, console records, result digests and raw outcomes:

| Variant | PASS | Stock preparation failure | Resource limit | Conditioning failure |
| --- | ---: | ---: | ---: | ---: |
| New adapter | 28 | 0 | 6 | 2 |
| Stock | 0 | 28 | 0 | 0 |
| Adapted repaired legacy | 30 | 0 | 2 | 0 |
| Total | 58 | 28 | 8 | 2 |

The benchmark worker is unchanged SHA256
`9e7f028e40c224afc519c096c9326c52bae836c0c60579fddfe9bc23a02912a5`.
The reviewed support SHA256 is
`6ba5f671f1152a46eaff3e25cec4979c2c2bfbf8b1b825425a2dc5d27223622b`.
The patch moves exactly the original initial fit into its existing exception
boundary. No equations, successful numerical path, condition/residual policy or
resource budgets changed. Historical source support 29a25360 remains identified.

All 58 successful raw results have checked current H/C, exact implementation module
hashes, source route/model, footprint, policies, publication, fine metric queries,
negative artifact controls and actual nine-group reader/CDR export receipts.
Every continuous geometry leaf has sufficient clearance and positive regularity,
with exact rational interval coverage of every cubic. Every dynamics edge has
positive speed, correct cyclic profile connections, accepted residuals, distance
and time enclosures. Actual QP conditions, primal residuals, iteration counts and
RSS remain within frozen limits. All 29 repeated pairs retain identical authority,
numerical values and checked receipts. Only predeclared jobs execute; the runner
rejects existing per-job outputs. The branch API lists one run of this benchmark
workflow, with run_attempt 1. The other branch workflow is ordinary Project A CI.

The independent numerical oracle uses 48-point Gauss quadrature on the actual
cubics and affine squared-speed edges, including the closing edge. It checks
length, integrated curvature energy, every edge distance/acceleration/time, all
exported right-hand retiming metadata and nominal lap time. Maximum absolute
nominal time discrepancy is 5.684341886080802e-14s. Sampled derivative/curvature
checks cross-check the continuous witnesses. These floating cross-checks are
diagnostics, not an independent regeneration of the rational continuous proofs.

All 30 repaired outputs preserve actual raw create_raceline coefficients/q and
monotone inherited q. Independent Fraction composition reconstructs every
adapted binary64 cubic and checks the captured error enclosure; largest declared
coordinate roundoff bound is 3.5315338435704532e-15m. Raw native geometry and
native velocity authority remain UNSUPPORTED. Common body/model and W2 retiming
apply only to the separately adapted authority. Matching spacing is required:

| S6 spacing | New model time, s | Adapted repaired model time, s | New energy, 1/m | Adapted repaired energy, 1/m |
| --- | ---: | ---: | ---: | ---: |
|.52m|68.00978787596144|67.9123088456264|.18992280180447835|.18999728506369107|
|.53m|68.00722143989995|67.91670249101215|.19009652212192069|.18998484418200037|

The new .5m attempt fails conditioning before a candidate; .4/.2/.1m requests
fail their original point limits. Repaired .5m passes, while repaired .4m exceeds
its point budget. These remain real negative outcomes. No result establishes
minimum curvature/time, general scale robustness or physical car/course approval.
Final96 executes serially with one numerical thread under 2-CPU container limits;
outer wall telemetry is descriptive and is not a new isolated whole-tree CPU claim.

The candidate's W3_BENCHMARKS.md and evidence/w3-independent/benchmarks.md were
reviewed as historical reports: they explicitly distinguish original 0c2d7c3/
17e4ec4 evidence, adaptation, source identity, unsupported raw/native claims,
failed sensitivity attempts and model-only times. Their old H/C and historical
numerical last bits are not approvals for final b961 artifacts. The fresh hosted
records above supply current-source provenance without rewriting that history.

Run `OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python3 audit_final96.py` from any
directory in this retained workspace. `audit-final96.json` contains all 58 checked
artifact authorities and all 38 negative identities/reasons. The separate nine
unchanged-artifact installed dual-validator replay is owned by runtime_final.
