"""Independent, read-only original hosted 96-job audit; no product imports or QP."""
import collections
from fractions import Fraction as F
import gzip
import hashlib
import json
import math
from pathlib import Path
import subprocess
import numpy as np

P=Path(__file__).parent
A=P/'artifact'
R='/workspace/forza-w3-audit'
S='b961d20ce4a803e55336fb5590c30574e23b2fad'
HS='7fcecd9330a153b8656033e821f23a1f59b32fc2'
sha=lambda b:hashlib.sha256(b).hexdigest()
def canonical(v,ascii=True):
    return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=ascii,allow_nan=False).encode()
def read(p):return json.loads(p.read_bytes())
def git(path,commit=S):return subprocess.check_output(['git','-C','/workspace/final-benchmarks-runner' if commit==HS else R,'show',commit+':'+path])
def close(a,b,atol=2e-9,rtol=2e-9):
    assert math.isfinite(a) and math.isfinite(b) and abs(a-b)<=atol+rtol*max(abs(a),abs(b)),(a,b)
report={'implementation':S,'workflow_harness':HS,'scope':'Read-only authenticated original hosted bytes; all96 provenance/status/policy/result/certificate/legacy lineages checked. Independent floating numerical oracles supplement but do not replace interval proofs. No product imports, optimization or Docker launched.'}
run=read(P/'run.json');api=read(P/'artifacts.json')['artifacts'][0]
assert run['id']==39110811058 and run['head_sha']==HS and run['event']=='push' and run['status']=='completed' and run['conclusion']=='success' and run['run_attempt']==1
assert api['workflow_run']['id']==run['id'] and api['workflow_run']['head_sha']==HS
branch=read(P/'branch-runs.json');assert branch['total_count']==len(branch['workflow_runs'])
same_workflow=[x for x in branch['workflow_runs'] if x['workflow_id']==run['workflow_id']]
assert len(same_workflow)==1 and same_workflow[0]['id']==run['id'] and same_workflow[0]['run_attempt']==1
raw=(P/'original-final96.zip').read_bytes();assert sha(raw)==api['digest'].removeprefix('sha256:') and len(raw)==api['size_in_bytes']
jobs=read(P/'jobs.json')['jobs'];assert len(jobs)==1 and jobs[0]['id']==117626360707 and jobs[0]['conclusion']=='success' and all(s['conclusion'] in ('success','skipped') for s in jobs[0]['steps'])
log=(P/'authenticated-job.log').read_text();assert '[command]/usr/bin/git checkout --progress --force '+S in log and 'git log -1 --format=%H' in log and S in log
assert (A/'source-sha.txt').read_text().strip()==S and (A/'harness-sha.txt').read_text().strip()==HS
runner=read(A/'runner.json');assert runner['environment']['GITHUB_RUN_ID']==str(run['id']) and runner['environment']['GITHUB_RUN_ATTEMPT']=='1' and runner['environment']['GITHUB_SHA']==HS and runner['source_sha']==S
ledger=read(A/'files.json');names=[x['path'] for x in ledger];assert len(names)==len(set(names));actual={str(x.relative_to(A)) for x in A.rglob('*') if x.is_file()};assert actual==set(names)|{'files.json'}
for row in ledger:
    b=(A/row['path']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256'],row['path']
before=read(A/'source-hashes-before.json');assert before==read(A/'source-hashes-after.json')
push=read(P.parent/'final-evidence-b961d20/hosted-audit.json');assert len(before)==push['source_hashes_equal_literal_git']
import zipfile
with zipfile.ZipFile(P.parent/'final-evidence-b961d20/original-push.zip') as z:assert before==json.loads(z.read('source-hashes-before.json'))
for name in ('prepare_full_replay.py','original_prepare_full_replay.py','check_replay.py','container_run.sh'):
    assert (A/name).read_bytes()==git('scripts/project_a/independent_benchmarks/'+name,HS)
workflow=git('.github/workflows/w3-independent-final-benchmarks.yml',HS).decode();assert 'ref: '+S in workflow and '--network none --read-only --cap-drop ALL' in workflow
patch=subprocess.check_output(['git','-C',R,'show','abdbc4ab232ebe850ec1b8c096fc89a2480c29b9','--','scripts/project_a/w3_benchmark_support.py']);assert patch==(A/'reviewed-support-change.patch').read_bytes()
changed=[x for x in patch.decode().splitlines() if x.startswith(('+','-')) and not x.startswith(('+++','---'))]
assert len(changed)==2 and changed[0][1:].strip()==changed[1][1:].strip()=='x, y, matrix, normals = fit(np.vstack((track[:, :2], track[0, :2])))'
assert (A/'runner-exit-codes.txt').read_text()=='primary=0\nmatched_coarse=0\n'
gx,gw=np.polynomial.legendre.leggauss(48)
def derivatives(c,t):
    c=np.asarray(c);t=np.asarray(t)
    d=c[:,1,None]+2*c[:,2,None]*t+3*c[:,3,None]*t*t
    dd=2*c[:,2,None]+6*c[:,3,None]*t
    speed=np.sqrt((d*d).sum(axis=0));curv=(d[0]*dd[1]-d[1]*dd[0])/speed**3
    return speed,curv
def integral(c,lo=0.,hi=1.,energy=False):
    speed,curv=derivatives(c,lo+(hi-lo)*(gx+1)/2)
    return float(np.dot(gw,speed*(curv**2 if energy else 1))*(hi-lo)/2)
counts=collections.Counter();variants=collections.defaultdict(collections.Counter);passed=[];rejected=[];maxima=collections.defaultdict(float)
expected=read(A/'full-replay/expected-statuses.json')
for name in ('primary','matched-coarse'):
    p=A/'full-replay'/name;ev='docs/project_a/evidence/w3-benchmarks/'+name+'/'
    m=read(p/'manifest.json');old=read(p/'original-manifest.json');historical=read(p/'historical-summary.json')['attempts'];hs={r['id']:r['status'] for r in historical}
    assert (p/'original-manifest.json').read_bytes()==git(ev+'manifest.json') and (p/'historical-summary.json').read_bytes()==git(ev+'summary.json')
    assert sha((p/'original-manifest.json').read_bytes())==m['independent_replay_of_manifest_sha256'] and sha((p/'historical-summary.json').read_bytes())==m['historical_summary_sha256']
    assert expected[name]==hs and m['source_sha']==S and m['source_status']=='' and m['outer_policy_predeclared']==old['outer_policy_predeclared']
    for k in ('dependencies','fixtures','dynamics_policy','geometry_policy','retime_policy','legacy_preparation_settings'):
        if k in old:assert m[k]==old[k],k
    assert m['script_sha256']==sha(git('scripts/project_a/benchmark_w3.py'))=='9e7f028e40c224afc519c096c9326c52bae836c0c60579fddfe9bc23a02912a5'
    assert m['support_sha256']==sha(git('scripts/project_a/w3_benchmark_support.py'))=='6ba5f671f1152a46eaff3e25cec4979c2c2bfbf8b1b825425a2dc5d27223622b'
    assert m['independent_reviewed_support_amendment']['original_sha256']==old['support_sha256']=='29a25360fc2ee4411fb6483ae70dffda30335cbebec1d02a0218ec3a9ae50f59'
    assert (p/'run_manifest.py').read_bytes()==git('docs/project_a/evidence/w3-benchmarks/matched-coarse/run_manifest.py')
    js={j['id']:j for j in m['jobs']};ojs={j['id']:j for j in old['jobs']};assert len(js)==len(m['jobs'])==len(hs)
    rows=read(p/'summary.json')['attempts'];assert rows==[json.loads(x) for x in (p/'attempts.jsonl').read_text().splitlines()] and len(rows)==len(js)
    console=[json.loads(x) for x in (A/('primary-console.log' if name=='primary' else 'matched-console.log')).read_text().splitlines()]
    assert console==[{k:r[k] for k in ('id','status','reason','outer_wall_seconds')} for r in rows]
    assert len(set(r['id'] for r in rows))==len(rows) and set(r['id'] for r in rows)==set(js)
    assert {x.name for x in p.glob('*.job.json')}=={j+'.job.json' for j in js}
    models={r['scenario']:r['model_sha256'] for r in historical if 'model_sha256' in r}
    for row in rows:
        ident=row['id'];j=js[ident];oj=ojs[ident]
        assert {k:v for k,v in j.items() if k not in ('route','output')}=={k:v for k,v in oj.items() if k not in ('route','output')}
        assert read(p/(ident+'.job.json'))==j and j['export_ros'] and j['artifacts']
        route=(p/'inputs'/(j['scenario']+'.json')).read_bytes();assert route==git(ev+'inputs/'+j['scenario']+'.json')
        b=(p/row['result_file']).read_bytes();assert sha(b)==row['result_sha256'];d=json.loads(gzip.decompress(b))
        for k in ('id','scenario','variant','repeat','solver_policy'):assert d[k]==j[k],(ident,k)
        assert row['worker_exit_code']==0 and d['status']==row['status']==hs[ident] and d['worker_script_sha256']==m['script_sha256'] and d['worker_support_sha256']==m['support_sha256']
        assert d['route_sha256']==sha(route) and d['route_bytes']==len(route)
        counts[d['status']]+=1;variants[j['variant']][d['status']]+=1
        assert row['outer_wall_seconds']<=m['outer_policy_predeclared']['wall_seconds'] and row['parent_peak_rss_bytes']<m['outer_policy_predeclared']['address_space_bytes']
        progress=[json.loads(x) for x in (p/(ident+'.progress.jsonl')).read_text().splitlines()];assert progress
        if d['status']!='PASS':
            assert not (p/'artifacts'/ident).exists() and not (p/'legacy'/ident).exists()
            if d['status']=='SOLVER_FAILURE':
                assert j['variant']=='new' and 'ill-conditioned' in d['reason']
                values=[x['failed_input_matrix_condition'] for x in d['phases'] if 'failed_input_matrix_condition' in x];assert values and max(values)>j['solver_policy']['max_condition']
            elif d['status']=='RESOURCE_LIMIT':assert 'point budget' in d['reason'] or 'max_points' in d['reason'] or 'point/wall' in d['reason'],d['reason']
            elif d['status']=='STOCK_PREPARATION_FAILURE':assert j['variant']=='stock' and 'Input vector should be 1-D' in d['reason'] and d['legacy']['repairs']==[]
            rejected.append({'id':ident,'status':d['status'],'reason':d['reason']});continue
        assert d['geometry']['status']==d['dynamics']['status']==d['geometry_status']==d['dynamics_status']=='PASS' and d['retime_status']=='CANDIDATE'
        assert d['model_sha256']==models[j['scenario']] and sha(canonical(d['model']))==d['model_sha256']
        artifact=A/Path(d['artifact_path']).relative_to('/records');env=read(artifact);v=env['payload'];H=sha(canonical(v,False));assert H==env['H']==d['H'] and artifact.parent.name==H
        assert v['curve']['coefficients']==d['coefficients'] and v['curve']['owners']==d['owners'] and v['curve']['q']==d['q']
        C=sha(canonical(dict(v['curve'],route_digest=sha(canonical(v['approved_route'])),numeric_policy=v['policies']['numeric'])))
        assert C==v['approved_curve_digest']==d['expected_curve_digest']==d['geometry']['curve_digest']==d['dynamics']['curve_digest']==v['speed_profile']['curve_digest']
        assert v['model']==d['model'] and v['footprint']==d['footprint'] and v['validation']['geometry']==d['geometry'] and v['validation']['dynamics']==d['dynamics']
        assert v['speed_profile']==d['retime']['profile'] and v['policies']['solver']==j['solver_policy']
        for mod,h in v['implementation']['module_sha256'].items():assert h==sha(git('planner/global_planner/global_planner/'+mod+'.py'))
        assert v['implementation']['dependencies']==m['dependencies'] and v['implementation']['optimizer_gitlink']=='b1b38ecfefec7200d5bcb243f115af1d795b3766'
        assert sha(json.dumps(d['coefficients'],separators=(',',':'),allow_nan=False).encode())==d['geometry']['coefficients_sha256']
        assert d['geometry']['route_sha256']==sha(route) and d['dynamics']['model_digest']==d['model_sha256']
        q=d['q'];assert q[0]==0 and all(a<b for a,b in zip(q,q[1:])) and len(q)==len(d['coefficients'])+1
        assert d['fine_query_count']==math.ceil(d['length_m']/.1) and d['fine_query_count']>0
        phases={x['name'] for x in d['phases']};assert {'encode_stage_reload_dual_validation_atomic_publish','fine_true_metric_queries_without_refit','legacy_ros_export_without_refit'}<=phases
        if j['repeat']==1:assert len(d['artifact_negative_controls'])==2 and all(x['status']=='REJECTED' for x in d['artifact_negative_controls'])
        if j['scenario']=='S1-wall-gaps':assert d['required_physical_coverage']['status']=='INCONCLUSIVE'
        qps=[x['qp'] for x in d['traces']] if j['variant']=='new' else d['legacy']['qps'];assert j['solver_policy']['max_iterations']>=len(qps)==d['iterations']>=j['solver_policy']['min_iterations']
        for z in qps:
            assert z['condition']<=j['solver_policy']['max_condition'] and z['max_violation']<=j['solver_policy']['qp_residual'] and z['peak_rss_bytes']<=j['solver_policy']['qp_memory_bytes']
        close(max(z['condition'] for z in qps),d['qp_condition_max']);close(max(z['max_violation'] for z in qps),d['qp_primal_residual_max'])
        close(sum(integral(c) for c in d['coefficients']),d['length_m'])
        energy=sum(integral(c,energy=True) for c in d['coefficients']);close(energy,d['curvature_energy_final_per_m'],1e-8,1e-7)
        intervals=d['geometry']['intervals'];byseg=collections.defaultdict(list)
        for z in intervals:
            assert z['clearance_lower_m']>=z['required_margin_m'] and z['speed_lower']>0 and 0<=z['t0']<z['t1']<=1
            lo,hi=F(*z['exact_t0']),F(*z['exact_t1']);byseg[z['segment']].append((lo,hi))
            speed,curv=derivatives(d['coefficients'][z['segment']],np.linspace(z['t0'],z['t1'],9));assert np.min(speed)+1e-10>=z['speed_lower'] and np.max(np.abs(curv))<=z['curvature_upper']+1e-9
        assert set(byseg)==set(range(len(d['coefficients'])))
        for ranges in byseg.values():
            end=F(0)
            for lo,hi in sorted(ranges):assert lo<=end and lo<hi;end=max(end,hi)
            assert end==1
        for gate in d['geometry']['gates']:assert gate['signed_direction_upper']<0 and gate['q_lower']<=gate['q_upper']
        knots=v['speed_profile']['knots'];edges=d['dynamics']['edges'];assert len(knots)==len(edges)==d['retime_edges']
        times=[];distance_total=0.;maxres=max(z['normalized_residual_upper'] for z in edges);metadata=d['retime']['metadata']
        assert metadata['curve_digest']==C and all(len(metadata[k])==len(knots) for k in ('stations_m','velocity_mps','acceleration_mps2','curvature_per_m','time_s'))
        for i,(k,z) in enumerate(zip(knots,edges)):
            nxt=knots[(i+1)%len(knots)];assert z['edge']==i and z['segment']==k['segment'] and z['t0']==k['t'] and z['closing']==(i==len(knots)-1)
            assert z['normalized_residual_upper']<=v['policies']['dynamics']['residual_abs'] and z['steering_angle_residual_rad']<=v['policies']['dynamics']['angle_abs_rad']
            end=nxt['t'] if nxt['segment']==k['segment'] and i+1<len(knots) else 1.;assert z['t1']==end
            dist=integral(d['coefficients'][k['segment']],k['t'],end);close(dist,z['distance_m'],3e-10,1e-10);assert z['distance_lower_m']-3e-10<=dist<=z['distance_upper_m']+3e-10
            acceleration=(nxt['u']-k['u'])/(2*dist);assert z['acceleration_lower_mps2']-1e-7<=acceleration<=z['acceleration_upper_mps2']+1e-7
            close(metadata['stations_m'][i],distance_total);close(metadata['time_s'][i],math.fsum(times));close(metadata['velocity_mps'][i],math.sqrt(k['u']));close(metadata['acceleration_mps2'][i],acceleration,1e-7,1e-7)
            _,k0=derivatives(d['coefficients'][k['segment']],[k['t']]);close(metadata['curvature_per_m'][i],float(k0[0]))
            speed,curv=derivatives(d['coefficients'][k['segment']],np.linspace(k['t'],end,9));assert np.max(np.abs(curv))<=z['curvature_upper']+1e-9
            assert min(k['u'],nxt['u'])>0 and max(k['u'],nxt['u'])<=z['cap_mps']**2+1e-7
            dt=2*dist/(math.sqrt(k['u'])+math.sqrt(nxt['u']));assert z['time_lower_s']-1e-9<=dt<=z['time_upper_s']+1e-9;times.append(dt);distance_total+=dist
        T=math.fsum(times);close(T,d['lap_time_s']);close(distance_total,d['length_m']);assert d['dynamics']['lap_time_lower_s']-2e-9<=T<=d['dynamics']['lap_time_upper_s']+2e-9
        close(metadata['lap_time_s'],T)
        maxima['lap_time_absolute_oracle_error_s']=max(maxima['lap_time_absolute_oracle_error_s'],abs(T-d['lap_time_s']));maxima['dynamic_normalized_residual_upper']=max(maxima.get('dynamic_normalized_residual_upper',-math.inf),maxres)
        if j['variant']=='repaired':
            leg=d['legacy'];assert leg['legacy_velocity']['status']=='UNSUPPORTED' and leg['raw_legacy_geometry_authorization']['status']=='UNSUPPORTED' and leg['coefficient_source']=='actual final create_raceline return; no sampled refit'
            assert leg['sources']=={'spline_approximation.py':'a1e6259858f24ba28493d1f049e88710385d2d218a5cbca1a1d2835904e81d52','iqp_handler.py':'b764ff805fd5585a6dfb30e23b1c0b3ef667c91d66129dca78d9b37a356f65ae','create_raceline.py':'98985622e8995f04fe38292f844b51b4fc9a1114825389eea3538279bca43fb5'}
            assert leg['create_raceline_sha256']==leg['sources']['create_raceline.py']
            assert leg['algebraic_subdivision'] and leg['closest_parameters'] and leg['repairs']
            for lin in leg['lineage']:
                src=lin['source_q'];inherit=lin['inherited_q'];assert all(a<b for a,b in zip(src,src[1:])) and all(a<b for a,b in zip(inherit,inherit[1:]))
                assert len(lin['segment'])==len(lin['t'])==len(inherit)-1
                for ix,t,got in zip(lin['segment'],lin['t'],inherit):close((1-t)*src[ix]+t*src[ix+1],got,1e-12,1e-12)
            # Recompose every raw cubic exactly in rational arithmetic, compare
            # against captured binary64 pieces and the recorded error enclosure.
            pieces=[];period=q[-1]
            for rec in leg['algebraic_subdivision']:
                ix=rec['source_segment'];rawc=leg['actual_final_coefficients'][ix];lower,upper=map(F,leg['actual_final_q'][ix:ix+2]);first,last=map(F,rec['source_q_interval']);start=(first-lower)/(upper-lower);step=(last-first)/(upper-lower)
                polynomial=[[sum(F(rawc[axis][k])*math.comb(k,jj)*start**(k-jj)*step**jj for k in range(jj,4)) for jj in range(4)] for axis in (0,1)]
                lap=math.floor((float(first)+float(last))/(2*period));pieces.append((float(first)-lap*period,polynomial,rec['coordinate_composition_roundoff_bound_m']))
            assert len(pieces)==len(d['coefficients'])
            for (_,exact,bound),actualc in zip(sorted(pieces,key=lambda x:x[0]),d['coefficients']):
                err=sum(abs(F(actualc[axis][jj])-exact[axis][jj]) for axis in (0,1) for jj in range(4));assert float(err)<=bound+1e-30
            maxima['legacy_composition_roundoff_bound_m']=max(maxima['legacy_composition_roundoff_bound_m'],leg['composition_roundoff_bound_m'])
        receipt=read(p/'legacy'/ident/'export.json');wp=read(p/'legacy'/ident/'global_waypoints.json');assert receipt['status']=='PASS' and receipt['H']==H and receipt['reason']=='Existing nine-group reader and ROS CDR roundtrip passed'
        assert len(wp)==9 and receipt['waypoint_count']==len(wp['global_traj_wpnts_iqp']['wpnts']);close(receipt['lap_time_s'],T);assert all(a['s_m']<b['s_m'] for a,b in zip(wp['global_traj_wpnts_iqp']['wpnts'],wp['global_traj_wpnts_iqp']['wpnts'][1:]))
        passed.append({'id':ident,'H':H,'curve_digest':C,'artifact_sha256':sha(artifact.read_bytes()),'fine_query_count':d['fine_query_count'],'lap_time_s':T,'geometry_leaves':len(intervals),'dynamics_edges':len(edges),'export_waypoints':receipt['waypoint_count'],'qp_count':len(qps)})
assert counts=={'PASS':58,'STOCK_PREPARATION_FAILURE':28,'RESOURCE_LIMIT':8,'SOLVER_FAILURE':2},counts
pair_groups=collections.defaultdict(list)
for z in passed:pair_groups[z['id'].rsplit('-r',1)[0]].append(z)
assert len(pair_groups)==29 and all(len(z)==2 for z in pair_groups.values())
for zs in pair_groups.values():
    assert {k:v for k,v in zs[0].items() if k!='id'}=={k:v for k,v in zs[1].items() if k!='id'}
report.update(PASS=True,run_id=run['id'],artifact_id=api['id'],zip_sha256=sha(raw),zip_bytes=len(raw),file_ledger_count=len(ledger),literal_source_hashes=len(before),run_attempt=1,status_counts=dict(counts),variants={k:dict(v) for k,v in variants.items()},passed=passed,rejected=rejected,numerical_oracle_maxima=dict(maxima),limitations=['Floating quadrature and pointwise curvature checks are numerical cross-checks, not independent exact proof regeneration. Every continuous certificate and exact interval coverage retained and checked; nine real installed dual-validator replays are separate.','No claim of minimum curvature/time optimality, physical vehicle validation, production readiness or W3 acceptance.'])
report['repeat_pairs_identical_authority_and_diagnostics']=len(pair_groups)
report['no_hidden_retries']={'same_workflow_branch_runs':len(same_workflow),'run_attempt':run['run_attempt'],'unique_rows':sum(counts.values()),'console_exactly_matches_append_only_ledger':True,'fresh_output_refuses_overwrite':True}
(P/'audit-final96.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('passed','rejected')},indent=2))
