# Independent W3 original failing-first evidence

Original reviewed implementation: `17e4ec4e8fedfa736467d02f6204b04e8552decb`.
The finding is described in `../../W3_INDEPENDENT_FINDINGS.md`.

`phase-i/query_zero_repro.py` retains the independently written original
reproducer. Run it with the pinned environment produced by the repository's safe
setup, with explicit paths:

```bash
python query_zero_repro.py --repo /explicit/exact-17e4ec4-checkout \
  --output /explicit/new-scratch/positive-profile --publish
```

The original expected exit is nonzero at the final positive-speed assertion,
after actual geometry/dynamics PASS and public publication/load PASS. The log
records Python 3.10.12 and unchanged original q, H, exact query station and observed
zero speed. It is not an unsupported-host or wrong-filename negative control.

`phase-i/original-source-identity.json` records the original source identities;
`SHA256SUMS` records these retained files relative to the repository root.
The corrected implementation must pass the new permanent regression and complete
final verification with its own literal-head push CI. This evidence alone is not
a final acceptance verdict or a physical vehicle claim.
