"""Read-only AST inventory for a concrete compact future production test selection."""
import ast
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path('/workspace/forza-audit-records/final-checkout')
BASE = ROOT / 'planner/global_planner/test'
OUT = Path('/workspace/forza-audit-records/production-preparation')
selection = {
 'test_route_input.py': [
  'test_selected_cycles', 'test_separate_branches_and_overlapping_surfaces',
  'test_semantic_adversaries', 'test_seed_cannot_recross_ownership_end_cap'],
 'test_route_reference.py': [
  'test_nonuniform_parameter_analytic_parabola', 'test_circle_metric_sign_and_periodicity',
  'test_original_speed_feature_and_explicit_budget_exhaustion',
  'test_canonical_endpoint_owners_and_adjacent_floats',
  'test_negative_seam_progress_retains_preceding_side'],
 'test_route_corridor.py': [
  'test_crossing_surfaces_do_not_share_widths_or_ownership',
  'test_normal_tangent_cuts_preserve_connected_interior',
  'test_distinct_close_semantic_caps_are_not_coalesced_or_preapplied',
  'test_metric_seam_samples_and_exact_portal_anchors_share_ownership'],
 'test_route_w2_shared_cap.py': [
  'test_exact_shared_cap_two_quadrilaterals_have_identical_cuts',
  'test_distinct_actual_gaps_are_never_merged'],
 'test_iqp_route_adapter.py': [
  'test_exact_64_knot_direct_pinned_equation_oracle',
  'test_whole_lap_candidates_and_original_intersections_every_qp',
  'test_final_exact_tum_shifted_coefficients_are_authority'],
 'test_route_validate_bounds_oracle.py': [
  'test_between_node_curvature_and_curvature_rate_peaks_are_enclosed',
  'test_nearly_parallel_large_derivatives_do_not_erase_small_curvature',
  'test_near_zero_derivative_requires_proof_and_retains_large_curvature',
  'test_squared_underflow_or_subnormal_conversion_never_grants_false_bound'],
 'test_route_validate_geometry.py': [
  'test_actual_whole_lap_candidates_have_independent_swept_certificates',
  'test_disconnected_projected_crossing_preserves_occurrence_surface_authority',
  'test_full_validator_rejects_original_notch_between_legal_solver_knots',
  'test_interior_curvature_peak_fails_even_when_every_coefficient_knot_passes',
  'test_all_resource_exhaustion_is_explicitly_inconclusive'],
 'test_route_w2_handoff.py': [
  'test_missing_independent_handoff_cannot_receive_either_pass',
  'test_rehashed_monotone_q_warp_cannot_move_an_original_cap'],
 'test_cyclic_retime.py': [
  'test_seam_cap_is_applied_before_retiming_with_upstream_braking',
  'test_table_full_range_minima_hashes_and_no_extrapolation'],
 'test_route_artifact.py': [
  'test_exact_roundtrip_preserves_w2_signed_zero_and_authority',
  'test_codec_preserves_numeric_spelling_bool_and_null',
  'test_strict_json_rejects_malformed_duplicate_overflow_and_depth',
  'test_predecode_nodes_text_and_encoded_byte_limits',
  'test_wrong_missing_expected_H_and_unsupported_context',
  'test_existing_target_and_unknown_extra_files_are_never_replaced',
  'test_publication_failure_is_absent_or_fully_valid',
  'test_concurrent_writers_have_one_winner_and_no_replacement',
  'test_coordinated_payload_q_profile_and_reports_cannot_replace_original_producer_approval',
  'test_historical_numeric_variation_does_not_reject_fresh_dual_pass',
  'test_historical_geometry_can_have_a_different_genuine_adaptive_partition',
  'test_historical_snapshots_fail_closed_on_incoherent_claims',
  'test_historical_PASS_never_overrides_failed_or_uncertain_fresh_proof',
  'test_frozen_main_time_must_remain_inside_fresh_enclosure',
  'test_publication_checks_ancestors_before_creating_output',
  'test_loaded_positive_profile_keeps_positive_speed_at_nextafter_boundaries'],
 'test_route_legacy_export.py': [
  'test_fields_follow_saved_coefficients_true_metric_and_original_owned_sides',
  'test_profile_boundaries_and_terminal_use_independent_closing_acceleration_and_main_time',
  'test_corrupt_staged_ros_serialization_is_never_published'],
}


def start(n):
 return min([n.lineno] + [d.lineno for d in getattr(n, 'decorator_list', [])])


def names(n):
 return {v.id for v in ast.walk(n) if isinstance(v, ast.Name) and isinstance(v.ctx, ast.Load)}


records=[]
for filename, chosen in selection.items():
 path=BASE/filename; raw=path.read_text(); tree=ast.parse(raw)
 functions={n.name:n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
 imports={}
 constants={}
 for n in tree.body:
  if isinstance(n,ast.Import):
   for a in n.names:imports[a.asname or a.name.split('.')[0]]=ast.get_source_segment(raw,n)
  if isinstance(n,ast.ImportFrom):
   for a in n.names:imports[a.asname or a.name]=ast.get_source_segment(raw,n)
  if isinstance(n,(ast.Assign,ast.AnnAssign)):
   for x in ast.walk(n):
    if isinstance(x,ast.Name) and isinstance(x.ctx,ast.Store):constants[x.id]=n
 closure=set(chosen); queue=list(chosen)
 while queue:
  n=functions[queue.pop()]
  dependencies=names(n) | {a.arg for a in n.args.args if a.arg in functions}
  for name in dependencies:
   if name in functions and name not in closure:
    closure.add(name);queue.append(name)
 for name in chosen:
  n=functions[name]; used=names(n)
  helpers=sorted((used | {a.arg for a in n.args.args}) & set(functions) - {name})
  records.append({'source':str(path.relative_to(ROOT)),'function':name,
   'start_line':start(n),'end_line':n.end_lineno,'source_span_loc':n.end_lineno-start(n)+1,
   'fixture_arguments':[a.arg for a in n.args.args],
   'same_file_function_dependencies':helpers,
   'direct_import_dependencies':{k:v for k,v in imports.items() if k in used},
   'module_constant_dependencies':{k:ast.get_source_segment(raw,v)
         for k,v in constants.items() if k in used},
   'source_file_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
   'default_target':'ordinary_numerical' if filename in (
        'test_iqp_route_adapter.py','test_route_validate_geometry.py','test_route_w2_handoff.py',
        'test_cyclic_retime.py','test_route_artifact.py','test_route_legacy_export.py') else 'fast',
  })
archive=BASE/'fixtures/project_a/w2_a04_candidates.json.gz'
record=json.loads(gzip.decompress(archive.read_bytes()))['candidates']['s0_route']
small={k:record[k] for k in ('coefficients','owners','q')}
canonical=json.dumps(small,sort_keys=True,separators=(',',':')).encode()
result={'status':'READ_ONLY_CONCRETE_SELECTION_NOT_IMPLEMENTED_OR_ACCEPTED',
 'candidate_sha':'b961d20ce4a803e55336fb5590c30574e23b2fad',
 'selected_test_functions':records,
 'test_function_count':len(records),
 'unchanged_test_function_span_loc':sum(x['source_span_loc'] for x in records),
 'minimal_coefficient_fixture':{
  'source_archive':str(archive.relative_to(ROOT)),
  'source_archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
  'source_archive_bytes':archive.stat().st_size,
  'source_candidate':'s0_route','fields':['coefficients','owners','q'],
  'segments':len(small['coefficients']),'proposed_canonical_bytes':len(canonical),
  'proposed_canonical_sha256':hashlib.sha256(canonical).hexdigest(),
  'canonicalization':"json.dumps(value,sort_keys=True,separators=(',',':')).encode()",
  'original_candidate_fixture_sha256':record['fixture_sha256'],
  'must_not_include':['historical PASS reports','profiles','optimizer traces','certificates'],
  'must_preserve':['all98coefficientsegments','allowners','allq','binary64 numeric values'],
  'reason':'Q1 positive-speed and fixed segment69 curvature regressions depend on this exact input. Fresh solve is separate and must not replace the red fixture.',
 },
 'fixtures':[],
 'helper_replacements':[],
 'sourcefree_minimal_closure':[],
 'adaptations_and_budgets':[],
}
(OUT/'curated-test-selection.json').write_text(json.dumps(result,indent=2)+'\n')
print({'functions':result['test_function_count'],'selected_test_spans':result['unchanged_test_function_span_loc']})
