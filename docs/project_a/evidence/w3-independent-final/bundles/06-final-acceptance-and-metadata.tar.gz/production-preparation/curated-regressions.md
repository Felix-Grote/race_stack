# Proposed permanent tests, selected by contract

This is a selection proposal pending accepted source. Test count and timing must
be measured on the actual production branch. Avoid copying all research tests
and then merely skipping most: retain minimal fixture builders, independent
oracles and chosen tests in compact permanent files with no research-file imports.
The research30-file function inventory and full intensive campaign stay archived.

## Ordinary pure checks (fast target; measure before setting a deadline)

- Legal input/selected cycle: test_route_input.py's selected_cycles,
  separate_branches_and_overlapping_surfaces, semantic_adversaries,
  malformed_json, seed_cannot_recross_ownership_end_cap and
  forward_gate_is_invariant_under_collinear_seed_subdivision. Preserve distinct
  S2 branch authority and coincident surfaces; reduce redundant parameter grids
  only after retaining both positive and negative boundary cases.
- Metric kernel: test_route_reference.py's nonuniform_parameter_analytic_parabola,
  circle_metric_sign_and_periodicity, regular_narrow_speed_features,
  original_speed_feature_and_explicit_budget_exhaustion,
  canonical_endpoint_owners_and_adjacent_floats, negative_seam_progress_retains_preceding_side.
  These protect analytic arc/inverse, periodic derivatives, W1 accuracy failure,
  explicit INCONCLUSIVE and nextafter ownership rather than sampling-only checks.
- Original corridor: test_route_corridor.py's crossing_surfaces_do_not_share_widths_or_ownership,
  physical_wall_gap_does_not_inflate_legal_bounds,
  normal_tangent_cuts_preserve_connected_interior,
  only_declared_shared_cap_can_join_touching_owned_intervals,
  distinct_close_semantic_caps_are_not_coalesced_or_preapplied and
  metric_seam_samples_and_exact_portal_anchors_share_ownership.
  Keep one representative tangent-contact case per geometric branch and the
  actual shared-cap/gap red regression from test_route_w2_shared_cap.py.
- Continuous numerical bounds: retain compact analytic/exact-Fraction checks
  from test_route_validate_bounds_oracle.py for an interior curvature peak,
  near-zero derivative, cancellation and squared-underflow uncertainty. Retain
  test_route_w2_numerical_oracle.py's outward sqrt and near-stationary arc oracle.
- Structured invalid policy/model/JSON inputs: selected loader/codec cases from
  test_route_compile.py and test_route_artifact.py. Include bool-versus-number,
  duplicate key, malformed UTF8, excessive size/depth and nonfinite values; these
  often fail before any expensive whole-lap proof.

## Ordinary numerical acceptance (small actual generated products)

Use a module/session fixture that freshly optimizes one small S0 route and one
S3 asymmetric bridge/notch route under explicit policies, then computes independent
geometry/dynamics PASS and retains C before retiming/serialization. Reuse these
actual products across trust/query/export checks. Do not trust archived PASS or
mock solvers as the only positive acceptance path. A small frozen coefficient
fixture is useful for focused mathematical corner cases, but it must execute
both validators independently and have an explicit trusted C; keep only its
necessary geometry/q, not an enormous historical report bundle.

- A04 helper-equation and original ownership: one64-knot direct pinned-equation
  oracle, and a test that original normal intersections execute on each QP plus
  actual final spline coefficients remain authority. Use one real feasible
  S3 case; record conditioning/resource failures explicitly.
- Geometry rejection: actual full rectangle overhang/hole or edge-crossing
  despite legal corners, interior notch despite legal endpoints, wrong bridge
  occurrence, missing approved C, coordinated monotone-q attack and exhausted
  budget→INCONCLUSIVE. Existing sources: test_route_validate_geometry.py and
  test_route_w2_handoff.py, especially rehashed_monotone_q_warp_cannot_move_an_original_cap.
- Cyclic retiming: seam cap requires upstream braking, closing edge acceleration
  meets the same actual bounds, model-region caps at a portal, table interval
  minima/no extrapolation and zero-motion rejection. Retain one independent
  closed-ellipse arc/time/lateral oracle from test_route_ellipse_dynamics.py.
- Artifact trust: exact signed-zero/binary64 coefficient/profile roundtrip,
  missing/wrong external H, changed independently selected policy, coordinated
  q/profile/report self-rehash with unchanged trusted C, and historical PASS
  cannot override failed/uncertain fresh proof. Instrument both real validators
  to prove they execute on loaded bytes. Positive proof-portability controls
  must accept a one-ULP outward time enclosure and a genuine adaptive partition
  change while preserving stored main T; categorical/coverage corruption fails.
- Metric queries: true metric affine-u interpolation and independent closing
  acceleration; negative/multiple laps, profile/cap/portal/curve endpoints and
  nextafter, reversed/rotated route, identical XY/heading at distinct visits.
  Retain the NEW positive-squared-speed cancellation red regression after W3
  acceptance, including speed positivity and elapsed time from a high-precision
  independent interpolation oracle near a falling-edge endpoint.
- Atomic publication/export: no overwrite of existing or malicious targets,
  symlink ancestor rejection before output creation, actual two-writer race,
  fsync/rename fault before and after publication, private incomplete staging
  never loadable. Every exposed digest directory must load under exact H with
  both validators. Keep race/signal tests bounded and mark Linux-only platform
  assumptions explicitly. Test-local numerical seams may speed fault matrices,
  but keep a real numerically accepted product for publication and reload.

## Installed ROS acceptance (required ordinary CI job)

- Clean recursive checkout and non-symlink colcon install of global_planner,
  f110_msgs and required packages, with current optimizerace99a48 unchanged.
  Assert all existing console entry points remain and add compile_route only.
- A separate source-free network-disabled runtime gets install+dependency prefix,
  policy/model/route resources and a small independent harness only. Assert
  /src,/workspace,/work/src,/work/build,/work/optimizer absent and imported
  modules are ordinary installed files. Record exact source SHA/module/resource/
  lock/gitlink identities; compile→validate→persist→reload→query→export.
- Actual current upstream read_global_waypoints returns9groups; each generated
  ROS message passes CDR serialize/deserialize with unchanged definitions. Check
  +X heading/signed curvature, original owned side distances, metric station,
  closing acceleration, s=L terminal duplicate, Float32 immutable main T and
  empty unavailable centerline/shortest-path groups.
- Negative controls use existing valid model/policy/resource paths: wrong H,
  stale policy, authoritative coefficient mutation, missing producer C and
  invalid swept geometry must fail for their intended reason. A missing path
  cannot stand in for a mathematical negative control.
- Verify compile/query modules import neither live planner nodes nor optimizer
  wrapper. Compare upstream node/publisher/launch/reader/msg/gitlink blobs
  against the recorded production base, establishing no runtime behavior change.

## Expensive optional stress/acceptance job

Use an explicit manually runnable or scheduled CI job; ordinary CI does not run
the entire96-attempt historical benchmark campaign.

- Actual S6 installed compilation at explicit0.52m policy, ~240m length, followed
  by fresh continuous geometry+dynamics, save/reload/query/export and reader/CDR.
  Predeclare wall/CPU/RSS/process budget; retain measured timings/conditioning and
  all failure outputs. A timeout is a failed or inconclusive job with durable
  partial records, never PASS. Choose the budget from measured final production
  execution with headroom; do not invent a120s or full competition robustness claim.
- Negative S6 fine-mesh point-budget and0.5m conditioning cases; small declared
  mesh/origin perturbations to expose sensitivity. One successful0.52 solve
  establishes only its declared synthetic input/policy.
- Integration equivalence S0,S2,S3,S6 against accepted research with identical
  explicit authority/model/policy. New H is expected from actual production
  source identity; compare numerical coefficient/profile/arc/time/constraints
  with predeclared justified limits, never bypass implementation-identity checks.
- Longer process termination/concurrency repetitions and optional wider
  high-precision bound/fault grids. Full S0–S6 legacy fairness/energy/origin
  campaign remains in the research archive and reproducible by its exact refs.
