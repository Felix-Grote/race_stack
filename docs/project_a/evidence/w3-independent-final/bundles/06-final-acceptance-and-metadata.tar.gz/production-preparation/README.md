# Read-only production preparation; extraction gate remains closed

No production branch, source transplant, source modification, push or merge was
performed. W3 acceptance is pending the root agent's final correction and full
verification. This package records implementation choices and an executable
inventory for after that gate; it is not production acceptance evidence.

## Current upstream and preservation boundary

Live `git ls-remote` again resolves official `ros2-humble` to
`6a2900ac06de2a767f1d1b818a8dec8f8b9c59aa`. Its optimizer gitlink is
`ace99a48e324234579b1d905a55c7b2bbf6c1ece`. Exact observed time and object identities
are in `upstream-observation.json`; fetch/recheck again immediately before the
actual new branch is created. `upstream-planner-diff.patch` records all planner
differences from historical upstream67981ed; protected blob/hash inventory is in
`source-inventory.json`.

Preserve current global_planner_node.py, global_trajectory_publisher.py, launch,
readwrite_global_waypoints.py, waypoint message definitions, maps, configs, RViz
and every existing gitlink. Current setup.py's three console scripts must survive
and gain only the new `compile_route` entry. Merge package.xml additions into the
current upstream file, retaining its `stack_master` exec_depend. Copying the
research package.xml wholesale would delete that newer dependency.

Current legacy node now uses stack_master.qos.LATCHED_QOS on all static waypoint,
marker and bound publishers; publishes independently generated centerline
waypoints; supports missing initial_pose by projecting onto the extracted track;
and runs optimizer `centerline` mode with its own velocity profile. The current
republisher publishes once with latched QoS rather than a ten-second timer. Its
launch defaults publish_centerline=true. None needs modification for this offline
addition. Do not run these nodes or the vehicle launch during acceptance.

The optimizer change b1b38ec→ace99a48 affects exactly one file,
trajectory_optimizer.py (24 insertions,5 deletions): it globally patches TPH's
closed velocity helper with a doubled-lap seam fix, and adds `centerline` mode
(alpha=0 plus ordinary downstream velocity). The full diff is retained in
`optimizer-wrapper-diff.patch`. The new offline planner does not import this
wrapper or its helpers: A04 invokes pinned PyPI TPH0.79 calc_splines/opt_min_curv
inside its bounded subprocess; A06 uses its own cyclic LP and independent dynamics
validator. Consequently retain ace99a48 and its velocity/centerline fixes. Prove
with fresh actual production compilation, not old W3 CI or optimizer downgrade.
A compile-module subprocess check should verify no global_racetrajectory_optimization
or live ROS node was imported; independent source comparison must confirm only
TPH's unrelated velocity routine is patched by legacy wrapper import.

## Runtime and dependency closure

`source-inventory.json` lists the exact11 modules at pre-final source67fbcc:
_route_geometry, route_input, route_reference, route_corridor, iqp_route_adapter,
route_validate, cyclic_retime, route_validate_dynamics, route_artifact,
route_compile, route_legacy_export. They total5,412 lines/258,328bytes. Refresh
hashes/LOC from the final accepted SHA after the positive-speed fix; never source
from dirty checkout bytes. Existing __init__.py and readwrite_global_waypoints.py
remain upstream-owned and are runtime dependencies for packaging/export.

Core direct nonstdlib dependencies: NumPy1.26.4, SciPy1.11.4,
quadprog0.1.7, trajectory-planning-helpers0.79; the runtime gate explicitly requires
CPython3.10.12. TPH package metadata additionally requires matplotlib>=3.3.1;
quadprog metadata requires Cython. TPH __init__.py imports its complete helper
package, so removing matplotlib merely because the planner avoids plots would
break ordinary imports. Preserve the current proven hashed lock initially; a
smaller lock can remove legacy-only OpenCV/skimage/Casadi/etc only after a fresh
clean numerical and ROS installation proves the full transitive closure. Do not
weaken the numerical version/hash guard to use Ubuntu's default NumPy/SciPy.

For ROS export explicitly declare rclpy, geometry_msgs, std_msgs,
visualization_msgs, rosidl_runtime_py and f110_msgs in package.xml, alongside
numpy/scipy and upstream stack_master. Research package.xml currently omits
rclpy/geometry_msgs, although its ROS image supplies them transitively; lean
integration should declare the actual direct imports. TPH/quadprog are PyPI
requirements: provide an operator-install lock and appropriate setup dependency
metadata without installing or downgrading packages globally on the user's host.

The22 installed fixture/model/policy/build-identity resources total349,800bytes;
retain their required closure deliberately. Do not import the research archive
or all testfixtures indiscriminately. The source inventory gives each size/hash.
A staged generated build_identity.json must record actual production source SHA,
clean state, current recursive gitlinks, lock hashes and installed-resource
hashes. It must not be the research placeholder or require a source checkout at
runtime. Keep source-free launch/runtime probes and actual reader/CDR proof.

## Required narrow provenance adjustment

route_artifact.implementation_identity currently hardcodes optimizer_gitlink=b1b38ec.
This historical research pin is inconsistent with production's actual ace99a48
checkout even though the new kernel never executes the optimizer wrapper. In a
separate documented integration commit, retain historical accepted-W2/research
source attribution, and report the actual production gitlink truthfully. An
explicit source constant matching the new baseline, crosschecked against the
staged build manifest in clean-build verification, is sufficient; a cwd Git
lookup would break source-free loading. Do not weaken implementation comparison
or load old research H under new code. Actual module/helper hashes, dependency
versions and production provenance must still bind new artifacts. Regenerate
production products using the new source identity and compare numerical behavior
against the accepted research run with identical route/model/policy inputs.

## Existing consumer contract

The upstream existing nine-group reader/writer and Wpnt/WpntArray definitions are
byte-identical to the research versions; protected source hashes record this.
Export creates map-info String, Float32 main lap time, centerline markers and
waypoints, IQP markers and waypoints, shortest-path markers and waypoints, and
trackbound markers. Absent centerline/shortest-path products remain explicit empty
messages; they are not fabricated trajectories. Main waypoints use +X/CCW heading,
signed curvature, original-owned right/left distances, true metric station,
cyclic edge acceleration and terminal duplicate s=L. Exercise actual generated
message setters and rclpy CDR with the existing reader from the CURRENT upstream
package installation. Empty optional products mean consumers requiring them need
separate approval/integration; the new CLI does not change launch defaults.

## Curated regression proposal and sequencing

See `curated-regressions.md`. The exhaustive30-file function inventory is retained
for source selection; it is not a proposal to transplant every research test.
Curate compact tests/helpers into new permanent files with no imports from
omitted research directories. Keep actual numerical and trust tests; avoid tests
that merely recite implementation constants. Baseline current upstream legacy
checks first, and compare exact pre-existing failure identities after integration.

After W3 ACCEPT: create branch from live upstream SHA, transplant accepted module
bytes/select resources and additive packaging, make documented provenance change,
run curated tests and new-source source-free acceptance. Regenerate S0/S2/S3/S6
artifacts and compare actual geometry/dynamics/profile/arc/ROS semantics. Have an
isolated review challenge source imports, preserved upstream blobs/gitlinks,
missing resources/dependencies, trust failures and install closure. Only then
publish fork branch and official upstream PR. Final research-versus-production
size table must include whole W0–W3 runtime/test LOC, evidence LOC, changed files,
new object/pack measurements, ancestry proving no research commits imported and
links to accepted archive. No physical vehicle validation is implied.
