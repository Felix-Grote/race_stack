"""Complete the read-only selection record with exact helper/fixture closure."""
import ast
import hashlib
import json
from pathlib import Path

out=Path('/workspace/forza-audit-records/production-preparation')
root=Path('/workspace/forza-audit-records/final-checkout')
p=out/'curated-test-selection.json'
d=json.loads(p.read_text())
helpers={
 'test_route_input.py':['payload'],
 'test_route_reference.py':['circle','feature_arc'],
 'test_route_corridor.py':['route','_nonuniform_circle'],
 'test_route_w2_shared_cap.py':['exact_root'],
 'test_iqp_route_adapter.py':['system'],
 'test_route_validate_bounds_oracle.py':['decimal_values','assert_enclosure'],
 'test_route_validate_geometry.py':['_between_node_notch'],
 'test_route_w2_handoff.py':['_model','_constant_profile'],
 'test_cyclic_retime.py':['synthetic_model'],
 'test_route_artifact.py':['write_reference'],
 'test_route_legacy_export.py':['_arc','_ray_distance'],
}
helper_records=[]
for filename,names in helpers.items():
 path=root/'planner/global_planner/test'/filename
 raw=path.read_text();tree=ast.parse(raw); nodes={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
 for name in names:
  n=nodes[name]
  used={v.id for v in ast.walk(n) if isinstance(v,ast.Name) and isinstance(v.ctx,ast.Load)}
  imports=[]
  for stmt in tree.body:
   aliases = stmt.names if isinstance(stmt,(ast.Import,ast.ImportFrom)) else []
   if any((a.asname or a.name.split('.')[0]) in used for a in aliases):
    imports.append(ast.get_source_segment(raw,stmt))
  helper_records.append({'source':str(path.relative_to(root)),'function':name,
      'start_line':n.lineno,'end_line':n.end_lineno,'source_span_loc':n.end_lineno-n.lineno+1,
      'import_statements':imports,'loaded_global_names':sorted(used)})
d['retained_helpers']=helper_records
d['retained_helper_span_loc']=sum(x['source_span_loc'] for x in helper_records)
for subdir,names in [
 ('planner/global_planner/test/fixtures/project_a',[
  's0_route.json','s0_reverse_route.json','s0_rotated_route.json',
  's2_upper_route.json','s2_lower_route.json','s3_surfaces_route.json','s3_notch_route.json',
  'dynamics/ggv_dip.csv','dynamics/motor_dip.csv']),
 ('planner/global_planner/config/project_a',[
  'models/synthetic_model.json','models/s3_notch_route_model.json',
  'policies/synthetic_policy.json'])]:
 for name in names:
  path=root/subdir/name;raw=path.read_bytes()
  canonical=json.dumps(json.loads(raw),sort_keys=True,separators=(',',':')).encode() if path.suffix=='.json' else raw
  d['fixtures'].append({'source':str(path.relative_to(root)),'source_bytes':len(raw),
    'source_sha256':hashlib.sha256(raw).hexdigest(),'minified_bytes':len(canonical),
    'minified_sha256':hashlib.sha256(canonical).hexdigest(),
    'role':'test_input_only' if '/test/' in str(path) else 'installed_operator_smoke_input'})
d['helper_replacements']=[
 {'originals':['test_iqp_route_adapter.candidates','test_route_validate_geometry.candidates',
     'test_route_validate_geometry.reports','test_route_artifact.inputs',
     'test_route_artifact.authority','test_route_artifact.published','test_route_legacy_export.references'],
  'replacement':'one session-scoped fresh_products mapping, computed once for s0_route and s3_notch_route',
  'sequence':['load validated original route','adapter.optimize(route) with default SolverPolicy spacing0.4',
    'assert CANDIDATE; immediately retain C=curve_digest(result.ordered) before retiming/serialization',
    'construct explicit artifact-test model RegionLimits(.05,3.,2.,3.,4.,2.5,-0.0,provenance) on each actual occurrence/surface; Footprint(.1,.1,.12,.01)',
    'run real validate_geometry with frozen C; assert PASS',
    'run real retime; assert CANDIDATE; retain actual profile+metadata',
    'run real validate_dynamics with frozen C and metadata; assert PASS',
    'build_payload with exact policies and all retained approvals/reports',
    'freeze expected_H before publish_reference; load_reference using independent expected_H/context',
    'cache optimization result, ordered, approved C, model, timed result, payload, context, published reference and both reports'],
  'compatibility_views':{
    'numerical_candidates':'{name:product.optimization} for two fresh cases',
    'candidates_fresh':'{name:product.ordered} for two fresh cases',
    'reports_fresh':'{name:product.geometry} for same cases',
    'authority':'(s0.payload,s0.context,s0.ordered,s0.model,s0.timed)',
    'published':'s0.reference',
    'references(name=s0_route)':'return fresh_products[name].reference, no additional optimization',
  },
  'scope_note':'Do not mutate cached objects between tests. Existing public APIs return detached payloads; construct local changed models/routes/curves for attacks.'},
 {'originals':['test_route_w2_handoff.handoff','test_route_artifact.test_loaded_positive_profile_keeps_positive_speed_at_nextafter_boundaries raw archive read'],
  'replacement':'hash-checked plain s0 coefficient fixture containing coefficients/owners/q only; reconstruct Curve+OrderedCurve from original S0 route',
  'approval':'retain C once before each deliberate downstream attack; no archived report is trusted',
  'profile':'_constant_profile for missing-C attack; retime real altered profile for coordinated-q attack'},
 {'originals':['test_route_validate_geometry.candidates for fixed index/threshold tests'],
  'replacement':'candidates_frozen={s0_route:frozen_s0_ordered}; use only _between_node_notch and fixed segment69 interior-curvature controls',
  'reason':'These controls use fixed segment12/69, tip5.8 and curvature.20915. Fresh upstream solves need not reproduce those incidental positions.'},
]
installed_source=root/'scripts/project_a/tests/test_w3_installed.py'
raw=installed_source.read_text();nodes={n.name:n for n in ast.parse(raw).body if isinstance(n,ast.FunctionDef)}
installed_names=['_hash','_canonical','_inputs','_invoke','product',
 'test_installed_w3_origins_resources_and_isolation',
 'test_installed_w3_persist_revalidate_query_export_cdr',
 'test_installed_w3_corruption_and_context_fail_closed']
d['installed_suite_functions']=[{'source':str(installed_source.relative_to(root)),'function':name,
 'start_line':nodes[name].lineno,'end_line':nodes[name].end_lineno,
 'source_span_loc':nodes[name].end_lineno-nodes[name].lineno+1} for name in installed_names]
d['installed_selected_span_loc']=sum(x['source_span_loc'] for x in d['installed_suite_functions'])
d['sourcefree_minimal_closure']=[
 {'source':'scripts/project_a/source_manifest.py','loc':82,
  'retain_functions':['_sha256','_git','_build_identity','main'],
  'adapt':'Replace _source_hashes research-wide globs with explicit lean production module/test/config/CI/msg inventory. Preserve schema fields source_commit/source_dirty/gitlinks/source_hashes/installed_resource_hashes/dependency_lock_hashes. Generate in staged copy only.'},
 {'source':'scripts/project_a/isolated_runtime.sh','loc':66,
  'retain':'same immutable image-ID check and actual isolated second-container launch; install+dependency prefix+harness readonly, results writable, source/build absent',
  'adapt':'copy only curated installed smoke test and runtime_verify.sh. Remove research scenario campaign and query-probe dependencies; keep launch/HostConfig/mount evidence.'},
 {'source':'scripts/project_a/runtime_verify.sh','loc':12,
  'adapt':'same ROS/ordinary install sourcing, pipcheck, plugin-disabled pytest with JUnit; invoke only curated installed test. Preserve nonzero return and partial stdout/stderr/timeout receipt.'},
 {'source':'scripts/project_a/container_verify.sh','section':'selected-package build and optimizer wheel block only',
  'retain':'copy selected packages; stage buildidentity; ordinary colcon build; build currentace99a48optimizer wheel without importing its live planner; install target prefix',
  'exclude':'all research numerical test lists and campaign orchestration'},
 {'source':'scripts/project_a/Dockerfile + requirements.build.lock + requirements.lock',
  'retain':'existing digest-pinned ROS base and hash-locked numerical tooling; retain exact hashes and TLS trust handling'},
 {'source':'scripts/project_a/tests/test_w3_installed.py::_inputs / _GITLINKS',
  'critical_adaptation':'Do not copy hardcoded historicalb1b38/gitlinks. Compare installed identity to an independently frozen expected-production identity JSON supplied by the trusted build/runner. Expected optimizerace99a48 and actual upstream recursive pins must match.'},
]
d['adaptations_and_budgets']=[
 {'kind':'LOC budget','known_test_function_spans':d['unchanged_test_function_span_loc'],
  'known_helper_spans':d['retained_helper_span_loc'],'known_installed_spans':d['installed_selected_span_loc'],
  'known_sum_before_imports_and_shared_fixture':d['unchanged_test_function_span_loc']+d['retained_helper_span_loc']+d['installed_selected_span_loc'],
  'planned_imports_headers_shared_fixture_lines':'~160-230 after consolidating into5testfiles+conftest',
  'expected_total_test_python_loc':'~1730-1800; measure actual reconstructed suite. No hard quota may discard a required assertion.',
  'separate_infrastructure':'build/source_manifest/container shell code and tiny optionalS6 runner are separate CI infrastructure LOC, report them honestly'},
 {'kind':'S3 variant','adapt':'Use freshly optimized s3_notch_route (stronger asymmetric notch input) for ordinary numerical and export oracle coverage. In test_fields_follow_saved_coefficients... treat name.startswith(s3_) as mixed-sign curvature and assert multiple surfaces; do not impose circle-positive-curvature assumption.'},
 {'kind':'fixture routing','adapt':'Rename original conflicting candidates fixtures to numerical_candidates/candidates_fresh/candidates_frozen explicitly. Positive whole-lap/ownership reports use fresh; fixed notch/interiorpeak/Q1 tests use hashchecked frozenS0.'},
 {'kind':'no archived product dependency','adapt':'Remove gzip archive reads and the original archivehash assertion from rewritten fixtures/Q1; replace them with the exact minimal-fixture hash. Do not copy w2_a04_candidates full7route archive or historical reports.'},
 {'kind':'writable output','adapt':'Replace Path(/work/...) research log writes with tmp_path or omit log-only writes while retaining all assertions, especially parabola. Tests must work under arbitrary pytest --basetemp.'},
 {'kind':'signed zero','adapt':'Fresh shared model must retain the original artifact inputs drag_over_mass=-0.0; otherwise test_exact_roundtrip... loses its signed-zero assertion meaning.'},
 {'kind':'real ROS mandatory','adapt':'The retained installed persist/revalidate/query/export/CDR test imports actual ROS packages directly. The selected corrupt-staged-ROS test must replace pytest.importorskip(f110_msgs.msg) with a direct required import in the ROS job; missing ROS cannot become a successful skip.'},
 {'kind':'avoid duplicate ROS positive','adapt':'Do not also copy test_actual_nine_group_reader_and_generated_ros_cdr into ordinary suite: its complete real-reader/CDR behavior is covered by retained installed test202-257. Keep source positivefunction as provenance/reference only.'},
 {'kind':'parameter grids','adapt':'Retain the selected functions parametrizations exactly initially; do not shrink closecap/gap/tangent/subnormal/Q1 matrices merely to lower runtime.'},
 {'kind':'strict new-code gates','adapt':'flake8(maxline99)+pep257 on everynewruntime module and all curatedtestPython. Assert real numerical suite collection counts/JUnit nofail/noerror/nounexpectedskip; exactcounts measured after reconstruction.'},
 {'kind':'optional competition acceptance','adapt':'Use installed compile→validate→query→export→reader/CDR once on s6_competition_route with s6_coarse_policy solver spacing.52 and actual model; retain explicit inherited policy values and resource/time receipts. Optional job remains separate from ordinarysmall suite; timeout is failed/inconclusive, never PASS.'},
]
d['legacy_ci_minimal_truthful_path']={
 'commit_only':'compact10failureIDs+2skipIDs/reasons and pure parser/comparator; no generated rawlogs or1182map in product branch',
 'recommended':'run exactbase6a2900a and currenthead selectedpackage ordinarybuild/wheel/colcontests sidebyside under identical pinnedimage/paths/networknone; compare exact emitted diagnosticCounters, failureIDs, skips and errors; upload rawoutputs as artifacts',
 'base_expected_observation':'12tests/0errors/10failures/2skips,1182stylelines; currenthead can have morepassingtests',
 'new_checks':'strictallnewsource/testlint and explicit curatednumerical/installtestreports are independently fatal',
 'truthful_lighter_alternative':'compact IDs+strictnewlint+protectedupstreamblobchecks only; describe narrower scope, not fullCounter equivalence',
 'historical_evidence_external':'/workspace/forza-audit-records/upstream-baseline/original-upstream-baseline.zip (authenticatedartifact12169317178)',
}
optional=[]
for name in ('fixtures/s6_competition_route.json','models/s6_competition_route_model.json','policies/s6_coarse_policy.json'):
 path=root/'planner/global_planner/config/project_a'/name
 optional.append({'source':str(path.relative_to(root)),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
d['optional_s6_inputs']=optional
p.write_text(json.dumps(d,indent=2)+'\n')
print({k:d[k] for k in ('test_function_count','unchanged_test_function_span_loc','retained_helper_span_loc','installed_selected_span_loc')})
