# Concrete compact permanent-suite selection

Read-only preparation against the clean literal `b961d20ce4a803e55336fb5590c30574e23b2fad` checkout. No production branch, transplantation, numerical solve, test execution or acceptance claim was made.

`curated-test-selection.json` is the actionable inventory: exact source/function names, source line numbers, source-file hashes, direct imports/constants, fixture arguments, local helper dependencies, retained helper spans/imports, selected input hashes, and required adaptations. The two adjacent Python scripts reproduce this AST-derived planning record; they do not create or modify product code.

## Size and layout

Select **50 existing test functions / 1,090 source-span LOC**, **16 helpers / 177 LOC**, and **8 installed-smoke helpers/tests / 287 LOC**. The known sum is **1,554 LOC** before consolidated imports, shared fixtures and headers. A further approximately160–230 LOC yields **1,714–1,784 Python test LOC**. This is an implementation estimate, not a measured future diff; report actual final counts and do not drop a required assertion to meet a cosmetic quota. Build and identity shell/Python infrastructure is separate and must be reported separately.

Group the selected functions into five compact test modules plus `conftest.py`: input/metric/corridor; bounds/geometry/handoff/retiming; optimizer; artifact/publication/query; export/installed ROS. Keep fast pure controls separate from actual numerical acceptance, and keep optional S6 in its own explicit job. Preserve the selected parameter grids initially; selected-function count is not expanded pytest count.

The selected contracts include:

- Legal cycles, branch choice, coincident decks, malformed semantics and ownership-end-cap recrossing.
- Analytic parabola inverse station, circle direction/periodicity, the original narrow-speed feature with explicit quadrature exhaustion, coefficient endpoints and negative seam ownership.
- Original side contacts, shared caps versus tiny real gaps, nearby semantic caps and exact portal anchors.
- Direct64-knot TPH equation oracle; every actual optimization iteration's original normal intersections/lineage; exact final shifted coefficient authority.
- Independent100-digit Decimal derivative enclosures, interior curvature/rate peaks, cancellation, near-zero derivative and subnormal/underflow uncertainty.
- Fresh whole-lap geometry coverage on S0 and S3 notch; fixed-input between-knot rectangle overhang despite legal knots/corners; fixed-input interior-curvature peak; explicit budget exhaustion.
- Missing independent C, coordinated monotone-q cap relocation, upstream braking into the cyclic seam and no table extrapolation.
- Signed-zero exact roundtrip, bounded codec, both real validators on load, external H, coordinated q/profile/report self-rehash attack, historical numeric/partition portability, historical categorical/coverage corruption, fresh non-PASS override and immutable main-time enclosure.
- No-overwrite publication, actual two-writer race, write/fsync failures before and after publication, unsafe ancestor rejection and the accepted Q1 positive-speed regression in both original parameterizations.
- Independent NumPy/SciPy arc/heading/curvature/side-ray/squared-speed/time/export oracles; closing acceleration and terminal s=L; actual installed CLI, current existing nine-group reader and actual generated-message CDR.

## Share two freshly optimized products

Create one session fixture that optimizes **S0 and `s3_notch_route` once each**, using the actual current production implementation and default0.4m solver policy. Immediately freeze C after the optimizer returns, before any downstream retiming or encoding. Independently run geometry PASS, real retiming and dynamics PASS. Then build the payload, freeze H, publish, independently reload and cache the actual numerical result, ordered curve, C, model, retimed profile/metadata, reports, payload/context and reference.

Use the original artifact-test model construction, including `drag_over_mass=-0.0`, and `Footprint(.1,.1,.12,.01)`. This retains the exact signed-zero test rather than accidentally making it vacuous. Bind each region to the actual route occurrence/surface. All mutations must use detached/local copies.

Expose explicit fixture views for original signatures: `numerical_candidates` for adapter results, `candidates_fresh`/`reports_fresh` for positive geometry tests, `authority` tuple and `published` for artifact tests, and `references(name)` for exporter tests. Do not carry the research fixtures that eagerly load/solve all seven cases. Preserve the assertions in the selected A04 tests while restricting their mapping to the two freshly generated products.

S3 notch is deliberately mixed-sign curvature. When adapting `test_fields_follow_saved_coefficients_true_metric_and_original_owned_sides`, classify every `s3_*` case as mixed-sign and assert multiple surfaces; do not retain its current name-only `s3_surfaces_route` condition, which would incorrectly apply the circle-positive-curvature assumption to the notch variant.

## Preserve one exact coefficient-only red fixture

The best targeted mathematical fixture is **only** `w2_a04_candidates.json.gz` → `candidates.s0_route` → `{coefficients,owners,q}`. This is98segments and **20,453 canonical JSON bytes**, SHA256:

`ea2e4ada24f6be243ad5c1d20e08a06cf0efa18cb02a80f4d200fe0a7e0f0fa5`

The source archive SHA is `2a506953026b75fc5be4defb1b018577faa46cebdbdfcd767c0103e733b2279b`. The full archive is60,383compressed /156,063uncompressed bytes and already contains no reports, but seven cases are unnecessary here. Do not carry the whole archive solely for one regression. Canonical byte construction and original route binding are recorded exactly in the JSON plan.

Keep all98segments, owners and q values. Q1 needs a complete independently legal periodic curve, real geometry/dynamics validation, public publish/load and endpoint queries. The fixed interior-curvature control uses segment69 and threshold.20915; the between-node notch control uses segment12 and tip5.8. Replacing these inputs with a new solve may silently lose their failing-first trigger. Use `candidates_frozen` for these fixed controls, independently retaining C before mutations. Use the freshly solved S0/S3 products for positive integration acceptance. No archived PASS, profile, trace or certificate is copied.

The small route-input closure is seven explicit S0/reversed/rotated/S2-upper/S2-lower/S3-surfaces/S3-notch JSON inputs plus the two tiny dip-table CSVs. They can be minified while preserving every decoded numeric value, signed zero and semantic authority; exact original and prospective canonical hashes/sizes are recorded. Install only S0/S3 notch and their model/policy resources for ordinary operator smoke; S6 resources belong to the separate optional job. Test-only branch/reversal fixtures need not all be installed.

## Minimum installed/source-free closure

Reuse selected functions from `scripts/project_a/tests/test_w3_installed.py`: `_hash`, `_canonical`, `_inputs`, `_invoke`, `product`, origins/isolation, persist/revalidate/query/export/CDR, and corruption/context rejection. The retained installed test already covers the full actual nine-group/CDR positive behavior, so do not also copy the redundant27-line source positive test. Keep the13-line staged-serializer corruption test in the ROS job and replace its `importorskip` with a mandatory import.

Reuse `source_manifest.py`'s82-line schema/identity mechanism, replacing research-wide globs with an explicit lean inventory; preserve source SHA/dirty state, recursive gitlinks, source/resource/lock hashes. Stage it in the copied build tree. Reuse only the selected-package ordinary-build/current-optimizer-wheel block from `container_verify.sh`.

Reuse the isolated second-container launch from `isolated_runtime.sh` and12-line `runtime_verify.sh`, but copy only the curated installed harness. Remove the nine-scenario campaign and `w3_query_probe.py` dependencies from ordinary CI. Retain networknone, readonly root/install/dependencies/harness, nonroot/no capabilities/no-newprivileges,2CPU/4GiB and actual mount/HostConfig evidence. No source/build/optimizer checkout is present in that runtime. Keep timeout stdout/stderr/RESOURCE_LIMIT receipt logic from `_invoke`.

Critical adaptation: `_inputs` currently hardcodes historical recursive gitlinks, including optimizer`b1b38ec`. Replace that comparison with an independently frozen expected-production identity supplied by the trusted build/runner; verify current upstream pins including`ace99a48`. Do not substitute the installed manifest as its own independent expectation. Hash `_route_geometry` as well as the ten already listed public/kernel modules. Preserve existing console entry points and add only `compile_route`.

## Lean permanent legacy CI

Do not embed the authenticated raw logs or1,182-line diagnostic map in the product branch. Retain only compact ordered failure IDs, skip IDs/reasons and a parser/comparator. Run literal base`6a2900a` and current head selected-package builds/tests side by side with the same pinned image, source-copy/wheel procedure, isolated network and container paths. Compare exact emitted diagnostic Counters and failure/skip/error identities; upload raw results as Actions artifacts. Current head may collect more passing curated tests than base12; do not fix its total to12 or waive new-code failures. Strict lint of every added module/test and explicit curated-suite/JUnit verification remain separate fatal gates.

For this release, the authenticated baseline is external at `../upstream-baseline`, artifact12169317178. The actual current upstream Counter is1,182, not historical1,173. A lighter compact-ID+strict-lint+protected-blob gate is possible but must be described as that narrower check rather than full diagnostic equivalence.

Optional S6 should call the actual installed compile→validate→query→export→existing reader/CDR path at explicitly supplied0.52m policy/model, with measured and retained wall/CPU/RSS/resource receipts. It does not need the full96-attempt research benchmark harness. No timeout may become PASS.
