# ForzaETH final independent audit checkpoint

User request: /workspace/attachments/00854f2c-f663-4956-9351-33538e2dfbba/Pasted text.txt

## R1 initialization
- Original /workspace/race_stack left untouched: clean `work` branch at 67981ed.
- Isolated repository: /workspace/forza-w3-audit (fetch in progress).
- GitHub actor Felix-Grote authenticated; fork permissions admin/maintain/push true.
- PR #3 OPEN; head 17e4ec4e8fedfa736467d02f6204b04e8552decb; base project-a/w1-geometry at 9fae5faed6ca62e0c943b6290babc50638477d9b; mergeable true.
- Evidence remote ref 326aa3783ac2d757b6e714eadd14fdba96f595fd verified by ls-remote.
- Current official ros2-humble head 6a2900ac06de2a767f1d1b818a8dec8f8b9c59aa verified by ls-remote.
- Managed Docker daemon 28.4.0/vfs healthy; ROS Humble base/core images available.
- No acceptance verdict yet. Later phases strictly gated on W3 ACCEPT.

## Remaining
Read repository instructions and mandatory architecture/review documents; independently investigate and test all W3 boundaries, run fresh installed verification; preserve failing-first evidence before any fixes. Finish R2/R3 before production extraction. Do not merge upstream production PR.

## R1 active execution
- Fresh exact candidate command started as unified session 98244:
  `scripts/project_a/fresh_verify.sh 17e4ec4e8fedfa736467d02f6204b04e8552decb /workspace/forza-audit-records/fresh-17e4ec4`
  wrapper log: /workspace/forza-audit-records/fresh-launch.log
- Pinned image project-a-humble:w0 successfully built, full suite now running. Initial A01 60 PASS / A02 47 PASS.
- Existing literal-head push run 38945204845 verified SUCCESS/event push/head17e4ec4; PR run38945212759 success separately. This is prior evidence, not new independent verdict.
- Immutable evidence checkout /workspace/forza-evidence-review at326aa378.
- Read-only agents: trust_review; numerical_review; filesystem_review; benchmark_review; evidence_audit. All outputs under this records directory; no production changes authorized to agents yet.
- Filesystem exploratory19/19 real OS state-machine checks passed with explicitly stubbed numerical/ROS seams; real pinned numerical replay running separately, so exploratory checks do not establish product acceptance.
- Benchmark archived integrity966 paths verified; independent polynomial quadrature on58 accepted original outputs passes distance/time/enclosure/energy checks. Original campaign not substituted for current-head execution.
- Upstream fetched read-only into audit repo as upstream/ros2-humble at6a2900a; optimizer ace99a48e324234579b1d905a55c7b2bbf6c1ece confirmed. Existing latched QoS/node/launch/package changes must be preserved. No production branch created; later gates remain pending.

## R1 infrastructure and independent outcomes
- Docker VFS concurrent rootfs copies exhausted32GiB filesystem briefly. Removed only own disposable/pending probe containers; preserved all bind-mounted evidence. Full initial suite remained running. Secondary independent build failed ENOSPC (original log retained), then fresh retry-src/retry-build/retry-install succeeded with all3 packages in shared container.
- All further probes MUST use `docker exec forza-independent-probes`; no new per-agent `docker run`. Shared mounts /src=initial audit checkout readonly, /frozen=initial fresh recursive checkout readonly, /records=all audit records, /work=independent-build. Pinned Python /opt/project-a/bin/python3; network none, nonroot, readonly root. Shared6GiB/2CPU/512PIDs is diagnostic functional context, not isolated4GiB performance evidence.
- Actual initial fresh suites through A04 pass:60/47/38/49/18; later suites ongoing.
- Filesystem report complete19/19 plus actual-reference pre/post-rename SIGTERM checks PASS; no defect. Ten export filesystem cases explicitly stub ROS; sourcefree/real ROS remains separate.
- All40 evidence checksum ledgers/3412 entries verified. Original/final authenticated CI ZIP catalogs and all9H/C /58final benchmark artifact bindings verify.
- Independent benchmark151/151 saved-output checks passed in pinned image.20predeclared S6 initial-fit/origin probes complete: .50 all severe condition~9.72e18 due~2.829e-7m semantic/uniform edge; .51-.54 initial fits supported, not proof of full robustness.
- Candidate numericalP2 at route_artifact.py568: affine-u cancellation gives speed0 for validpositiveu; pinned real geometry/dynamics PASS with originalq unmodified. Public publish+reload failing assertion pending completion. Do not mark confirmed until output available. No production changes yet.
- Current old-hosted unchanged replay on this machine matches old historical reports andPASSes, so original crosshost failure must be reproduced with actual deterministic conservative bounds/refinement; do not misstate observed current-host result. Agent evidence_audit owns this and9current hosted installed replays.

## Resume after environment restart
- All audit files survived; previous worker processes stopped. Original17 fresh attempt is interrupted/incomplete (local summary586/26 groups, no final sourcefree); NOT final acceptance. Keep its raw logs/XML.
- Current PR3 head67fbcc8283e59649d38dc9318291634089df3741 preserved: trusted directory4a941599, installed-timeout retention72b72c65, legacy initial-fit classificationabdbc4ab, archive docs67fbcc8.
- Standalone clean repository /workspace/forza-audit-records/final-checkout, branch audit/w3-positive-speed based67fbcc. No remote push yet.
- New permanent query regression fails on exact67 production as intended:1failed112deselected27.05s; actual public publish/load PASS then zero speed. Red logs/XML and original17 repro retained under source docs/project_a/evidence/w3-positive-speed.
- Implemented nearest-endpoint interpolation with direct end_arc-current_arc. Production route_artifact.py SHA256076a5283865ec02fa720692bcf9dfd4fcf82e891035ff70111b86733da6339bc. One focused case green27.98s. Expanded2parameter regression (coefficient vsinterior, bothdirections, closingedges) included in all artifact/export relevant test run; session22605/log resume-numerical/artifact-export-regressions.log running.
- Independent corrected-source numerics completed4,442 pinned queries+496strict endpoint checks, real validators/public publish/load,65digit mpmath; allPASS source hash matches. Reports resume-numerical/REVIEW.md +RESULTS.json +SHA256SUMS. Final commit mapping still needed.
- Source docsSTATUS/RESULTS/DECISIONS updated with Q1 and pending final gates. Record targeted full result before committing/pushing normal FF to PR3. Then run fresh_verify.sh literal final SHA and exact-headpushCI; noACCEPT yet.
- Original67 exactpushCI39038300516/ZIP12104048523 independently authenticated:9,328,342bytes/SHAa17354ea04b7005ee860e3b47c3a90e8cac05a2311e6c8f031978d4eef383210,610tests27groups,138exact source hashes,9H/C bindings. Direct gh download blocked atblobproxy403, approvednative GitHubconnector download succeeded; never bypass proxy/TLS.
- Deterministic old portability comparator defect reproduced with both real validatorsPASS: old rejects1ULP outward report and genuine subdivision224→225; initial17 accepts both. Actual original old products9/9PASS on this host, no claim native mismatch universal.
- Read-only production prep /records/production-preparation complete: liveupstream6a2900a/ace99a48; keepnewQoS/node/launch/stack_master; core11modules usesTPH directly, changeonlytruthful production optimizer provenance later. Declare rclpy/geometry_msgs directly. No production branch/extraction started.
- Onlyshared Docker forza-independent-probes used; start it after restart ifstopped. Avoidnewper-agentcontainers topreventVFSdiskexhaustion. Host cgroup2CPU. Full final fresh must run withoutparallelQPbenchmarks.

## Final committed candidate and 19 October continuation
- Correction committed/pushed normally as b961d20ce4a803e55336fb5590c30574e23b2fad; remotePR3stillopen atb961, base9faeunchanged. Targetedstrictartifact/export141PASS(twoROSdeselectedforfullgate),4,442independentpinnedqueries/496endpointchecksPASS. Productionmodule076a5283 mappedexactGitcommit.
- ExactpushCI39110306747SUCCESS andPR39110310707SUCCESS. Nativeoriginalpushartifact12131022724,SHAe78d8f386b898e573d4a1f61834e3ced7879e3878fc8fceaab456691d49f3e9d,9,328,625bytes; independenthostedauditPASS612tests/27groups,138sourcehashes,21resources,2locks,7gitlinks,tenexactlegacyIDs,9trustedH/C bindings. /records/final-evidence-b961d20/hosted-audit.json.
- Separate96finalbenchmarkCI39110811058SUCCESS onrunnerbranch7fcecd9; sourcecheckoutMUSTbeverifiedliteralb961. AuthenticatedZIPdownloaded /records/final-benchmarks/original-final96.zip. Agentfinal_artifact_audit owns fullstatus/provenance/numericassessment (noACCEPTyet).
- Prior /records/fresh-b961d20 completedordinaryfunctional+legacy+install, interruptedsourcefreelastscenario(4/5testsprinted); doNOTclaimcomplete. Started completecleanfreshagain /records/fresh-b961d20-complete viafresh_verify literalb961; launchlogfresh-b961d20-complete-launch.log, unifiedsession88893. CPU2host, doNOTrunparallelQPbenchmarks.
- runtime_final agent ownsactualsourcefreemountcapture/checks,lastsourcefree+legacyrecordsaudit,9unchangedhostedb961artifactsreplay underpriorb961ordinaryinstalledprefix(noidentitybypass,sourcevisibleforensicreplayseparatefromtruesourcefree). Replay5/9PASSsofar. Currentagentsforknone; previoususage-limitinterruptionpreservedallfiles.
- ResearchPRdescriptionupdatedhonestlycandidatependingb961 viaGHRESTPATCH (ghpredithasdeprecatedProjectsGraphQLfailure). NoW3ACCEPT,noresearchmerge,noacceptedtag,noproductionbranchyet.

## Latest continuation — 19 October, before final local completion
- All final hosted and full96 independent audits are now PASS. Full96 actualstatus58PASS/28stock/8resource/2condition; all29repeatedpairs and58success numerical/export authorities checked. AuthZIP12131293704 is24,320,530B/SHA825f3fa1906c6e51088db277cdbf399a46af4bf57f9abf961470db18f2a33a7c. Reports final-benchmarks/audit-final96.json, final-evidence-b961d20/hosted-audit.json +raw-hosted-audit.json.
- runtime_final completed all9unchangedhostedfinalartifacts ordinaryinstalled replay with9+9realvalidators,7722+7722queries,actual9groupreader/CDR and frozenTchecks. Explicitlysourcevisibleforensiccontainer; separateactualsourcefree observersrunning. Earlierpartial redundant1008querymatrixcanceledhonestly; authoritative4442queriescomplete.
- Exactofficial6a baseline authenticallycompletedCI39215679295,artifact12169317178,SHA1e056004f03c35c8a44b0f9f7810d5af054f5aa8c2b03536b94b77e1995ac4d7. Normal3pkginstall,12legacytests10samefail2sameskip; actualCURRENTupstreamdiagnosticCounter1182,notresearch1173. Productionmustcompare1182map. Fullrecords/ledgerupstream-baseline/README.md.
- Completefresh88893 active: sourcefunctional,ordinaryinstall,installedROS/W1/W2/W3/exportPASS; legacyfull588testpackage rerunningnow, thenactualsourcefree5tests/9scenarios. Freshwrapperexitnotpresentyet=>W3gateOPEN. Keepwatch; doNOTrestartorclaimcomplete.
- final_artifact_audit preparing deterministicstaticarchivebundles andinventory underarchive-preparation; rootfinal-runtime/fresh-complete/release-preparation/HANDOFFmutableexcluded. upstream_baseline preparing exactcuratedtestselection underproduction-preparation,read-onlyplanningonly.
- Rootdraftrelease-preparation/W3_ACCEPTANCE.draft.md explicitlypendingcompletion. Noacceptedtag,noresearchmerge,noproductionbranch. LatestPR3preflightOPENheadb961/base9fae,mergeableclean. Officialheadstill6a2900a. NeedfinishW3gate,archive+mergeandCI,thenactualleanproduction+independentchallenge+upstreamPR. Userlatestasksfinish; nofinalresponseuntilcompletedoractualhardblocker.

## Active final source-free gate — 19 October 08:00 UTC
- Completefresh ordinary functional/install/actualROS and fulllegacyrepeat finished successfully as functionalgate. Exact10legacyfailures/2copyrightskips/all1173diagnosticCounter independentlyPASS in final-runtime-b961d20/complete-legacy.json; ordinary15intendednegativesPASS. Fulllegacy took16m32s; failures remainseparateexpectedchecks.
- Actualsourcefreecontainer1ae75d577c33fb90a0af6ebc9bdcae2147346b25192411f6cd21d63f80a5d577 started07:51:42. ActualDockercontrols4mounts+ROroot/networknone/nonroot/capdrop/4GB2CPU256PIDPASS;11implementation+existingreader12installedorigin+21resourcebytesactualnamespacePASS, allsource/build/recordsabsent. First4testsPASS,sourcefree15intendednegativesPASS. Fifth9scenario campaign5/9PASSsofar (S0forward/reverse/rotated,S2upper/lower); nofailure. WAIT FULLWRAPPER0+61227summary+agentcomplete-audit.json beforeACCEPT. Session88893active, mainlogfresh-b961d20-complete-launch.log.
- Rootgate release-preparation/final_acceptance_gate.py prepared (notrun): validatesallcompletefreshXML/9scenario/exits/manifests/independentaudits/liveexactCIheads then writesimmutableW3_ACCEPTANCE.json. PendingdraftreportW3_ACCEPTANCE.draft.md mustbefinalizedwithscopeclarity. Initial17customtrust/filesystemprobesmustbelabeledinitialsource; finalfulltests+unmodifiedsourceanalysisseparatelybindcandidate. final_artifact_auditreviewingdraft/gatescriptread-only.
- Staticarchive6bundlesDONE /workspace/forza-evidence-bundles,189638047compressedB,4585files397947419payloadB,largest58518581B<90MB;allmember/sourcehashreadbackPASS anddeterministic02repackexact. All73filesystem/installed+20salvagedJUnitretained. archive-preparation/static-bundle-index.json +STATIC_BUNDLE_SHA256SUMS+coverage/sensitivescan0matches. ConvenienceGitcommitteddata3bundles98702652B areexplicitduplicates;otherstaticexternal90935395B. Finalfresh/runtime/release-preparation/HANDOFFstilldeferred mutable; production-preparationnowcomplete.
- Read-onlyconcreteproductiontestselection50functions1090LOC+16helpers177+installed287=>1554knownspan,estimated1714-1784actualtestLOC. ExactASTimports/functionspans/fixtureclosure inproduction-preparation/curated-test-selection.json/.md. CachefreshactualS0+S3notch once; preservefixedS0coeff-only98segments20453canonicalB/SHAea2e4ada24f6be243ad5c1d20e08a06cf0efa18cb02a80f4d200fe0a7e0f0fa5 forQ1andfixedsegment12/69negatives. NooldPASSrecordsneeded. Agentupstream_baselineDONE, canbeaskedauthorcuratedtestsonlyafterproductiongateopens;rootownsmodules/packaging/CI/docs.
- New productionequivalence predeclaredcriteria inrelease-preparation/PRODUCTION_EQUIVALENCE_PROTOCOL.md BEFOREanyproductionnumerics. SiximportantcasesS0,S2upper/lower,S3surf/notch,S6.52;actualnewHrequired,nobypass,explicit1e-10m+1e-12relativecoeff/qbounds,1e-8s+1e-10nominaltime;everyrealproof/policyunchanged. OptionalS6outerbudget600sec, internal120driver20childunchanged. Needdiagnoseanydeviationnotwidentols.
- RootS6_FINAL_TELEMETRY.json originalfinal96nonoverlappingtop-levelworker134.22/134.68wall;121.77/122.16parentCPU+12.54/12.60childCPU;separateparentRSS~163MB,child~274MB,notaggregateliveRSS. Optimizer~22sec;donotclaimfullpipeline120sec. StoredartifactT68.00978787596146,rawretimerdiagnostic.44withinbound;maxindependenttimeerror5.69e-14.
- Original17precisemeasurementsnowarchive-preparation/ORIGINAL17_MEASUREMENTS.md:3purePythonruntime1685LOC83008B;7PythonTestfiles2595addedLOC132156B;21input/model/policyJSON14302LOC349421B;1771evidencefiles695389addedlines;1826changed716864added47deleted;1598objects;nonthinpack55152693B/SHAa72e2fb817bf31cf4ac626ab5aff554dbc127b45e0828d30d11b2154f41d46e7. ExplicitdenominatorW3delta9faealready8modules versusleanupstreamnone. FinalA07runtime1721LOC;all11closure5425LOC259137B.
- AppattachartifactPR3nowSUCCESS (previoushandlerfailuretransient).


## R2 COMPLETE
W3_RESEARCH_ACCEPTED at 2026-10-19T18:18:36.805468+00:00; exact b961d20, 612/27, final fresh/sourcefree exits0, 9/9cases, 30negativecontrolinstances. release-preparation/W3_ACCEPTANCE.json binds raw decisive evidence. Remaining: archive publication, safe personalPR3merge+CI, currentupstreamleanextraction, actualproductionverification/challenge, upstreamPR.
