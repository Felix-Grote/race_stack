"""Seal final research records; no product, Git, network, or numerical operations."""
from pathlib import Path
import collections, gzip, hashlib, io, json, os, re, shutil, stat, subprocess, tarfile, zipfile

ROOT=Path('/workspace/forza-audit-records')
PREP=ROOT/'archive-preparation'
OUT=Path('/workspace/forza-evidence-bundles')
LIMIT=89999999
sha=lambda data:hashlib.sha256(data).hexdigest()
def write(name,value):
    path=PREP/name
    assert name.startswith('final-') and not path.exists(),path
    path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def under(path,prefix):return path==prefix or path.startswith(prefix+'/')
def regular_files(head):
    base=ROOT/head
    for path in ([base] if base.is_file() else sorted(base.rglob('*'))):
        if path.is_dir() and not path.is_symlink():continue
        yield path
def row(path):
    raw=path.read_bytes()
    return {'bytes':len(raw),'sha256':sha(raw)}

accepted=json.loads((ROOT/'release-preparation/W3_ACCEPTANCE.json').read_text())
assert accepted['verdict']=='ACCEPT'
assert accepted['accepted_source']=='b961d20ce4a803e55336fb5590c30574e23b2fad'
assert json.loads((ROOT/'final-runtime-b961d20/WRITERS_STOPPED.json').read_text())['writers_stopped']
for path in ['fresh-b961d20-complete/fresh-exit-code.txt','fresh-b961d20-complete/verification/exit-code.txt','fresh-b961d20-complete/verification/source-free/exit-code.txt']:
    assert (ROOT/path).read_text().strip()=='0'
assert (ROOT/'HANDOFF-at-W3-ACCEPT.md').is_file()

# Preserve actual legacy result records before excluding the disposable build.
salvage=[]
base=ROOT/'fresh-b961d20-complete/verification/build'
for source in sorted(base.rglob('*')):
    if not source.is_file() or source.is_symlink():continue
    parts=source.relative_to(base).parts
    if source.name!='pytest.xml' and 'test_results' not in parts and 'Testing' not in parts:continue
    rel=source.relative_to(ROOT)
    target=PREP/'final-salvaged-build-results'/rel
    assert not target.exists()
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(source.read_bytes())
    assert target.read_bytes()==source.read_bytes()
    salvage.append({'original_path':str(rel),'archived_copy':str(target.relative_to(ROOT)),**row(source)})
assert salvage
write('final-salvaged-build-results-index.json',salvage)

name05='05-final-runtime-and-complete-fresh'
name06='06-final-acceptance-and-metadata'
includes05=['final-runtime-b961d20','fresh-b961d20-complete','fresh-b961d20-complete-launch.log','archive-preparation/final-salvaged-build-results','archive-preparation/final-salvaged-build-results-index.json']
excluded05=['fresh-b961d20-complete/checkout']+['fresh-b961d20-complete/verification/'+d for d in ['build','install','src','python','wheels','a09-harness-tmp','.cache','.config']]
for head in includes05:
    for f in regular_files(head):
        rel=f.relative_to(ROOT).as_posix()
        if f.is_symlink():excluded05.append(rel)
        elif f.name=='__pycache__' or '__pycache__' in f.parts:excluded05.append(rel)
excluded05=sorted(set(excluded05))
files05={}
for head in includes05:
    for f in regular_files(head):
        rel=f.relative_to(ROOT).as_posix()
        if any(under(rel,e) for e in excluded05) or '__pycache__' in f.parts:continue
        assert f.is_file() and not f.is_symlink(),rel
        files05[rel]=row(f)
assert all(any(under(p,head) for p in files05) for head in includes05)
for case in ['s0_route','s0_reverse_route','s0_rotated_route','s2_lower_route','s2_upper_route','s3_surfaces_route','s3_notch_route','s4_repeated_route','s6_competition_route']:
    assert any(under(p,'fresh-b961d20-complete/verification/source-free/results/w3-scenarios/'+case) for p in files05),case

def package(name,includes,excludes):
    command=['python',str(PREP/'package_records.py'),'--output',str(OUT/(name+'.tar.gz'))]
    for value in includes:command+=['--include',value]
    for value in excludes:command+=['--exclude',value]
    result=subprocess.run(command,capture_output=True,text=True)
    assert result.returncode==0,(result.stdout,result.stderr)
    receipt=json.loads(result.stdout)
    assert receipt['archive_bytes']<=LIMIT
    return receipt

receipt05=package(name05,includes05,excluded05)
sealed=PREP/'final-sealed-bundle-manifests'
sealed.mkdir()
for suffix in ['manifest.json','receipt.json']:
    source=OUT/(name05+'.tar.gz.'+suffix)
    (sealed/source.name).write_bytes(source.read_bytes())

# Explicit frozen file selection prevents metadata archives from selecting their
# own future index, coverage, manifests or console records.
external_names=['final-bundle-index.json','final-coverage-audit.json','final-selection-inventory.json','final-duplication-accounting.json','final-ARCHIVE_REPORT.md','final-SHA256SUMS','final-WRITERS_STOPPED.json','final-package-console.log']
meta_excludes=['archive-preparation/'+n for n in external_names]+['archive-preparation/final-salvaged-build-results','archive-preparation/final-salvaged-build-results-index.json','archive-preparation/salvaged-build-results','archive-preparation/salvaged-build-results-index.json']
metadata=[]
for f in regular_files('archive-preparation'):
    rel=f.relative_to(ROOT).as_posix()
    if any(under(rel,e) for e in meta_excludes) or '__pycache__' in f.parts:continue
    assert f.is_file() and not f.is_symlink(),rel
    metadata.append(rel)
plan={'schema_version':1,'accepted_source':accepted['accepted_source'],'authority':'release-preparation/W3_ACCEPTANCE.json','writers_stopped_receipt':'final-runtime-b961d20/WRITERS_STOPPED.json','bundles':{name05:{'includes':includes05,'excludes':excluded05},name06:{'includes':['production-preparation','release-preparation','HANDOFF-at-W3-ACCEPT.md']+sorted(metadata)+['archive-preparation/final-selection-plan.json','archive-preparation/final-sensitive-scan.json'],'selection':'Frozen explicit metadata files; final publication control records are external to prevent self-reference.','excludes':meta_excludes}},'max_archive_bytes':LIMIT,'mutable_root_handoff':'HANDOFF.md excluded; immutable HANDOFF-at-W3-ACCEPT.md retained','salvaged_actual_build_result_files':len(salvage),'deduplication':'All selected path identities retained. Duplicate bytes quantified, never removed.','static_bundles':'Six original static bundles remain unchanged; their original metadata preserved.'}
write('final-selection-plan.json',plan)
includes06=plan['bundles'][name06]['includes']

patterns={
 'credential_query_url':re.compile(rb'https?://[^\s<>"\x27]+[?&](?:token|access_token|sig|signature|X-Amz-Signature|X-Amz-Credential|se|sp|sv|skoid|sktid)=[^\s<>"\x27&]+',re.I),
 'github_token':re.compile(rb'(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,})'),
 'private_key':re.compile(rb'-----BEGIN (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----'),
 'authorization_bearer':re.compile(rb'Authorization[\x22\x27 ]*[:=][\x22\x27 ]*Bearer [A-Za-z0-9_.-]{20,}',re.I),
}
scan_paths=set(files05)
for head in includes06:
    if head=='archive-preparation/final-sensitive-scan.json':continue
    for f in regular_files(head):
        rel=f.relative_to(ROOT).as_posix()
        if '__pycache__' in f.parts:continue
        assert f.is_file() and not f.is_symlink(),rel
        scan_paths.add(rel)
matches=[];chunks=0;historical=[]
def scan_bytes(path,raw,depth=0):
    global chunks
    chunks+=1
    for label,pattern in patterns.items():
        if pattern.search(raw):matches.append({'path':path,'pattern':label})
    if depth>=3:return
    if raw.startswith(b'\x1f\x8b'):
        scan_bytes(path+' [decoded gzip]',gzip.decompress(raw),depth+1)
    elif zipfile.is_zipfile(io.BytesIO(raw)):
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            for m in z.infolist():
                if not m.is_dir():scan_bytes(path+' [zip member '+m.filename+']',z.read(m),depth+1)
    elif path.endswith('.zip'):historical.append({'path':path,'bytes':len(raw),'reason':'Historical ZIP-suffix file is not a ZIP; raw bytes scanned and retained.'})
for path in sorted(scan_paths):scan_bytes(path,(ROOT/path).read_bytes())
assert not matches,matches
scan_report={'selected_regular_files_scanned':len(scan_paths),'scanned_regular_or_decoded_archive_chunks':chunks,'patterns':sorted(patterns),'matches':matches,'historical_non_ZIP_files':historical,'scope':'Final selected originals plus decoded gzip and ZIP members; no matched values printed. Prior six static bundles retain prior sensitive-selected-scan.json. This report generated after scan, then checked before metadata seal.','report_self_check':'Report bytes checked against same patterns before packaging.'}
write('final-sensitive-scan.json',scan_report)
for pattern in patterns.values():assert not pattern.search((PREP/'final-sensitive-scan.json').read_bytes())
receipt06=package(name06,includes06,[])

# Every original/member is independently read again. Regenerate deterministic
# archive bytes into a hash sink to prove the second serialization is identical.
class HashSink:
    def __init__(self):self.h=hashlib.sha256();self.size=0
    def write(self,data):self.h.update(data);self.size+=len(data);return len(data)
    def flush(self):pass
all_receipts=json.loads((PREP/'static-bundle-index.json').read_text())['bundles']+[receipt05,receipt06]
selected={};owners=collections.defaultdict(list);determinism={}
for receipt in all_receipts:
    archive=OUT/receipt['archive'];raw=archive.read_bytes()
    assert len(raw)==receipt['archive_bytes'] and sha(raw)==receipt['archive_sha256']
    assert len(raw)<=LIMIT
    manifest_raw=archive.with_suffix(archive.suffix+'.manifest.json').read_bytes()
    assert sha(manifest_raw)==receipt['manifest_sha256']
    manifest=json.loads(manifest_raw)
    with tarfile.open(archive) as tar:
        members=tar.getmembers()
        assert len(members)==len(manifest['files'])+1
        assert len({m.name for m in members})==len(members)
        for member in members:
            assert member.isfile() and not member.name.startswith('/') and '..' not in Path(member.name).parts
            value=tar.extractfile(member).read()
            if member.name=='MANIFEST.json':assert value==manifest_raw;continue
            entry=manifest['files'][member.name]
            assert len(value)==entry['bytes'] and sha(value)==entry['sha256']
            assert row(ROOT/member.name)==entry,member.name
            if member.name in selected:assert selected[member.name]==entry
            selected[member.name]=entry;owners[member.name].append(receipt['archive'])
    if receipt in [receipt05,receipt06]:
        sink=HashSink()
        with gzip.GzipFile(filename='',mode='wb',fileobj=sink,mtime=0,compresslevel=6) as zipped:
            with tarfile.open(fileobj=zipped,mode='w',format=tarfile.USTAR_FORMAT) as tar:
                for name,value in [('MANIFEST.json',manifest_raw)]+[(n,(ROOT/n).read_bytes()) for n in sorted(manifest['files'])]:
                    info=tarfile.TarInfo(name);info.size=len(value);info.mode=0o644;info.uid=info.gid=info.mtime=0;info.uname=info.gname='';tar.addfile(info,io.BytesIO(value))
        assert sink.h.hexdigest()==receipt['archive_sha256'] and sink.size==receipt['archive_bytes']
        determinism[receipt['archive']]={'PASS':True,'second_serialization_sha256':sink.h.hexdigest(),'bytes':sink.size}
    assert manifest['payload_files']==len(manifest['files'])

groups=collections.defaultdict(list)
for name,entry in selected.items():groups[(entry['sha256'],entry['bytes'])].append(name)
duplicates=[{'sha256':h,'bytes':n,'paths':names,'repeated_bytes':(len(names)-1)*n} for (h,n),names in groups.items() if len(names)>1]
write('final-duplication-accounting.json',{'selected_unique_paths':len(selected),'payload_bytes':sum(e['bytes'] for e in selected.values()),'unique_byte_groups':len(groups),'unique_payload_bytes':sum(n for h,n in groups),'repeated_bytes_across_unique_paths':sum(g['repeated_bytes'] for g in duplicates),'duplicate_groups':duplicates,'cross_bundle_same_path_repetition':[{'path':p,'bundles':bs,'bytes':selected[p]['bytes']} for p,bs in owners.items() if len(bs)>1],'policy':'No result or history removed. Duplicate path/content identities are explicit.'})

inventory=[];totals=collections.defaultdict(lambda:{'files':0,'bytes':0})
legacy=json.loads((PREP/'selection-inventory.json').read_text())
legacy_by_path={r['path']:r for r in legacy}
for f in sorted(ROOT.rglob('*')):
    if f.is_dir() and not f.is_symlink():continue
    path=f.relative_to(ROOT).as_posix();mode=f.lstat().st_mode
    kind='regular' if stat.S_ISREG(mode) else 'symlink' if stat.S_ISLNK(mode) else 'special'
    entry={'path':path,'kind':kind,'bytes':f.lstat().st_size}
    if path in selected:
        entry.update(classification='SELECTED_SEALED',bundles=owners[path],sha256=selected[path]['sha256'])
        assert kind=='regular'
    elif path=='HANDOFF.md':entry.update(classification='EXCLUDED_MUTABLE_HANDOFF',reason='Immutable HANDOFF-at-W3-ACCEPT.md is selected.')
    elif path.startswith('archive-preparation/final-'):
        entry.update(classification='EXTERNAL_FINAL_PUBLICATION_CONTROL_RECORD',reason='Retain alongside bundles in archive branch; excluded from metadata bundle to avoid recursive hashes.')
    elif any(under(path,e) for e in excluded05):
        entry.update(classification='EXCLUDED_RECONSTRUCTIBLE',reason='Explicit disposable checkout/build/install/dependency/cache/scratch or symlink alias; actual build results salvaged and all regular logs retained.')
    elif path in legacy_by_path:
        previous=legacy_by_path[path]
        assert previous['classification']=='EXCLUDED_RECONSTRUCTIBLE',(path,previous['classification'])
        entry.update(classification='EXCLUDED_RECONSTRUCTIBLE',reason=previous['reason'])
    elif '__pycache__' in f.parts:entry.update(classification='EXCLUDED_RECONSTRUCTIBLE',reason='Python bytecode cache.')
    else:raise AssertionError(('Unclassified file',path))
    inventory.append(entry);totals[entry['classification']]['files']+=1;totals[entry['classification']]['bytes']+=entry['bytes']
# Final control files produced after this frozen inventory have an explicit policy.
write('final-selection-inventory.json',{'files':inventory,'totals':dict(totals),'subsequent_control_records':external_names,'subsequent_control_record_policy':'Retain every listed final-* file externally in archive branch. No runtime/release/production evidence remains deferred.','complete_root_scan':True})

coverage={'PASS':True,'bundles':len(all_receipts),'unique_selected_regular_files':len(selected),'archive_bytes':sum(r['archive_bytes'] for r in all_receipts),'all_archives_under_90MB':True,'original_and_member_size_hash_readback':'PASS all eight bundles','all_selected_sources_rehashed_unchanged':True,'selected_symlinks_or_specials':0,'final_determinism_second_serialization':determinism,'final_salvaged_actual_build_result_files':len(salvage),'prior_salvaged_actual_build_result_files':20,'final_sensitive_matches':len(matches),'final_deferred_evidence_roots':[],'immutable_handoff_selected':'HANDOFF-at-W3-ACCEPT.md','mutable_handoff_excluded':'HANDOFF.md','scope':'Archival completeness/integrity; research acceptance authority remains release-preparation/W3_ACCEPTANCE.json.'}
write('final-coverage-audit.json',coverage)
write('final-bundle-index.json',{'schema_version':1,'bundles':all_receipts,'accepted_source':accepted['accepted_source'],'acceptance_receipt':'release-preparation/W3_ACCEPTANCE.json','coverage':'archive-preparation/final-coverage-audit.json','selection':'archive-preparation/final-selection-plan.json','full_inventory':'archive-preparation/final-selection-inventory.json','sensitivity':'archive-preparation/final-sensitive-scan.json','deduplication':'archive-preparation/final-duplication-accounting.json','external_control_records':external_names,'publication':'Publish all eight tar.gz archives and their manifest/receipt sidecars, plus external final-* publication records. No Git operation performed by packager.'})
(PREP/'final-SHA256SUMS').write_text(''.join(r['archive_sha256']+'  '+r['archive']+'\n' for r in all_receipts))
report=['# Final research archive at W3 ACCEPT','',f"Accepted source: `{accepted['accepted_source']}`. Acceptance authority: `release-preparation/W3_ACCEPTANCE.json`.",'','All eight archives are below 90,000,000 bytes. Every original and archive member was size/hash checked; every selected source rehashed unchanged. The six prior archives were preserved exactly. Both new archives regenerated to identical deterministic bytes.','',f"Retained {len(selected)} unique regular source paths; {len(salvage)} final clean-build JUnit/Testing files salvaged before excluding reconstructible build state. All final runtime, complete fresh raw products, harnesses, logs, identities, XML, release acceptance/CI/protocol/telemetry and production preparation are preserved. Nine source-free case directories are retained. No selected symlinks/specials or sensitive-pattern matches. Mutable HANDOFF.md is excluded; HANDOFF-at-W3-ACCEPT.md is sealed.",'','| Archive | Bytes | SHA-256 |','|---|---:|---|']
report += [f"| {r['archive']} | {r['archive_bytes']} | `{r['archive_sha256']}` |" for r in all_receipts]
report += ['','The metadata bundle uses a frozen explicit file list. Final index, coverage, full inventory, deduplication, checksum list, this report and writer-stop receipt remain external publication control records to avoid recursive hashes. Preserve them with archive publication. Selection/exclusion, salvage provenance and duplicate accounting are explicit; no evidence deletion, source modification, Git mutation or numerical workload occurred.','']
(PREP/'final-ARCHIVE_REPORT.md').write_text('\n'.join(report))
write('final-WRITERS_STOPPED.json',{'status':'SEALED_FINAL_ARCHIVE_WRITERS_STOPPED','writers_stopped':True,'bundles':8,'new_bundles':[receipt05['archive'],receipt06['archive']],'no_further_archive_preparation_writes':True,'publish_external_control_records':external_names,'scope':'Publication remote readback remains parent responsibility.'})
print(json.dumps({'new_bundles':[receipt05,receipt06],'coverage':coverage,'report':str(PREP/'final-ARCHIVE_REPORT.md')},indent=2))
