"""Execute frozen selections; never overwrite prior bundle bytes."""
from pathlib import Path
import hashlib,json,subprocess,sys
P=Path(__file__).parent
plan=json.loads((P/'selection-plan.json').read_text());receipts=[]
for name,g in plan['bundles'].items():
 command=[sys.executable,str(P/'package_records.py'),'--root',plan['root'],'--output',g['output'],'--max-archive-bytes',str(g['max_archive_bytes'])]
 for value in g['includes']:command+=['--include',value]
 for value in g['excludes']:command+=['--exclude',value]
 print('Packaging '+name,flush=True)
 result=subprocess.run(command,capture_output=True,text=True)
 if result.returncode:
  print(result.stdout,flush=True);print(result.stderr,flush=True);raise SystemExit(result.returncode)
 receipt=json.loads(result.stdout);assert receipt['archive_bytes']<90000000
 receipts.append(receipt);print(json.dumps(receipt),flush=True)
(P/'static-bundle-index.json').write_text(json.dumps({'bundles':receipts,'scope':'Completed static research records only; active final runtime/fresh/production writers still deferred. No acceptance assertion.'},indent=2)+'\n')
