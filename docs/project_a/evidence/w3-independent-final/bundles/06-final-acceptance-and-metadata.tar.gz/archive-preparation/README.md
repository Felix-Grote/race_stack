# Research archive preparation

Six static evidence bundles are sealed in `/workspace/forza-evidence-bundles`.
They preserve 4,585 selected regular files / 397,947,419 payload bytes in
189,638,047 archive bytes. Each bundle is below 90,000,000 bytes; the largest
is 58,518,581 bytes. Every member and selected source file passed size/SHA256
readback. A second independent packaging of bundle02, with a different output
name/location, reproduced the identical archive SHA256.

| Bundle | Archive bytes | SHA256 |
| --- | ---: | --- |
| 01a committed research core |34,544,690|f173726352ed7149c9b28a8b8d8f613ec9aa02ece73ba9199c6ea0c4dd022011|
| 01b committed benchmarks |33,166,909|efdbfdd968be3b4131bba8f686636b3352694f6fdac453d807f6009806dcf4b7|
| 01c committed runtime/publication |30,991,053|93e58929d8ef2eb5b58eaab8a892127be70f42c1563b3f813dcc3bee902f7abc|
| 02 independent investigations |14,178,225|937fbbdb40a67156536b3fa275bb7371839b182db9e3e8b6d0226132d7d1feac|
| 03 final hosted CI and96 |58,518,581|390ec57637373333f68139b59b384e248cf17b8a34bf3fe7cf64d539e5363b44|
| 04 original local attempts/upstream |18,238,589|611ecf48944eee22a057473297bd6bee7c8b52a636ce1467bf3cbcdf9079edd1|

`static-bundle-index.json`, `STATIC_BUNDLE_SHA256SUMS` and copied sidecar
manifests/receipts under `sealed-static-bundle-manifests/` identify exact output
filenames and contents. `static-coverage-audit.json` cross-checks the frozen
selection against all six manifests. `selection-plan.json` contains every include
and exclusion prefix; `selection-inventory.json` classifies every observed path
as selected, deferred, reconstructible or preparation metadata. Inventory totals
are a snapshot taken while final writers remain active, not a final runtime seal.

The committed research convenience bundles retain the complete b961 docs/evidence
tree and 18 unique or changed prior-remediation documents/results. They duplicate
98,702,652 archive bytes of evidence already available in authoritative Git.
The three external static bundles total 90,935,395 archive bytes. Across selected
payload paths there are 2,950 distinct byte groups / 341,919,557 unique bytes;
373 duplicate groups account for 56,027,862 repeated bytes. These are byte counts,
not claims about GitHub storage. No research history was deleted.

Original investigation coverage includes trust attacks, malformed codec inputs,
filesystem and termination failures, real installed ROS/export checks, negative
controls, initial/retry builds, numerical red/green regressions, source identity
rejections, sensitivity attempts, original and aborted local verifications,
hosted67, final hosted CI, all96 final benchmark rows, and authentic upstream
baseline diagnostics. All 73 `filesystem/installed/` files are included: that
directory contains unique executed evidence. Twenty actual JUnit/CTest result
files were salvaged from otherwise reconstructible build trees, with their
original paths and hashes in `salvaged-build-results-index.json`.

Excluded data consists of reconstructible checkout/Git/build/install/dependency
trees, caches, enumerated symlink aliases and rejected fault-test scratch. Actual
ordinary build/legacy logs remain. The original zero-byte historical failed
download `evidence/newer-original-push-artifact.zip` is retained as failure history;
it is explicitly identified as non-ZIP and never treated as a valid CI archive.

The exact selected-content scan examined 4,585 files and 8,608 regular/decoded
archive chunks for credential-bearing URLs, GitHub tokens and private keys.
There were zero matches, so no sensitive ephemeral URL exclusions were required.
Only counts and filenames are retained; no secret values were printed.

`fresh-b961d20-complete`, `final-runtime-b961d20`, the complete-fresh launch log,
root `HANDOFF.md` and mutable `release-preparation` remain deferred. Completed
`production-preparation` belongs in the final metadata bundle with the final root
report. `pending-final-selection.json` prepares those later selections, including
raw test-result salvage and explicit exclusions. Do not package any active writer.

`ORIGINAL17_MEASUREMENTS.md` and its exact JSON/per-file report separately confirm
original W3 runtime3 modules / 1,685 added LOC / 83,008 bytes, seven Python tests /
2,595 added LOC, and separate fixture/model/policy data. Packaging these records
does not assert W3 acceptance, physical validation or publishing authority.
