"""Cross-check frozen selection against all archive manifests and credential patterns."""
from pathlib import Path
import collections,gzip,hashlib,json,re,zipfile
P=Path(__file__).parent;R=P.parent;B=Path('/workspace/forza-evidence-bundles')
sha=lambda b:hashlib.sha256(b).hexdigest()
inventory=json.loads((P/'selection-inventory.json').read_text());selected={x['path']:x for x in inventory if x['classification']=='SELECTED_STATIC'}
index=json.loads((P/'static-bundle-index.json').read_text());union={};sums=collections.Counter();copies=[]
for rec in index['bundles']:
 archive=B/rec['archive'];raw=archive.read_bytes();assert len(raw)==rec['archive_bytes']<90000000 and sha(raw)==rec['archive_sha256']
 manifest_raw=(B/(rec['archive']+'.manifest.json')).read_bytes();assert sha(manifest_raw)==rec['manifest_sha256'];m=json.loads(manifest_raw)
 assert m['payload_files']==rec['payload_files']==len(m['files']) and m['payload_bytes']==rec['payload_bytes']==sum(x['bytes'] for x in m['files'].values())
 assert rec['readback']=='PASS every member size/hash, then every selected source file rehashed unchanged'
 for name,info in m['files'].items():
  assert name in selected and name not in union,(name,'missing selection or duplicate member across bundles')
  assert info=={k:selected[name][k] for k in ('bytes','sha256')};assert sha((R/name).read_bytes())==info['sha256'];union[name]=rec['archive']
 sums['archive_bytes']+=rec['archive_bytes'];sums['payload_bytes']+=rec['payload_bytes'];sums['files']+=rec['payload_files']
assert set(union)==set(selected)
installed=[x for x in selected if x.startswith('filesystem/installed/')];assert len(installed)==73 and all(union[x]=='02-independent-investigations.tar.gz' for x in installed)
assert 'filesystem/installed/actual-ROS-results.json' in installed and 'filesystem/installed/negative-control-results.json' in installed and 'filesystem/installed/staged-manifest-vs-git.json' in installed
salvage=json.loads((P/'salvaged-build-results-index.json').read_text())
for row in salvage:
 assert row['archived_copy'] in union and sha((R/row['original_path']).read_bytes())==row['sha256']==sha((R/row['archived_copy']).read_bytes())
patterns={'credential_query_url':re.compile(rb'https?://[^\s\"<>]+(?:[?&](?:sig|signature|X-Amz-Signature|X-Goog-Signature|token|access_token)=)[^\s\"<>]+',re.I),'github_token':re.compile(rb'\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,})\b'),'private_key':re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----')}
findings=[];chunks_count=0;decode_failures=[]
for name in sorted(union):
 f=R/name;data=f.read_bytes();chunks=[('',data)]
 if f.suffix=='.gz' and not f.name.endswith('.tar.gz'):
  try:chunks=[('gzip',gzip.decompress(data))]
  except Exception:pass
 elif f.suffix=='.zip':
  try:
   with zipfile.ZipFile(f) as z:chunks=[(n,z.read(n)) for n in z.namelist() if not n.endswith('/')]
  except zipfile.BadZipFile:
   decode_failures.append({'path':name,'bytes':len(data),'reason':'Historical file has ZIP suffix but is not a ZIP archive; raw bytes retained and scanned.'})
 for member,data in chunks:
  chunks_count+=1
  for kind,pattern in patterns.items():
   n=len(pattern.findall(data))
   if n:findings.append({'path':name,'member':member,'kind':kind,'count':n})
scan={'selected_regular_files':len(selected),'scanned_regular_or_decoded_archive_chunks':chunks_count,'historical_non_ZIP_files':decode_failures,'patterns':list(patterns),'matches':findings,'sensitive_ephemeral_URL_exclusions_required':bool(findings),'scope':'Pattern check of selected originals, decoded gzip and originalZIP members. Values are never printed. Ordinary unsigned GitHub API/archive endpoints are provenance, not bearer credentials.'}
(P/'sensitive-selected-scan.json').write_text(json.dumps(scan,indent=2)+'\n');assert not findings,'Potential credentials require archival redaction/exclusion before publishing; inspect filenames only.'
report={'PASS':True,'bundles':len(index['bundles']),'unique_selected_regular_files':len(selected),'payload_bytes':sums['payload_bytes'],'archive_bytes':sums['archive_bytes'],'all_archives_under_90MB':True,'all_manifests_bind_frozen_selection':True,'all_selected_sources_rehashed_unchanged':True,'filesystem_installed_unique_evidence_files':len(installed),'salvaged_actual_build_result_files':len(salvage),'sensitive_matches':len(findings),'deferred':json.loads((P/'selection-plan.json').read_text())['deferred_roots'],'scope':'Static archival completeness and byte integrity only. Active final evidence remains deferred; no research acceptance or publishing assertion.'}
(P/'static-coverage-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
