# Read-only review of root acceptance draft and gate

Reviewed root-owned files without modification or executing the gate. Exact
reviewed snapshots and SHA256 values are in `reviewed-root-draft-snapshots/`
and `acceptance-review-input-snapshots.json`. Findings below describe that
reviewed version; root has agreed to make the corrections before finalization.

1. **Separate initial-source custom probes from final-source gates.** Draft
   lines55–60 list trust/codec31, filesystem19, installed ROS10, termination2
   and one-ULP /224→225-leaf investigations within a final acceptance report.
   These custom probes executed on initial17. Explicitly say so, and separately
   identify final b961 full-suite/permanent-regression coverage. The source-visible
   nine-case unchanged hosted replay is already correctly distinguished from the
   separately observed source-free runtime. The high-precision query probes ran
   reviewed correction bytes on67 base; their final route_artifact.py hash mapping
   is valid, but this is source-byte equivalence evidence, not a new exact-commit
   rerun. Only route_artifact.py changed in runtime modules between67 and b961.

2. **Bind decisive raw records and child reports in the acceptance receipt.**
   The reviewed gate hashes selected aggregate JSONs, while raw exit-code files,
   XML, source-before/after files and several decisive child reports are not in
   `evidence_inputs`. Bind their bytes or a sealed per-file manifest. Read/assert
   actual source-free control count rather than copying a literal15 into the
   acceptance receipt. Decisive report schema:

   - `final-runtime-b961d20/sourcefree-15-controls.json`: status PASS,
     source_commit b961, source_free true, negative_controls_checked15,
     controls length15, command_count21, accepted_artifact_unchanged true.
   - `sourcefree-record-audit.json`, created only after the wrapper finishes:
     status PASS, source_commit b961, source_free true,
     sourcefree_negative_controls15, scenario_count9, command_count36,
     scenarios length9, resource_count21, actual_inspect_id and image_id.
   - `actual-sourcefree-namespace-closure.json`: status PASS, source_commit b961,
     source_free true, implementation_module_count11, modules length12,
     resources length21, manifest_sha256 matching the actual build-identity file.
   - `actual-sourcefree-imports.json`: status PASS, source_commit b961,
     source_free true, modules length11. Match actual-sourcefree-inspect.Id,
     live-sourcefree-controls-audit.actual_container and
     sourcefree-record-audit.actual_inspect_id; also match their image IDs.
   - `complete-manifest-vs-git.json`:138 source files,21 resources,2 locks,
     exact source_commit, manifest_sha256. `complete-legacy.json`: ten failure
     identities, two copyright skips, exact_style_lines_including_repeats1173,
     no_added_or_removed_style_diagnostics true.

   The gate correctly requires all three wrapper exit codes, all27 groups /
   612 tests, all nine scenario IDs, exact clean source and completed child audit.
   It was not run during this review, and incomplete local work is not accepted.

3. **Label S6 phase sums separately from whole-worker wall duration.** Every
   inspected raw metadata/phase field matches the authenticated original final96
   result. The first repeat's selected top-level sum omits the corruption/identity
   negative-control phase:0.3316603389998818s wall and0.330541341s parent CPU.
   Its all-top-level phase sum is134.5522137280002s, versus the recorded selected
   sum134.22055338900032s. The second repeat's phase sum is134.68194934499934s.
   True runner-observed outer worker wall times are135.32048072800012s and
   135.44744620000006s. Source:
   `final-benchmarks/artifact/full-replay/primary/summary.json`, attempts by ID
   `S6-240m-new-0.52-r1/r2`, field `outer_wall_seconds`, also in attempts.jsonl.
   The worker's compressed result does not contain outer timing because the
   enclosing runner measures it. Parent/child RSS maxima are correctly kept
   separate and must not be presented as aggregate live process-tree memory.
   `s6-telemetry-readonly-review.json` binds the exact result/summary hashes.

Additional claims cross-checked successfully: the original hosted raw legacy
diagnostic Counter exactly matches the literal W2 historical baseline, including
all1,173 emitted style diagnostics; the targeted artifact/export XML contains
141 actual testcases; the saved numerical report totals4,442 queries and496
strict endpoint checks. Existing benchmark scope, adapted-vs-raw legacy
distinction, bounded metric inversion and absence of physical-validation claims
are appropriately limited. Final complete-runtime/archive work remains pending.

No root-owned files were changed, no gate executed, and no acceptance declared.
