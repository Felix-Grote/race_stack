"""Exact Git added-line split: executable modules, Python tests, input data, evidence."""
import collections,hashlib,json,pathlib,subprocess,time
P=pathlib.Path(__file__).parent;R='/workspace/forza-audit-records/final-checkout'
BASE='9fae5faed6ca62e0c943b6290babc50638477d9b';HEAD='17e4ec4e8fedfa736467d02f6204b04e8552decb'
def git(*args):return subprocess.check_output(['git','-C',R,*args])
def category(path):
 if '/evidence/' in path:return 'generated_or_retained_evidence'
 if path.startswith('planner/global_planner/global_planner/') and path.endswith('.py'):return 'pure_production_python_modules'
 if path.endswith('.py') and (path.startswith('planner/global_planner/test/') or path.startswith('scripts/project_a/tests/')):return 'python_tests'
 if path.startswith('planner/global_planner/config/project_a/') and any('/'+d+'/' in path for d in ('fixtures','models','policies')):return 'fixture_model_policy_JSON_data'
 if path.startswith('planner/global_planner/config/'):return 'other_configuration_resources'
 if path in ('planner/global_planner/setup.py','planner/global_planner/package.xml'):return 'packaging'
 if path.startswith(('scripts/','.github/','docker')):return 'verification_benchmark_harness_CI_container'
 if path.startswith('docs/') or path.endswith('.md'):return 'research_documentation'
 return 'other'
cats=collections.defaultdict(lambda:{'files':0,'added_lines':0,'deleted_lines':0,'binary_files':0,'head_bytes':0,'paths':[]});records=[]
for line in git('diff','--numstat','--no-renames',BASE,HEAD).decode().splitlines():
 a,d,path=line.split('\t',2);cat=category(path);x=cats[cat];x['files']+=1;x['paths'].append(path)
 try:data=git('show',HEAD+':'+path)
 except subprocess.CalledProcessError:data=b''
 row={'path':path,'category':cat,'added_lines':None if a=='-' else int(a),'deleted_lines':None if d=='-' else int(d),'head_bytes':len(data),'head_sha256':hashlib.sha256(data).hexdigest(),'head_physical_lines':len(data.splitlines())};records.append(row);x['head_bytes']+=len(data)
 if a=='-':x['binary_files']+=1
 else:x['added_lines']+=int(a);x['deleted_lines']+=int(d)
objects=git('rev-list','--objects',HEAD,'^'+BASE).decode().splitlines();ids=[x.split()[0] for x in objects]
check=subprocess.check_output(['git','-C',R,'cat-file','--batch-check=%(objecttype) %(objectsize)'],input=('\n'.join(ids)+'\n').encode()).decode().splitlines();types=collections.defaultdict(lambda:{'objects':0,'uncompressed_bytes':0})
for line in check:
 typ,n=line.split();types[typ]['objects']+=1;types[typ]['uncompressed_bytes']+=int(n)
process=subprocess.Popen(['git','-C',R,'-c','pack.threads=1','-c','core.compression=6','pack-objects','--stdout','--revs'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE);process.stdin.write((HEAD+'\n^'+BASE+'\n').encode());process.stdin.close();h=hashlib.sha256();count=0
while True:
 b=process.stdout.read(1024*1024)
 if not b:break
 h.update(b);count+=len(b)
err=process.stderr.read();assert process.wait()==0,err
ancestor=subprocess.run(['git','-C',R,'merge-base','--is-ancestor',BASE,HEAD]).returncode;assert ancestor==0
prod=[x for x in records if x['category']=='pure_production_python_modules'];assert len(prod)==3 and sum(x['added_lines'] for x in prod)==1685 and sum(x['head_bytes'] for x in prod)==83008
report={'label':'original17_W3_vs_accepted_W2','base':BASE,'head':HEAD,'definitions':{'LOC':'git diff --numstat physical added/deleted source lines, including comments/docstrings/blank lines. Production category includes only executable planner package Python modules, not packaging, JSON resources or evidence. This is not a semantic executable-statement count.','python_tests':'Only planner/global_planner/test/*.py and scripts/project_a/tests/*.py authored test source; copied tests inside retained evidence remain evidence.','fixture_data':'Packaged fixture/model/policy JSON is separate from Python tests and executable production modules.','pack':'Non-thin standalone incremental git -c pack.threads=1 -c core.compression=6 pack-objects --stdout --revs, input HEAD and ^BASE. Byte count is method/object-representation specific, not GitHub physical storage.'},'categories':dict(cats),'changed_files':len(records),'added_lines':sum(x['added_lines'] or 0 for x in records),'deleted_lines':sum(x['deleted_lines'] or 0 for x in records),'new_object_count':len(ids),'new_objects':dict(types),'standalone_incremental_pack_bytes':count,'standalone_incremental_pack_sha256':h.hexdigest(),'git_version':git('--version').decode().strip(),'ancestry':{'accepted_W2_base_is_ancestor':True,'merge_base':git('merge-base',BASE,HEAD).decode().strip(),'commits_after_base':int(git('rev-list','--count',BASE+'..'+HEAD))},'original_A07_runtime_confirmation':{'files':3,'physical_added_LOC':1685,'bytes':83008,'modules':prod},'scope':'Read-only original research measurement. Lean integration quantities must be measured separately on its actual branch; no inferred production savings or acceptance.'}
(P/'original17-precise-research-measurements.json').write_text(json.dumps(report,indent=2)+'\n');(P/'original17-per-file-diff-measurements.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('definitions','categories','original_A07_runtime_confirmation')},indent=2));print(json.dumps({k:{kk:vv for kk,vv in v.items() if kk!='paths'} for k,v in cats.items()},indent=2))
