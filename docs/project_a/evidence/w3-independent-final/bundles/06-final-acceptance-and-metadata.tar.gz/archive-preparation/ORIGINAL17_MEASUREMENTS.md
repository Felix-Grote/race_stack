# Original17 precise research size measurement

Exact comparison: accepted W2 `9fae5faed6ca62e0c943b6290babc50638477d9b` to original W3 `17e4ec4e8fedfa736467d02f6204b04e8552decb`.

LOC means physical added source lines from Git numstat, including comments, docstrings and blank lines. Production includes only the three executable planner Python module files; packaging and input data are separate.

| Category | Changed files | Added LOC | Deleted LOC | Head bytes in changed files |
| --- | ---: | ---: | ---: | ---: |
| verification_benchmark_harness_CI_container | 12 | 1,457 | 45 | 88,856 |
| research_documentation | 9 | 1,414 | 1 | 191,479 |
| generated_or_retained_evidence | 1,771 | 695,389 | 0 | 119,063,375 |
| other_configuration_resources | 1 | 9 | 0 | 379 |
| fixture_model_policy_JSON_data | 21 | 14,302 | 0 | 349,421 |
| pure_production_python_modules | 3 | 1,685 | 0 | 83,008 |
| packaging | 2 | 13 | 1 | 2,497 |
| python_tests | 7 | 2,595 | 0 | 132,156 |

**A07 runtime confirmed:** route_artifact.py 1,006 lines, route_compile.py 382 lines, route_legacy_export.py 297 lines: exactly **1,685 LOC and 83,008 bytes**. Authored Python tests are seven files, 2,595 added LOC: 2,016 planner-test lines and 579 harness-test lines. The 21 fixture/model/policy JSON files add 14,302 data lines and are excluded from both code counts.

Total: 1,826 changed files, +716,864/-47 text lines. Retained evidence includes 663 binary files; its text LOC is not executable production code.

New Git objects: 1,598 (6 commits, 403 trees, 1,189 blobs). Standalone incremental non-thin pack: **55,152,693 bytes**, SHA256 `a72e2fb817bf31cf4ac626ab5aff554dbc127b45e0828d30d11b2154f41d46e7`. This freshly reproduced the previously retained measurement exactly. Compression is method-specific and is not a measurement of GitHub physical storage.

Ancestry: 9fae is the exact merge base and an ancestor of original17; six commits follow it. The lean integration must be measured separately against its actual official upstream base. These figures make no acceptance or physical-validation assertion.

Reproduction: `python3 measure_precise_research.py`. Exact per-file categories, bytes and SHA256 values are in original17-per-file-diff-measurements.json.
