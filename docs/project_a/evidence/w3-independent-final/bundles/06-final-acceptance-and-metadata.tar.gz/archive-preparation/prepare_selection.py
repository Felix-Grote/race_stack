"""Inventory complete static research evidence and explicit deferred/excluded paths."""
from pathlib import Path
import collections,hashlib,json,shutil,stat,subprocess
ROOT=Path('/workspace/forza-audit-records');P=ROOT/'archive-preparation';OUT=Path('/workspace/forza-evidence-bundles')
sha=lambda b:hashlib.sha256(b).hexdigest()
groups={
 '01a-committed-research-core-b961':{'includes':['final-checkout/docs/project_a'],'excludes':['final-checkout/docs/project_a/evidence/w3-benchmarks','final-checkout/docs/project_a/evidence/w3-a09','final-checkout/docs/project_a/evidence/w3-report-portability']},
 '01b-committed-benchmarks-b961':{'includes':['final-checkout/docs/project_a/evidence/w3-benchmarks'],'excludes':[]},
 '01c-committed-runtime-publication-b961':{'includes':['final-checkout/docs/project_a/evidence/w3-a09','final-checkout/docs/project_a/evidence/w3-report-portability'],'excludes':[]},
 '02-independent-investigations':{'includes':['evidence','filesystem','numerical','trust','benchmarks','independent-build','resume-evidence','resume-installed','resume-numerical'],'excludes':[]},
 '03-final-hosted-ci-and96':{'includes':['final-evidence-b961d20','final-benchmarks'],'excludes':[]},
 '04-original-local-attempts-and-upstream':{'includes':['fresh-17e4ec4','fresh-b961d20','fresh-launch.log','fresh-b961d20-launch.log','upstream-baseline','research-pr-body-pending.json','research-pr-body-pending.md'],'excludes':['fresh-17e4ec4/checkout','fresh-b961d20/checkout','upstream-baseline/ci-checkout']},
}
for d in ['build','install','src','retry-build','retry-install','retry-src','retry-python','retry-wheels']:
 groups['02-independent-investigations']['excludes'].append('independent-build/'+d)
for head in ['fresh-17e4ec4','fresh-b961d20']:
 for d in ['build','install','src','python','wheels','a09-harness-tmp','.cache','.config']:
  groups['04-original-local-attempts-and-upstream']['excludes'].append(head+'/verification/'+d)
# Preserve every unique prior documentation/evidence byte beyond the final tree.
old=ROOT/'remediation-checkout/docs/project_a';new=ROOT/'final-checkout/docs/project_a';prior=[]
for f in sorted(old.rglob('*')):
 if not f.is_file() or f.is_symlink():continue
 q=new/f.relative_to(old)
 if not q.exists() or f.read_bytes()!=q.read_bytes():
  rel=str(f.relative_to(ROOT));groups['01a-committed-research-core-b961']['includes'].append(rel);prior.append({'path':rel,'sha256':sha(f.read_bytes()),'bytes':f.stat().st_size,'reason':'Prior remediation bytes absent from or differing from final candidate; history retained.'})
# Test XML and actual test logs are evidence even inside a disposable build tree.
salvage=[]
for base in ['fresh-17e4ec4/verification/build','fresh-b961d20/verification/build','independent-build/build','independent-build/retry-build']:
 for f in sorted((ROOT/base).rglob('*')):
  if not f.is_file() or f.is_symlink():continue
  rel=f.relative_to(ROOT);parts=f.relative_to(ROOT/base).parts
  if f.name=='pytest.xml' or 'test_results' in parts or 'Testing' in parts:
   raw=f.read_bytes();target=P/'salvaged-build-results'/rel
   target.parent.mkdir(parents=True,exist_ok=True)
   if target.exists():assert target.read_bytes()==raw
   else:target.write_bytes(raw)
   salvage.append({'original_path':str(rel),'archived_copy':str(target.relative_to(ROOT)),'bytes':len(raw),'sha256':sha(raw)})
(P/'salvaged-build-results-index.json').write_text(json.dumps(salvage,indent=2)+'\n')
groups['02-independent-investigations']['includes']+=['archive-preparation/salvaged-build-results','archive-preparation/salvaged-build-results-index.json']
# Explicitly enumerate ephemeral caches and symlink aliases, never silently follow.
for name,g in groups.items():
 for inc in g['includes']:
  d=ROOT/inc
  for f in ([d] if d.is_file() else sorted(d.rglob('*'))):
   rel=str(f.relative_to(ROOT))
   if f.is_symlink():g['excludes'].append(rel)
   elif f.is_dir() and f.name in ('__pycache__','.pytest_cache','.cache'):
    g['excludes'].append(rel)
 g['excludes']=sorted(set(g['excludes']))
 g['output']=str(OUT/(name+'.tar.gz'))
 g['max_archive_bytes']=89999999
deferred={'fresh-b961d20-complete':'Active complete fresh verification writer; final evidence bundle after completion.','final-runtime-b961d20':'Active installed replay/source-free audit writers; bundle after completion.','production-preparation':'Writers completed; preserve in final metadata bundle with finalized root report.','release-preparation':'Mutable root acceptance draft and equivalence protocol; defer until finalized.','HANDOFF.md':'Root agent updating current handoff.','fresh-b961d20-complete-launch.log':'Active complete verification log.'}
rows=[];totals=collections.defaultdict(lambda:{'files':0,'bytes':0})
def under(path,prefix):return path==prefix or path.startswith(prefix+'/')
for f in sorted(ROOT.rglob('*')):
 if f.is_dir() and not f.is_symlink():continue
 rel=str(f.relative_to(ROOT));mode=f.lstat().st_mode;kind='symlink' if stat.S_ISLNK(mode) else 'regular' if stat.S_ISREG(mode) else 'special';sel=[]
 for n,g in groups.items():
  if any(under(rel,x) for x in g['includes']) and not any(under(rel,x) for x in g['excludes']) and '__pycache__' not in f.parts:sel.append(n)
 if sel:
  assert kind=='regular',(rel,kind);reason='SELECTED_STATIC';status=reason
 elif any(under(rel,x) for x in deferred):status='DEFERRED_MUTABLE';reason=next(v for x,v in deferred.items() if under(rel,x))
 elif under(rel,'archive-preparation'):status='PREPARATION_METADATA_FOR_FINAL_INDEX';reason='Selection, inventories, scripts and archive index retained separately; finalize metadata after bundle creation.'
 else:
  status='EXCLUDED_RECONSTRUCTIBLE';reason='Reconstructible checkout/build/install/dependency/cache or symlink alias; all actual result records selected elsewhere.'
  if rel.startswith('remediation-checkout/docs/project_a/') or rel.startswith('final-checkout/docs/project_a/'):
   reason='Identical committed evidence bytes already selected from final candidate, or excluded ephemeral cache.'
 row={'path':rel,'kind':kind,'bytes':f.lstat().st_size,'classification':status,'bundle':sel,'reason':reason}
 if sel:row['sha256']=sha(f.read_bytes())
 rows.append(row);totals[status]['files']+=1;totals[status]['bytes']+=row['bytes']
plan={'root':str(ROOT),'bundles':groups,'deferred_roots':deferred,'prior_remediation_unique_or_changed_files':prior,'salvaged_build_result_files':len(salvage),'inventory':'selection-inventory.json','scope':'Complete static independent investigations, original/failing attempts, original CI ZIPs and committed historical research convenience snapshot; no acceptance or publishing authority. Active final writers explicitly deferred. No evidence deleted.'}
(P/'selection-plan.json').write_text(json.dumps(plan,indent=2)+'\n');(P/'selection-inventory.json').write_text(json.dumps(rows,indent=2)+'\n');(P/'selection-totals.json').write_text(json.dumps(dict(totals),indent=2)+'\n')
print(json.dumps({'bundles':len(groups),'totals':dict(totals),'prior_unique_or_changed':len(prior),'salvaged_build_results':len(salvage)},indent=2))
