"""No production imports: high precision portal transport on persisted cubics."""
import bisect
from fractions import Fraction as F
import json
from pathlib import Path
import sys

import mpmath as m

root = Path(sys.argv[1])
name = sys.argv[2]
digits = int(sys.argv[3]) if len(sys.argv) > 3 else 70
m.mp.dps = digits
probe = json.loads((root / ('result-' + name + '.json')).read_text())
payload = json.loads(next((root / ('reference-' + name)).glob('*/reference.json')).read_text())[
    'payload']
coefficients = payload['curve']['coefficients']
q = payload['curve']['q']
owners = payload['curve']['owners']


def arc(coefficient, high):
    rows = [[m.mpf(value) for value in row] for row in coefficient]
    return m.quad(lambda t: m.sqrt(sum(
        (row[1] + 2 * row[2] * t + 3 * row[3] * t * t) ** 2 for row in rows)), [0, high])


lengths = [arc(coefficient, 1) for coefficient in coefficients]
cumulative = [m.mpf(0)]
for length in lengths:
    cumulative.append(cumulative[-1] + length)
ends = [0.] + [q[i] for i in range(1, len(q) - 1) if owners[i] != owners[i - 1]] + [q[-1]]
exact_q = [F(value) for value in q]


def station(progress):
    i = min(bisect.bisect_right(exact_q, progress) - 1, len(q) - 2)
    parameter = (progress - exact_q[i]) / (exact_q[i + 1] - exact_q[i])
    parameter = m.mpf(parameter.numerator) / parameter.denominator
    return cumulative[i] + arc(coefficients[i], parameter)


period = F(q[-1])
windows = []
for i, portal in enumerate(payload['approved_route']['transitions']):
    low = (F(ends[i + 1]) - F(portal['before_m'])) % period
    high = (F(ends[i + 1]) + F(portal['after_m'])) % period
    windows.append((portal['id'], station(low), station(high)))
issues = []
for row in probe['portal_parameter_disagreements']:
    s = m.mpf(row['s'])
    support = [name for name, low, high in windows
               if (low <= s <= high if low <= high else s >= low or s <= high)]
    if row['reported'] != support:
        issues.append({**row, 'true_metric_support': support})
result = {'case': name, 'precision_digits': digits, 'mpmath': m.__version__,
          'scope': 'numerical boundary diagnostics; no physical evidence',
          'rechecked': len(probe['portal_parameter_disagreements']),
          'true_metric_disagreements': issues,
          'omitted_support': sum(bool(set(row['true_metric_support']) - set(row['reported']))
                                 for row in issues)}
(root / ('high_precision_portals-' + name + '-' + str(digits) + '.json')).write_text(
    json.dumps(result, indent=2))
print(json.dumps(result, indent=2))
