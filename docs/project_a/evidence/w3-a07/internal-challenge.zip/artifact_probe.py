"""Independent scratch probe; no production edits or authority refits."""
from fractions import Fraction as F
import json
import math
from pathlib import Path
import sys

sys.path.insert(0, '/src/planner/global_planner/test')
from test_route_artifact import inputs
import global_planner.route_artifact as a

name = sys.argv[1] if len(sys.argv) > 1 else 's0_route'
payload, context, ordered, model, timed = inputs(name)
reference = a.publish_reference(payload, '/work/reference-' + name,
                                expected_H=a.artifact_identity(payload),
                                expected_curve_digest=payload['approved_curve_digest'],
                                validation_context=context)
curve = reference.ordered.curve
issues, successes = [], 0
ends = [0.]
for occurrence in reference.ordered.route.occurrences:
    ends.append(ends[-1] + occurrence.length)
boundaries = list(reference._stations)
for portal, low, high in reference._portal_windows:
    boundaries.extend([low, high])
for station in boundaries:
    for s in [math.nextafter(station, -math.inf), station,
              math.nextafter(station, math.inf)]:
        row = reference.sample(s)
        segment, parameter = curve.locate(s)
        q = (1-F(parameter))*F(ordered.q[segment]) + F(parameter)*F(ordered.q[segment+1])
        exact_support = []
        for i, portal in enumerate(ordered.route.portals):
            period = F(ordered.period)
            low = (F(ends[i+1])-F(portal.before)) % period
            high = (F(ends[i+1])+F(portal.after)) % period
            hit = low <= q <= high if low <= high else q >= low or q <= high
            if hit:
                exact_support.append(portal.id)
        if tuple(exact_support) != row.portal_support:
            issues.append({'s':s, 'segment':segment, 't':parameter,
                           'q':float(q), 'reported':row.portal_support,
                           'exact_at_returned_parameter':exact_support})
        successes += 1
result = {'checks':successes,'portal_parameter_disagreements':issues,
          'H':reference.H, 'geometry':reference.geometry_report.status,
          'dynamics':reference.dynamics_report.status}
Path('/work/result-' + name + '.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
