"""Preserve complete cross-host replay evidence as a bounded data-only archive."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import shutil
import tarfile


ROOT = Path.cwd()
SOURCE = ROOT / 'work/w3/postfix-portability'
DESTINATION = ROOT / 'work/w3/postfix-portability-evidence'
ARCHIVE = ROOT / 'work/w3/postfix-portability-evidence.tar.gz'
SUMMARY = ROOT / 'work/w3/postfix-portability-summary.json'
RECEIPT = ROOT / 'work/w3/postfix-portability-archive.json'
COMMIT = '17e4ec4e8fedfa736467d02f6204b04e8552decb'


def sha(path):
    """Return the exact persisted file digest."""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def copy(path, relative):
    """Copy a regular evidence file and prove the copied bytes equal the original."""
    assert path.is_file() and not path.is_symlink(), path
    target = DESTINATION / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(path, target)
    assert target.read_bytes() == path.read_bytes(), path


assert not any(path.exists() for path in (DESTINATION, ARCHIVE, SUMMARY, RECEIPT))
outcome = json.loads((SOURCE / 'summary.json').read_bytes())
provenance = json.loads((SOURCE / 'launch-provenance.json').read_bytes())
rows = json.loads((SOURCE / 'results/main-time.json').read_bytes())
original = json.loads((SOURCE / 'results/portability.json').read_bytes())
main = json.loads((SOURCE / 'results/main-time-summary.json').read_bytes())
assert outcome['status'] == main['status'] == 'PASS'
assert outcome['runtime_exit_code'] == 0
assert outcome['source_commit'] == provenance['source_commit'] == main['source_commit'] == COMMIT
assert outcome['source_dirty_before_and_after'] is False
assert main['validated_hosted_products'] == len(rows) == len(original) == 9
assert main['all_frozen_main_time_hex_values_preserved'] is True
assert main['all_original_artifact_bytes_unchanged'] is True
assert (SOURCE / 'exit-code.txt').read_text().strip() == '0'
assert (SOURCE / 'results/original-exit-code.txt').read_text().strip() == '0'
DESTINATION.mkdir()
for path in sorted(SOURCE.rglob('*')):
    if path.is_file():
        copy(path, Path('runtime') / path.relative_to(SOURCE))
incoming = Path(provenance['incoming_root'])
for case in provenance['artifacts']:
    path = incoming / case['relative_artifact']
    assert sha(path) == case['sha256']
    copy(path, Path('incoming') / case['relative_artifact'])
    receipt_relative = 'w3-scenarios/' + case['case'] + '/compile.json'
    receipt = incoming / receipt_relative
    assert sha(receipt) == case['controlled_receipt']['sha256']
    copy(receipt, Path('incoming') / receipt_relative)
copy(incoming / 'build-identity.json', Path('incoming/build-identity.json'))
prefix = ROOT / 'work/w3/postfix-fresh/verification'
hosted = ROOT / 'work/w3/postfix-ci'
for folder, label in ((prefix, 'local'), (hosted, 'hosted')):
    for name in ('dependencies.txt', 'os-packages.txt', 'runtime-identity.json',
                 'image-id.txt', 'build-identity.json', 'source-hashes-before.json',
                 'source-hashes-after.json'):
        copy(folder / name, Path('context') / label / name)
share = prefix / 'install/global_planner/share/global_planner/project_a'
for name in ('synthetic_policy.json', 's6_coarse_policy.json'):
    copy(share / 'policies' / name, Path('policies') / name)
copy(ROOT / 'work/w3/curate_postfix_portability.py', Path('curate_postfix_portability.py'))
cases = []
for row in rows:
    assert row['status'] == 'PASS'
    assert row['stored_producer_main_time_hex'] == row['reference_main_time_hex']
    cases.append({
        'case': row['case'], 'H': row['H'], 'curve_digest': row['curve_digest'],
        'unchanged_artifact_sha256': row['unchanged_artifact_sha256'],
        'stored_producer_main_time_hex': row['stored_producer_main_time_hex'],
        'fresh_report_nominal_time_hex': row['fresh_report_nominal_time_hex'],
        'fresh_minus_stored_nominal_time_s': (
            row['fresh_report_nominal_time_s'] - row['stored_producer_main_time_s']),
        'changed_geometry_report_leaves': row['geometry_report_changes']['changed_leaves'],
        'geometry_report_structural_changes': row['geometry_report_changes']['structural_changes'],
        'changed_dynamics_report_leaves': row['dynamics_report_changes']['changed_leaves'],
        'dynamics_report_structural_changes': row['dynamics_report_changes']['structural_changes'],
    })
summary = {
    'status': 'PASS', 'source_commit': COMMIT, 'source_dirty_before_and_after': False,
    'hosted_push_run_url': provenance['hosted_run_url'],
    'original_CI_zip_sha256': provenance['hosted_zip_sha256'],
    'externally_trusted_catalog_sha256': provenance['catalog_sha256'],
    'image_id': provenance['image_id'], 'runtime_exit_code': 0,
    'unchanged_original_failure_reproducer': 'PASS', 'products': 9,
    'both_fresh_independent_validators': 'PASS for each product',
    'unchanged_H_C_coefficients_q_owners_profile_model_footprint_policies_and_raw_bytes': True,
    'all_nine_frozen_producer_time_hex_values_preserved': True,
    'cases_with_geometry_report_differences': main['cases_with_geometry_report_differences'],
    'cases_with_dynamics_report_differences': main['cases_with_dynamics_report_differences'],
    'cases_with_changed_fresh_nominal_time': sum(
        item['fresh_minus_stored_nominal_time_s'] != 0 for item in cases),
    'maximum_absolute_nominal_time_difference_s': max(
        abs(item['fresh_minus_stored_nominal_time_s']) for item in cases),
    'S6_actual_nine_group_reader_and_CDR': main['S6_actual_reader_CDR'],
    'S6_stored_producer_main_time_hex': main['S6_stored_producer_main_time_hex'],
    'S6_expected_float32_s': main['S6_expected_float32_s'],
    'S6_actual_reader_float32_s': main['S6_actual_reader_float32_s'],
    'identity_bypass_or_refit': False, 'cases': cases,
    'limitation': 'Synthetic planar offline software evidence; independent W3 review required',
}
SUMMARY.write_text(json.dumps(summary, indent=2) + '\n')
copy(SUMMARY, Path('summary.json'))
(DESTINATION / 'README.md').write_text(
    '# Current cross-host saved-artifact replay evidence\n\n'
    'Product commit: `' + COMMIT + '`. All nine exact hosted products replayed under '
    'their externally trusted controlled compile receipt H in the separate clean local '
    'installed runtime. Both independent validators passed. Producer time remained exact; '
    'fresh historical report differences were recorded without making them a requirement.\n\n'
    '`runtime/` preserves the unchanged original RED reproducer, supplemental checks, '
    'launch provenance, raw outputs and all exit codes. `incoming/` preserves actual '
    'hosted artifact and receipt bytes bound to unique original CI ZIP members. '
    '`context/` preserves local/hosted inventories and exact source/build identities. '
    '`policies/` contains the explicitly installed independent validation resources.\n\n'
    'The original hosted CI ZIP is separately retained under its recorded SHA-256; '
    'it is not duplicated in this archive. No installed binaries, source/build tree, '
    'device access or vehicle operation is included. See `runtime/PREPARED.md` and '
    '`runtime/launch.sh` for the recorded reproduction procedure.\n')
files = sorted(path for path in DESTINATION.rglob('*') if path.is_file())
ledger = {str(path.relative_to(DESTINATION)): {
    'sha256': sha(path), 'bytes': path.stat().st_size} for path in files}
ledger_path = DESTINATION / 'files.json'
ledger_path.write_text(json.dumps(ledger, indent=2, sort_keys=True) + '\n')
with ARCHIVE.open('xb') as archive_file:
    with gzip.GzipFile(filename='', mode='wb', fileobj=archive_file, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as archive:
            for path in sorted(item for item in DESTINATION.rglob('*') if item.is_file()):
                raw = path.read_bytes()
                member = tarfile.TarInfo('postfix-portability-evidence/' +
                                         str(path.relative_to(DESTINATION)))
                member.size, member.mode, member.mtime = len(raw), 0o644, 0
                archive.addfile(member, io.BytesIO(raw))
with tarfile.open(ARCHIVE, mode='r:gz') as archive:
    members = archive.getmembers()
    assert len(members) == len(ledger) + 1
    for member in members:
        relative = Path(member.name).relative_to('postfix-portability-evidence')
        assert archive.extractfile(member).read() == (DESTINATION / relative).read_bytes()
receipt = {
    'source_commit': COMMIT, 'archive': str(ARCHIVE.relative_to(ROOT)),
    'archive_sha256': sha(ARCHIVE), 'archive_bytes': ARCHIVE.stat().st_size,
    'files': len(ledger) + 1,
    'uncompressed_bytes': sum(path.stat().st_size for path in
                              DESTINATION.rglob('*') if path.is_file()),
    'file_ledger_sha256': sha(ledger_path),
    'summary': str(SUMMARY.relative_to(ROOT)), 'summary_sha256': sha(SUMMARY),
    'original_CI_zip_sha256': provenance['hosted_zip_sha256'],
    'scope': 'Data-only cross-host acceptance evidence; product source unchanged',
}
RECEIPT.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'archive_receipt': receipt, 'summary': summary}, indent=2))
