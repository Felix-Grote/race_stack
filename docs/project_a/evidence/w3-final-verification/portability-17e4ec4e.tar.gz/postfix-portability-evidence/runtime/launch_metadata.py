"""Bind a controlled hosted catalog to an unchanged clean local installed prefix."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import zipfile


EXPECTED_SOURCE = '17e4ec4e8fedfa736467d02f6204b04e8552decb'
IMAGE = 'sha256:2cc1f6ad969cdb3256f14b4b45500cb0fcdd4a3f321b4c2a1bbc7c7fb6ca0f88'
HERE = Path(__file__).resolve().parent
REPOSITORY = HERE.parents[2]
PREFIX = HERE.parent / 'postfix-fresh/verification'
EXPECTED_CASES = {
    's0_route', 's0_reverse_route', 's0_rotated_route', 's2_upper_route', 's2_lower_route',
    's3_surfaces_route', 's3_notch_route', 's4_repeated_route', 's6_competition_route',
}
ORIGINAL_HASHES = {
    'harness/verify.py': '5c6642b6d8d7054f6bed25f596d99d14666823ec22d33a6f1a208f4c6f077a08',
    'harness/run.sh': 'b46df64b20b73acf1c84faca156d096fa2acc936ec5869c3e30d44b364ea0710',
}


def sha(path):
    """Return a file identity without decoding or rewriting its bytes."""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def canonical(value):
    """Encode the published JSON identity independently of the implementation."""
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=False, allow_nan=False).encode('utf-8')


def archive_binding(archive, relative, path):
    """Bind exact extracted bytes to one actual hosted ZIP member."""
    member = 'source-free/results/' + relative
    assert archive.namelist().count(member) == 1, member
    raw = path.read_bytes()
    assert archive.read(member) == raw, member
    return {'zip_member': member, 'sha256': hashlib.sha256(raw).hexdigest()}


def clean_source():
    """Require the advertised product commit and a clean tree before and after runtime."""
    head = subprocess.check_output(['git', '-C', str(REPOSITORY), 'rev-parse', 'HEAD'],
                                   text=True).strip()
    dirty = subprocess.check_output(['git', '-C', str(REPOSITORY), 'status', '--porcelain'],
                                    text=True)
    assert head == EXPECTED_SOURCE and not dirty, (head, dirty)


def prepare(incoming_name, catalog_name, run_name, zip_name):
    """Persist launch trust provenance after the parent independently verifies hosted inputs."""
    clean_source()
    assert not (HERE / 'results').exists(), 'Preserve prior runtime results'
    assert not (HERE / 'launch-provenance.json').exists(), 'Preserve prior launch identity'
    incoming, catalog_path, run_path, zip_path = (
        Path(name).resolve(strict=True)
        for name in (incoming_name, catalog_name, run_name, zip_name))
    assert incoming.is_dir() and all(path.is_file() for path in
                                     (catalog_path, run_path, zip_path))
    assert zip_path.suffix == '.zip'
    run = json.loads(run_path.read_bytes())
    assert run['headSha'] == EXPECTED_SOURCE
    assert run['event'] == 'push' and run['status'] == 'completed'
    assert run['conclusion'] == 'success'
    catalog = json.loads(catalog_path.read_bytes())
    assert len(catalog) == 9 and {case['case'] for case in catalog} == EXPECTED_CASES
    installed_manifest = PREFIX / 'install/global_planner/share/global_planner/project_a'
    installed_manifest /= 'build_identity.json'
    local = json.loads(installed_manifest.read_bytes())
    hosted_manifest = incoming / 'build-identity.json'
    hosted = json.loads(hosted_manifest.read_bytes())
    hosted_canonical_sha = hashlib.sha256(canonical(hosted)).hexdigest()
    for manifest in (local, hosted):
        assert manifest['source_commit'] == EXPECTED_SOURCE and manifest['source_dirty'] is False
    for field in ('source_hashes', 'installed_resource_hashes', 'dependency_lock_hashes',
                  'gitlinks'):
        assert local[field] == hosted[field], field
    artifacts = []
    with zipfile.ZipFile(zip_path) as archive:
        hosted_manifest_binding = archive_binding(archive, 'build-identity.json', hosted_manifest)
        for case in catalog:
            assert re.fullmatch('[0-9a-f]{64}', case['H'])
            assert re.fullmatch('[0-9a-f]{64}', case['curve_digest'])
            relative = Path(case['relative_artifact'])
            assert not relative.is_absolute() and '..' not in relative.parts
            artifact = (incoming / relative).resolve(strict=True)
            assert artifact.is_relative_to(incoming) and not (incoming / relative).is_symlink()
            artifact_binding = archive_binding(archive, relative.as_posix(), artifact)
            receipt_relative = 'w3-scenarios/' + case['case'] + '/compile.json'
            receipt_path = incoming / receipt_relative
            receipt_binding = archive_binding(archive, receipt_relative, receipt_path)
            receipt = json.loads(receipt_path.read_bytes())
            assert receipt['status'] == 'PASS' and receipt['H'] == case['H']
            assert receipt['geometry']['curve_digest'] == case['curve_digest']
            assert receipt['dynamics']['curve_digest'] == case['curve_digest']
            payload = json.loads(artifact.read_bytes())['payload']
            assert payload['provenance']['source_commit'] == EXPECTED_SOURCE
            assert payload['provenance']['build_manifest_sha256'] == hosted_canonical_sha
            artifacts.append({**case, **artifact_binding, 'controlled_receipt': receipt_binding})
    for name, expected in ORIGINAL_HASHES.items():
        assert sha(HERE / name) == expected, name
    files = list(ORIGINAL_HASHES) + [
        'extra-harness/run.sh', 'extra-harness/main_time.py', 'launch.sh', 'launch_metadata.py']
    provenance = {
        'source_commit': EXPECTED_SOURCE, 'source_dirty': False, 'image_id': IMAGE,
        'trust_source': 'Parent independently verified current hosted push compile receipts',
        'hosted_run_url': run['url'], 'hosted_run_metadata_path': str(run_path),
        'hosted_run_metadata_sha256': sha(run_path), 'hosted_zip_path': str(zip_path),
        'hosted_zip_sha256': sha(zip_path), 'incoming_root': str(incoming),
        'externally_trusted_catalog_path': str(catalog_path), 'catalog_sha256': sha(catalog_path),
        'local_install': str(PREFIX / 'install'), 'local_python': str(PREFIX / 'python'),
        'local_build_manifest_sha256': sha(installed_manifest),
        'hosted_build_manifest_sha256': sha(hosted_manifest),
        'hosted_build_manifest_canonical_sha256': hosted_canonical_sha,
        'hosted_build_manifest_archive_binding': hosted_manifest_binding,
        'artifacts': artifacts, 'harness_sha256': {name: sha(HERE / name) for name in files},
        'source_or_build_mounts': [],
        'readonly_mounts': ['/work/install', '/work/python', '/harness', '/extra-harness',
                            '/incoming', '/catalog.json'],
        'writable_mounts': ['/results', '/tmp'], 'network': 'none', 'uid': 1000,
        'root_readonly': True, 'cap_drop': 'ALL', 'no_new_privileges': True,
        'blas_threads': 1, 'omp_threads': 1,
        'scope': 'Unchanged current hosted artifacts under external receipt H; no identity bypass',
    }
    (HERE / 'trusted-catalog.json').write_bytes(catalog_path.read_bytes())
    (HERE / 'hosted-run.json').write_bytes(run_path.read_bytes())
    (HERE / 'launch-provenance.json').write_text(json.dumps(provenance, indent=2) + '\n')
    (HERE / 'results').mkdir()


def finish(runtime_code):
    """Record actual completion and verify that runtime did not rewrite any incoming bytes."""
    clean_source()
    provenance = json.loads((HERE / 'launch-provenance.json').read_bytes())
    unchanged = all(sha(Path(provenance['incoming_root']) / case['relative_artifact']) ==
                    case['sha256'] for case in provenance['artifacts'])
    assert unchanged
    for name, expected in provenance['harness_sha256'].items():
        assert sha(HERE / name) == expected, name
    main = HERE / 'results/main-time-summary.json'
    original = HERE / 'results/original-exit-code.txt'
    complete = int(runtime_code) == 0 and main.exists() and original.read_text().strip() == '0'
    result = {
        'status': 'PASS' if complete else 'FAIL', 'runtime_exit_code': int(runtime_code),
        'source_commit': EXPECTED_SOURCE, 'source_dirty_before_and_after': False,
        'all_hosted_artifact_bytes_unchanged': unchanged,
        'original_harness_sha256': ORIGINAL_HASHES,
        'source_of_trusted_H': provenance['trust_source'],
        'hosted_run_url': provenance['hosted_run_url'],
        'hosted_zip_sha256': provenance['hosted_zip_sha256'],
    }
    if main.exists():
        result['additional_main_time_and_reader_checks'] = json.loads(main.read_bytes())
    if complete:
        assert result['additional_main_time_and_reader_checks']['status'] == 'PASS'
        assert result['additional_main_time_and_reader_checks']['validated_hosted_products'] == 9
    (HERE / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
    return 0 if complete else 1


if __name__ == '__main__':
    if sys.argv[1] == 'prepare':
        assert len(sys.argv) == 6
        prepare(*sys.argv[2:])
    elif sys.argv[1] == 'finish':
        assert len(sys.argv) == 3
        raise SystemExit(finish(sys.argv[2]))
    else:
        raise ValueError('prepare or finish required')
