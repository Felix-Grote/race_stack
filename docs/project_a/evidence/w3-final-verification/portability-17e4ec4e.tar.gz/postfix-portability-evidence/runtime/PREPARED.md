# Current hosted artifact portability acceptance

Prepared only. Do not execute until the parent supplies the independently verified
current push CI artifact, run metadata and receipt-derived trusted catalog.

The local runtime prefix is the clean ordinary installation from commit
`17e4ec4e8fedfa736467d02f6204b04e8552decb`, under
`work/w3/postfix-fresh/verification/{install,python}`. The image is
`sha256:2cc1f6ad969cdb3256f14b4b45500cb0fcdd4a3f321b4c2a1bbc7c7fb6ca0f88`.

Launch with explicit trusted inputs after authorization:

```bash
bash work/w3/postfix-portability/launch.sh \
  CURRENT_CI_SOURCE_FREE_RESULTS \
  EXTERNALLY_VERIFIED_RECEIPT_CATALOG_JSON \
  CURRENT_PUSH_RUN_JSON \
  CURRENT_PUSH_ORIGINAL_CI_ZIP
```

The launcher requires a successful current push run, the exact clean installed
commit, matching local/hosted resource and source manifests, and all nine current
artifact provenance bindings. It copies the externally supplied trusted catalog;
it never obtains trust from received artifact self-hashes. It preserves prior
results rather than overwriting them. Each of the nine exact extracted artifact
files and controlled compile receipts, plus the hosted build manifest, must match
their unique raw-byte member in the original hosted ZIP.

The first program is the exact original RED harness. Its unchanged hashes are:

- `harness/verify.py`: `5c6642b6d8d7054f6bed25f596d99d14666823ec22d33a6f1a208f4c6f077a08`
- `harness/run.sh`: `b46df64b20b73acf1c84faca156d096fa2acc936ec5869c3e30d44b364ea0710`

It loads all nine unchanged hosted references under their receipt H values,
reruns both independent validators, queries cyclic progress, exports S6 and uses
the actual existing nine-group reader and generated ROS CDR.

The separate supplemental program reloads all nine through the real public
loader, verifies exact saved coefficients/q/owners/profile/model/policies and
retained C/H, checks `Reference.lap_time_s.hex()` against the saved producer T,
and counts historical/fresh report differences without requiring any difference.
It checks the actual S6 reader and CDR Float32 time against the saved producer T.
No identity hook, checker, policy, coefficient or report is patched.

One separate nonroot, networkless container has read-only root, dropped
capabilities, no new privileges and read-only installed products, minimal
harnesses, incoming references and catalog. It has no source or build mount.
Only results and temporary storage are writable. The launcher records exact
input, catalog, CI ZIP and harness hashes, and verifies all original artifact
bytes and the clean product HEAD again after execution.
