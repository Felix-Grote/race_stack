"""Check exact producer time and unchanged hosted authority through real replay."""
from dataclasses import asdict
import hashlib
import json
import math
import os
from pathlib import Path
import socket
import struct

from ament_index_python.packages import get_package_share_directory
from global_planner import route_artifact
from global_planner.cyclic_retime import curve_digest
from global_planner.readwrite_global_waypoints import read_global_waypoints
from global_planner.route_artifact import load_reference
from global_planner.route_compile import load_policy
from rclpy.serialization import deserialize_message, serialize_message
from rosidl_runtime_py.convert import message_to_ordereddict


EXPECTED_SOURCE = '17e4ec4e8fedfa736467d02f6204b04e8552decb'


def canonical(value):
    """Encode the published identity independently of the artifact implementation."""
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=False, allow_nan=False).encode('utf-8')


def differences(stored, fresh):
    """Count exact report differences without requiring any platform variation."""
    result = {'changed_leaves': 0, 'changed_numeric_leaves': 0,
              'structural_changes': 0, 'first_changed_paths': []}

    def visit(left, right, path):
        if type(left) is dict and type(right) is dict:
            for key in sorted(set(left) | set(right)):
                if key not in left or key not in right:
                    result['structural_changes'] += 1
                else:
                    visit(left[key], right[key], path + '.' + key)
        elif type(left) is list and type(right) is list:
            result['structural_changes'] += abs(len(left) - len(right))
            for index, (before, after) in enumerate(zip(left, right)):
                visit(before, after, path + '[' + str(index) + ']')
        elif canonical(left) != canonical(right):
            result['changed_leaves'] += 1
            if len(result['first_changed_paths']) < 32:
                result['first_changed_paths'].append(path)
            if type(left) in (int, float) and type(right) in (int, float):
                result['changed_numeric_leaves'] += 1

    visit(stored, json.loads(canonical(fresh)), '$')
    result['exact_report_match'] = canonical(stored) == canonical(fresh)
    return result


assert os.getuid() == 1000
assert socket.if_nameindex() == [(1, 'lo')]
security = dict(line.split(':', 1) for line in
                Path('/proc/self/status').read_text().splitlines() if ':' in line)
assert int(security['CapEff'].strip(), 16) == 0
assert security['NoNewPrivs'].strip() == '1'
absent_paths = ('/src', '/workspace', '/work/src', '/work/build', '/work/optimizer')
for absent in absent_paths:
    assert not Path(absent).exists(), absent
readonly_paths = ('/', '/work/install', '/work/python', '/harness', '/extra-harness',
                  '/incoming', '/catalog.json')
for readonly in readonly_paths:
    assert os.statvfs(readonly).f_flag & os.ST_RDONLY, readonly
assert str(Path(route_artifact.__file__).resolve()).startswith('/work/install/')
share = Path(get_package_share_directory('global_planner')) / 'project_a'
manifest = json.loads((share / 'build_identity.json').read_text())
assert manifest['source_commit'] == EXPECTED_SOURCE
assert manifest['source_dirty'] is False
catalog = json.loads(Path('/catalog.json').read_text())
assert len(catalog) == 9 and len({case['case'] for case in catalog}) == 9
outcomes = []
original_bytes = {}
for case in catalog:
    path = Path('/incoming') / case['relative_artifact']
    before = path.read_bytes()
    original_bytes[str(path)] = hashlib.sha256(before).hexdigest()
    envelope = json.loads(before)
    payload = envelope['payload']
    assert envelope['H'] == case['H']
    assert hashlib.sha256(canonical(payload)).hexdigest() == case['H']
    assert payload['approved_curve_digest'] == case['curve_digest']
    policy_name = ('s6_coarse_policy.json' if case['case'] == 's6_competition_route'
                   else 'synthetic_policy.json')
    _, context, _ = load_policy(share / 'policies' / policy_name)
    reference = load_reference(path, expected_H=case['H'], validation_context=context)
    assert reference.H == case['H']
    assert curve_digest(reference.ordered) == case['curve_digest']
    assert reference.geometry_report.status == reference.dynamics_report.status == 'PASS'
    for key, actual in (('coefficients', reference.ordered.curve.coefficients),
                        ('owners', reference.ordered.curve.owners), ('q', reference.ordered.q)):
        assert canonical(actual) == canonical(payload['curve'][key])
    for key, actual in (('speed_profile', reference.profile), ('model', reference.model),
                        ('footprint', reference.footprint), ('policies', reference.policies)):
        assert canonical(asdict(actual)) == canonical(payload[key])
    assert canonical(reference.payload) == canonical(payload)
    stored_time = payload['validation']['dynamics']['lap_time_s']
    assert type(stored_time) is float and math.isfinite(stored_time)
    assert reference.lap_time_s.hex() == stored_time.hex()
    assert reference.dynamics_report.lap_time_lower_s <= stored_time
    assert stored_time <= reference.dynamics_report.lap_time_upper_s
    assert path.read_bytes() == before
    outcomes.append({
        'case': case['case'], 'status': 'PASS', 'H': case['H'],
        'curve_digest': case['curve_digest'],
        'unchanged_artifact_sha256': original_bytes[str(path)],
        'stored_producer_main_time_s': stored_time,
        'stored_producer_main_time_hex': stored_time.hex(),
        'reference_main_time_hex': reference.lap_time_s.hex(),
        'fresh_report_nominal_time_s': reference.dynamics_report.lap_time_s,
        'fresh_report_nominal_time_hex': reference.dynamics_report.lap_time_s.hex(),
        'geometry_report_changes': differences(payload['validation']['geometry'],
                                               asdict(reference.geometry_report)),
        'dynamics_report_changes': differences(payload['validation']['dynamics'],
                                               asdict(reference.dynamics_report)),
    })
    Path('/results/main-time.json').write_text(json.dumps(outcomes, indent=2) + '\n')

case = next(item for item in catalog if item['case'] == 's6_competition_route')
payload = json.loads((Path('/incoming') / case['relative_artifact']).read_bytes())['payload']
stored_time = payload['validation']['dynamics']['lap_time_s']
expected_float32 = struct.unpack('!f', struct.pack('!f', stored_time))[0]
exported = json.loads(Path('/results/export.json').read_text())
assert exported['H'] == case['H'] and exported['lap_time_s'].hex() == stored_time.hex()
assert exported['legacy_lap_time_float32_s'] == expected_float32
groups = read_global_waypoints(str(Path(exported['output_path']).parent))
assert len(groups) == 9 and groups[1].data == expected_float32
for message in groups:
    restored = deserialize_message(serialize_message(message), type(message))
    assert message_to_ordereddict(restored) == message_to_ordereddict(message)
assert groups[5].wpnts[-1].s_m == exported['length_m']
for path, before in original_bytes.items():
    assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == before
summary = {
    'status': 'PASS', 'source_commit': EXPECTED_SOURCE, 'source_dirty': False,
    'validated_hosted_products': len(outcomes), 'all_original_artifact_bytes_unchanged': True,
    'all_frozen_main_time_hex_values_preserved': True,
    'report_variation_required_for_acceptance': False,
    'cases_with_geometry_report_differences': sum(
        not row['geometry_report_changes']['exact_report_match'] for row in outcomes),
    'cases_with_dynamics_report_differences': sum(
        not row['dynamics_report_changes']['exact_report_match'] for row in outcomes),
    'S6_H': case['H'], 'S6_stored_producer_main_time_s': stored_time,
    'S6_stored_producer_main_time_hex': stored_time.hex(),
    'S6_expected_float32_s': expected_float32, 'S6_actual_reader_float32_s': groups[1].data,
    'S6_actual_reader_CDR': 'PASS; all nine groups',
    'runtime_module': str(Path(route_artifact.__file__).resolve()),
    'uid': os.getuid(), 'network': 'loopback only',
    'cap_eff': security['CapEff'].strip(), 'no_new_privileges': security['NoNewPrivs'].strip(),
    'verified_readonly_paths': readonly_paths, 'verified_absent_paths': absent_paths,
}
Path('/results/main-time-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, sort_keys=True))
