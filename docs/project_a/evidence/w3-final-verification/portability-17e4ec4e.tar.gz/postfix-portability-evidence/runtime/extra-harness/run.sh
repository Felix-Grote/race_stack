#!/bin/bash
set -eo pipefail
set +e
/bin/bash /harness/run.sh
original_rc=$?
set -e
printf '%s\n' "$original_rc" > /results/original-exit-code.txt
if [ "$original_rc" -ne 0 ]; then exit "$original_rc"; fi
source /opt/ros/humble/setup.bash
export PYTHONPATH=/work/python
source /work/install/setup.bash
python -m flake8 --max-line-length=99 /extra-harness/main_time.py
python /extra-harness/main_time.py
