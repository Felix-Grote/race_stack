#!/usr/bin/env bash
# Launch only after the parent supplies a verified current hosted receipt catalog.
set -euo pipefail
if [ "$#" -ne 4 ]; then
  echo 'Usage: launch.sh INCOMING_ROOT TRUSTED_CATALOG HOSTED_RUN_JSON HOSTED_CI_ZIP' >&2
  exit 2
fi
if [ "$(id -u)" -ne 1000 ]; then
  echo 'Use the recorded nonroot uid1000 for this cross-host acceptance run.' >&2
  exit 1
fi
here=$(cd "$(dirname "$0")" && pwd)
prefix=$(realpath "$here/../postfix-fresh/verification")
incoming=$(realpath "$1")
python3 "$here/launch_metadata.py" prepare "$incoming" "$2" "$3" "$4"
unset DOCKER_HOST DOCKER_CONTEXT DOCKER_TLS DOCKER_TLS_VERIFY DOCKER_CERT_PATH
set +e
docker --host=unix:///var/run/docker.sock run --rm \
  --user 1000:1000 --read-only --network none --ipc private \
  --cap-drop ALL --security-opt no-new-privileges --pids-limit 256 --memory 4g --cpus 2 \
  --workdir /results --tmpfs /tmp:rw,nosuid,nodev,size=256m,mode=1777 \
  -e PYTHONDONTWRITEBYTECODE=1 -e MPLBACKEND=Agg -e MPLCONFIGDIR=/tmp/project-a-mpl \
  -e OPENBLAS_NUM_THREADS=1 -e OMP_NUM_THREADS=1 \
  --mount "type=bind,src=$prefix/install,dst=/work/install,readonly" \
  --mount "type=bind,src=$prefix/python,dst=/work/python,readonly" \
  --mount "type=bind,src=$here/harness,dst=/harness,readonly" \
  --mount "type=bind,src=$here/extra-harness,dst=/extra-harness,readonly" \
  --mount "type=bind,src=$incoming,dst=/incoming,readonly" \
  --mount "type=bind,src=$here/trusted-catalog.json,dst=/catalog.json,readonly" \
  --mount "type=bind,src=$here/results,dst=/results" \
  --entrypoint /bin/bash \
  sha256:2cc1f6ad969cdb3256f14b4b45500cb0fcdd4a3f321b4c2a1bbc7c7fb6ca0f88 \
  /extra-harness/run.sh 2>&1 | tee "$here/console.log"
runtime_rc=${PIPESTATUS[0]}
set -e
printf '%s\n' "$runtime_rc" > "$here/exit-code.txt"
python3 "$here/launch_metadata.py" finish "$runtime_rc"
