# Current cross-host saved-artifact replay evidence

Product commit: `17e4ec4e8fedfa736467d02f6204b04e8552decb`. All nine exact hosted products replayed under their externally trusted controlled compile receipt H in the separate clean local installed runtime. Both independent validators passed. Producer time remained exact; fresh historical report differences were recorded without making them a requirement.

`runtime/` preserves the unchanged original RED reproducer, supplemental checks, launch provenance, raw outputs and all exit codes. `incoming/` preserves actual hosted artifact and receipt bytes bound to unique original CI ZIP members. `context/` preserves local/hosted inventories and exact source/build identities. `policies/` contains the explicitly installed independent validation resources.

The original hosted CI ZIP is separately retained under its recorded SHA-256; it is not duplicated in this archive. No installed binaries, source/build tree, device access or vehicle operation is included. See `runtime/PREPARED.md` and `runtime/launch.sh` for the recorded reproduction procedure.
