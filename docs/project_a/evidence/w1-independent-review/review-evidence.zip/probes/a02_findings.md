# Independent A02 audit

Reviewed source: `133a96fd6653e4d3b16d71c38e1c70fc38585101` at
`/workspace/work/w1-review/source`. The module is
`planner/global_planner/global_planner/route_reference.py` (293 lines).
The reviewed snapshot was not changed.

## P1 — Accepted metric integration/inversion can exceed its stated error budget

Source references: `_integrate`, lines 114–120; `parameter`, lines 133–149;
`Curve` budget distribution, lines 189–196. `_regularity`, lines 63–86, correctly
detects nonregular derivatives but discards its subdivisions before integration.

Contract: controlled integration of the exact cubic gives a whole-lap
`arc_abs=1e-10 m`; accepted inverse queries meet `station_abs=1e-8 m`. The source
explicitly calls the QUADPACK error *estimated*, which is not treated here as a
formal interval certificate. The demonstrated defect is an actual numerical error
larger than the published error budget, including an inverse routine reporting
success after checking itself against the same inaccurate integral.

Minimal reproduction:

```python
from global_planner.route_reference import CubicSegment
s = CubicSegment(((0, .0899, -.3, 1/3), (0, 2e-7, 0, 0)))
target = .75 * s.length
t = s.parameter(target)
print(s.length, s.arc_error, target, t, s.arc(t) - target)
```

Observed with the project's pinned Humble Python/NumPy/SciPy versions as well as
the host numerical environment:

* `length = 0.12323333334188319 m`.
* QUADPACK estimated error `1.5271498741260836e-13 m` (accepted).
* `target = 0.09242500000641239 m`, `t = 0.9304256195843263`.
* Internal inverse residual `-4.618250226684495e-13 m` (accepted).

Independent mathematical lower bound: `x'=(t-.3)^2-.01^2`, `y'=2e-7`.
The derivative norm is at least `2e-7`, exceeding the default `1e-7` threshold
everywhere. Because `hypot(x',y') >= abs(x')`, true length is at least

```
integral_0^1 x' dt + 8/3 * .01^3 = 0.12323599999999998 m.
```

Consequently true length undercount is at least `2.6666581167955616e-6 m`.
At the returned inverse parameter the exact piecewise-polynomial `integral abs(x')`
likewise proves a true station residual at least `2.6666627948174204e-6 m`.
These are conservative lower bounds; no quadrature oracle is needed to establish
the failure. Independent fixed 64/128/256-point Gaussian rules, split around the
derivative roots and their narrow neighborhoods, return respectively
`0.12323600003508088 / 0.12323600003508056 / 0.12323600003508094 m`, supporting
the lower bound; 256-point true inverse residual is `2.6666978726191948e-6 m`.

The saved probe also supplies eight explicit knots and `q=0..8` creating an
accepted periodic `Curve.interpolate`. Its first segment has the same error,
its per-segment arc budget is `1.25e-11 m`, and `Curve.sample` returns the same
incorrect station. Thus this is reachable through the periodic public query API,
not confined to a nonperiodic analytic helper. Full coefficients, points, sample,
and lower bounds are in the JSON.

A supplementary example avoids any retracing in x:

```python
s = CubicSegment(((0, .211669921876, -.3984375, .25),
                  (0, 4e-6, 0, 0)))
```

Here `x'=.75*(t-17/32)^2+1e-12>0`, `y'=4e-6`. Integrating the exact polynomial
lower envelope `max(x', (x'+y')/sqrt(2))` proves length undercount at least
`1.2066621715711712e-8 m`; an accepted 75%-length query has true residual at least
`1.1912202106667547e-8 m`. These exceed both default budgets.

Root cause: unconstrained adaptive `quad` samples miss a narrow region where the
norm differs materially from its surrounding polynomial behavior; its returned
estimate is then much smaller than actual error. The inversion residual is
computed with the same defective integration and therefore is not a guard against
this failure. Increasing `quad_limit` or densifying a resampling mesh does not
force an adaptive integrator to inspect a region it has already judged smooth.

Recommended bounded correction: resolve critical derivative-speed regions before
quadrature (for cubic geometry, stationary speed candidates are real roots of
the cubic `r' dot r''`) and use controlled subdivisions/enclosures or an
independent conservative check that cannot accept unresolved narrow minima.
Retain explicit budget exhaustion/rejection. The existing derivative Bézier
subdivision is reusable rather than introducing a second geometric authority.
Do not merely reduce `epsabs`, increase a sampling density, or loosen the claimed
station tolerance. A repair should justify both total integration and partial
integration used during inversion.

Regression requirements: the minimal near-stationary pocket, the monotone variant,
and the accepted periodic embedding; verify actual errors using the analytic lower
bounds and independently split high-accuracy integration. Sweep pocket centers,
scales and widths, repeat under rigid transforms, exercise interior inverse
queries and reject if the budget cannot be justified.

## P2 — Floating-point endpoint normalization violates periodic/right-hand semantics

Source references: compensated sums lines 210–218; `station` lines 256–260;
`wrap/locate` lines 262–272; owner selection lines 277–280.

Minimal negative-seam reproduction:

```python
theta = np.linspace(0, 2*np.pi, 64, endpoint=False)
c = Curve.interpolate(np.c_[6*np.cos(theta), 6*np.sin(theta)])
print(c.wrap(-1e-20), c.length)
c.sample(-1e-20)
```

Observed: `wrap(-1e-20) == L == 37.69910696841439`; `sample` raises
`GeometryError('segment station outside arc')`. A valid finite supplied progress
has passed the explicit precision guard. `%` rounded a negative remainder to L,
outside the promised half-open lap; subsequent subtraction lies just above the
last segment's stored length. Other knot counts return a sample with `s=L` and
`last,t=1` instead of an exception, also outside the half-open wrapped range.

Independent endpoint-anchor reproduction:

```python
theta = np.linspace(0, 2*np.pi, 5, endpoint=False)
c = Curve.interpolate(np.c_[6*np.cos(theta), 4*np.sin(theta)],
    owners=[('o'+str(i), 's'+str(i)) for i in range(5)])
print(c.station(2,1), c.cumulative[3])
print(c.sample(c.station(2,1)).occurrence_id)
```

Observed: `station(2,1)=18.232675003474927` while canonical next knot is
`18.23267500347493`; sampling this endpoint reports `o2` / `(2,1)` rather than
the documented right-hand `o3` / `(3,0)`. Compensated cumulative addition and
ordinary addition in `station` produce different binary64 numbers for the same
anchor. This is a bounded endpoint convention defect; it does not demonstrate
switching to a disconnected nonadjacent deck.

Recommended correction: return canonical cumulative values for exact `t=0/1`
anchors, define a half-open remainder normalization including negative values
that round to L, and make the segment residual conversion robust within a
justified floating-point allowance. Preserve the intended side of a seam where
ownership differs; do not broadly snap all nearby queries across semantic
boundaries using the station tolerance.

Regressions: the two minimal cases; every `(i,1)` must roundtrip to canonical
`cumulative[i+1]`, next segment/owner and seam wrap; query `nextafter` on both
sides of every knot and seam, small negative numbers including subnormals, and
negative/multiple-lap versions. Check explicit owner assertions as well as XY.

## Executed independent coverage and limitations

Command (host):

```
/workspace/race_stack_setup/venv/bin/python /workspace/work/w1-review/probes/a02_adversarial.py > /workspace/work/w1-review/evidence/a02_adversarial_host.log
```

Exit 0 means both demonstrated defects reproduced and the stated invariants
passed. Host Python 3.12.14, NumPy 1.26.4, SciPy 1.12.0. Pinned Humble replay uses
Python 3.10.12, NumPy 1.26.4, SciPy 1.11.4; see `a02_adversarial_humble.*` and
the per-probe runtime/execution JSON for exact container argv and isolation.

* Independent analytic parabola: exact length `1.4789428575445975 m`, production
  `1.4789428575445973 m`. The true continuous worst nominal-fraction error is
  `0.16703482227024902 m`, consistent with the historical approximately .1656 m
  mesh-dependent example. W1's genuine inverse has maximum actual residual
  `1.3128564901876416e-10 m` over 201 queries. Therefore W1 fixes the original
  parameter-fraction bug on that curve, but that passing example does not
  establish robust controlled integration on all accepted cubics.
* Nonuniform 35-knot ellipse: rotation .713 rad, translation (71.3,-93.8), reversal
  and cyclic-origin metamorphisms passed. Maximum transformed XY error
  `1.4210854715202004e-14 m`, curvature rotation error `2.270406085358445e-13/m`,
  reversal curvature sign error `6.106226635438361e-15/m`, length difference
  `3.552713678800501e-15 m`. These validate stated examples, not arbitrary inputs.
* Fixed-seed 1631, 100 nonuniform periodic ellipses, 36,616 near-knot queries:
  no query exceptions; 1,045 endpoint-to-right-hand segment mismatches were
  demonstrated; maximum anchor discrepancy `3.552713678800501e-15 m`.
* Independent zero-derivative, quadrature-budget, regularity-budget and very-short
  segment probes all failed closed as expected. Subthreshold short normalized
  segments are expressly unsupported by the minimum derivative policy.

No ROS, TUM, mutable cache, global association state or caller-array mutation is
present in this module. Coefficients, samples, owners and cumulative lengths are
deep immutable tuples with frozen policy/record dataclasses. Construction checks
position, unit tangent and signed curvature at every join/seam; normalized
parameter-derivative magnitudes may legitimately differ. Metric inversion uses
stored exact cubic coefficients rather than fitting a second curve or increasing
sample density. Those design choices are coherent.

Existing A02 tests cover the analytic parabola, smooth nonuniform ellipse,
circle/reversal, normal exact cumulative knots, reconstruction/immutability,
several malformed curves and explicit budgets. They do not cover hidden narrow
speed minima with an independent error bound, endpoint station-to-locate metadata
roundtrips, or negative progress sufficiently close to the seam to round to L.
Their smooth fixed-order Gaussian example cannot establish the difficult
near-stationary cases. The future A05 continuous footprint validator is outside
this audit; the reported numerical defects are A02 responsibilities already.
