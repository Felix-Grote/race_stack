"""Independent A01 probes: JSON faults, identity, metamorphisms, exact predicates."""
import copy
import json
import math
from pathlib import Path
import random
import tempfile

from global_planner.route_input import RouteError, load_route, validate_route
from global_planner._route_geometry import simple_polygon, segments_touch

SOURCE = Path('/workspace/work/w1-review/source')
FIX = SOURCE / 'planner/global_planner/test/fixtures/project_a'
base = json.loads((FIX / 's0_route.json').read_text())
report = {}

def transform(p, angle, shift):
    p = copy.deepcopy(p)
    ca, sa = math.cos(angle), math.sin(angle)
    def pt(v):
        x,y=v
        return [ca*x-sa*y+shift[0],sa*x+ca*y+shift[1]]
    for o in p['occurrences']:
        for key in ('seed','left','right'):
            o[key] = [pt(v) for v in o[key]]
    for t in p['transitions']:
        for key in ('gate','support'):
            t[key] = [pt(v) for v in t[key]]
    p['initialization']['zone'] = [pt(v) for v in p['initialization']['zone']]
    return p

# A rigid transform preserves declared cycle, surfaces, seed distances and legality.
r = validate_route(base)
metamorphic=[]
for a in (0, .17, math.pi/2, -math.pi+.013):
    for xy in ((0,0),(1000,-730),(99980,99980)):
        v=validate_route(transform(base,a,xy))
        e=max(abs(x.length-y.length) for x,y in zip(r.occurrences,v.occurrences))
        assert e < 1e-8
        assert [(x.id,x.surface_id) for x in r.occurrences]==[(x.id,x.surface_id) for x in v.occurrences]
        metamorphic.append({'angle_rad':a,'translation':xy,'max_seed_length_error_m':e})
report['rigid_transform_invariant']=metamorphic

# Recursive key order is not identity; data normalization must not mutate caller data.
def reorder(v):
    if isinstance(v,dict): return {k:reorder(v[k]) for k in reversed(v)}
    if isinstance(v,list): return [reorder(x) for x in v]
    return v
assert validate_route(reorder(base)).digest==r.digest
p=copy.deepcopy(base); before=copy.deepcopy(p); v=validate_route(p); assert p==before
p['occurrences'][0]['seed'][0][0]=888
assert v.payload==before
report['canonical_recursive_order_and_caller_mutation']='PASS'

faults={
 'duplicate occurrence NFC':lambda p:(p['occurrences'][0].update(id='\u00e9'),p['occurrences'][1].update(id='e\u0301')),
 'boolean surface id':lambda p:p['surfaces'][0].update(id=True),
 'boolean transition id':lambda p:p['transitions'][0].update(id=True),
 'boolean route id':lambda p:p.update(route_id=True),
 'overflow numeric':lambda p:p['physical_map'].update(registration=[10**1000,0,0]),
 'infinity coordinate':lambda p:p['occurrences'][0]['seed'][2].__setitem__(0,float('inf')),
 'missing closing portal':lambda p:p['transitions'].pop(),
 'illegal nonadjacent switch':lambda p:p['transitions'][0].update(to='o2'),
 'reversed closing gate':lambda p:p['transitions'][-1]['gate'].reverse(),
 'duplicate gate sequence':lambda p:p['gate_sequence'].__setitem__(1,p['gate_sequence'][0]),
 'unknown surface':lambda p:p['occurrences'][0].update(surface_id='unselected'),
 'unsupported hole':lambda p:p['occurrences'][0].update(holes=[[[0,0],[1,0],[0,1]]]),
 'metadata extra contradictory approval':lambda p:p['provenance'].update(approved=False),
 'self-crossing boundary':lambda p:p['occurrences'][0]['left'].__setitem__(5,[100,100]),
 'degenerate seed':lambda p:p['occurrences'][0]['seed'].__setitem__(1,p['occurrences'][0]['seed'][0]),
}
results={}
for name,fault in faults.items():
    p=copy.deepcopy(base); fault(p)
    try: validate_route(p)
    except RouteError as e: results[name]=str(e)
    else: raise AssertionError('accepted '+name)
report['independent_manifest_faults_rejected']=results

# Same simple geometry with distinct visit IDs remains permitted, not collapsed.
# Declared physical coverage does not alter the legal geometry view.
p=copy.deepcopy(base); p['physical_map']['coverage']='complete'
a=validate_route(p)
p['physical_map']['coverage']='partial'; b=validate_route(p)
assert a.occurrences==b.occurrences and a.portals==b.portals and a.digest!=b.digest
report['physical_coverage_independence']='PASS'

# Duplicate and normalized-colliding JSON keys are tested before schema interpretation.
raws=['{"schema_version":1,"schema_version":2}', '{"\u00e9":1,"e\u0301":2}',
      '{"x":NaN}','{"x":Infinity}','{"x":-Infinity}','{"x":1e999}']
with tempfile.TemporaryDirectory(prefix='a01-review-') as td:
    for i,raw in enumerate(raws):
        path=Path(td)/f'bad-{i}.json'; path.write_text(raw)
        try: load_route(path)
        except RouteError: pass
        else: raise AssertionError('accepted JSON fault')
report['strict_json_faults_rejected']=len(raws)

# Exact rational oracle: proper crossing of nonadjacent polygon edges is invalid.
# Integer-grid coordinates avoid ambiguity and are exactly representable after translation.
def orient(a,b,c):
    return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def proper(a,b,c,d):
    return orient(a,b,c)*orient(a,b,d)<0 and orient(c,d,a)*orient(c,d,b)<0
rng=random.Random(20261016)
count=0
for trial in range(4000):
    poly=tuple((rng.randrange(-100,101),rng.randrange(-100,101)) for _ in range(8))
    es=list(zip(poly,poly[1:]+poly[:1]))
    crossings=[(i,j) for i,(a,b) in enumerate(es) for j,(c,d) in enumerate(es)
               if j>i+1 and (i,j)!=(0,len(es)-1) and proper(a,b,c,d)]
    if crossings:
        assert not simple_polygon(poly)
        translated=tuple((a+90000,b+90000) for a,b in poly)
        assert not simple_polygon(translated)
        count+=1
report['exact_integer_crossed_polygon_rejections']={'seed':20261016,'trials':4000,'crossed_cases':count,'translations_checked':2}

# Segment predicates get independent exact crossing cases across length scales.
count=0
for trial in range(10000):
    seg=tuple((rng.randrange(-1000,1001),rng.randrange(-1000,1001)) for _ in range(4))
    if proper(*seg):
        assert segments_touch(*seg)
        count+=1
report['exact_integer_segment_crossings_detected']={'trials':10000,'proper_crossings':count}
print(json.dumps(report,indent=2,sort_keys=True))
