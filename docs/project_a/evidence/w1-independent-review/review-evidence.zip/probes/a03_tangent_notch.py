import sys,json
sys.path.insert(0, '/workspace/work/w1-review/source/planner/global_planner')
from global_planner.route_input import Occurrence
from global_planner.route_corridor import _normal_geometry
from global_planner._route_geometry import simple_polygon,inside,line_intervals
# A locally simple ribbon: a notch from the right boundary touches the query normal.
o=Occurrence('strip','ground',((0.,0.),(10.,0.)),
             ((0.,2.),(10.,2.),(10.,1.),(5.,.75),(10.,.5),(10.,.1)),
             ((0.,-1.),(10.,-1.)),((0.,4.),))
p=(5.,0.); n=(0.,1.)
print(json.dumps({'simple_polygon':simple_polygon(o.polygon),
    'raw_intervals':line_intervals(p,n,o.polygon),
    'accepted_corridor':_normal_geometry((o,),p,(1.,0.)),
    'notch_tip_legal_interior':inside((5.,.75),o.polygon,False),
    'probe_points':[(a,inside((5.,a),o.polygon,False)) for a in (.5,.75,1.,1.9)]},indent=2))
