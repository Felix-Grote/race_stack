"""Exact binary64 segment oracle near the declared geometric tolerance."""
from fractions import Fraction
import json
import math
import random
from global_planner._route_geometry import segments_touch

def o(a,b,c):
    a,b,c=[tuple(Fraction.from_float(float(x)) for x in p) for p in (a,b,c)]
    return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])

def exactproper(a,b,c,d): return o(a,b,c)*o(a,b,d)<0 and o(c,d,a)*o(c,d,b)<0
rng=random.Random(2026101601)
proper=0; missed=[]
for i in range(20000):
    length=10**rng.uniform(-7,4)
    other=10**rng.uniform(-7,4)
    angle=10**rng.uniform(-14,0)
    phi=rng.uniform(-math.pi,math.pi)
    center=(rng.choice((0.,80000.)),rng.choice((0.,-80000.)))
    v=(math.cos(phi),math.sin(phi)); w=(math.cos(phi+angle),math.sin(phi+angle))
    a=(center[0]-length*.25*v[0],center[1]-length*.25*v[1])
    b=(center[0]+length*.75*v[0],center[1]+length*.75*v[1])
    c=(center[0]-other*.63*w[0],center[1]-other*.63*w[1])
    d=(center[0]+other*.37*w[0],center[1]+other*.37*w[1])
    if exactproper(a,b,c,d):
        proper+=1
        if not segments_touch(a,b,c,d):
            missed.append({'a':a,'b':b,'c':c,'d':d,'length':length,'other':other,'angle':angle})
print(json.dumps({'seed':2026101601,'trials':20000,'exact_proper_crossings':proper,'missed':missed[:10],'missed_count':len(missed)},indent=2))
