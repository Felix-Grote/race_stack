import sys,json,math
sys.path.insert(0, '/workspace/work/w1-review/source/planner/global_planner')
from global_planner.route_input import Occurrence
from global_planner.route_corridor import _normal_geometry
from global_planner._route_geometry import inside,line_intervals
base=Occurrence('strip','ground',((0.,0.),(10.,0.)),
 ((0.,2.),(10.,2.),(10.,1.),(5.,.75),(10.,.5),(10.,.1)),
 ((0.,-1.),(10.,-1.)),((0.,4.),))
results=[]
for angle in (0.,.37,1.1,2.9):
 for translation in ((0.,0.),(10000.,-20000.)):
  c,s=math.cos(angle),math.sin(angle)
  def trans(p):return(c*p[0]-s*p[1]+translation[0],s*p[0]+c*p[1]+translation[1])
  o=Occurrence(base.id,base.surface_id,tuple(map(trans,base.seed)),tuple(map(trans,base.left)),tuple(map(trans,base.right)),base.caps)
  interval=_normal_geometry((o,),trans((5.,0.)),(c,s))
  results.append({'angle':angle,'translation':translation,'interval':interval,'tip_interior':inside(trans((5.,.75)),o.polygon,False)})
print(json.dumps({'invariant':'Rigid rotation/translation preserves metric normal interval and tangent-contact exclusion','observed':results},indent=2))
print('FINITE_GAP_PERTURBATIONS')
for dx in (-1e-6,-5e-9,-1e-9,0,1e-6):
 left=list(base.left);left[3]=(5+dx,.75)
 o=Occurrence(base.id,base.surface_id,base.seed,tuple(left),base.right,base.caps)
 print(json.dumps({'tip_dx':dx,'raw_intervals':line_intervals((5.,0.),(0.,1.),o.polygon),'returned':_normal_geometry((o,),(5.,0.),(1.,0.))}))
