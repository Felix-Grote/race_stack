"""A01 directed-gate acceptance changes under collinear seed subdivision."""
import copy
import json
import math
from pathlib import Path
from global_planner.route_input import validate_route, RouteError
from global_planner._route_geometry import cross, sub, distance
ROOT=Path('/workspace/work/w1-review')
p=json.loads((ROOT/'source/planner/global_planner/test/fixtures/project_a/s0_route.json').read_text())
# A simple circular ribbon, center radius 6 m and full width 0.1 mm.
# This is inside the documented metre/range/tolerance model; no vehicle claim.
for o in p['occurrences']:
    for side,radius in (('left',6-.00005),('right',6+.00005)):
        o[side]=[[x*radius/6,y*radius/6] for x,y in o['seed']]
for i,t in enumerate(p['transitions']):
    o=p['occurrences'][i]
    t['gate']=[o['right'][-1],o['left'][-1]]
original=validate_route(p)
# Collinear subdivision changes neither the polyline nor its direction nor topology.
p2=copy.deepcopy(p)
a=p2['occurrences'][0]['seed']; b=p2['occurrences'][1]['seed']
join=a[-1]
incoming=distance(a[-2],join); outgoing=distance(b[1],join)
epsilon=1e-6
before=[join[k]+epsilon/incoming*(a[-2][k]-join[k]) for k in (0,1)]
a.insert(len(a)-1,before)
after=[join[k]+epsilon/outgoing*(b[1][k]-join[k]) for k in (0,1)]
b.insert(1,after)
gate=p2['transitions'][0]['gate']; travel=sub(after,before)
value=cross(sub(gate[1],gate[0]),travel)
try:
    validate_route(p2)
    result='ACCEPTED'
except RouteError as e:
    result=f'{type(e).__name__}: {e}'
(ROOT/'evidence/a01_gate_scale_input.json').write_text(json.dumps(p2,indent=2)+'\n')
print(json.dumps({'original':'ACCEPTED','subdivided':result,'seed_subdivision_m':epsilon,
 'gate_length_m':distance(*gate),'travel_length_m':math.hypot(*travel),
 'gate_cross_travel_m2':value,
 'normalized_directed_cross':value/(distance(*gate)*math.hypot(*travel)),
 'seed_length_change_m':sum(distance(x,y) for x,y in zip(a,a[1:]))-original.occurrences[0].length,
 'input':'evidence/a01_gate_scale_input.json'},indent=2))
assert result=='RouteError: wrong directed gate'
