"""Independent read-only A02 probes, pinned to the reviewed W1 snapshot.

Run with the numerical venv; no implementation or repository file is changed.
An exit code of zero means the recorded probes, including demonstrated defects,
reproduced as described. This is a review evidence script, not an acceptance test.
"""
import json
import math
from pathlib import Path
import platform
import sys

import numpy as np
import scipy

SOURCE = Path('/workspace/work/w1-review/source')
sys.path.insert(0, str(SOURCE / 'planner/global_planner'))
from global_planner.route_reference import CubicSegment, Curve, GeometryError, NumericPolicy


def polynomial_value(row, t, order=0):
    """Independent NumPy polynomial differentiation/evaluation."""
    return np.polynomial.polynomial.polyval(
        t, np.polynomial.polynomial.polyder(row, order))


def x_roots(coeff):
    a = np.asarray(coeff)
    roots = np.polynomial.polynomial.polyroots(
        np.polynomial.polynomial.polyder(a[0]))
    return sorted(float(z.real) for z in roots
                  if abs(z.imag) < 1e-12 and 0 < z.real < 1)


def projected_variation(coeff, t=1.):
    """Integral |dx/dt| <= integral hypot(dx/dt,dy/dt), exactly piecewise polynomial.

    Root/evaluation roundoff is below 1e-14 m for these O(1) coefficients,
    immaterial to the demonstrated 2.6e-6 m violations.
    """
    anchors = [0.] + [r for r in x_roots(coeff) if r < t] + [t]
    return math.fsum(abs(polynomial_value(coeff[0], b) -
                         polynomial_value(coeff[0], a))
                     for a, b in zip(anchors, anchors[1:]))


def independent_arc(coeff, t=1., order=128):
    """Fixed Gaussian rule split around derivative roots; no production arc calls.

    Narrow neighborhoods use explicit logarithmic scale breakpoints. Agreement
    between 64/128/256 point rules is recorded rather than assumed a proof.
    The projected-variation lower bound independently proves the defect.
    """
    roots = x_roots(coeff)
    anchors = {0., t}
    for root in roots:
        slope = abs(polynomial_value(coeff[0], root, 2))
        width = abs(polynomial_value(coeff[1], root, 1)) / max(slope, 1e-15)
        for factor in [-1000, -100, -10, -1, -.1, -.01,
                       0, .01, .1, 1, 10, 100, 1000]:
            p = root + factor * width
            if 0 < p < t:
                anchors.add(p)
    anchors = sorted(anchors)
    nodes, weights = np.polynomial.legendre.leggauss(order)
    pieces = []
    for lo, hi in zip(anchors, anchors[1:]):
        p = lo + (nodes + 1) * (hi - lo) / 2
        dx = polynomial_value(coeff[0], p, 1)
        dy = polynomial_value(coeff[1], p, 1)
        pieces.append(float(np.dot(weights, np.hypot(dx, dy)) * (hi - lo) / 2))
    return math.fsum(pieces)


def parabola():
    seg = CubicSegment(((0, 1, 0, 0), (0, 0, 1, 0)))
    def exact(t):
        return .5 * t * math.sqrt(1 + 4 * t * t) + .25 * math.asinh(2 * t)
    length = exact(1.)
    t_worst = math.sqrt(length * length - 1) / 2
    residuals = [abs(exact(seg.parameter(float(s))) - s)
                 for s in np.linspace(0, seg.length, 201)]
    assert max(residuals) < seg.policy.station_abs
    return {'exact_length_m': length, 'reported_length_m': seg.length,
            'old_nominal_fraction_worst_error_m': abs(exact(t_worst) - length * t_worst),
            'old_nominal_fraction_t_at_worst': t_worst,
            'new_inverse_worst_residual_m_201_queries': max(residuals),
            'verdict': 'Original nominal-fraction error is fixed on the parabola.'}


def hidden_pocket():
    # x'=(t-.3)^2-.01^2, y'=2e-7. Both derivative roots are regular.
    coeff = ((0., .0899, -.3, 1 / 3), (0., 2e-7, 0., 0.))
    seg = CubicSegment(coeff)
    bound = projected_variation(seg.coefficients)
    oracle = {str(n): independent_arc(seg.coefficients, order=n) for n in (64, 128, 256)}
    target = .75 * seg.length
    t = seg.parameter(target)
    residual_bound = projected_variation(seg.coefficients, t) - target
    residual_oracle = independent_arc(seg.coefficients, t, 256) - target
    assert bound - seg.length > 10000 * seg.policy.arc_abs
    assert residual_bound > 100 * seg.policy.station_abs
    return {'coefficients': coeff, 'policy': vars(seg.policy),
            'derivative_norm_lower_bound': 2e-7,
            'reported_length_m': seg.length, 'reported_quad_error_m': seg.arc_error,
            'exact_projected_variation_lower_bound_m': bound,
            'proven_length_undercount_lower_bound_m': bound - seg.length,
            'independent_gaussian_arc_m': oracle,
            'inversion_target_m': target, 'returned_t': t,
            'production_inverse_residual_m': seg.arc(t) - target,
            'proven_true_inverse_residual_lower_bound_m': residual_bound,
            'independent_true_inverse_residual_m': residual_oracle,
            'verdict': 'DEMONSTRATED: actual length and station errors exceed advertised budgets.'}


def monotone_near_stationary():
    # A supplementary counterexample has dx/dt strictly positive everywhere:
    # dx/dt=A*(t-c)^2+z, dy/dt=e. It does not retrace along x.
    A, c, z, e = .75, 17 / 32, 1e-12, 4e-6
    seg = CubicSegment(((0., A * c * c + z, -A * c, A / 3),
                        (0., e, 0., 0.)))
    # Euclidean norm >= (dx+e)/sqrt(2) and >= dx. Their maximum
    # exceeds dx on [c-w,c+w]; integrate that excess analytically.
    w = math.sqrt(((math.sqrt(2) + 1) * e - z) / A)
    correction = 2 * ((e / math.sqrt(2) - (1 - 1 / math.sqrt(2)) * z) * w -
                      (1 - 1 / math.sqrt(2)) * A * w ** 3 / 3)
    def lower_bound(t):
        assert t > c + w
        return A * (t ** 3 / 3 - c * t * t + c * c * t) + z * t + correction
    target = .75 * seg.length
    t = seg.parameter(target)
    assert lower_bound(1.) - seg.length > seg.policy.arc_abs
    assert lower_bound(t) - target > seg.policy.station_abs
    return {'coefficients': seg.coefficients,
            'positive_x_derivative_lower_bound': z,
            'speed_lower_bound': e,
            'reported_length_m': seg.length,
            'reported_error_m': seg.arc_error,
            'proven_length_undercount_lower_bound_m': lower_bound(1.) - seg.length,
            'inversion_target_m': target, 'returned_t': t,
            'proven_true_inverse_error_lower_bound_m': lower_bound(t) - target,
            'verdict': 'DEMONSTRATED: a non-retracing regular cubic also violates both budgets.'}


PERIODIC_POINTS = [
    [-1.5024623491492127e-15, -7.957616698076442e-22],
    [.12323333333333301, 1.9999999999986714e-7],
    [.2867959417586583, -.4813887455929313],
    [-1.4997593897109303, -1.6151633169617934],
    [-.647436223972624, .9494314068337777],
    [-.20927157109936093, .9423388372100486],
    [1.4381127571538583, -.3109547412709052],
    [.23234307397572523, -.12505112468113805],
]


def periodic_pocket():
    c = Curve.interpolate(PERIODIC_POINTS, q=np.arange(9, dtype=float),
                          owners=[('o' + str(i), 'surface' + str(i)) for i in range(8)])
    seg = c.segments[0]
    target = .75 * seg.length
    v = c.sample(target)
    bound = projected_variation(seg.coefficients)
    # Robust derivative-y bound valid on the whole first segment.
    b = seg.coefficients[1]
    speed_lower = abs(b[1]) - 2 * abs(b[2]) - 3 * abs(b[3])
    assert speed_lower > c.policy.min_speed
    assert projected_variation(seg.coefficients, v.t) - target > 1e-6
    totals = {str(n): math.fsum(independent_arc(a, order=n) for a in c.coefficients)
              for n in (64, 128, 256)}
    return {'knots': PERIODIC_POINTS, 'q': list(range(9)),
            'accepted_periodic_curve_length_m': c.length,
            'independent_gaussian_lap_m': totals,
            'first_segment_coefficients': seg.coefficients,
            'first_segment_arc_budget_m': seg.policy.arc_abs,
            'first_segment_reported_length_m': seg.length,
            'first_segment_reported_error_m': seg.arc_error,
            'first_segment_speed_lower_bound': speed_lower,
            'first_segment_proven_length_undercount_m': bound - seg.length,
            'sample_s_m': target, 'returned_sample': vars(v),
            'sample_proven_true_station_error_m': projected_variation(seg.coefficients, v.t) - target,
            'verdict': 'DEMONSTRATED: defect is reachable through accepted periodic Curve.sample.'}


def endpoint_probes():
    theta = np.linspace(0, 2 * np.pi, 64, endpoint=False)
    circle = Curve.interpolate(np.c_[6 * np.cos(theta), 6 * np.sin(theta)])
    s = -1e-20
    wrapped = circle.wrap(s)
    try:
        actual = {'sample': vars(circle.sample(s))}
    except GeometryError as exc:
        actual = {'exception': type(exc).__name__, 'message': str(exc)}
    assert wrapped == circle.length and 'exception' in actual
    theta = np.linspace(0, 2 * np.pi, 5, endpoint=False)
    c = Curve.interpolate(np.c_[6 * np.cos(theta), 4 * np.sin(theta)],
                          owners=[('o' + str(i), 's' + str(i)) for i in range(5)])
    station = c.station(2, 1.)
    v = c.sample(station)
    assert v.occurrence_id == 'o2' and station < c.cumulative[3]
    nextafter_failures = []
    for i, knot in enumerate(c.cumulative[1:]):
        for value in (np.nextafter(knot, -np.inf), knot, np.nextafter(knot, np.inf)):
            try:
                c.sample(float(value))
            except GeometryError as exc:
                nextafter_failures.append([i, float(value), str(exc)])
    return {'negative_seam_query': {'input_s_m': s, 'length_m': circle.length,
                                    'wrapped_s_m': wrapped, 'actual': actual,
                                    'expected': 'A defined periodic sample with 0 <= wrapped s < L.'},
            'endpoint_anchor': {'input_anchor': [2, 1.], 'computed_station_m': station,
                                'canonical_next_knot_m': c.cumulative[3],
                                'actual_owner': v.occurrence_id, 'actual_locate': c.locate(station),
                                'expected_owner_by_right_hand_contract': 'o3'},
            'nextafter_tests': 15, 'nextafter_failures': nextafter_failures,
            'verdict': 'DEMONSTRATED: endpoint floating-point normalization is inconsistent.'}


def metamorphic():
    # Invariant: rigid rotation/translation preserves metric length and ownership;
    # reversal preserves length and negates curvature at corresponding knots;
    # cyclic-origin shift preserves the same curve geometry at corresponding knots.
    n = 35
    theta = 2 * np.pi * (np.arange(n) / n) ** 1.3
    points = np.c_[6 * np.cos(theta), 3 * np.sin(theta)]
    c = Curve.interpolate(points)
    angle = .713
    rotation = np.array([[math.cos(angle), -math.sin(angle)],
                         [math.sin(angle), math.cos(angle)]])
    shift = np.array([71.3, -93.8])
    transformed = Curve.interpolate(points @ rotation.T + shift)
    reversed_curve = Curve.interpolate(points[::-1])
    rolled = Curve.interpolate(np.roll(points, -7, axis=0))
    xy_error = 0.
    curvature_error = 0.
    reversal_error = 0.
    origin_error = 0.
    for i in range(n):
        a = c.sample(c.cumulative[i])
        b = transformed.sample(transformed.cumulative[i])
        r = reversed_curve.sample(reversed_curve.cumulative[n - 1 - i])
        z = rolled.sample(rolled.cumulative[(i - 7) % n])
        xy_error = max(xy_error, math.dist(np.array(a.xy) @ rotation.T + shift, b.xy))
        curvature_error = max(curvature_error, abs(a.curvature - b.curvature))
        reversal_error = max(reversal_error, abs(a.curvature + r.curvature))
        origin_error = max(origin_error, math.dist(a.xy, z.xy))
    assert xy_error < 1e-10 and curvature_error < 1e-10
    assert reversal_error < 1e-10 and origin_error < 1e-10
    assert max(abs(x.length - c.length) for x in (transformed, reversed_curve, rolled)) < 1e-10
    return {'knot_count': n, 'rotation_radians': angle, 'translation_m': shift.tolist(),
            'length_m': c.length,
            'max_transformed_xy_error_m': xy_error,
            'max_rotation_curvature_error_per_m': curvature_error,
            'max_reversal_curvature_sign_error_per_m': reversal_error,
            'max_cyclic_origin_xy_error_m': origin_error,
            'max_length_difference_m': max(abs(x.length - c.length)
                                           for x in (transformed, reversed_curve, rolled)),
            'verdict': 'PASS for the stated finite synthetic metamorphic coverage.'}


def bounded_station_stress():
    # Fixed seed, varying nonuniform segment lengths and right/left knot queries.
    rng = np.random.default_rng(1631)
    total_queries = 0
    rejected_curves = []
    failures = []
    endpoint_owner_failures = 0
    max_anchor_discrepancy = 0.
    for trial in range(100):
        n = int(rng.integers(4, 200))
        theta = np.r_[0, np.cumsum(rng.uniform(.01, 1, size=n - 1))]
        theta *= 2 * np.pi / (theta[-1] + rng.uniform(.01, 1))
        try:
            c = Curve.interpolate(np.c_[6 * np.cos(theta), 4 * np.sin(theta)],
                                  q=np.r_[theta, 2 * np.pi])
        except GeometryError as exc:
            rejected_curves.append([trial, str(exc)])
            continue
        for i, s in enumerate(c.cumulative[1:]):
            anchor = c.station(i, 1.)
            max_anchor_discrepancy = max(max_anchor_discrepancy, abs(anchor - s))
            if c.locate(anchor)[0] != (i + 1) % n:
                endpoint_owner_failures += 1
            for value in (np.nextafter(s, -np.inf), anchor,
                          np.nextafter(anchor, -np.inf), np.nextafter(anchor, np.inf)):
                total_queries += 1
                try:
                    c.sample(float(value))
                except GeometryError as exc:
                    failures.append([trial, i, float(value), str(exc)])
    return {'seed': 1631, 'trials': 100, 'queries': total_queries,
            'rejected_curves': rejected_curves, 'query_failures': failures,
            'endpoint_half_open_segment_mismatches': endpoint_owner_failures,
            'max_station_endpoint_vs_cumulative_discrepancy_m': max_anchor_discrepancy}


def fail_closed_budgets():
    cases = [
        ('zero_derivative', ((0, -.5, .5, 0), (0, 0, 0, 0)), NumericPolicy()),
        ('integration_budget', ((0, 1, 0, 0), (0, 0, 20, 0)), NumericPolicy(quad_limit=1)),
        ('regularity_budget', ((0, 1, -1, 0), (0, 1.2, -2, 4 / 3)),
         NumericPolicy(regularity_budget=1, regularity_depth=1)),
        ('short_segment', ((0, 1e-9, 0, 0), (0, 0, 0, 0)), NumericPolicy()),
    ]
    result = {}
    for name, coeff, policy in cases:
        try:
            CubicSegment(coeff, policy)
            result[name] = 'UNEXPECTED ACCEPT'
        except GeometryError as exc:
            result[name] = str(exc)
    assert not any(v == 'UNEXPECTED ACCEPT' for v in result.values())
    return result


def main():
    results = {'reviewed_sha': '133a96fd6653e4d3b16d71c38e1c70fc38585101',
               'python': platform.python_version(), 'numpy': np.__version__,
               'scipy': scipy.__version__,
               'parabola': parabola(), 'hidden_pocket': hidden_pocket(),
               'monotone_near_stationary': monotone_near_stationary(),
               'periodic_pocket': periodic_pocket(), 'endpoint_probes': endpoint_probes(),
               'metamorphic': metamorphic(), 'station_stress': bounded_station_stress(),
               'fail_closed_budgets': fail_closed_budgets()}
    destination = Path('/workspace/work/w1-review/evidence/a02_adversarial.json')
    destination.write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps(results, indent=2))


if __name__ == '__main__':
    main()
