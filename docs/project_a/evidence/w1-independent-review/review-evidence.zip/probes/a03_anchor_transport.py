import sys,json,math
import numpy as np
sys.path.insert(0, '/workspace/work/w1-review/source/planner/global_planner')
from global_planner.route_input import load_route,validate_route
from global_planner.route_corridor import seed_curve,_sample,OrderedCurve,prepare_route,resample_ordered
from global_planner.route_reference import Curve
r=load_route('/workspace/work/w1-review/source/planner/global_planner/test/fixtures/project_a/s0_route.json')
base=seed_curve(r); raw=r.payload
for o in raw['occurrences']:
    o['left']=[[x*.01/5.3,y*.01/5.3] for x,y in o['left']]
for i,tr in enumerate(raw['transitions']):
    tr['gate'][1]=raw['occurrences'][i]['left'][-1]
    tr['support']=[[-100,-100],[100,-100],[100,100],[-100,100]]
r=validate_route(raw)
small=OrderedCurve(r,Curve(np.asarray(base.curve.coefficients)/60,base.curve.owners),base.q)
worst=[]
for q in np.linspace(.01,r.occurrences[0].length-.01,501):
    v=_sample(small,small.station_at_q(q))
    worst.append((abs(v.q-q),v.q-q,float(q)))
worst.sort(reverse=True)
print('WORST',worst[:10])
err,d,q=next(v for v in worst if v[1] < -1e-9)
# A cap anchor must be preserved and assigned its right-hand value.
raw['occurrences'][0]['caps'].append({'at_m':q,'max_speed_mps':1})
r=validate_route(raw); small=OrderedCurve(r,small.curve,small.q)
prepared=prepare_route(r,spacing=.02,ordered=small)
v=min(prepared.samples,key=lambda v:abs(v.q-q))
print(json.dumps({'route_digest':r.digest,'original_q_anchor':q,'observed_q':v.q,'q_error':v.q-q,
 'expected_right_hand_cap':1,'observed_cap':v.cap_mps,'samples':len(prepared.samples),'curve_length':small.curve.length},indent=2))
