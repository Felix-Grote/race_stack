import sys,json,math
from pathlib import Path
sys.path.insert(0, '/workspace/work/w1-review/source/planner/global_planner')
from global_planner.route_input import load_route,validate_route
from global_planner.route_corridor import seed_curve,_sample,normal_interval,prepare_route
from global_planner._route_geometry import inside,line_intervals
P=Path('/workspace/work/w1-review/source/planner/global_planner/test/fixtures/project_a/s0_route.json')
r=load_route(P); o=seed_curve(r)
q=sum(math.dist(a,b) for a,b in zip(r.occurrences[0].seed[:16],r.occurrences[0].seed[1:17]))
v=_sample(o,o.station_at_q(q)); n=(-v.tangent[1],v.tangent[0]); tip=[v.xy[k]+.2*n[k] for k in (0,1)]
payload=r.payload
# notch belongs to left chain; geometry/seed/portals and curve remain otherwise unchanged.
payload['occurrences'][0]['left'].insert(19,tip)
payload['route_id']='tangent-notch-adversarial'
r2=validate_route(payload); o2=seed_curve(r2); v2=_sample(o2,o2.station_at_q(q)); c=normal_interval(o2,v2)
raw=line_intervals(v2.xy,n,r2.occurrences[0].polygon)
print(json.dumps({'query_q':q,'query_xy':v2.xy,'tangent':v2.tangent,'notch_tip':tip,
 'raw_intervals':raw,'returned_width_left':c.left,'returned_width_right':c.right,
 'tip_in_interior':inside(tip,r2.occurrences[0].polygon,False),
 'support_occurrences':c.support_occurrences,'portal_id':c.portal_id,
 'legal_route_digest':r2.digest},indent=2))
Path('/workspace/work/w1-review/evidence/a03_tangent_public_route.json').write_text(json.dumps(payload,indent=2))
