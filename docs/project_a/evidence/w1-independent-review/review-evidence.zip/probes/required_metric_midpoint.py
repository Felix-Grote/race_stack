"""Reproduce the architecture's 0.16557464 m midpoint defect analytically."""
import json
import math
import sys
sys.path.insert(0, '/workspace/work/w1-review/source/planner/global_planner')
from global_planner.route_reference import CubicSegment

def exact(t):
    return .5*t*math.sqrt(1+4*t*t)+.25*math.asinh(2*t)

segment = CubicSegment(((0,1,0,0),(0,0,1,0)))
target = exact(1)/2
t = segment.parameter(target)
print(json.dumps({'analytic_length_m':exact(1), 'target_station_m':target,
                  'nominal_t':.5, 'nominal_true_station_m':exact(.5),
                  'old_midpoint_station_error_m':target-exact(.5),
                  'w1_t':t, 'w1_true_station_m':exact(t),
                  'w1_inverse_residual_m':exact(t)-target,
                  'coefficient_segments':1, 'resampling_used':False},indent=2))
assert abs(exact(t)-target) < 1e-8
