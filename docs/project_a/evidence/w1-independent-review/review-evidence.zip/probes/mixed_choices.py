"""Two separately selected visits to a split/remerge, retaining occurrence identity."""
import copy
import itertools
import json
from pathlib import Path
import sys
sys.path.insert(0, '/workspace/work/w1-review/source/planner/global_planner')
from global_planner.route_input import load_route, validate_route, RouteError
from global_planner.route_corridor import prepare_route

fix=Path('/workspace/work/w1-review/source/planner/global_planner/test/fixtures/project_a')
rows=[]
for choices in itertools.product(('upper','lower'),repeat=2):
    legs=[load_route(fix/('s2_'+c+'_route.json')).payload for c in choices]
    result=copy.deepcopy(legs[0]); result['route_id']='two-selected-split-visits-'+'-'.join(choices)
    result['occurrences']=[];result['transitions']=[]
    for i,p in enumerate(legs):
        prefix=str(i)+'-'
        for o in p['occurrences']:
            o['id']=prefix+o['id']
        for t in p['transitions']:
            t['id']=prefix+t['id'];t['from']=prefix+t['from'];t['to']=prefix+t['to']
        p['transitions'][-1]['to']=str((i+1)%2)+'-o0'
        result['occurrences']+=p['occurrences'];result['transitions']+=p['transitions']
    result['gate_sequence']=[t['id'] for t in result['transitions']]
    result['finish']=result['gate_sequence'][-1]
    result['initialization']['occurrence_id']='0-o0'
    r=validate_route(result);prepared=prepare_route(r,spacing=.5)
    assert len(prepared.gates)==8
    assert {c.occurrence_id for c in prepared.corridors}=={o.id for o in r.occurrences}
    bad=copy.deepcopy(result);bad['transitions'][0]['to']='1-o1'
    try:validate_route(bad)
    except RouteError: rejection=True
    else:raise AssertionError('illegal visit switching accepted')
    rows.append({'choices':choices,'occurrences':len(r.occurrences),'gates':len(prepared.gates),
                 'samples':len(prepared.samples),'illegal_visit_switch_rejected':rejection,'digest':r.digest})
print(json.dumps({'invariant':'Each visit has independently selected alternatives and distinct occurrence IDs even along coincident return geometry.','results':rows},indent=2))
