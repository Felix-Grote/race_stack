import sys,json,math
import numpy as np
from pathlib import Path
sys.path.insert(0, '/workspace/work/w1-review/source/planner/global_planner')
from global_planner.route_input import load_route,validate_route
from global_planner.route_corridor import seed_curve,_sample,OrderedCurve,prepare_route
from global_planner.route_reference import Curve
r=load_route('/workspace/work/w1-review/source/planner/global_planner/test/fixtures/project_a/s0_route.json'); base=seed_curve(r)
points=[]
for i,q in enumerate(base.q[:-1]):
    a=np.arctan2(*base.curve.segments[i].evaluate(0)[::-1])
    if i<32:
        t=q/r.occurrences[0].length
        a=(math.pi/2)*(t+.99/(2*math.pi)*math.sin(2*math.pi*t))
    points.append((6*math.cos(a),6*math.sin(a)))
curve=Curve.interpolate(points,base.q,base.curve.owners)
ordered=OrderedCurve(r,curve,base.q)
worst=[]
for q in np.linspace(.01,r.occurrences[0].length-.01,1001):
    v=_sample(ordered,ordered.station_at_q(q)); worst.append((abs(v.q-q),v.q-q,float(q)))
worst.sort(reverse=True); print('WORST',worst[:10])
err,d,q=next(v for v in worst if v[1]<-1e-9)
raw=r.payload;raw['occurrences'][0]['caps'].append({'at_m':q,'max_speed_mps':1})
r=validate_route(raw);ordered=OrderedCurve(r,curve,base.q)
p=prepare_route(r,spacing=.25,ordered=ordered)
v=min(p.samples,key=lambda v:abs(v.q-q))
print(json.dumps({'cap_q':q,'returned_q':v.q,'error':v.q-q,'cap':v.cap_mps,'samples':len(p.samples),'metric_L':curve.length,'anchor_station':ordered.station_at_q(q),'returned_station_residual_m':curve.station(v.segment,v.t)-ordered.station_at_q(q),'station_abs_m':curve.policy.station_abs,'q_classification_epsilon_m':1e-9,'dense_max_radius_error_m':max(abs(math.hypot(*seg.evaluate(t))-6) for seg in curve.segments for t in np.linspace(0,1,65))},indent=2))
Path('/workspace/work/w1-review/evidence/a03_anchor_legal_reparam_route.json').write_text(json.dumps(raw,indent=2))
Path('/workspace/work/w1-review/evidence/a03_anchor_legal_reparam_points.json').write_text(json.dumps(points))
