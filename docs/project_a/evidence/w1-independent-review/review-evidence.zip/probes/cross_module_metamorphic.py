"""Independent rigid-motion invariance across A01/A02/A03, no source writes."""
import copy
import json
import math
from pathlib import Path
import sys

SOURCE = Path('/workspace/work/w1-review/source')
sys.path.insert(0, str(SOURCE / 'planner/global_planner'))
from global_planner.route_input import load_route, validate_route
from global_planner.route_corridor import seed_curve, _sample, normal_interval

def transform(payload, angle, delta):
    p = copy.deepcopy(payload)
    ca, sa = math.cos(angle), math.sin(angle)
    def point(v):
        return [ca*v[0]-sa*v[1]+delta[0], sa*v[0]+ca*v[1]+delta[1]]
    for o in p['occurrences']:
        for k in ('seed', 'left', 'right'):
            o[k] = [point(v) for v in o[k]]
    for t in p['transitions']:
        for k in ('gate', 'support'):
            t[k] = [point(v) for v in t[k]]
    p['initialization']['zone'] = [point(v) for v in p['initialization']['zone']]
    return p, point

rows = []
for name in ('s0_route', 's2_upper_route', 's2_lower_route', 's3_surfaces_route', 's3_notch_route'):
    r = load_route(SOURCE / 'planner/global_planner/test/fixtures/project_a' / (name+'.json'))
    base = seed_curve(r)
    for angle, delta in ((.713, (0,0)), (.713,(99980,99980)), (math.pi/2,(500,-730))):
        raw, point = transform(r.payload, angle, delta)
        moved = seed_curve(validate_route(raw))
        row = {'fixture':name, 'angle_rad':angle, 'translation_m':delta,
               'length_error_m':abs(base.curve.length-moved.curve.length),
               'queries':0, 'max_xy_error_m':0., 'max_width_error_m':0.,
               'max_curvature_error_per_m':0., 'owners_preserved':True}
        for fraction in (.037,.173,.319,.437,.571,.683,.819,.937):
            a = _sample(base, fraction*base.curve.length)
            b = _sample(moved, fraction*moved.curve.length)
            ca, cb = normal_interval(base,a), normal_interval(moved,b)
            row['queries'] += 1
            row['max_xy_error_m'] = max(row['max_xy_error_m'], math.dist(point(a.xy), b.xy))
            row['max_width_error_m'] = max(row['max_width_error_m'],abs(ca.left-cb.left),abs(ca.right-cb.right))
            row['max_curvature_error_per_m'] = max(row['max_curvature_error_per_m'],abs(a.curvature-b.curvature))
            row['owners_preserved'] &= (a.occurrence_id,a.surface_id,ca.support_occurrences,ca.portal_id)==(b.occurrence_id,b.surface_id,cb.support_occurrences,cb.portal_id)
        assert row['length_error_m'] < 1e-8, row
        assert row['max_xy_error_m'] < 1e-8, row
        assert row['max_width_error_m'] < 2e-9, row
        assert row['max_curvature_error_per_m'] < 1e-8, row
        assert row['owners_preserved'], row
        rows.append(row)
print(json.dumps({'invariant':'Rigid motions preserve metric length, signed widths, curvature and topological owner; XY transforms covariantly.', 'results':rows},indent=2))
