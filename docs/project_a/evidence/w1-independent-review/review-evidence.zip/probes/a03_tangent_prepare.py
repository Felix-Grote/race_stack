exec(open('/workspace/work/w1-review/probes/a03_tangent_public.py').read())
payload['occurrences'][0]['caps'].append({'at_m':q,'max_speed_mps':4})
r3=validate_route(payload)
prepared=prepare_route(r3,spacing=.4)
hits=[(v.q,c.left,c.right,c.occurrence_id) for v,c in zip(prepared.samples,prepared.corridors) if abs(v.q-q)<1e-8]
print('PREPARE_ACCEPTED',len(prepared.samples),'EXACT_NOTCH_QUERY_CORRIDOR',hits)
Path('/workspace/work/w1-review/evidence/a03_tangent_prepare_route.json').write_text(json.dumps(payload,indent=2))
