# Independent A01 audit fragment

Source: immutable archive `/workspace/work/w1-review/source`, parent-discovered W1 SHA `133a96fd6653e4d3b16d71c38e1c70fc38585101`.

## Demonstrated finding: dimensionally inconsistent directed-gate threshold (P2)

**Location:** `planner/global_planner/global_planner/route_input.py:217–218`.

**Violated contract:** A01 accepts directed travel-ordered legal ribbons and gates under a 1e-9 metre geometric policy. Inserting collinear points into a seed polyline preserves its geometry, direction, ownership, route connectivity and gate passage. That transformation should not turn an unambiguously forward gate into a reversed one when every new segment remains well above the distance tolerance.

**Minimal reproduction:** `probes/a01_gate_scale.py`; complete rejected manifest is `evidence/a01_gate_scale_input.json`. The script loads the fixed S0 fixture, changes its two circular borders to radii `6 ± 0.00005` m, updates gates to the new shared end caps, and validates successfully. It then inserts a point 1e-6 m before p0 and a point 1e-6 m after p0, each collinear with the existing seed segment. No geometry is moved or removed. Calling `validate_route` again raises `RouteError: wrong directed gate`.

Executed command:

```bash
PYTHONPATH=/workspace/work/w1-review/source/planner/global_planner /workspace/race_stack_setup/venv/bin/python /workspace/work/w1-review/probes/a01_gate_scale.py > /workspace/work/w1-review/evidence/a01_gate_scale.json
```

Observed measurements:

- Before subdivision: accepted.
- After subdivision: `RouteError: wrong directed gate`.
- Gate length: `9.999999999799059e-05 m`.
- Travel chord length: `1.999397637392408e-06 m`.
- `cross(gate, travel)`: `-1.9993976373522318e-10 m²`.
- Normalized cross: `-1.0`, so the direction is exactly perpendicular and forward.
- Original occurrence seed-polyline length change: `0.0 m`.

Expected: acceptance of the same legal directed polyline, subject to downstream A02/A03 numerical/chart validation.

Root cause: the code compares a cross product with units m² directly against `-EPS`, documented as metres. The sign check therefore depends on gate width and adjacent sampling distances. It conflates a small product of two well-resolved lengths with ambiguous travel direction.

Minimal correction: use a dimensionally consistent signed-distance or normalized-direction predicate (for example divide cross by gate length before applying a metre ambiguity allowance), with separately checked nondegenerate vectors. Do not loosen EPS globally.

Regression: validate this route before and after collinear subdivision around p0; assert both load, retain the same directed occurrence/portal relationships and seed lengths. Include common rigid transforms and reversed gates. This is a bounded false rejection, not a false ownership acceptance or vehicle-feasibility claim. Its synthetic corridor width is 0.1 mm and no physical vehicle claim is made; classify P2 or explicitly track the supported-scale limitation.

## Other A01 conclusions

The validator enforces a selected cyclic list, unique NFC-normalized occurrence and surface IDs, explicit consecutive directed portals including the seam, common end-cap endpoints, coincident seed endpoints, ordered gate/finish IDs, simple ribbon/support/initialization polygons, travel-side winding, nondegenerate seed edges, local caps and required references. It rejects unknown fields, including holes rather than filling them. It does not infer adjacency from XY coincidence. Seed segments cannot touch legal sides, leave a concavity, or revisit an ownership cap outside the first/last permitted segment.

`load_route` rejects duplicate JSON keys before normalization. `_normalize` rejects booleans, null, nonfinite/overflow numbers and normalized key collisions; finite binary64/integral/-0 and NFC normalization are explicit. `validate_route` returns frozen records containing tuples of frozen records/tuples/bytes; its caller-owned arrays are copied and `payload` returns a new decoded tree. No mutation, cache, ROS dependency or unordered geometry traversal was found on the supported loader path. Physical-map coverage/provenance remains separate from legal geometry and affects identity without changing widths/regions.

Provenance uses required nonempty author/source/revision/approval strings. There is no machine-readable approved/rejected policy enum or authenticity proof. The architecture explicitly calls approval a human assertion and forbids upgrading synthetic annotations to physical evidence, so arbitrary approval text alone is not a demonstrated authentication defect. Semantic initialization applicability on the final curve is explicitly deferred, while its field shapes, occurrence ID and bounded intervals are validated now.

The public `Route(occurrences, portals, encoded)` constructor has no `__post_init__` invariant; `dataclasses.replace` can create a new object whose geometry/caps disagree with encoded identity, or callers can directly pass mutable containers. This is a real API trust-boundary caution/coverage gap. It is not evidence that outputs of `validate_route` mutate or that supported route loading accepts wrong ownership. A04 should retain the validated original Route and use `refit_ordered` for candidates. If direct construction/replacement is intended to be supported, add consistency checks or make the factory-only boundary explicit; do not classify intentional bypass of the loader as P0.

## Independent experiments and failed falsification attempts

All files were written in scratch; no implementation source changed. The initial host numerical venv was Python/NumPy 1.26.4/SciPy 1.12.0, which is not claimed as pinned Humble evidence. Parent suites agent is independently rerunning these pure-Python probes inside the pinned environment.

Command:

```bash
PYTHONPATH=/workspace/work/w1-review/source/planner/global_planner /workspace/race_stack_setup/venv/bin/python /workspace/work/w1-review/probes/a01_adversarial.py > /workspace/work/w1-review/evidence/a01_adversarial.json
```

Results:

- 12 rigid transforms: angles 0, .17, pi/2, -pi+.013; translations (0,0), (1000,-730), (99980,99980). Invariant: route/portal/surface identities and connectivity persist; occurrence seed metric is unchanged. Maximum length difference `2.915001573455811e-12 m`, acceptance threshold `1e-8 m`.
- Recursive dictionary key reversal preserves digest; validation does not modify caller arrays and later caller mutation cannot modify the route.
- 15 independent malformed-manifest cases reject with RouteError: NFC-colliding occurrence IDs; boolean route/surface/transition IDs; overflow registration; infinite coordinate; missing closing portal; illegal nonconsecutive switch; reversed closing gate; duplicated gate sequence; unknown surface; hole field; extra contradictory metadata flag; crossed boundary; zero seed edge.
- Six duplicate-key/NFC-collision/nonfinite JSON cases reject.
- Physical coverage change complete → partial changes digest but leaves exact occurrence/portal tuples unchanged.
- Fixed seed 20261016: 4,000 random 8-vertex integer-grid polygons; exact integer orientation oracle identifies 3,902 with proper nonadjacent crossings. All rejected, including copies translated by (90000,90000).
- Same generator: 10,000 random integer segments; all 2,329 proper crossings detected by segments_touch.

Near-parallel suspicion was investigated and **not substantiated**. `segments_touch` switches to endpoint proximity below `EPS*(len(v)+len(w))`. This looked risky but a proper intersection in that range brings at least an appropriate endpoint within the metre allowance for these probes. A second fixed-seed Fraction oracle tests the exact binary64 coordinates rather than recomputed floating-point orientation:

```bash
PYTHONPATH=/workspace/work/w1-review/source/planner/global_planner /workspace/race_stack_setup/venv/bin/python /workspace/work/w1-review/probes/a01_neardegenerate.py > /workspace/work/w1-review/evidence/a01_neardegenerate.json
```

Seed 2026101601, 20,000 generated crossing candidates, segment lengths 1e-7–1e4 m, relative angles 1e-14–1 rad, centers at (0 or 80000, 0 or -80000). Fraction.from_float exact orientation identifies 15,917 proper crossings. None missed. This is bounded evidence, not a proof of all polygon-predicate error bounds; do not report the original suspicion as a defect.

## Remaining verification gaps

Existing tests and these bounded probes do not prove a formal robust-predicate guarantee for every binary64 annotation. The directed-gate scale/subdivision invariant above was absent from existing tests and demonstrably fails. Public direct record construction consistency is untested; normal loader immutability is established. Provenance authentication and initialization validity on a final optimized curve are outside A01's current guarantees. Continuous spline/footprint containment is A05, not an A01 acceptance requirement.
