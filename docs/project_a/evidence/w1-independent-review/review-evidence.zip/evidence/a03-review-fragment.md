# Independent A03 review fragment

Reviewed immutable source snapshot `133a96fd6653e4d3b16d71c38e1c70fc38585101`. No implementation files edited. Probes run with `/workspace/race_stack_setup/venv/bin/python`; independent pinned Humble replays are coordinated with the suite agent. The source snapshot is an exported tree, not a Git checkout (`git status --short` there returns exit 128); source/CI identity is handled separately.

## Verified P1: tangent legal-side contact is silently joined into a larger normal corridor

**Source:** `planner/global_planner/global_planner/route_corridor.py:160–174,181–202,253`; `planner/global_planner/global_planner/_route_geometry.py:84–109`.

**Contract:** A03 must use the connected original-owned legal interior interval containing the reference, fail closed on ambiguous/tangent normal geometry, and never bridge disjoint normal intervals or inflate widths. This is a defect at a sampled normal, independent of A05 between-sample or swept-footprint certification.

**Small geometric reproduction:** horizontal reference at `(5,0)`, tangent `(1,0)`, right chain `[(0,-1),(10,-1)]`, left chain `[(0,2),(10,2),(10,1),(5,.75),(10,.5),(10,.1)]`. This is a simple polygon; the normal touches an inward triangular notch tip at offset `.75`. `line_intervals` correctly returns open interior components `[(-1,.75),(.75,2)]`; `_normal_geometry` returns `(-.999999999,1.999999999)` and thus spans the forbidden non-interior contact at `.75`. Full `.75` contact is exact; this principal example does not claim a finite-width illegal strip.

**Full public reproduction:** start with the checked-in S0 route, form its original spline, and query original seed progress `q=4.711915876399159`. Its XY is `(4.242640687119286,4.242640687119285)` and tangent `(-.7071067811865476,.7071067811865475)`. Insert `xy+.2*left_normal = (4.101219330881976,4.1012193308819755)` at index 19 of `occurrences[0].left`. The normal touches that notch tip at `.2`. Add a cap at that same q solely to force an exact prepared sample. `validate_route` accepts; `prepare_route(...,spacing=.4)` accepts 107 samples. At that exact sample `normal_interval` returns left width `.6999999989999999`, right `.8999999990000003`, owner `o0`, no portal, support owners `('o0',)`, although original open-interior intervals are `(-.9000000000000002,.19999999999999957)` and `(.19999999999999957,.6999999999999998)` and the tip fails `inside(...,boundary=False)`.

**Commands:**
```
/workspace/race_stack_setup/venv/bin/python /workspace/work/w1-review/probes/a03_tangent_notch.py
/workspace/race_stack_setup/venv/bin/python /workspace/work/w1-review/probes/a03_tangent_public.py
/workspace/race_stack_setup/venv/bin/python /workspace/work/w1-review/probes/a03_tangent_prepare.py
/workspace/race_stack_setup/venv/bin/python /workspace/work/w1-review/probes/a03_geometry_metamorphic.py
```
All exit 0 and demonstrate acceptance. Outputs are `a03_tangent_notch.txt`, `a03_tangent_public.txt`, `a03_tangent_prepare.txt`, `a03_geometry_metamorphic.txt`; full fixtures are `a03_tangent_public_route.json` and `a03_tangent_prepare_route.json` in this evidence directory. Humble versions use `_humble.log` names.

**Root:** `_merge` merges sorted *open* components when `a <= previous_hi`, erasing a legal-side boundary cut. `line_intervals` also deduplicates cuts separated by at most EPS, so near-tangent small gaps become the same touching-interval case. The inward allowance is only applied to outer returned endpoints; it cannot remove an interior boundary contact. `_component` consequently sees one interval containing zero. Correct ownership tags do not prevent this local geometry error.

**Expected:** reject the ambiguous/tangent normal, or conservatively retain the zero-containing component with its upper limit below `.2` (full route) / `.75` (minimal strip), with a numerical inward allowance. Do not merge across that original legal side. A direct `<=` to `<` replacement should be assessed carefully because explicit portal/shared-endcap connectivity can legitimately join adjacent owned interiors; preserve contact provenance or explicitly reject non-gate tangent contacts before union.

**Metamorphic evidence:** rotations `{0,.37,1.1,2.9}` radians and translations `{(0,0),(10000,-20000)}` preserve the bad full-width result to approximately `2e-12m`, so the failure is not a special axis/origin artifact. A finite notch perturbation of `dx=-1e-6` produces a real gap of approximately `1e-7m` and is correctly restricted to `.749999949m`; `dx=0` alone jumps to `1.999999999m`. Near-degenerate perturbations `dx=-5e-9` and `-1e-9` have positive exact geometric gaps of approximately `5e-10m` / `1e-10m` but cut deduplication merges them; these are below the declared EPS and should be considered uncertainty/fail-closed stress, not a separate large-clearance physical defect.

**Regression:** run the full public fixture through `prepare_route`, force the contact point into prepared samples, and require rejection or width below `.2`. Repeat rigid transforms and both positive/negative apex perturbations. Include portal control cases so authorized shared-endcap unions remain valid.

## Verified P2: semantic cap anchors are reconstructed through inverse tolerance and can receive the upstream cap

**Source:** `route_corridor.py:63–71,105–114,125–142`; contrast reference inversion tolerance/check in `route_reference.py:137–154`.

**Contract:** A03 promises exact inherited cap/occurrence/portal anchors through metric resampling, with right-hand caps. Numerical inversion within its advertised physical tolerance must not change the identity/value of an exact semantic event.

**Reproduction:** unchanged S0 geometry/ownership; make a candidate curve from radius-six circle knots with first-occurrence angular parameters `theta=(pi/2)*(t+.99*sin(2*pi*t)/(2*pi))`, `t=q/o0.length`, preserving knot order/endpoints, route ownership and every occurrence anchor. Use the ordinary periodic cubic interpolation and `OrderedCurve` constructors. Add a right-hand cap of `1m/s` at `q=4.805954193927142` after the initial `4m/s` cap. `prepare_route(route,spacing=.25,ordered=candidate)` accepts 163 samples. Its sample generated for the cap event has q `4.80595419066715` (error `-3.2599913879494125e-9m`) and reports cap **4**, while the declared right-hand event cap is **1**. The metric station inversion residual is only `-3.895372913120809e-11m`, safely inside `station_abs=1e-8m`; this is an A03 semantic transport mismatch, not an A02 tolerance violation. Dense independent cubic evaluations show the maximum radius departure is `.002083367m`, well within the original `.7/.9m` ribbon; the normal preparation itself accepts.

**Command:**
```
/workspace/race_stack_setup/venv/bin/python /workspace/work/w1-review/probes/a03_anchor_legal_reparam.py
```
Exit 0. Output `a03_anchor_legal_reparam.txt`; full route fixture and candidate point list saved as `a03_anchor_legal_reparam_route.json` and `a03_anchor_legal_reparam_points.json`.

**Root:** resampling knows exact semantic q, converts it into a station, then `_sample` inverts that station and recomputes q with a different error budget. Cap selection applies a fixed `+EPS=1e-9m` in q, which is insufficient to absorb the permitted inverse transport error. The preserved station is not an exactly preserved event. This can give a discrete downstream consumer the wrong cap value at a forced splitting event. Exposure is bounded in q in this reproduction, and A04 refits that keep cap anchors as knots reduce common-path exposure; hence P2 rather than a claim of a demonstrated finite-length speeding trajectory.

**Fix:** carry exact known event q/segment/t and event identity into semantic anchor samples and validate these consistently with `normal_interval`'s sample-integrity check. Avoid merely increasing EPS or globally tightening A02 tolerances. Regular uniform samples can continue to use metric inverse transport.

**Regression:** monotone nonuniform parameter warp with slow positive derivative near a cap; assert the exact event's lineage and right-hand cap survive `resample_ordered`, repeated refit/resample and multiple spacing choices. Check both negative and positive inverse rounding errors, and place an occurrence/portal control nearby.

## Positive source assessment and remaining verification gaps

A03 consults only the q-selected original occurrence or two explicitly adjacent portal-support occurrences; it contains no nearest-XY association. Inherited q is monotone and original occurrence knots are required, while strict `normal_interval` sample equality rejects forged source/owner tags. Asymmetric crossing and repeated identical-XY route tests do exercise this policy. TUM right-positive normals and widths are consistent with left-positive geometric offsets. Legal widths ignore physical-wall coverage, no min-width inflation appears, and numeric/pair/sample budgets reject explicitly. Modules are ROS independent.

The tangent defect does not demonstrate wrong-surface reassociation. Sampled normal charts/curvature Jacobians and pair checks do not establish continuous spline containment or swept footprint legality; A05 remains legitimately required. Existing tests omit tangent side-vertex split intervals, sub-EPS contact uncertainty, slow-q semantic-anchor transport, and explicit adjacent sample normal-intersection tests. Do not convert those unexecuted gaps into alleged verified defects.
