# Source identity, full diff, integration and CI review fragment

This fragment is read-only evidence for the independent W1 review. It is not a mathematical acceptance verdict.

## Source and exact review target

GitHub PR [#1](https://github.com/Felix-Grote/race_stack/pull/1) is draft/open, title "Project A W1: strict legal-route geometry (A01–A03)", head branch `project-a/w1-geometry`, head SHA `133a96fd6653e4d3b16d71c38e1c70fc38585101`. Its base `project-a/w0-cloud-foundation` resolves to `6370d0436aabd011d1b885fe1f500644b957b536`, which is also the merge base; compare is ahead 6, behind 0. No remote or tracked source mutation was performed.

W1 linear commit history, oldest first:

1. `6dc2b38dd7862ed81410f474161c53dc68ab2c77` — feat(project-a): validate strict directed legal-route input (A01)
2. `cd6749d88139222bd6d4016bee5bb160feb19405` — test(project-a): enforce clean A01 source style and refresh evidence
3. `61c320e0b5551dc983d5b866460900a3f8428de2` — feat(project-a): add periodic true-arclength reference kernel (A02)
4. `f4048adac1471c4db03616d5292f06aa83f78a13` — feat(project-a): prepare occurrence-owned legal corridors (A03)
5. `129c28100cd060d155cafb4a1a4e0469e0855cae` — fix(project-a): harden schema and gate ambiguity after adversarial review
6. `133a96fd6653e4d3b16d71c38e1c70fc38585101` — docs(project-a): close W1 with clean-clone, CI and continuation evidence

The initial environment checkout `/workspace/race_stack` was legacy `67981ed7964a6d35e1da48f0c22bbd9f6d123d5e`, not W1. The shared review source is `/workspace/work/w1-review/source`. Independently recomputing Git blob SHA-1 for each of the 211 changed files in that source gave **211/211 matches** to the exact-head GitHub comparison response. Full W0/W1 recursive Git tree comparison gives exactly 211 changed leaves and no gitlink change. This checks changed binary/evidence files too, rather than relying on incomplete PR patches.

## Gitlinks and preservation

Both W0 and W1 trees contain the same five top-level gitlinks:

| Path | SHA |
|---|---|
| base_system/f110_simulator/f1tenth_gym | f8f8c9d4781d44a2959bae013f276410cb4e9da0 |
| base_system/f110_simulator/f1tenth_gym_ros | 163020c0b631a5bdd9ddc59e6132337cec04cc27 |
| base_system/f1tenth_system | 5d6490fc6426deb1254198020133a85c0614f183 |
| planner/global_planner/global_planner/global_racetrajectory_optimization | b1b38ecfefec7200d5bcb243f115af1d795b3766 |
| sensors/vesc | 2fd19be756544693752d3e5b36c128e6157e4bd3 |

The unchanged f1tenth_system commit fixes nested `ackermann_mux` at `ed4eac7284d13cae66628688e6fd32e585a96a62` and `teleop_tools` at `09938461991ec2260ddab6db8ac962f46d205669`. The push-CI checkout log independently confirms all seven recursive pins. `.gitmodules`, legacy planner modules/setup entry points, original maps/configuration, ROS message sources, optimizer source/gitlink, controller, localization and actuator source are unchanged in the full tree diff.

## Entire diff inventory

211 changed leaves comprise 186 retained evidence files, seven documentation files, four new production modules, seven fixtures, three source test files, one dependency manifest, and three CI/test integration files. Exact paths/status/hashes are in `identity-ci.json`, full metadata and available patches in `github-compare.json`.

Production additions:

- `_route_geometry.py` (109 lines): private planar predicates and normal-line/polygon intervals.
- `route_input.py` (260): strict JSON normalization/canonical hash and frozen route/occurrence/portal records, selected directed cyclic topology and annotation validation.
- `route_reference.py` (293): immutable exact cubic coefficients, periodic interpolation, regularity checks, adaptive true-arc integration and inverse, stateless frame/metric queries.
- `route_corridor.py` (386): original-route q/ownership, anchored metric resampling/refits, owned signed normal intervals, actual polynomial gate crossing checks, preparation/normal-chart checks and TUM geometry views.

Fixtures: S0 forward, reverse, rotated origin; S2 lower/upper selections; S3 surfaces and notch. New source suites are `test_route_input.py`, `test_route_reference.py`, `test_route_corridor.py`. Their final declared/CI-observed counts are 48/12/18.

Dependency change is only `planner/global_planner/package.xml:10–11`, adding explicit `python3-numpy`/`python3-scipy` execution dependencies. Pinned numerical locks, Dockerfile, image base and standalone Compose are unchanged from W0; no geometry framework was introduced.

Integration changes:

- `.github/workflows/project-a.yml:5,7` adds Project A docs to existing push/PR path filters, updates test-step label at line 22 and artifact name at line 37; checkout/action SHAs, read-only permissions and isolated build policy remain pinned.
- `scripts/project_a/container_verify.sh:16–20` adds scoped flake8 and explicit A01/A02/A03 gates before original W0 numerical checks; line 37 adds the installed W1 test. Existing original W0 checks are retained. Summary includes W1 groups and explicitly says legal planner acceptance is not implemented (line 60).
- `scripts/project_a/tests/test_w1_installed.py:7–21` checks all three public modules import from actual non-symlink `/work/install`, then exercises a metric periodic circle and a prepared corridor. This verifies installation, not the complete geometry contract.
- `container_verify.sh:39–53` still records red legacy tests without failing `all`; the warning step at workflow lines 24–31 exposes this. This behavior predates W1. It is not evidence that legacy lint/XML passed, and CI does not itself compare failure identities. The full logs and independent baseline comparison must be retained.

Documentation inspected: EXECUTION_PLAN, STATUS, DECISIONS, RESULTS, W1_GEOMETRY, W1_SELF_REVIEW, RUNBOOK, REVIEW, canonical architecture/roadmap, planner AGENTS. Supported v1 simple-ribbon/shared-cap restrictions and rejection of holes are explicitly declared. Rejecting unsupported holes agrees with architecture line 73 ("explicitly represented or rejected"). Final continuous curve/footprint certification, dynamics, optimizer adapter, artifact/export and runtime tracking are explicitly not claimed. In particular W1_GEOMETRY's between-node restrictions/A05 disclaimer is a legitimate scope boundary; it does not excuse an incorrect *returned* interval or owner. Documentation's "W1 complete/no technical blockers" statements are implementing-agent claims, not independent evidence.

## Exact-head hosted CI

At first observation both final runs were in progress. Both subsequently completed SUCCESS while branch head remained unchanged.

| Run | Event and actual checkout | Result |
|---|---|---|
| [38867639532](https://github.com/Felix-Grote/race_stack/actions/runs/38867639532) | push, exact W1 SHA 133a96fd6653e4d3b16d71c38e1c70fc38585101 | SUCCESS, updated 2026-10-16 07:32:45 UTC |
| [38867646470](https://github.com/Felix-Grote/race_stack/actions/runs/38867646470) | pull_request, synthetic merge ece844a570ff9dcbd77bbd0051d79f92140d1e5f | SUCCESS, updated 2026-10-16 07:32:31 UTC |

The PR API reports `head_sha=133a96fd...`, but the actual PR checkout is the synthetic merge. Therefore **the push run is the exact-head acceptance evidence**. Both jobs are `isolated-humble`; setup/test/artifact upload steps all succeeded. Exact push log verifies Ubuntu 22.04.5/ROS Humble/Python 3.10.12, NumPy 1.26.4/SciPy 1.11.4 and recursive pins. Its observed tests:

- A01: 48 passed (07:31:40 UTC)
- A02: 12 passed (07:31:43 UTC)
- A03: 18 passed (07:31:52 UTC)
- Original W0 numerical: 7 passed
- Three-package build: 3 packages finished
- Original installed ROS: 4 passed
- Installed W1: 1 passed
- Legacy aggregate: 90 tests, 0 errors, 10 failures, 2 skipped; `colcon_test=1`, `colcon_test_result=1`.

The CI build/test success establishes execution of these checks only. It does not establish all advertised abstractions or numerical error bounds; independent adversarial probes remain decisive. No integration-specific correctness regression was demonstrated by this inventory audit.

## Remote commands and retained evidence

Read-only connector requests:

```
github_fetch_pr(repo_full_name="Felix-Grote/race_stack", pr_number=1)
github_compare_commits(base="6370d0436aabd011d1b885fe1f500644b957b536", head="project-a/w1-geometry")
GET /repos/Felix-Grote/race_stack/compare/6370d0436aabd011d1b885fe1f500644b957b536...133a96fd6653e4d3b16d71c38e1c70fc38585101
GET /repos/Felix-Grote/race_stack/git/ref/heads/project-a/w0-cloud-foundation
GET /repos/Felix-Grote/race_stack/git/ref/heads/project-a/w1-geometry
GET /repos/Felix-Grote/race_stack/git/trees/{W0_SHA,W1_SHA}?recursive=1
GET /repos/Felix-Grote/race_stack/actions/runs?head_sha=133a96fd6653e4d3b16d71c38e1c70fc38585101
GET /repos/Felix-Grote/race_stack/actions/runs/{38867639532,38867646470}
github_fetch_workflow_run_jobs(run_id=38867639532 / 38867646470)
github_fetch_workflow_job_logs(job_id=116864045222 / 116864065324)
```

An attempt to GET a branch with a URL-encoded slash in the branches endpoint was rejected by the connector's URL validator; the equivalent Git refs endpoint above succeeded. No evidence was inferred from those failures. The limited `github_fetch_commit_workflow_runs` wrapper only reports PR-triggered runs, so direct REST collection was used to discover the exact-head push run as well.

Files in this evidence directory: `identity-ci.json`, `github-compare.json`, `github-w0-tree.json`, `github-w1-tree.json`, `github-final-ref.json`, `github-push-run.json`, `github-pr-run.json`, `github-push-job.json`, `github-pr-job.json`, `github-push.log`, `github-pr.log`.

