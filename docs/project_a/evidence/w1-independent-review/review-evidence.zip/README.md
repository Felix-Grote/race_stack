# W1 independent review evidence

Review target: Felix-Grote/race_stack@133a96fd6653e4d3b16d71c38e1c70fc38585101.
Baseline: 6370d0436aabd011d1b885fe1f500644b957b536.

Read W1_ADVERSARIAL_REVIEW_REPORT.md first. The verdict is CHANGES REQUIRED.
Two P1 and three P2 defects are demonstrated. A probe exiting zero means its
observations reproduced, including failures of W1; it does not mean W1 is accepted.

Contents:

- probes/: 12 final pinned independent probes, one exploratory cap probe and detailed A02 notes.
- evidence/: raw probe output, complete counterexample JSON, exact argv/runtime/image/hash records,
  GitHub compare/tree/CI data and logs, component review notes, final source check.
- suites/: replay scripts, raw W0/W1 logs/JUnit, dependency/runtime inventories and legacy comparison.
  Compiled build/install products and copied third-party packages are omitted.
- source/: unmodified W1 core modules, tests/fixtures, authoritative project documentation,
  test runner/Docker/lock inputs and manifest. This is a selected source subset, not a full checkout.
- SHA256SUMS: hashes of every other member, including the report and selected source.

To replay all independent probes with their original paths, extract this archive
into /workspace/work/w1-review (or change the fixed paths in COPIES of the probes
and runner; that changes their recorded hashes). No source edits are needed.

Use the existing project-a-humble:w1-review image, or build the original image from
the included inputs. The original managed environment command was:

```bash
cd /workspace/work/w1-review/source
env -u DOCKER_HOST -u DOCKER_CONTEXT -u DOCKER_TLS -u DOCKER_TLS_VERIFY -u DOCKER_CERT_PATH \
  docker --host=unix:///var/run/docker.sock build \
  --secret id=system_ca,src=/etc/ssl/certs/ca-certificates.crt \
  -f scripts/project_a/Dockerfile -t project-a-humble:w1-review .
cd /workspace/work/w1-review
python3 suites/run_probe_humble.py \
  a01_adversarial a01_gate_scale a01_neardegenerate \
  a02_adversarial a03_anchor_legal_reparam a03_geometry_metamorphic \
  a03_tangent_notch a03_tangent_public a03_tangent_prepare \
  cross_module_metamorphic mixed_choices required_metric_midpoint
```

Use the configured proxy/CA policy for your environment; do not disable TLS
verification. The resulting image's content ID may differ because apt indexes
and image build metadata are time-dependent. Compare recorded runtime/package pins
and source hashes, not an assumption that all rebuilds are byte-identical.

For original full functional-suite replay, obtain complete exact W1/W0 git archives
in source/ and suites/w0-source/, plus the optimizer checkout at the recorded pin.
The included suites/run_suites.sh records the exact original read-only mount path
for that optimizer. Adjust that mount path to your matching pinned checkout if
needed. The report gives source acquisition/build/replay commands. No remote push,
branch change, PR action or hardware launch is required.

The final evidence/humble-probes-summary.json verifies script hashes and all 859
tracked non-gitlink source blobs after experiments. Probe stderr files are retained
even when empty. Raw historical GitHub timestamps are UTC; report dates use Zurich.

Verify after extraction:

```bash
sha256sum -c SHA256SUMS
```
