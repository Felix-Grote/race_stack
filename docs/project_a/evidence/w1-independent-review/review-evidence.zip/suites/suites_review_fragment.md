## Independent functional and regression replay

Source under review: immutable `git archive` of W1 commit
`133a96fd6653e4d3b16d71c38e1c70fc38585101`; comparison archive W0
`6370d0436aabd011d1b885fe1f500644b957b536`. The existing main checkout was not
checked out or edited: it remained clean at
`67981ed7964a6d35e1da48f0c22bbd9f6d123d5e` before and after the replay.
The optimizer was mounted read-only from the existing initialized submodule at
the unchanged pin `b1b38ecfefec7200d5bcb243f115af1d795b3766`.

The archive has no Git administration files. Rather than run `setup.sh`, which
initializes submodules in its source tree, I executed its prescribed Docker build
directly, then replayed each archive's unchanged `container_verify.sh all` under
the same isolation flags as `docker-compose.test.yaml`. The existing configured
Docker daemon and proxy/CA configuration were used. No root hardware Compose
file, hardware device, stack launch, branch mutation, commit or PR action occurred.

Executed from `/workspace/work/w1-review/source`:

```bash
env -u DOCKER_HOST -u DOCKER_CONTEXT -u DOCKER_TLS -u DOCKER_TLS_VERIFY -u DOCKER_CERT_PATH \
  docker --host=unix:///var/run/docker.sock build \
  --secret id=system_ca,src=/etc/ssl/certs/ca-certificates.crt \
  -f scripts/project_a/Dockerfile -t project-a-humble:w1-review .
bash /workspace/work/w1-review/suites/run_suites.sh w0
bash /workspace/work/w1-review/suites/run_suites.sh w1
python3 /workspace/work/w1-review/suites/compare_legacy.py
```

Build exit 0. Image ID:
`sha256:8c9c36d25927e34e03ab3e9978bd1a1a56ab4f60a7ec57ce90c17c053c7ab8d3`.
The Dockerfile and both dependency lockfiles have no W1 diff. Base ROS image:
`ros:humble-ros-base-jammy@sha256:860e53793ccf575e5369b5e9a19939de2bfcfb46a299954d06f54f2af54fed19`.
Actual dependencies: Ubuntu 22.04.5, ROS Humble, Python 3.10.12, NumPy 1.26.4,
SciPy 1.11.4, pytest 8.3.5, quadprog 0.1.7,
trajectory-planning-helpers 0.79. Both runs passed `pip check`.

| Independent run | Functional results | Build | Legacy aggregate |
|---|---|---|---|
| W0 | 7 numerical + 4 ROS; exit 0 | 3 packages pass | 12 tests, 0 errors, 10 failures, 2 skipped |
| W1 | 48 A01 + 12 A02 + 18 A03 + 7 numerical + 4 ROS + 1 installed-module; exit 0 | 3 packages pass | 90 tests, 0 errors, 10 failures, 2 skipped |

The three packages are `f110_msgs`, `frenet_conversion`, and `global_planner`.
Installation was non-symlink. The W1 installed-module test verified imports from
`/work/install`, generated a curve, prepared a corridor and checked periodic
sampling. The four original ROS tests executed against generated ROS messages;
these are distinct from pure numerical tests. W1 scoped flake8 passed.

`comparison.json` independently asserts equal failing and skipped leaf-test
identities between W0 and W1. Eight failing JUnit leaf cases comprise four
flake8/pep257 tests, three `f110_msgs` CMake formatting cases, and its XML-schema
case; the aggregate includes two additional failing CTest wrappers. No new failing
identity was introduced. Both legacy `colcon_test` and `colcon_test_result` return
1, preserved explicitly rather than described as passing. Workflow success means
the functional gates passed; the legacy result remains a warning.

Both runs' executed isolation checks report UID 1000, effective capabilities 0,
`NoNewPrivs=1`, only loopback networking, and read-only root and source. Source
copies, build/install outputs and generated evidence are confined to scratch.

The existing W1 parabola test reports exact length 1.4789428575445975 m,
integrated length 1.4789428575445973 m, maximum inverse station residual
1.2471490506982263e-10 m, and a 1e-8 m acceptance threshold on its 51-point mesh.
The separate unchanged W0 legacy characterization measures 0.1669380946018666 m
nominal station discrepancy. These passing existing tests do not establish the
advertised bound outside their covered mesh; independent adversarial A02 findings
must be evaluated separately.

Raw evidence is in `suites/image-build.log`, `suites/w0-run/` and
`suites/w1-run/` (full logs, JUnit, OS/dependency inventories, runtime identity,
metric/QP measurements); `suites/comparison.json` contains the comparison.
`suites/run_suites.sh` preserves the exact Docker command. No implementation
change was made.

## Independent-probe replay in the same pinned environment

The final versions of these 12 independent probes were also executed under the
same image, UID 1000, no network/capabilities, read-only root and source, and a
separate writable evidence overlay preserving the original host evidence:

```bash
python3 /workspace/work/w1-review/suites/run_probe_humble.py \
  a01_adversarial a01_gate_scale a01_neardegenerate a02_adversarial \
  a03_tangent_notch a03_tangent_public a03_tangent_prepare \
  a03_anchor_legal_reparam a03_geometry_metamorphic \
  cross_module_metamorphic required_metric_midpoint mixed_choices
```

Every final probe execution exited 0, including assertions reproducing the
reported defects. Each `evidence/<name>_humble_execution.json` records the exact
Docker argv, image ID, probe SHA-256, exit code and a check that its script did not
change during execution. The corresponding `_humble_runtime.json` records the
actual Python/NumPy/SciPy versions, UID, effective capabilities, loopback-only
networking and read-only root/source. `_humble.log` and `_humble.stderr` preserve
stdout/stderr. Generated Humble fixtures have distinct `_humble` names.

`evidence/humble-probes-summary.json` verifies that all 12 recorded probe hashes
match their final versions, that all 859 tracked non-gitlink W1 source blobs
still match the exact reviewed Git tree after the experiments, and that the
existing main checkout remains clean. Nothing in the source snapshot was edited.

The midpoint oracle independently reproduces the historical 0.16557464142413925 m
error using analytic `x=t,y=t²` at nominal `t=.5`. W1 inverts the target station
to `t=.6107386829580599` with zero observed analytic residual, using one cubic
coefficient segment and no resampling. This establishes that the historical
nominal-parameter defect is repaired for that curve; the independent hidden-pocket
and monotone-near-stationary oracles separately expose the remaining integration
failure.

The cross-module metamorphic probe passes 15 rigid-motion cases across five
fixtures, 120 query pairs, and preserves every occurrence/surface/portal owner.
Worst errors are 5.11591e-12 m in lap length, 1.45520e-11 m in transformed XY,
1.47138e-11 m in legal width, and 5.66582e-10 /m in curvature. The four independent
two-visit upper/lower branch combinations all prepare successfully with eight
distinct occurrences and eight directed gates, and all injected illegal
cross-visit branch switches are rejected.
