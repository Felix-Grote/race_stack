"""Execute immutable independent probes in the accepted pinned Humble image."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

root = Path('/workspace/work/w1-review')
generated = root / 'suites/humble-generated'
generated.mkdir(exist_ok=True)
docker = ['docker', '--host=unix:///var/run/docker.sock']
environment = dict(os.environ)
for key in ('DOCKER_HOST', 'DOCKER_CONTEXT', 'DOCKER_TLS', 'DOCKER_TLS_VERIFY',
            'DOCKER_CERT_PATH'):
    environment.pop(key, None)
image = subprocess.check_output(docker + ['image', 'inspect',
    'project-a-humble:w1-review', '--format', '{{.Id}}'], env=environment, text=True).strip()
wrapper = '''import json,os,pathlib,platform,runpy,socket,sys,numpy,scipy
status=dict(line.split(':',1) for line in pathlib.Path('/proc/self/status').read_text().splitlines() if ':' in line)
pathlib.Path(sys.argv[2]).write_text(json.dumps({
 'python':platform.python_version(),'numpy':numpy.__version__,'scipy':scipy.__version__,
 'platform':platform.platform(),'uid':os.getuid(),'interfaces':socket.if_nameindex(),
 'cap_eff':status['CapEff'].strip(),'no_new_privs':status['NoNewPrivs'].strip(),
 'root_readonly':bool(os.statvfs('/').f_flag & os.ST_RDONLY),
 'source_readonly':bool(os.statvfs('/workspace/work/w1-review/source').f_flag & os.ST_RDONLY),
 'image_id':sys.argv[3]},indent=2)+'\\n')
runpy.run_path(sys.argv[1],run_name='__main__')
'''
for name in sys.argv[1:]:
    probe = root / 'probes' / (name + '.py')
    before = hashlib.sha256(probe.read_bytes()).hexdigest()
    runtime = root / 'evidence' / (name + '_humble_runtime.json')
    command = docker + ['run', '--rm', '--user', '1000:1000', '--workdir', '/work',
        '--read-only', '--network', 'none', '--ipc', 'private', '--cap-drop', 'ALL',
        '--security-opt', 'no-new-privileges:true', '--pids-limit', '256',
        '--memory', '4g', '--cpus', '2', '-e', 'PYTHONDONTWRITEBYTECODE=1',
        '-e', 'MPLBACKEND=Agg', '-e', 'OPENBLAS_NUM_THREADS=1', '-e', 'OMP_NUM_THREADS=1',
        '-e', 'HOME=/tmp', '-e', 'PYTHONPATH=' + str(root / 'source/planner/global_planner'),
        '--mount', f'type=bind,src={root},dst={root},readonly',
        '--mount', f'type=bind,src={generated},dst={root}/evidence',
        '--tmpfs', '/tmp:rw,nosuid,nodev,size=256m,mode=1777',
        'project-a-humble:w1-review', 'python', '-c', wrapper,
        str(probe), str(runtime), image]
    stdout = root / 'evidence' / (name + '_humble.log')
    stderr = root / 'evidence' / (name + '_humble.stderr')
    with stdout.open('w') as out, stderr.open('w') as err:
        result = subprocess.run(command, stdout=out, stderr=err, env=environment)
    shutil.copyfile(generated / runtime.name, runtime)
    record = {'probe': str(probe), 'probe_sha256': before,
              'probe_unchanged': before == hashlib.sha256(probe.read_bytes()).hexdigest(),
              'exit_code': result.returncode, 'image_id': image,
              'stdout': str(stdout), 'stderr': str(stderr), 'command': command}
    (root / 'evidence' / (name + '_humble_execution.json')).write_text(
        json.dumps(record, indent=2) + '\n')
    print(json.dumps({k: record[k] for k in ('probe', 'exit_code', 'probe_unchanged')}), flush=True)
