"""Compare independent W0/W1 failing test identities without suppressing either run."""
import json
import re
import xml.etree.ElementTree as ET
from pathlib import Path

root = Path(__file__).resolve().parent
results = {}
for case in ('w0', 'w1'):
    output = root / (case + '-run')
    build = output / 'build'
    failures = []
    skips = []
    for path in sorted(build.rglob('*.xml')):
        document = ET.parse(path).getroot()
        for testcase in document.iter('testcase'):
            identity = [str(path.relative_to(build)), testcase.get('classname'),
                        testcase.get('name')]
            if testcase.find('failure') is not None or testcase.find('error') is not None:
                failures.append(identity)
            if testcase.find('skipped') is not None:
                skips.append(identity)
    summary = re.search(r'^Summary: .*$', (output / 'legacy-results.txt').read_text(), re.M)
    results[case] = {'aggregate': summary.group(), 'junit_failure_identities': failures,
                     'junit_skip_identities': skips,
                     'functional_exit': int((output / 'exit-code.txt').read_text()),
                     'functional_summary': json.loads((output / 'summary.json').read_text())}
results['failure_identities_equal'] = (
    results['w0']['junit_failure_identities'] == results['w1']['junit_failure_identities'])
results['skip_identities_equal'] = (
    results['w0']['junit_skip_identities'] == results['w1']['junit_skip_identities'])
assert results['failure_identities_equal'] and results['skip_identities_equal']
destination = root / 'comparison.json'
destination.write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps(results, indent=2))
