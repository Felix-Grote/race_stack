#!/usr/bin/env bash
# Independent read-only replay of the committed functional runner.
set -euo pipefail
suite_case=${1:?w0 or w1}
suite_root=/workspace/work/w1-review/suites
case "$suite_case" in
  w0) suite_source="$suite_root/w0-source" ;;
  w1) suite_source=/workspace/work/w1-review/source ;;
  *) exit 2 ;;
esac
suite_out="$suite_root/$suite_case-run"
mkdir -p "$suite_out"
unset DOCKER_HOST DOCKER_CONTEXT DOCKER_TLS DOCKER_TLS_VERIFY DOCKER_CERT_PATH
set +e
docker --host=unix:///var/run/docker.sock run --rm \
  --name "project-a-review-$suite_case" \
  --user "$(id -u):$(id -g)" --workdir /work --read-only \
  --network none --ipc private --cap-drop ALL \
  --security-opt no-new-privileges:true --pids-limit 256 --memory 4g --cpus 2 \
  -e PYTHONDONTWRITEBYTECODE=1 -e MPLBACKEND=Agg \
  -e OPENBLAS_NUM_THREADS=1 -e OMP_NUM_THREADS=1 -e HOME=/work \
  --mount "type=bind,src=$suite_source,dst=/src,readonly" \
  --mount "type=bind,src=/workspace/race_stack/planner/global_planner/global_planner/global_racetrajectory_optimization,dst=/src/planner/global_planner/global_planner/global_racetrajectory_optimization,readonly" \
  --mount "type=bind,src=$suite_out,dst=/work" \
  --tmpfs /tmp:rw,nosuid,nodev,size=256m,mode=1777 \
  project-a-humble:w1-review /bin/bash /src/scripts/project_a/container_verify.sh all \
  > "$suite_out/run.log" 2>&1
suite_rc=$?
set -e
printf '%s\n' "$suite_rc" > "$suite_out/exit-code.txt"
exit "$suite_rc"
