"""Run independent exact/110-digit probes in the pinned isolated runner."""
from pathlib import Path
import os
import runpy


def test_independent_numerical_primitives():
    os.environ['CONTRACTS_OUTPUT'] = '/work'
    runpy.run_path(str(Path(__file__).with_name('probe_numerical_contracts_decimal.py')))
