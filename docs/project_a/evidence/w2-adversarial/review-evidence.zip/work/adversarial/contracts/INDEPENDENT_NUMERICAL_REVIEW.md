# Independent numerical-contract investigation

Reviewed implementation: `e852641849b2497efea51dfca5ead38ad4476235`.
Scope: exact polynomial/Bernstein bounds, binary64 outward conversion,
reference-aligned rectangle normalization, and the shared W1 arc primitive used
by both retimer and independent dynamics checker. This investigation made no
implementation changes. Attached/project documentation was treated as claimed
contracts and compared with source; historical execution instructions were not
treated as a replacement for the user's W2 scope.

## Source and independent obligations

`route_validate.py:100–107` forms the exact power-to-Bernstein transform after
`t=lo+(hi-lo)*u`. Its vector derivative is quadratic. The curve derivative is a
convex combination of its three vector controls, so its norm is bounded above
by the maximum control norm (`:152–153`), despite the nonmatching component
extrema. The distance of the enclosing component box from zero is a valid lower
bound (`:148–150`). Subdivision is necessary when that box contains zero; zero
in the box does not establish a singular derivative.

For `d=r'`, `g=d·d`, and `c=cross(d,d')`, independently differentiating gives
`kappa=c/g^(3/2)` and `d(kappa)/ds=(2*c'*g-3*c*g')/(2*g^3)`. The source's exact
polynomial products and Bernstein coefficient bounds implement these formulas
(`:154–163`). Neither endpoint curvature nor floating subtraction is used to
authorize an interval. The formulas are invariant under rigid motion; geometric
scaling by lambda changes speed by lambda, curvature by 1/lambda, and curvature
rate by 1/lambda².

For a body-fixed point `z` with `|z|<=R`, the moving body is
`x(s)=r(s)+Q(theta(s))*z`. Since `|r_s|=1` and `theta_s=kappa`,
`|x_s| <= 1+R*|kappa|`. A parameter interval of width `dt` has every point at
metric distance at most `h=V*dt/2` from its midpoint. Integrating the preceding
inequality proves `|x(s)-x(s_mid)| <= (1+R*K)*h`. This bound includes every
interior rectangle point, all four edges/corners, and arbitrary curvature sign
changes. It requires regularity and a whole-interval K; these are independently
checked. Each coefficient is certified on its own closed interval, so no cubic
join is crossed inside this proof. Both one-sided endpoint footprints are
covered by adjacent certificates.

`_rectangle` (`:398–414`) evaluates position and derivative exactly as rational
numbers. Only component conversion, hypot and normalization use binary64.
Input derivative magnitudes are bounded by the 1e8 coefficient domain, and the
accepted derivative norm exceeds the independent minimum-speed policy. Thus
there is no overflow or underflow of the derivative norm in the supported
acceptance path. Component conversion, one-ulp hypot and division each contribute
a small multiple of binary64 epsilon to the unit-vector error. The declared
`512*eps*(1+R)*max(1,V/v_min)` positional allowance is substantially larger than
the resulting `O(eps*R)` frame error. Rational rectangle products then avoid
coordinate-translation cancellation. The width/2 operation is rounded before
conversion, but its maximum half-width rounding error is also absorbed by this
allowance. The allowance is conditional on the stated elementary-function model;
this review is not a machine-checked floating-point proof.

`_sqrt` (`:52–72`) scales the exact rational before converting it. The scaled
value lies within a fixed ordinary range around unity, so its conversion does
not lose a subnormal fraction. Outward nextafter steps enclose conversion and
sqrt error before ldexp, and another outward step encloses subnormal ldexp
rounding. Unrepresentable upper bounds become uncertainty. Exact rational tests
below check lower² <= exact input <= upper², independently of any sqrt oracle.

## Shared arc primitive

Both candidate generation and dynamics acceptance reconstruct `Curve` and use
its local arc routine. This is a correlated-failure risk: a shared arc error
could produce matching acceleration and time metadata in both modules. Digest
agreement and retimer/checker agreement do not independently establish distance
accuracy. The independent analytic oracle below addresses this primitive directly.

`route_reference.py:118–172` computes Gauss32 values and a derivative remainder.
With `d(u)=r'(a+h*u)`, bounds D0,D1,D2 on d and its first two u derivatives give
Taylor derivative bounds of `g=d·d`: `G1=2D0D1`, `G2=D1²+D0D2`,
`G3=D1D2`, `G4=D2²/4`, and Gk=0 above order four. Differentiating `f²=g`, where
`f=|d|`, gives `2*f*f_k=g_k-sum(f_j*f_(k-j))`. Replacing each term by an absolute
upper bound and f by a positive lower bound yields exactly the implemented
recurrence. Applying the Gauss32 remainder constant to F64 proves a panel
truncation bound independently of agreement between quadrature estimates.

The source adds a separate value-evaluation allowance proportional to the
coefficient derivative scale, avoiding a relative-error assumption on a nearly
cancelled derivative. Control-box and positive bound arithmetic use 128-eps
inflation. The recurrence's fsum/product/add/divide operations involve at most
63 terms per coefficient, within this declared headroom. The positive error sum
and final value sum retain separate rounding allowances. Unresolved derivative
boxes or panel limits reject rather than fall back to sampled arc/chord length.
No counterexample was found to these stated arithmetic assumptions.

## Executed independent experiments

`probe_numerical_contracts.py` is the exploratory Python3.12/mpmath110 control.
Its initial harness TypeError (mixing mpf and Fraction) is retained separately as
`probe_numerical_contracts_initial_harness_failure.log`; it is not an implementation
failure. The corrected exploratory script completed with zero failed bounds.

`probe_numerical_contracts_decimal.py` uses only Python's Decimal at 110 digits,
exact binary64 input conversion, an analytic antiderivative, and an independently
seeded input campaign. `test_numerical_contracts.py` runs this script through the
pinned isolated test runner. The oracle does not call the production arc routine
to compute expected distances or use production normalization to construct the
expected unit tangent.

The arc family has `r'=(scale*(t-a), scale*epsilon)` with dyadic source parameters,
epsilon from 2^-25 to 2, scale 2^-3 to 2^11, and a across the interval. Its primitive
is `(z*sqrt(z²+e²)+e²*asinh(z/e))/(2*scale)`, z=scale*(t-a). Full and three partial
integrals per supported family independently challenge the small-speed region.
Budget rejection remains an acceptable fail-closed outcome.

Command:

```
scripts/project_a/unit.sh work/adversarial/contracts/final-pinned \
  work/adversarial/contracts/test_numerical_contracts.py
```

Pinned run identity, source hashes before/after, dependency list, image identity,
container inspection, oracle hashes, JUnit XML, log, exit code and exact counts
are in `final-pinned/`. Host exploratory and pinned evidence must be distinguished;
the pinned run is the acceptance-environment result.

## Remaining limits and disposition

No verified numerical defect was demonstrated in this delegated scope.
The mathematical sufficiency arguments remain conditional on the declared
binary64 elementary-function model and correct interpretation of binary64 inputs
as exact values. This campaign is an independent regression challenge, not a
replacement continuous certificate or exhaustive proof over all floating inputs.

The geometry and dynamics modules share schemas, W1 curve reconstruction/local
arc integration, and A05 interval bounds. The checker independently reconstructs
authority and constraints but is not numerically independent of those kernels.
Future changes to any shared primitive therefore require an external analytic or
precision-controlled oracle; comparing the two modules against each other alone
would be insufficient. Resource-limited uncertainty must continue to prevent
combined acceptance. Other reviewers own original polygon/portal semantics,
optimizer quality, cap/model applicability and whole-pipeline false-positive tests.

## Pinned result

The command exited 0: **1 campaign test passed in 27.63 s**. It executed
20,000 exact sqrt inputs (18,984 enclosed and 1,016 explicitly uncertain),
2,500 independent normalization/body-corner checks (all enclosed), and
240 analytic arc families (231 supported and nine explicit geometry/budget
rejections), with no enclosure violation. The maximum observed frame error was
0.001312055 times its allowance. The maximum observed full/partial arc error was
0.019672861 times the returned bound. Source hashes before and after match.
Runtime: Python3.10.12, ROS Humble, Linux x86_64/glibc2.35, image
`sha256:78d2201ecb18b242c03348876bc9b5e43128d012e1bf30d571b2244ac2d7a3ae`.
The inspection/identity confirms UID1000, no effective capabilities,
no-new-privileges, only loopback network, and read-only root/source.
