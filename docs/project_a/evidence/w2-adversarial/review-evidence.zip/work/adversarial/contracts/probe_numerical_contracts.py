"""Independent adversarial numerical controls. No production source mutation."""
from fractions import Fraction
from pathlib import Path
import hashlib
import json
import math
import random
import sys

import mpmath as mp

from global_planner.route_reference import CubicSegment, GeometryError, NumericPolicy
from global_planner.route_validate import BoundUncertain, Footprint, _rectangle, _sqrt, interval_bounds

OUT = Path(__file__).resolve().parent
mp.mp.dps = 110
rng = random.Random(0xC0FFEE27)


def m(value):
    if isinstance(value, mp.mpf):
        return value
    f = Fraction(value)
    return mp.mpf(f.numerator) / f.denominator


roots = {'attempted': 0, 'enclosed': 0, 'uncertain': 0, 'failure': []}
for i in range(20000):
    # Independent exact check: lower^2 <= input <= upper^2.
    exponent = rng.randrange(-2500, 2300)
    value = Fraction(rng.randrange(1, 2**53), rng.randrange(1, 2**53))
    value *= Fraction(2**exponent) if exponent >= 0 else Fraction(1, 2**(-exponent))
    roots['attempted'] += 1
    try:
        lower, upper = _sqrt(value, False), _sqrt(value, True)
        if Fraction(lower)**2 > value or Fraction(upper)**2 < value:
            roots['failure'].append({'exponent': exponent, 'lower': lower, 'upper': upper})
        else:
            roots['enclosed'] += 1
    except BoundUncertain:
        roots['uncertain'] += 1

frames = {'attempted': 0, 'enclosed': 0, 'uncertain': 0,
          'maximum_actual_error_over_allowance': 0., 'failure': []}
for i in range(2500):
    exponent = rng.uniform(-6, 7.3)
    speed = 10.**exponent
    angle = rng.uniform(-math.pi, math.pi)
    derivative = (speed*math.cos(angle), speed*math.sin(angle))
    coefficients = ((rng.uniform(-1e8, 1e8), derivative[0], 0., 0.),
                    (rng.uniform(-1e8, 1e8), derivative[1], 0., 0.))
    span = 10.**rng.uniform(-12, 6)
    body = Footprint(span, span * .37, span * .71, 0.)
    frames['attempted'] += 1
    try:
        bounds = interval_bounds(coefficients)
        rectangle, allowance = _rectangle(tuple(tuple(Fraction(x) for x in row)
                                                for row in coefficients), Fraction(1, 3), body, bounds)
        norm = mp.sqrt(m(derivative[0])**2+m(derivative[1])**2)
        tx, ty = m(derivative[0])/norm, m(derivative[1])/norm
        px = m(coefficients[0][0]) + m(derivative[0])/3
        py = m(coefficients[1][0]) + m(derivative[1])/3
        errors=[]
        for actual, (x, y) in zip(rectangle, ((body.front_m, m(body.width_m)/2),
                                             (-body.rear_m, m(body.width_m)/2),
                                             (-body.rear_m, -m(body.width_m)/2),
                                             (body.front_m, -m(body.width_m)/2))):
            true = px + m(x)*tx-m(y)*ty, py+m(x)*ty+m(y)*tx
            errors.append(mp.sqrt((m(actual[0])-true[0])**2+(m(actual[1])-true[1])**2))
        ratio = max(errors)/m(allowance)
        frames['maximum_actual_error_over_allowance'] = max(
            frames['maximum_actual_error_over_allowance'], float(ratio))
        if ratio > 1:
            frames['failure'].append({'coefficients': coefficients, 'ratio': float(ratio)})
        else:
            frames['enclosed'] += 1
    except BoundUncertain:
        frames['uncertain'] += 1

arcs = {'attempted': 0, 'accepted': 0, 'uncertain': 0,
        'maximum_actual_error_over_reported_bound': 0., 'failure': [], 'cases': []}
for i in range(240):
    center = Fraction(rng.randrange(1, 2**16), 2**16)
    scale = 2.**rng.randrange(-3, 12)
    epsilon = 2.**rng.randrange(-25, 2)
    # r'=(scale*(t-center),scale*epsilon). Exact antiderivative is known.
    coefficients = ((0., -scale*float(center), scale/2, 0.),
                    (0., scale*epsilon, 0., 0.))
    arcs['attempted'] += 1
    try:
        seg = CubicSegment(coefficients, NumericPolicy(quad_limit=256))
        ee = m(scale*epsilon)
        ss = m(scale)
        aa = m(center)
        def primitive(t):
            z=ss*(t-aa)
            return (z*mp.sqrt(z*z+ee*ee)+ee*ee*mp.asinh(z/ee))/(2*ss)
        expected = primitive(mp.mpf(1))-primitive(mp.mpf(0))
        actual_error = abs(m(seg.length)-expected)
        ratio = actual_error/m(seg.arc_error)
        arcs['maximum_actual_error_over_reported_bound'] = max(
            arcs['maximum_actual_error_over_reported_bound'],float(ratio))
        if ratio>1:
            arcs['failure'].append({'coefficients': coefficients,'ratio':float(ratio)})
        arcs['accepted'] += 1
        if len(arcs['cases']) < 10:
            arcs['cases'].append({'coefficients': coefficients,'length':seg.length,
                                  'error_bound':seg.arc_error,'actual_error':float(actual_error)})
        for part in (Fraction(1, 3), center, Fraction(2, 3)):
            t = float(part)
            value, error = seg._integrate(t)
            expected = primitive(m(t))-primitive(mp.mpf(0))
            actual_error = abs(m(value)-expected)
            ratio = actual_error/m(error)
            arcs['maximum_actual_error_over_reported_bound'] = max(
                arcs['maximum_actual_error_over_reported_bound'],float(ratio))
            if ratio>1:
                arcs['failure'].append({'coefficients':coefficients,'t':t,'ratio':float(ratio)})
    except GeometryError:
        arcs['uncertain'] += 1

source_root = Path(__file__).resolve().parents[3]
source = [source_root/'planner/global_planner/global_planner'/name for name in
          ('route_reference.py','route_validate.py','route_validate_dynamics.py')]
result = {'python': sys.version, 'mpmath':mp.__version__, 'precision_decimal_digits':mp.mp.dps,
          'seed':0xC0FFEE27, 'source_sha256': {str(p.relative_to(source_root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in source},
          'square_root': roots, 'normalization': frames, 'analytic_arc': arcs}
(OUT/'numerical_contracts_results.json').write_text(json.dumps(result,indent=2))
print(json.dumps({k:v for k,v in result.items() if k!='source_sha256'},indent=2))
assert not roots['failure'] and not frames['failure'] and not arcs['failure']
