# Independent P2 shared-cap orientation review

Root review requested an independent assessment after a newly generated rotated,
translated, asymmetric ellipse received A05 seed PASS (137 leaves), but A04
rejected its first preparation with zero completed iterations. The original
route/seed and full diagnostic are retained by the integration reviewer under
`work/adversarial/integration/novel/`.

The reduced case in `shared-cap/test_exact_shared_cap.py` needs only two adjacent
four-vertex strips, a line point/normal and their identical shared cap. Exact
Fraction arithmetic establishes both directed cap evaluations have the same
root:

`-6493513456432416 / 89282567569951896214720469081`

The old binary64 computations give source interval ending at
`-7.56631403522638e-14` and target interval starting at
`-7.25105095042528e-14`: an artificial gap approximately 3.15e-15 m in the normal
offset coordinate. Strict interval merging correctly refuses that numerical
gap, but it incorrectly rejects these truly shared-cap interiors as disconnected.

The proposed smallest repair canonicalizes each edge's endpoint order
lexicographically before computing the line intersection. This is mathematically
sound: edge reversal leaves the real z intersection unchanged and transforms
the segment parameter t to 1-t. Edge orientation is not used for polygon winding;
the original polygon remains unchanged for interior predicates. Identical
binary64 shared caps then run identical arithmetic in both occurrences. This
does not add an EPS merge, change strict `_merge`, lower margins, or change any
legal polygon. It is a P2 availability / false-negative repair; no geometry
false PASS was demonstrated by this finding.

Verification on pinned Python3.10.12, ROS Humble, read-only source/root,
network-none, nonroot and unchanged implementation hashes:

* `scripts/project_a/unit.sh work/adversarial/geometry/shared-cap-red
  work/adversarial/geometry/shared-cap/test_exact_shared_cap.py -x` — exit 1,
  one failed in 0.05 s at the exact shared-cap equality assertion.
* `scripts/project_a/unit.sh work/adversarial/geometry/shared-cap-proposed
  work/adversarial/geometry/shared-cap/test_exact_shared_cap.py
  --canonical-shared-cap` — exit 0, 49 passed in 0.12 s. The option uses a
  scratch-only import-time function copy and pytest monkeypatch; production
  source remains unchanged. Controls include the reduced case; 12 combinations
  of rotation, translation and polygon winding; 24 positive physical gaps from
  1e-10 through 1e-6 m (including below EPS) under rigid transformations; and
  all 12 prior F1 tangent-side contact configurations.

These tests establish the identified orientation inconsistency and preservation
of the challenged strict gap/contact behavior. They do not turn binary64 W1
preparation predicates into exact predicates or replace final independent A05
certification of any optimized candidate.

## Authorized application and frozen focused verification

After root review released F2 source edits, the helper received only the
lexicographic endpoint-order condition and its explanatory comment. Explicit
coordinate tuple keys preserve compatibility with different point sequence
types. No EPS, `_merge`, or other W1 source changed. The 49 self-contained
controls were promoted to
`planner/global_planner/test/test_route_w2_shared_cap.py`; they require no
scratch data, import hook or optional dependency.

`scripts/project_a/unit.sh work/adversarial/geometry/shared-cap-final
planner/global_planner/test/test_route_corridor.py
planner/global_planner/test/test_route_w2_shared_cap.py` exits **0: 87 passed in
49.36 s**, comprising all 38 original A03 cases and the 49 new controls. Complete
before/after implementation/fixture hashes match. Both applied files also pass
isolated pinned strict flake8 at 99 columns, syntax compilation and diff checks.

The preceding `shared-cap-green` run had all 87 test bodies pass, but its
hashguard correctly invalidated the run after the requested explicit coordinate
key edit and one whitespace-only lint correction occurred during execution.
That attempt is retained as nonaccepting evidence and is superseded by the
stable `shared-cap-final` run.

Applied SHA256 identities:

* `_route_geometry.py`:
  `90b957a7356a2252ef5755031598ecbedbc40f7a7015f87e172b9cfde02f68f2`
* `test_route_w2_shared_cap.py`:
  `f6df05c0664175dc24bab623ca6cfc46424632d0959358ff573e29163d82d141`

Root review owns the coherent corrective commit, complete final verification,
remote publication and exact-head CI. This agent made no commit or push.
