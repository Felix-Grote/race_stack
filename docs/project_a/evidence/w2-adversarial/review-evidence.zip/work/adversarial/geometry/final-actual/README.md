# Final actual-output independent geometric falsification

Target implementation/source identity:
`37b36ccc1f33300ce50e6c120c886147db11b4a7`.

This run consumes the seven freshly optimized and retimed scenarios emitted by
the final isolated ROS Humble verification at
`work/adversarial/final-full/w2-pipeline.json`. It does not use the earlier
frozen A04 coefficient fixture or old A05 certificate reports. The original
Phase-I `geometry/independent_oracle.py` remains unchanged.

Executed command, exit **0**:

```bash
work/adversarial/geometry/oracle-venv/bin/python \
  work/adversarial/geometry/final-actual/independent_final_oracle.py \
  > work/adversarial/geometry/final-actual/final-actual.log \
  2> work/adversarial/geometry/final-actual/final-actual.stderr
```

The oracle imports no production geometry, Bernstein, polygon, corridor,
optimizer or retimer code. It uses 80-digit Decimal evaluation of exact binary64
coefficients and normalization, GEOS polygon union/intersection and full-body
containment/distance, and an independent gate-root method based on analytic
derivative critical points and 160 bisections at 80-digit precision. Exact
endpoint-zero predicates use Fraction arithmetic. Ambiguous near tangencies
cannot silently pass the oracle.

It independently checks the complete actual handoff hash, route identity,
ownership order, portal q applicability and every segment's exact certificate
partition. It checks every sampled body's legality and original 0.01 m margin,
speed/curvature enclosure, midpoint-to-pose movement bounds, finite directed
gate uniqueness, gate support and the actual reported root brackets. All
production Python bytes are checked against the final verification's initial
source manifest; source identity must match the target SHA. The result records
60 explicit source/input/script hashes.

Results: **7 scenarios, 1,541 leaves, 7,705 body poses and 28 directed gates**
pass. Minimum sampled body clearance is **0.019275699389656977 m**; maximum
sampled movement-to-certified-bound ratio is **0.9999780322709407**. Minimum
reported certificate slack in these actual outputs is
**8.949819354105348e-5 m**.

Production execution is isolated Python3.10 / ROS Humble. The external oracle
uses Python3.12.14, Shapely2.1.2 / GEOS3.13.1, mpmath1.3.0 and NumPy2.3.5;
exact versions are retained in `oracle-environment.json`. Runtime separation is
intentional. This sampled/high-precision campaign is independent falsification,
not a sampled replacement for the production continuum certificate.

Actual pipeline SHA256:
`fb42f757f888a524be7e8912ba2bb77e9b87f584c59c26cac0e513643bc3f862`.

The full verification's legacy aggregate reruns the pipeline and overwrites its
JSON with a second fresh result. The final oracle was rerun successfully after
the complete verification closed, against that exact retained JSON; its
oracle-relevant results are identical. `retained-final-w2-pipeline.json` preserves
the tested final input. The initial functional-stage fresh input/result are
also preserved separately as `functional-stage-w2-pipeline.json` and
`functional-stage-oracle-result.json` (input SHA256
`886a5ae3f048db79bebad842eb24c24f4c1ce4893d35c1ce313555e65afbbf83`).

Final oracle source SHA256:
`373c71fd92fc5d11c5aa20ff583cd00ce559bbc5419f6c954643be20d3cb0cad`.

The earlier `preflight-on-earlier-corrected.json` exercises the adapter against
an earlier corrected full-run output and is not final acceptance evidence. Its
initial output-path handling failure is preserved in `preflight1-failure.txt`
with the original preflight source snapshot. No production edit occurred during
this work.
