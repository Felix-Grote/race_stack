"""Failing-first regression: unbound intermediate authority cannot grant PASS."""
import gzip
import json
from pathlib import Path

from global_planner.route_corridor import OrderedCurve
from global_planner.route_input import load_route
from global_planner.route_reference import Curve
from global_planner.route_validate import Footprint, validate_geometry


def test_unbound_complete_curve_authority_cannot_grant_pass():
    fixtures = Path('/src/planner/global_planner/test/fixtures/project_a')
    record = json.loads(gzip.decompress((fixtures / 'w2_a04_candidates.json.gz').read_bytes()))[
        'candidates']['s0_route']
    route = load_route(fixtures / 's0_route.json')
    candidate = OrderedCurve(route, Curve(record['coefficients'], record['owners']), record['q'])
    report = validate_geometry(candidate, route, Footprint(.10, .10, .12, .01))
    assert report.status == 'INCONCLUSIVE', (report.status, report.reason)
