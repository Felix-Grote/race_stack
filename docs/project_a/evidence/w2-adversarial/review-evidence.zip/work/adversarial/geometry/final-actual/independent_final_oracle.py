"""Independent 80-digit coefficient and GEOS geometry campaign, read-only source.

This is a falsification oracle, not a sampled replacement for certification.
It imports no production geometry, Bernstein, polygon, or corridor helper.
"""
from decimal import Decimal as D, localcontext
import gzip
import hashlib
import json
import math
from pathlib import Path
import platform
import sys
import unicodedata
from fractions import Fraction

import mpmath as mp
import shapely
from shapely.geometry import Point, Polygon

ROOT = Path(__file__).resolve().parents[4]
FIX = ROOT / 'planner/global_planner/test/fixtures/project_a'
EXPECTED_SOURCE = '37b36ccc1f33300ce50e6c120c886147db11b4a7'
PIPELINE = ROOT / 'work/adversarial/final-full/w2-pipeline.json'
SOURCE_MANIFEST = ROOT / 'work/adversarial/final-full/source-hashes-before.json'
SOURCE_IDENTITY = ROOT / 'work/adversarial/final-full/source-identity.txt'


def exact(value):
    return D.from_float(float(value))


def evaluate(rows, t):
    a = [[exact(v) for v in row] for row in rows]
    p = [row[0] + t * (row[1] + t * (row[2] + t * row[3])) for row in a]
    d = [row[1] + 2 * t * row[2] + 3 * t * t * row[3] for row in a]
    dd = [2 * row[2] + 6 * t * row[3] for row in a]
    speed = sum(v * v for v in d).sqrt()
    tangent = [v / speed for v in d]
    curvature = abs(d[0] * dd[1] - d[1] * dd[0]) / speed ** 3
    return p, tangent, speed, curvature


def body_at(rows, t, body):
    p, tangent, speed, curvature = evaluate(rows, t)
    front, rear, half = exact(body['front_m']), exact(body['rear_m']), exact(body['width_m']) / 2
    corners = [[p[0] + x * tangent[0] - y * tangent[1],
                p[1] + x * tangent[1] + y * tangent[0]]
               for x, y in ((front, half), (-rear, half), (-rear, -half), (front, -half))]
    return p, corners, speed, curvature


def fraction(pair):
    return D(pair[0]) / D(pair[1])


def canonical(value):
    if isinstance(value, dict):
        return {unicodedata.normalize('NFC', k): canonical(v) for k, v in value.items()}
    if isinstance(value, list):
        return [canonical(v) for v in value]
    if isinstance(value, str):
        return unicodedata.normalize('NFC', value)
    number = float(value)
    return int(number) if number.is_integer() else number


def mnumber(value):
    value = Fraction(value)
    return mp.mpf(value.numerator) / value.denominator


def polynomial(coefficients, t):
    result = mp.mpf(0)
    for value in reversed(coefficients):
        result = result * t + mnumber(value)
    return result


def roots_on_unit_interval(coefficients):
    """Independent monotonic decomposition from analytic derivative roots.

    No production roots, Bernstein controls, Descartes count or solver samples.
    Exact endpoint-zero predicates are rational; all other ordinary roots use
    160 bisections at 80 digits. Near-tangent oracle ambiguity rejects this
    regression control rather than manufacturing an extra root.
    """
    coefficients = list(coefficients)
    while len(coefficients) > 1 and coefficients[-1] == 0:
        coefficients.pop()
    derivative = [i * coefficients[i] for i in range(1, len(coefficients))]
    critical = []
    if len(derivative) == 3 and derivative[2]:
        c, b, a = derivative
        discriminant = b * b - 4 * a * c
        if discriminant >= 0:
            square = mp.sqrt(mnumber(discriminant))
            critical.extend(((-mnumber(b) - square) / (2 * mnumber(a)),
                             (-mnumber(b) + square) / (2 * mnumber(a))))
    elif len(derivative) >= 2 and derivative[1]:
        critical.append(-mnumber(derivative[0]) / mnumber(derivative[1]))
    cuts = [mp.mpf(0)] + sorted(set(t for t in critical if 0 < t < 1)) + [mp.mpf(1)]
    for t in cuts[1:-1]:
        assert abs(polynomial(coefficients, t)) > mp.mpf('1e-60'), 'ambiguous oracle tangency'
    found = []
    if coefficients[0] == 0:
        found.append((mp.mpf(0), True))
    if sum(coefficients, Fraction(0)) == 0:
        found.append((mp.mpf(1), True))
    for lo, hi in zip(cuts, cuts[1:]):
        flo, fhi = polynomial(coefficients, lo), polynomial(coefficients, hi)
        if flo * fhi >= 0:
            continue
        for _ in range(160):
            mid = (lo + hi) / 2
            fmid = polynomial(coefficients, mid)
            if fmid == 0:
                lo = hi = mid
                break
            if flo * fmid < 0:
                hi, fhi = mid, fmid
            else:
                lo, flo = mid, fmid
        found.append(((lo + hi) / 2, False))
    return sorted(found)


def verify_gates(candidate, route):
    owners, q, rows = candidate['owners'], candidate['q'], candidate['coefficients']
    names = [o['id'] for o in route['occurrences']]
    ends = [mp.mpf(0)]
    for owner in names:
        final = max(i for i, value in enumerate(owners) if value[0] == owner)
        ends.append(mnumber(q[final + 1]))
    results = []
    for j, portal in enumerate(route['transitions']):
        a, b = [[Fraction(v) for v in point] for point in portal['gate']]
        gx, gy = b[0] - a[0], b[1] - a[1]
        norm2 = gx * gx + gy * gy
        matches = []
        for i, coefficient in enumerate(rows):
            if owners[i][0] not in (portal['from'], portal['to']):
                continue
            cx, cy = [[Fraction(v) for v in row] for row in coefficient]
            f = [gx * cy[k] - gy * cx[k] for k in range(4)]
            f[0] -= gx * a[1] - gy * a[0]
            for t, endpoint in roots_on_unit_interval(f):
                x, y = polynomial(cx, t), polynomial(cy, t)
                projection = mnumber(gx) * (x - mnumber(a[0])) + mnumber(gy) * (y - mnumber(a[1]))
                if projection < 0 or projection > mnumber(norm2):
                    continue
                assert 0 < projection < mnumber(norm2), (portal['id'], 'gate endpoint')
                direction = polynomial([k * f[k] for k in range(1, 4)], t) / mp.sqrt(mnumber(norm2))
                assert direction < -mp.mpf('1e-9'), (portal['id'], 'direction')
                actual_q = mnumber(q[i]) + t * (mnumber(q[i + 1]) - mnumber(q[i]))
                delta = actual_q - ends[j + 1]
                if j == len(names) - 1 and owners[i][0] == names[0]:
                    delta = actual_q
                assert -mnumber(portal['before_m']) <= delta <= mnumber(portal['after_m'])
                assert Polygon(portal['support']).contains(Point(float(x), float(y)))
                duplicate = any(endpoint and old[2] and (
                    (t == 0 and old[1] == 1 and (old[0] + 1) % len(rows) == i) or
                    (t == 1 and old[1] == 0 and (i + 1) % len(rows) == old[0])) for old in matches)
                if not duplicate:
                    matches.append((i, t, endpoint, actual_q, direction))
        assert len(matches) == 1, (portal['id'], 'independent finite-root count', len(matches))
        segment, t, _, actual_q, direction = matches[0]
        reported = next(g for g in candidate['geometry']['gates'] if g['portal_id'] == portal['id'])
        assert reported['segment'] == segment, (portal['id'], segment, reported)
        assert mnumber(reported['t0']) <= t <= mnumber(reported['t1']), (portal['id'], str(t), reported)
        assert direction <= mnumber(reported['signed_direction_upper']) + mp.mpf('1e-60')
        results.append({'portal_id': portal['id'], 'segment': segment, 't_80digits': str(t),
                        'q_80digits': str(actual_q), 'normal_direction_80digits': str(direction)})
    return results


def main():
    pipeline_path = (Path(sys.argv[1]) if len(sys.argv) > 1 else PIPELINE).resolve()
    assert SOURCE_IDENTITY.read_text().splitlines()[0] == EXPECTED_SOURCE
    original = json.loads(pipeline_path.read_bytes())
    actual = original['scenarios']
    body = {'front_m': .1, 'rear_m': .1, 'width_m': .12, 'margin_m': .01}
    assert original['footprint'] == body
    reports = {}
    for name, candidate in actual.items():
        route = json.loads((FIX / (name + '.json')).read_bytes())
        route_hash = hashlib.sha256(json.dumps(canonical(route), sort_keys=True,
            separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode('utf-8')).hexdigest()
        assert route_hash == candidate['route_sha256']
        authority = {k: candidate[k] for k in ('coefficients', 'owners', 'q', 'numeric_policy')}
        authority['route_digest'] = route_hash
        authority_hash = hashlib.sha256(json.dumps(authority, sort_keys=True,
            separators=(',', ':'), allow_nan=False).encode('utf-8')).hexdigest()
        assert authority_hash == candidate['expected_curve_digest']
        assert authority_hash == candidate['geometry']['curve_digest'] == candidate['dynamics']['curve_digest']
        assert authority_hash == candidate['retimer']['profile']['curve_digest']
        occurrences = {o['id']: Polygon(o['right'] + list(reversed(o['left'])))
                       for o in route['occurrences']}
        selected = [o['id'] for o in route['occurrences']]
        actual_order = [owner[0] for i, owner in enumerate(candidate['owners'])
                        if i == 0 or owner[0] != candidate['owners'][i - 1][0]]
        assert actual_order == selected
        assert len(candidate['q']) == len(candidate['coefficients']) + 1
        assert candidate['q'][0] == 0
        assert all(a < b for a, b in zip(candidate['q'], candidate['q'][1:]))
        portals = {p['id']: p for p in route['transitions']}
        domains = {p['id']: occurrences[p['from']].union(occurrences[p['to']]).intersection(
            Polygon(p['support'])) for p in route['transitions']}
        report = candidate['geometry']
        assert report['status'] == 'PASS'
        for segment in range(len(candidate['coefficients'])):
            partition = sorted((Fraction(*leaf['exact_t0']), Fraction(*leaf['exact_t1']))
                               for leaf in report['intervals'] if leaf['segment'] == segment)
            assert partition and partition[0][0] == 0 and partition[-1][1] == 1
            assert all(a[1] == b[0] for a, b in zip(partition, partition[1:]))
        minimum, maximum_curvature, minimum_speed = math.inf, 0., math.inf
        largest_motion_ratio, checked = 0., 0
        for leaf in report['intervals']:
            rows = candidate['coefficients'][leaf['segment']]
            owner = candidate['owners'][leaf['segment']][0]
            assert leaf['occurrence_id'] == owner
            if leaf['portal_id']:
                portal = portals[leaf['portal_id']]
                assert owner in (portal['from'], portal['to'])
                source_final = max(i for i, value in enumerate(candidate['owners'])
                                   if value[0] == portal['from'])
                end = Fraction(candidate['q'][source_final + 1])
                q0, q1 = (Fraction(value) for value in candidate['q'][leaf['segment']:leaf['segment'] + 2])
                qlo = q0 + Fraction(*leaf['exact_t0']) * (q1 - q0)
                qhi = q0 + Fraction(*leaf['exact_t1']) * (q1 - q0)
                if portal['to'] == selected[0] and owner == selected[0]:
                    dlo, dhi = qlo, qhi
                else:
                    dlo, dhi = qlo - end, qhi - end
                assert -Fraction(portal['before_m']) <= dlo <= dhi <= Fraction(portal['after_m'])
                domain = domains[leaf['portal_id']]
            else:
                domain = occurrences[owner]
            lo, hi = fraction(leaf['exact_t0']), fraction(leaf['exact_t1'])
            mid_p, mid_body, _, _ = body_at(rows, (lo + hi) / 2, body)
            for j in range(5):
                t = lo + (hi - lo) * D(j) / 4
                p, corners, speed, curvature = body_at(rows, t, body)
                rectangle = Polygon([(float(x), float(y)) for x, y in corners])
                assert domain.covers(rectangle), (name, leaf['segment'], str(t), 'outside')
                clearance = domain.boundary.distance(rectangle)
                assert clearance > body['margin_m'] + 1e-10, (name, leaf['segment'], clearance)
                assert curvature <= exact(leaf['curvature_upper']), (name, leaf['segment'], 'K')
                assert leaf['curvature_upper'] <= 1., (name, leaf['segment'], 'independent limit')
                assert speed >= exact(leaf['speed_lower']), (name, leaf['segment'], 'speed')
                if leaf['method'] == 'rectangle_curvature_sweep':
                    motion = max(sum((x - y) ** 2 for x, y in zip(point, midpoint)).sqrt()
                                 for point, midpoint in zip(corners, mid_body))
                else:
                    motion = sum((x - y) ** 2 for x, y in zip(p, mid_p)).sqrt()
                allowed = exact(leaf['displacement_upper_m']) + exact(leaf['numeric_error_m'])
                assert motion <= allowed, (name, leaf['segment'], 'motion', str(motion), str(allowed))
                largest_motion_ratio = max(largest_motion_ratio, float(motion / allowed))
                minimum = min(minimum, clearance)
                maximum_curvature = max(maximum_curvature, float(curvature))
                minimum_speed = min(minimum_speed, float(speed))
                checked += 1
        reports[name] = {'actual_curve_digest': authority_hash,
                         'sampled_rectangles': checked, 'certificate_leaves': len(report['intervals']),
                         'minimum_reported_certificate_slack_m': min(
                             leaf['clearance_lower_m'] - leaf['displacement_upper_m'] -
                             leaf['required_margin_m'] - leaf['numeric_error_m']
                             for leaf in report['intervals']),
                         'minimum_sampled_body_clearance_m': minimum,
                         'maximum_sampled_abs_curvature_per_m': maximum_curvature,
                         'minimum_sampled_parameter_speed': minimum_speed,
                         'maximum_sampled_motion_to_certified_bound_ratio': largest_motion_ratio,
                         'independent_directed_gates': verify_gates(candidate, route)}
    manifest = json.loads(SOURCE_MANIFEST.read_bytes())
    production = [ROOT / p for p in manifest if p.startswith('planner/global_planner/global_planner/')]
    for path in production:
        assert hashlib.sha256(path.read_bytes()).hexdigest() == manifest[str(path.relative_to(ROOT))]
    paths = [pipeline_path, SOURCE_MANIFEST, SOURCE_IDENTITY, Path(__file__)] + production + [FIX / (n + '.json') for n in actual]
    result = {'scope': 'Independent falsification only; sampled results do not certify continua',
              'reviewed_source_sha': EXPECTED_SOURCE,
              'oracle': '80-digit Decimal exact-binary64 differentiation and normalization; GEOS polygon union/intersection/containment/distance; 80-digit analytic derivative-root decomposition plus bisection for directed finite gates',
              'python': platform.python_version(), 'shapely': shapely.__version__,
              'mpmath': mp.__version__, 'geos': shapely.geos_version_string, 'reports': reports,
              'sha256': {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}}
    output = Path(sys.argv[2]) if len(sys.argv) > 2 else Path(__file__).with_name('independent-final-oracle-result.json')
    output.write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
    print(json.dumps(reports, indent=2))


if __name__ == '__main__':
    mp.mp.dps = 80
    with localcontext() as context:
        context.prec = 80
        main()
