"""New independent numerical/geometry falsification controls (no source mutation)."""
from decimal import Decimal as D, localcontext
from fractions import Fraction as F
import math
import random

from global_planner import route_validate as production


def test_sqrt_outward_inequalities_are_exact_rational_at_extreme_scales():
    rng = random.Random(271829)
    for exponent in range(-2200, 2201, 7):
        multiplier = F(rng.randrange(1, 2 ** 62), rng.randrange(1, 2 ** 62))
        x = multiplier * (F(2 ** exponent) if exponent >= 0 else F(1, 2 ** -exponent))
        try:
            low, high = production._sqrt(x, False), production._sqrt(x, True)
        except production.BoundUncertain:
            continue
        assert 0 <= low <= high
        assert F(low) ** 2 <= x <= F(high) ** 2, (exponent, low, high)


def test_normalization_allowance_encloses_exact_decimal_rectangle():
    # Exactly straight but severe endpoint cancellation, generic non-dyadic
    # directions, near-singular derivatives and many footprint scales.
    families = [((0., 129.49704339477165, -80.92011912710188, 10.781064989810702),
                 (0., 194.24556509215748, -121.38017869065283, 16.171597484716052)),
                ((1e5, 1.01e-7, 2e-13, 0.), (-1e5, -3.99e-8, 3e-13, 0.)),
                ((-1e5, 1e7, -1e7, 1e7), (1e5, -1e7, 1e7, -1e7))]
    with localcontext() as context:
        context.prec = 100
        for rows in families:
            coeff = production._coefficient_records(rows)
            for numerator in range(33):
                t = F(numerator, 32)
                lo, hi = max(F(0), t - F(1, 2 ** 28)), min(F(1), t + F(1, 2 ** 28))
                try:
                    bounds = production.interval_bounds(coeff, lo, hi)
                except production.BoundUncertain:
                    continue
                td = D(t.numerator) / D(t.denominator)
                exact_rows = [[D.from_float(v) for v in row] for row in rows]
                position = [a + td * (b + td * (c + td * d)) for a, b, c, d in exact_rows]
                derivative = [b + 2 * td * c + 3 * td * td * d for a, b, c, d in exact_rows]
                speed = sum(d * d for d in derivative).sqrt()
                tangent = [d / speed for d in derivative]
                for scale in (1e-200, 1e-5, 1., 1e5, 1e100):
                    body = production.Footprint(.13 * scale, .7 * scale, .27 * scale, 0.)
                    rectangle, error = production._rectangle(coeff, t, body, bounds)
                    front, rear, half = D.from_float(body.front_m), D.from_float(body.rear_m), D.from_float(body.width_m) / 2
                    for actual, (x, y) in zip(rectangle, ((front, half), (-rear, half), (-rear, -half), (front, -half))):
                        expected = [position[0] + x * tangent[0] - y * tangent[1],
                                    position[1] + x * tangent[1] + y * tangent[0]]
                        error2 = sum((D(p.numerator) / D(p.denominator) - q) ** 2
                                     for p, q in zip(actual, expected))
                        assert error2.sqrt() <= D.from_float(error)


def test_bernstein_whole_interval_bounds_against_high_precision_random_cubics():
    rng = random.Random(219912)
    exercised = 0
    with localcontext() as context:
        context.prec = 100
        for case in range(250):
            scale = 2. ** rng.randrange(-22, 23)
            rows = tuple(tuple(scale * rng.uniform(-2, 2) for _ in range(4)) for _ in range(2))
            lo = F(rng.randrange(0, 240), 256)
            hi = min(F(1), lo + F(rng.randrange(1, 17), 256))
            try:
                bounds = production.interval_bounds(rows, lo, hi)
            except production.BoundUncertain:
                continue
            exact_rows = [[D.from_float(v) for v in row] for row in rows]
            for j in range(9):
                t = lo + (hi - lo) * F(j, 8)
                td = D(t.numerator) / D(t.denominator)
                d = [b + 2 * td * c + 3 * td * td * k for a, b, c, k in exact_rows]
                dd = [2 * c + 6 * td * k for a, b, c, k in exact_rows]
                jerk = [6 * k for a, b, c, k in exact_rows]
                g = sum(x * x for x in d)
                speed = g.sqrt()
                cross = d[0] * dd[1] - d[1] * dd[0]
                cp = d[0] * jerk[1] - d[1] * jerk[0]
                gp = 2 * sum(x * y for x, y in zip(d, dd))
                curvature = abs(cross) / speed ** 3
                rate = abs(2 * cp * g - 3 * cross * gp) / (2 * g ** 3)
                assert D.from_float(bounds.speed_lower) <= speed <= D.from_float(bounds.speed_upper)
                assert curvature <= D.from_float(bounds.curvature_upper)
                assert rate <= D.from_float(bounds.curvature_rate_upper)
                exercised += 1
    assert exercised >= 2000
