# A05 complete-curve handoff binding remediation

Applied only `planner/global_planner/global_planner/route_validate.py` and
`planner/global_planner/test/test_route_validate_geometry.py` after the root
reviewer released Phase II on a completed stable baseline. No W1 geometry,
numerical tolerance, margin, domain, gate predicate or swept bound changed.

Both geometry and the public dynamics facade now accept keyword-only
`expected_curve_digest`. Missing independent authority returns INCONCLUSIVE;
malformed pins and mismatches return FAIL. Geometry independently rehashes
actual canonical coefficients, owners, q, approved-route digest and numerical
policy. It does not call the optimizer digest helper. The caller must retain
the expected hash at a trusted handoff before intermediate mutation. Hashing
the received candidate cannot independently establish historical q inheritance.
The report appends `curve_digest`, preserving prior positional field meanings,
and every report path records the recomputed identity once available.

New regressions cover missing/malformed authority, mismatched valid pins,
internally monotone q forgery retaining the exact coefficients/owners, a poisoned
optimizer digest helper, and agreement of PASS report identity with the caller's
retained authority. Existing geometry adversaries still exercise intrinsic
malformed ownership, curve metadata, gates, unsupported geometry, margins and
budget checks. All existing geometry callsites migrated to explicit handoff pins.

Verification:

* Original failing-first run: `scripts/project_a/unit.sh
  work/adversarial/geometry/authority-red
  work/adversarial/geometry/test_geometry_authority_failing_first.py` — one
  failed in 7.26 s, observed original PASS where independent authority was absent.
* Before modifying implementation, the complete proposed files were exercised
  through a scratch import hook: `scripts/project_a/unit.sh
  work/adversarial/geometry/authority-proposed
  work/adversarial/geometry/proposed/test_route_validate_geometry.py` — 40
  passed in 90.26 s, exit 0, frozen implementation unchanged. One subsequent
  formatting-only line wrap corrected the sole 100-column line.
* Applied source and tests: `scripts/project_a/unit.sh
  work/adversarial/geometry/authority-green
  planner/global_planner/test/test_route_validate_geometry.py` — test bodies
  40 passed in 96.52 s. The harness correctly invalidated acceptance because
  other reviewers' authorized source copies occurred during this run. Exit 1,
  retained intact; this is not presented as final acceptance evidence. Root
  review owns the complete frozen-source final verification.
* Applied files pass syntax compilation, `git diff --check`, and isolated pinned
  Python3.10 `python -m flake8 --max-line-length=99` on both files (exit 0).

No additional false-positive intrinsic geometric enclosure defect was found.
Phase-I high-precision / GEOS controls and all original failed experiments remain
unchanged. Root review owns the coherent corrective commit, remote push, complete
final verification and exact-head CI; this agent made no commit or push.
