"""Load the proposed validator without changing the frozen source checkout."""
import importlib.util
from pathlib import Path
import sys

import global_planner

_SPEC = importlib.util.spec_from_file_location(
    'global_planner.route_validate', Path(__file__).with_name('route_validate.py'))
_MODULE = importlib.util.module_from_spec(_SPEC)
sys.modules[_SPEC.name] = _MODULE
_SPEC.loader.exec_module(_MODULE)
global_planner.route_validate = _MODULE
