"""Opt-in hypothetical one-line repair without editing frozen implementation."""
import inspect

import pytest

from global_planner import _route_geometry as geometry
from global_planner import route_corridor as corridor


def pytest_addoption(parser):
    parser.addoption('--canonical-shared-cap', action='store_true')


@pytest.fixture(autouse=True)
def proposed_edge_canonicalization(request, monkeypatch):
    if not request.config.getoption('--canonical-shared-cap'):
        return
    source = inspect.getsource(geometry.line_intervals)
    source = source.replace('    for a, b in edges(poly):\n',
                            '    for a, b in edges(poly):\n'
                            '        if b < a:\n'
                            '            a, b = b, a\n')
    namespace = vars(geometry).copy()
    exec(compile(source, '<proposed lexicographic edge orientation>', 'exec'), namespace)
    function = namespace['line_intervals']
    monkeypatch.setattr(geometry, 'line_intervals', function)
    monkeypatch.setattr(corridor, 'line_intervals', function)
