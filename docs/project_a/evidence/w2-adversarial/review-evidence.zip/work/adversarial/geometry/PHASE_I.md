# A05 independent adversarial investigation

Reviewed source: `e852641849b2497efea51dfca5ead38ad4476235`; implementation source
remained unchanged during this investigation. Repository-local instructions,
execution plan, W2 numerics, status/results/decisions, and canonical architecture /
roadmap were read as reference claims, not independently established facts.

## Actual implementation inventory and mathematical reconstruction

`route_validate.py` rebuilds route and Curve authorities, checks q occurrence
anchors/owners, reconstructs exact rational original polygons and shared-cap
stitched unions, isolates directed finite-gate roots, then adaptively certifies
all exact rational subintervals. All polynomial products, Bernstein conversion,
polygon parity/intersection predicates and segment-distance squares use Fraction.
It shares Curve reconstruction / NumericalPolicy with W1; it never reads solver
residuals, optimizer widths or sampled headings to grant geometry acceptance.

For d=r', c=cross(d,d'), g=d.d, exact derivative Bernstein boxes give positive
g_min and V. The implementation's K=|c|/g_min^(3/2) and
K_s=|2*c'*g-3*c*g'|/(2*g_min^3) are correctly derived. Speed-squared upper
bounds use convexity of squared norm on the derivative Bezier control hull.
Unresolved derivative boxes require subdivision, not sampled regularity.

For a body offset a with |a|<=R and arclength parameter s,
P(s)=r(s)+Rot(theta(s))*a, P_s=T+kappa*J*Rot(theta)*a, hence
|P_s|<=1+R*K. Integrating from a parameter midpoint, with
Delta_s<=V*dt/2, gives the implemented (1+R*K)*V*dt/2 bound. The enclosing-disc
alternative follows independently from |r(t)-r(mid)|<=V*dt/2 and |a|<=R.
Both checks demand strict greater-than clearance after the original legal margin
and stated numerical allowance. Interval budgets exhaust to INCONCLUSIVE.

Original polygon handling checks the entire rectangle, including edge crossings
and polygon vertices inside the body. Shared cap removal requires exact endpoint
equality and a simple stitched polygon; holes / unknown schema extensions reject.
Unrelated projected surfaces cannot contribute legal area. Gate isolation uses
exact Bernstein sign variation, including exact endpoint roots, and cannot
replace an unresolved tangency with a sampled crossing. Gate-root and continuous
interval budgets are independent and partial certificates cannot grant PASS.

## Executed independent controls

1. `work/adversarial/geometry/oracle-venv/bin/python
   work/adversarial/geometry/independent_oracle.py` — PASS. The script imports no
   production geometry / predicate / bound helper. It reconstructs every frozen
   candidate's actual rectangle using 80-digit Decimal differentiation and
   normalization, then GEOS/Shapely 2.1.2 independently checks polygon union /
   intersection, full-body containment, and distance. All 7,705 sampled bodies
   across the seven actual candidates remain legal with original 0.01 m margin;
   minimum sampled body clearance is 0.019275699389656977 m. Independently
   differentiated speed / curvature and body-point movement remain enclosed by
   every tested certificate leaf. Maximum movement-to-bound ratio is
   0.9999780322709407. These are falsification controls, not continuum proofs.
   Input/source hashes and exact versions are in independent-oracle-result.json.
2. `scripts/project_a/unit.sh work/adversarial/geometry/runtime-primitives
   work/adversarial/geometry/test_adversarial_geometry.py` — exit 0, 3 passed in
   1.07 s. Python3.10.12 / ROS Humble, nonroot, read-only source/root, network none,
   zero capabilities, no-new-privileges. All source hashes remained unchanged.
   Exact rational squared inequalities challenge sqrt conversion for 629
   exponent cases spanning [-2200,2200]. 250 random cubics challenge independent
   100-digit speed/curvature/rate bounds. Severe derivative cancellation,
   near-singular derivatives, large translations and footprint scales
   1e-200..1e100 challenge midpoint normalization allowances.

## Findings and limitations

No false-positive planar containment or swept-body enclosure was demonstrated.
The reported approximately 8.95e-5 m minimum certificate slack is not consumed
by a newly discovered error in the tested rational or normalization bounds.

The integration reviewer independently demonstrated coordinated internal-q
tampering that moves a narrow cap and is accepted by both validators after
updating the candidate profile digest. A05 only verifies monotonic q, exact
occurrence anchors and owners. Actual final coefficients alone cannot prove
historical W1 q inheritance. A separate independently retained complete curve
handoff authority must bind coefficients, q, owners, approved route and numerical
policy; recomputing a hash from the already corrupted candidate cannot do so.
The root review owns severity, minimal full-pipeline reproducer and remediation.

Curve's numerical join tests still use binary64 endpoint/frame evaluation.
A mathematically straight cubic with x=(0,129.49704339477165,
-80.92011912710188,10.781064989810702), y=1.5*x exactly, has a float endpoint
tangent error of 7.95e-8 radians due derivative cancellation near 1.1e-7
parameter speed. This is NOT a complete accepted curve counterexample: its
float endpoint curvature also becomes large, and full reconstruction / joining
requirements remain applicable. It must not be promoted to a demonstrated
false-PASS finding. Exact join certification remains a precision limitation to
state; individual A05 closed-interval body certificates enclose both one-sided
endpoint footprints.
