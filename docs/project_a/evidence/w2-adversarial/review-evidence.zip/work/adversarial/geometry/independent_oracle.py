"""Independent 80-digit coefficient and GEOS geometry campaign, read-only source.

This is a falsification oracle, not a sampled replacement for certification.
It imports no production geometry, Bernstein, polygon, or corridor helper.
"""
from decimal import Decimal as D, localcontext
import gzip
import hashlib
import json
import math
from pathlib import Path
import platform
import sys

import shapely
from shapely.geometry import Polygon

ROOT = Path(__file__).resolve().parents[3]
FIX = ROOT / 'planner/global_planner/test/fixtures/project_a'
EVIDENCE = ROOT / 'docs/project_a/evidence/w2-a05/a05-geometry.json.gz'


def exact(value):
    return D.from_float(float(value))


def evaluate(rows, t):
    a = [[exact(v) for v in row] for row in rows]
    p = [row[0] + t * (row[1] + t * (row[2] + t * row[3])) for row in a]
    d = [row[1] + 2 * t * row[2] + 3 * t * t * row[3] for row in a]
    dd = [2 * row[2] + 6 * t * row[3] for row in a]
    speed = sum(v * v for v in d).sqrt()
    tangent = [v / speed for v in d]
    curvature = abs(d[0] * dd[1] - d[1] * dd[0]) / speed ** 3
    return p, tangent, speed, curvature


def body_at(rows, t, body):
    p, tangent, speed, curvature = evaluate(rows, t)
    front, rear, half = exact(body['front_m']), exact(body['rear_m']), exact(body['width_m']) / 2
    corners = [[p[0] + x * tangent[0] - y * tangent[1],
                p[1] + x * tangent[1] + y * tangent[0]]
               for x, y in ((front, half), (-rear, half), (-rear, -half), (front, -half))]
    return p, corners, speed, curvature


def fraction(pair):
    return D(pair[0]) / D(pair[1])


def main():
    candidate_path = FIX / 'w2_a04_candidates.json.gz'
    frozen = json.loads(gzip.decompress(candidate_path.read_bytes()))['candidates']
    original = json.loads(gzip.decompress(EVIDENCE.read_bytes()))
    body = original['footprint']
    reports = {}
    for name, candidate in frozen.items():
        route = json.loads((FIX / (name + '.json')).read_bytes())
        occurrences = {o['id']: Polygon(o['right'] + list(reversed(o['left'])))
                       for o in route['occurrences']}
        domains = {p['id']: occurrences[p['from']].union(occurrences[p['to']]).intersection(
            Polygon(p['support'])) for p in route['transitions']}
        report = original['reports'][name]
        assert report['status'] == 'PASS'
        minimum, maximum_curvature, minimum_speed = math.inf, 0., math.inf
        largest_motion_ratio, checked = 0., 0
        for leaf in report['intervals']:
            rows = candidate['coefficients'][leaf['segment']]
            domain = domains[leaf['portal_id']] if leaf['portal_id'] else occurrences[leaf['occurrence_id']]
            lo, hi = fraction(leaf['exact_t0']), fraction(leaf['exact_t1'])
            mid_p, mid_body, _, _ = body_at(rows, (lo + hi) / 2, body)
            for j in range(5):
                t = lo + (hi - lo) * D(j) / 4
                p, corners, speed, curvature = body_at(rows, t, body)
                rectangle = Polygon([(float(x), float(y)) for x, y in corners])
                assert domain.covers(rectangle), (name, leaf['segment'], str(t), 'outside')
                clearance = domain.boundary.distance(rectangle)
                assert clearance > body['margin_m'] + 1e-10, (name, leaf['segment'], clearance)
                assert curvature <= exact(leaf['curvature_upper']), (name, leaf['segment'], 'K')
                assert speed >= exact(leaf['speed_lower']), (name, leaf['segment'], 'speed')
                if leaf['method'] == 'rectangle_curvature_sweep':
                    motion = max(sum((x - y) ** 2 for x, y in zip(point, midpoint)).sqrt()
                                 for point, midpoint in zip(corners, mid_body))
                else:
                    motion = sum((x - y) ** 2 for x, y in zip(p, mid_p)).sqrt()
                allowed = exact(leaf['displacement_upper_m']) + exact(leaf['numeric_error_m'])
                assert motion <= allowed, (name, leaf['segment'], 'motion', str(motion), str(allowed))
                largest_motion_ratio = max(largest_motion_ratio, float(motion / allowed))
                minimum = min(minimum, clearance)
                maximum_curvature = max(maximum_curvature, float(curvature))
                minimum_speed = min(minimum_speed, float(speed))
                checked += 1
        reports[name] = {'sampled_rectangles': checked, 'certificate_leaves': len(report['intervals']),
                         'minimum_sampled_body_clearance_m': minimum,
                         'maximum_sampled_abs_curvature_per_m': maximum_curvature,
                         'minimum_sampled_parameter_speed': minimum_speed,
                         'maximum_sampled_motion_to_certified_bound_ratio': largest_motion_ratio}
    paths = [candidate_path, EVIDENCE, Path(__file__)] + [FIX / (n + '.json') for n in frozen]
    result = {'scope': 'Independent falsification only; sampled results do not certify continua',
              'oracle': '80-digit Decimal exact-binary64 differentiation and normalization; GEOS polygon union/intersection/containment/distance',
              'python': platform.python_version(), 'shapely': shapely.__version__,
              'geos': shapely.geos_version_string, 'reports': reports,
              'sha256': {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}}
    output = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).with_name('independent-oracle-result.json')
    output.write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
    print(json.dumps(reports, indent=2))


if __name__ == '__main__':
    with localcontext() as context:
        context.prec = 80
        main()
