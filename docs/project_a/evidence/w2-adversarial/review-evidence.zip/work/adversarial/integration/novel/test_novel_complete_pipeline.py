"""New analytic varying-width ellipse, independent of retained seven fixtures."""
from dataclasses import asdict
import hashlib
import json
import math
from pathlib import Path
import sys
import time

import numpy as np
from scipy.integrate import quad

from global_planner.cyclic_retime import (
    DynamicsModel, ModelRegion, RegionLimits, SteeringLimits, curve_digest, retime)
from global_planner.iqp_route_adapter import optimize
from global_planner.route_input import validate_route
from global_planner.route_validate import Footprint, validate_geometry
from global_planner.route_validate_dynamics import validate_dynamics

OUT = Path('/work')
BODY = Footprint(.1, .1, .12, .01)


def generated_route():
    # Construct all geometry analytically; no existing route fixture is read.
    a, b, angle, count = 9.7, 4.6, .37, 128
    rotation = np.array(((math.cos(angle), -math.sin(angle)),
                         (math.sin(angle), math.cos(angle))))
    translation = np.array((19.25, -7.5))
    seed, left, right, tangent, normal = [], [], [], [], []
    for index in range(count):
        theta = 2 * math.pi * index / count
        center = rotation @ np.array((a * math.cos(theta), b * math.sin(theta))) + translation
        derivative = rotation @ np.array((-a * math.sin(theta), b * math.cos(theta)))
        direction = derivative / np.linalg.norm(derivative)
        inward = np.array((-direction[1], direction[0]))
        lw, rw = .7 + .1 * math.cos(3 * theta), .55 + .1 * math.sin(2 * theta)
        seed.append(center.tolist())
        left.append((center + lw * inward).tolist())
        right.append((center - rw * inward).tolist())
        tangent.append(direction)
        normal.append(inward)
    for values in (seed, left, right):
        values.append(values[0])  # Exact shared periodic endpoint identity.
    provenance = {'author': 'independent W2 adversarial reviewer',
                  'source': 'analytic ellipse with sinusoidal asymmetric borders; synthetic only',
                  'revision': 'independent-novel-v1', 'approval': 'synthetic software tests only'}
    occurrences = []
    for index in range(4):
        begin, finish = 32 * index, 32 * (index + 1)
        caps = [{'at_m': 0., 'max_speed_mps': 4.}]
        if index == 1:
            caps += [{'at_m': 1.37, 'max_speed_mps': 1.},
                     {'at_m': 1.87, 'max_speed_mps': 4.}]
        occurrences.append({'id': 'e' + str(index), 'surface_id': 'analytic-planar',
                            'seed': seed[begin:finish + 1], 'left': left[begin:finish + 1],
                            'right': right[begin:finish + 1], 'caps': caps,
                            'provenance': provenance})

    def support(index):
        c, t, n = np.asarray(seed[index]), tangent[index], normal[index]
        return [(c + u * t + v * n).tolist() for u, v in
                ((-.6, -1.4), (.6, -1.4), (.6, 1.4), (-.6, 1.4))]

    transitions = []
    for index in range(4):
        end = 32 * (index + 1) % count
        transitions.append({'id': 'g' + str(index), 'from': 'e' + str(index),
                            'to': 'e' + str((index + 1) % 4),
                            'gate': [right[end], left[end]], 'support': support(end),
                            'before_m': .3, 'after_m': .3, 'continuity': 'shared_endcap',
                            'provenance': provenance})
    payload = {'schema_version': 1, 'course_id': 'independent-novel-varying-ellipse',
               'route_id': 'novel-ellipse-v1', 'frame_id': 'independent-synthetic-map',
               'units': 'm', 'conventions': 'x-forward_y-left_heading-ccw',
               'physical_map': {'sha256': hashlib.sha256(
                   b'no-physical-map:independent-novel-analytic-ellipse').hexdigest(),
                   'frame_id': 'independent-synthetic-map', 'registration': [0., 0., 0.],
                   'coverage': 'unknown', 'provenance': provenance},
               'provenance': provenance,
               'surfaces': [{'id': 'analytic-planar', 'kind': 'planar',
                             'provenance': provenance}],
               'occurrences': occurrences, 'transitions': transitions,
               'gate_sequence': [tr['id'] for tr in transitions], 'finish': 'g3',
               'initialization': {'occurrence_id': 'e0', 'seed_interval_m': [0., .2],
                                  'zone': support(0),
                                  'heading_interval_rad': [-math.pi, math.pi]}}
    return payload


def polynomial(coefficients, t, order=0):
    c = np.asarray(coefficients)
    if order == 1:
        return c[:, 1] + t * (2 * c[:, 2] + 3 * t * c[:, 3])
    if order == 2:
        return 2 * c[:, 2] + 6 * t * c[:, 3]
    return c[:, 0] + t * (c[:, 1] + t * (c[:, 2] + t * c[:, 3]))


def arc(coefficients, first=0., last=1.):
    result, error = quad(lambda t: math.hypot(*polynomial(coefficients, t, 1)),
                         first, last, epsabs=2e-13, epsrel=2e-13)
    assert error < 1e-10
    return result


def sampled_oracle(ordered, timed, supplied):
    # Imported from the independent geometry review's pinned, retained wheel.
    try:
        from shapely.geometry import Polygon
        from shapely.ops import unary_union
        import shapely
    except ImportError:
        Polygon = None
        shapely = None
    occurrences = ordered.route.occurrences
    ends = [0.]
    for occurrence in occurrences:
        ends.append(ends[-1] + occurrence.length)
    polygons = [Polygon(o.polygon) for o in occurrences] if Polygon else []
    supports = [Polygon(p.support) for p in ordered.route.portals] if Polygon else []
    unions = [unary_union((polygons[i], polygons[(i + 1) % 4]))
              .intersection(supports[i]) for i in range(4)] if Polygon else []
    min_clearance, geometry_bad, max_curvature = math.inf, [], 0.
    for i, coefficients in enumerate(ordered.curve.coefficients):
        owner = next(j for j, o in enumerate(occurrences)
                     if o.id == ordered.curve.owners[i][0])
        for t in np.linspace(0., 1., 19):
            p = polynomial(coefficients, t)
            d, dd = polynomial(coefficients, t, 1), polynomial(coefficients, t, 2)
            speed = math.hypot(*d)
            curvature = abs(d[0] * dd[1] - d[1] * dd[0]) / speed ** 3
            max_curvature = max(max_curvature, curvature)
            if Polygon is None:
                continue
            tangent = d / speed
            normal = np.array((-tangent[1], tangent[0]))
            rectangle = Polygon([(p + x * tangent + y * normal).tolist() for x, y in
                ((BODY.front_m, BODY.width_m / 2), (-BODY.rear_m, BODY.width_m / 2),
                 (-BODY.rear_m, -BODY.width_m / 2), (BODY.front_m, -BODY.width_m / 2))])
            q = (1 - t) * ordered.q[i] + t * ordered.q[i + 1]
            domains = [polygons[owner]]
            for j, portal in enumerate(ordered.route.portals):
                if ordered.curve.owners[i][0] not in (portal.source, portal.target):
                    continue
                delta = q - ends[j + 1]
                if j == 3 and q < ordered.period / 2:
                    delta = q
                if -portal.before - 1e-12 <= delta <= portal.after + 1e-12:
                    domains.append(unions[j])
            clearances = [domain.boundary.distance(rectangle) for domain in domains
                          if domain.covers(rectangle)]
            clearance = max(clearances, default=-math.inf)
            min_clearance = min(min_clearance, clearance)
            if clearance < BODY.margin_m - 2e-10:
                geometry_bad.append((i, float(t), clearance))
    # Reconstruct every profile distance/acceleration/time with distinct QUADPACK
    # integration and sample exact geometric lateral residuals within each edge.
    max_diamond, max_motor, max_lateral = -math.inf, -math.inf, -math.inf
    distances, times, accel_errors = [], [], []
    for i, knot in enumerate(timed.profile.knots):
        following = timed.profile.knots[(i + 1) % len(timed.profile.knots)]
        end = following.t if following.segment == knot.segment else 1.
        coefficients = ordered.curve.coefficients[knot.segment]
        distance = arc(coefficients, knot.t, end)
        acceleration = (following.u - knot.u) / (2 * distance)
        distances.append(distance)
        times.append(2 * distance / (math.sqrt(knot.u) + math.sqrt(following.u)))
        accel_errors.append(abs(acceleration - timed.metadata.acceleration_mps2[i]))
        limits = supplied.regions[0].limits  # Uniform independently supplied model.
        for t in np.linspace(knot.t, end, 13):
            fraction = arc(coefficients, knot.t, float(t)) / distance
            u = knot.u + fraction * (following.u - knot.u)
            d, dd = polynomial(coefficients, t, 1), polynomial(coefficients, t, 2)
            kappa = abs(d[0] * dd[1] - d[1] * dd[0]) / math.hypot(*d) ** 3
            drive = acceleration + limits.drag_over_mass * u
            lateral = kappa * u / limits.ay_mps2
            max_lateral = max(max_lateral, lateral)
            max_diamond = max(max_diamond, drive / limits.ax_pos_mps2 + lateral,
                               -drive / limits.ax_neg_mps2 + lateral)
            max_motor = max(max_motor, drive / limits.motor_mps2)
    return {'geos_available': Polygon is not None,
            'shapely_version': shapely.__version__ if shapely else None,
            'sampled_geometry_points': 19 * len(ordered.curve.segments),
            'sampled_geometry_violations': geometry_bad,
            'sampled_minimum_body_boundary_clearance_m': min_clearance if Polygon else None,
            'sampled_maximum_abs_curvature': max_curvature,
            'independent_quad_length_m': math.fsum(distances),
            'independent_quad_lap_time_s': math.fsum(times),
            'maximum_acceleration_metadata_error_mps2': max(accel_errors),
            'sampled_lateral_utilization_max': max_lateral,
            'sampled_diamond_utilization_max': max_diamond,
            'sampled_motor_utilization_max': max_motor,
            'minimum_speed_mps': min(timed.metadata.velocity_mps),
            'maximum_speed_mps': max(timed.metadata.velocity_mps)}


def test_new_analytic_varying_width_route_complete_pipeline():
    began = time.monotonic()
    report = {'scope': 'independent synthetic planar software only',
              'generation': {'ellipse_semiaxes_m': [9.7, 4.6], 'rotation_rad': .37,
                             'translation_m': [19.25, -7.5], 'seed_intervals': 128,
                             'left_width_m': '.7+.1*cos(3*theta)',
                             'right_width_m': '.55+.1*sin(2*theta)',
                             'interior_cap': {'occurrence': 'e1', 'q_local_m': [1.37, 1.87],
                                              'speed_mps': 1.}},
              'footprint': asdict(BODY)}
    def save():
        report['elapsed_seconds'] = time.monotonic() - began
        (OUT / 'novel-report.json').write_text(json.dumps(report, indent=2, allow_nan=False))
    payload = generated_route()
    (OUT / 'generated-route-raw.json').write_text(json.dumps(payload, indent=2, allow_nan=False))
    try:
        route = validate_route(payload)
        (OUT / 'approved-route.json').write_bytes(route.encoded)
        report['route_digest'] = route.digest
        report['route_file_sha256'] = hashlib.sha256(route.encoded).hexdigest()
        report['input_status'] = 'PASS'
        save()
        numerical = optimize(route)
        report['optimizer'] = {
            'status': numerical.status, 'reason': numerical.reason,
            'policy': asdict(numerical.policy),
            'traces': [asdict(trace) for trace in numerical.traces]}
        if numerical.ordered is not None:
            report['optimizer']['coefficients'] = numerical.ordered.curve.coefficients
            report['optimizer']['q'] = numerical.ordered.q
            report['optimizer']['owners'] = numerical.ordered.curve.owners
        save()
        assert numerical.status == 'CANDIDATE', (numerical.status, numerical.reason)
        expected = curve_digest(numerical.ordered)  # Trusted boundary, captured once.
        report['expected_curve_digest'] = expected
        ordered = numerical.ordered
        geometry = validate_geometry(ordered, route, BODY, expected_curve_digest=expected)
        report['geometry'] = asdict(geometry)
        limits = RegionLimits(.05, 4., 2., 3., 4., 2.5, .02,
                              'independent explicit synthetic diamond/model budgets')
        model = DynamicsModel(tuple(ModelRegion(o.id, o.surface_id, limits)
                                    for o in route.occurrences),
                              'independent novel analytic route; no physical calibration',
                              SteeringLimits(.3, .7, 3.))
        report['model'] = asdict(model)
        timed = retime(ordered, model, spacing_m=.5)
        report['retimer'] = asdict(timed)
        save()
        assert timed.status == 'CANDIDATE', (timed.status, timed.message)
        dynamic = validate_dynamics(ordered, timed.profile, model, metadata=timed.metadata,
                                    expected_curve_digest=expected)
        report['dynamics'] = asdict(dynamic)
        oracle = sampled_oracle(ordered, timed, model)
        report['independent_oracle'] = oracle
        report['combined_pass'] = (geometry.status == dynamic.status == 'PASS' and
            geometry.curve_digest == dynamic.curve_digest == timed.profile.curve_digest == expected)
        save()
        assert report['combined_pass'], (geometry.status, geometry.reason,
                                         dynamic.status, dynamic.reason)
        assert not oracle['sampled_geometry_violations'], oracle
        assert oracle['sampled_diamond_utilization_max'] <= 1 + 1e-8, oracle
        assert oracle['sampled_motor_utilization_max'] <= 1 + 1e-8, oracle
        assert abs(oracle['independent_quad_length_m'] - ordered.curve.length) < 1e-9
        assert dynamic.lap_time_lower_s <= oracle['independent_quad_lap_time_s'] <= \
            dynamic.lap_time_upper_s
        assert oracle['maximum_acceleration_metadata_error_mps2'] < 1e-8
    except Exception as exc:
        report['error'] = type(exc).__name__ + ': ' + str(exc)
        save()
        raise
