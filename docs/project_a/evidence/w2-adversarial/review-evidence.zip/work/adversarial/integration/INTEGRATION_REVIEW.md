# W2 independent cross-module review — Phase I

Reviewed source: `e852641849b2497efea51dfca5ead38ad4476235`.
Corrected W1 baseline: `9440c2ce68e3dee549de7efacff1cf723fe830df`.
Scope: standalone synthetic planar software; no ROS launch, devices or physical deployment.
The implementation remained unmodified during all Phase I probes below.

## Confirmed finding I1 — P1: independent A04 handoff identity is not bound

The existing geometry validator reconstructs original approved route records,
actual coefficients, owners, exact occurrence anchors and numerical policy.
The dynamics validator additionally reconstructs model applicability and verifies
profile/candidate self-digests. Neither receives an independently retained A04
final curve identity. A coordinated downstream mutation of coefficients/q/owners
that remains structurally valid can change that accepted authority while also
replacing all candidate-provided self-digests.

Minimal reproduction: `probe_q_lineage.py` loads the actual S0 A04 coefficients,
adds an original seed-local cap of 0.1 m/s on q=[3,3.01], then changes only internal
q knots by `q+1.5*sin(pi*(q-1)/7)^2` for q in (1,8). This map is strictly monotone,
retains every occurrence anchor, unchanged coefficient geometry, applicable gate
brackets and initialization. It changes where the original local cap is applied.
The retimer regenerates a self-consistent profile and curve digest under this map.

Observed before repair (`phase1/q-lineage-boundary.json`):

- Geometry under changed q: **PASS**.
- Independent dynamics under changed q/profile: **PASS**.
- Same coefficients/profile checked against original handoff q, with the profile
  self-digest recomputed: **FAIL**, original static/model speed violation, edge 14.

This is a missing independent authority boundary, not a defect in the rational
speed inequalities or numerical validity of the changed supplied q map. Final
coefficients cannot uniquely reveal optimizer ancestry: A04 must supply/capture
that authority at the trusted handoff, before subsequent operations. Hashing the
changed input again does not authenticate the original handoff.

Relevant contracts: W2_NUMERICS.md:16–20 carries inherited original q; :64–70
consumes actual coefficients/q and checks exact occurrence anchors/ownership;
:134 transports caps through original q lineage. Architecture:67 defines local
seed-metric caps; :70 inherited segment/t links; :71 and :77 final segment/t
anchors; :118 requires valid q/occurrence order. W1_REMEDIATION_REPORT.md:174–177
states record factories are an internal trust boundary and q is supplied. Thus
there was no pre-existing promise of reconstructing authenticated history from
coefficients alone. The current user's explicit intermediate-tampering scope
requires binding the independently retained A04 output across this boundary.

Required bounded correction: both independent validators require an independently
supplied expected complete curve digest covering exact coefficients, q, owners,
original route and numerical policy. Capture it from trusted/audited A04 output
or explicitly approved synthetic authority before any downstream transformation.
Missing expected authority must not PASS; altered authority must FAIL even if
candidate self-hashes are regenerated. This does not create a fictitious proof
that any arbitrary supplied digest authenticates historical optimization.

Failing-first tests: `test_handoff_binding_regression.py`; execution results and
source/environment manifests in `handoff-red/`. Root review owns remediation and
final exact-head acceptance.

## New independent metamorphic and fault experiments

`test_integration_adversarial.py` uses the actual frozen A04 coefficients from
all-source-hash-checked fixture `w2_a04_candidates.json.gz` (SHA256
`2a506953026b75fc5be4defb1b018577faa46cebdbdfcd767c0103e733b2279b`).
The initial `phase1/` group failed because its proposed 2^20-m translation was
outside the declared 1e5-m input coordinate range. This is a test-domain error,
preserved with the original script/log. The valid-domain 2^14-m experiment is
retained in `phase1b/`.

Command:

```
scripts/project_a/unit.sh work/adversarial/integration/phase1b work/adversarial/integration/test_integration_adversarial.py
```

Result: **3 passed in 117.46 s**, isolated pinned Python 3.10 container. Numerical
source/fixture/harness hashes stayed unchanged across this run.

Seven metamorphic variations all obtain geometry PASS and independent dynamics
PASS: S0 quarter-turn rotation, exact algebraic cubic half-subdivision (no refit),
translation by (2^14,-2^14) metres, physical similarity scales 1/8 and 16; S3-notch
quarter-turn and half-subdivision. For similarity scale a and fixed speed, scale
body/margin and wheelbase by a, acceleration/lateral/motor budgets and drag/mass
by 1/a, steering rate by 1/a and independent curvature policy by 1/a. Distance and
lap time must scale by a; speed remains unchanged. An independent QUADPACK speed
integral (distinct from production fixed Gauss32/bound construction) gives the
same displayed binary64 length after the appropriate similarity normalization
in all seven cases, and constant-speed oracle times lie inside every independently
reported time enclosure. Samples/oracle agreement do not replace certificates.

Actual retiming succeeds after both S0 quarter-turn and half-subdivision; both
validators PASS on those exact authorities. Lap times differ 8.59396246115154 vs
8.592439496674894 s (~0.0177%). This is a discretization/conservatism observation:
subdivision adds coefficient/profile knots and can tighten whole-edge bounds;
this LP does not promise an invariant continuum optimum or minimum lap time.

Nine coordinated faults all deny combined PASS: changed approved route
provenance plus regenerated profile digest; forged surface/owner plus regenerated
digest; relaxed candidate numerical policy plus regenerated digest; changed q
period by one nextafter plus regenerated digest; reduced model speed plus
regenerated model digest; excessive profile endpoint speed; geometry budget
exhaustion while dynamics passes; dynamics budget exhaustion while geometry
passes; unsupported absent model while geometry passes. There is no production
combined artifact compiler in W2: conjunction must check both exact PASS results
on the same retained authority; A07 compiler/artifact work remains W3.

## Preservation and architectural observations

`w1-preservation.json` independently compares all four corrected W1 production
modules and all three W1 test suites against both reviewed W2 and current source.
They are byte-for-byte identical. F1 open-interior tangent topology, F2 bounded
arc quadrature, F3 exact semantic anchors, F4 half-open seam ownership and F5
dimensionally normalized gate direction remain in the unchanged suites. Root
executes their acceptance tests with the complete full verification.

The independent dynamics checker duplicates applicability/model residual logic,
but intentionally shares A05 rational Bernstein curvature bounds and the W1 arc
kernel. The independent QUADPACK oracle here provides one check against correlated
arc errors; geometry/math agents add independent predicate and analytic controls.
Sharing dataclass model records with cyclic_retime also imports SciPy into the
checker, but does not cause it to consume optimizer rows/residuals.

Dense A04 matrix/QP bounds (512 points, child limits) and W2 cooperative deadlines
are explicit supported limits. Competition scale may exceed the default 0.4-m
mesh point cap; that is a prospective W3 mesh/complexity concern, not an unmeasured
claim that W3 is impossible. The A04 reviewer owns a bounded ~240-m preflight
probe. No new framework/backend is justified by these observations.

## Phase II — corrected boundary independently verified

Root authorized a small API correction rather than claiming hashes can reconstruct
history. Both validators now require `expected_curve_digest` from an independent
trusted handoff; missing authority yields INCONCLUSIVE, malformed or mismatched
authority FAIL. Geometry reports now include the full curve digest separately
from its coefficient-only reporting digest. Numerical bounds, legal area, margins,
solver limits and residual acceptance criteria remain unchanged.

I migrated only `test_w2_pipeline.py` and `scripts/project_a/tests/test_w2_installed.py`,
and added the self-contained `test_route_w2_handoff.py`. Both numerical pipeline
paths capture the expected identity once immediately after trusted A04 CANDIDATE,
carry it across retiming, pass the same retained value to both validators, and
require geometry/dynamics/profile/metadata identities all to match it. Ten handoff
regressions cover missing, malformed, valid and mismatched expected authority,
coordinated q/cap/profile self-rehash and mixed-authority denial, including public
geometry-facade forwarding of the expected identity.

The seven fresh A04 histories are also replayed independently using the A04
reviewer's distinct periodic second-derivative linear system, with no second QP
or another optimization run. It starts at the approved seed and checks exact q
inheritance/source half-open interval, every semantic anchor, original ownership,
reference/shifted fits, right-normal sign, damping, eroded nodal interval and exact
final coefficient/q identity. A deliberately altered final q is rejected.

Commands and observed results, on a globally frozen implementation/test tree:

```
scripts/project_a/unit.sh work/adversarial/integration/handoff-pipeline-green planner/global_planner/test/test_route_w2_handoff.py planner/global_planner/test/test_w2_pipeline.py
# 20 passed in 125.95 s; exit 0; source/fixture/harness hashes unchanged.

scripts/project_a/unit.sh work/adversarial/integration/phase2-metamorphic work/adversarial/integration/proposed/test_integration_adversarial_bound.py
# 3 passed in 107.11 s; exit 0; source/fixture/harness hashes unchanged.
```

Every fresh A04 scenario has three iterations. Across all seven independent
replays: source-point error <=8.89e-16 m, reference coefficient error <=8.70e-14 m,
shifted coefficient error <=5.82e-14 m, right-normal component error <=3.34e-16.
These comparisons are independent regression controls, not replacements for
continuous geometry or dynamic certificates.

The exact original q-warp reproducer was rerun with original handoff identity
retained before mutation (`phase2-q-bound/`). Geometry now FAILS: “complete curve
differs from independently retained authority”. Dynamics now FAILS: “independently
expected final-curve authority digest mismatch”. The same profile against original
q still demonstrates the original static-cap violation at edge14. No cap or model
release criterion was weakened. The old two PASS results remain preserved in
`phase1/`.

All seven independent similarity/subdivision cases still PASS/PASS. All nine
coordinated faults deny combined PASS, and the changed-route/self-rehashed-profile
case is now also denied by dynamics against its separately retained handoff. Both
actual retiming transformations retain prior PASS/PASS results and numerical times.
The original Phase I script remains unchanged; the bound copy explicitly captures
trusted synthetic authority before downstream mutation and passes retained values.

Scope limit: a caller that supplies a newly computed digest of an already altered
candidate is approving that different authority; the validators cannot distinguish
that external authorization error. The new guard authenticates the trusted handoff
within the calling pipeline; it does not invent optimizer-history authentication
for arbitrary external initial curves or arbitrary expected digests. The fresh
independent A04 history oracle separately verifies the actual supported seed path.
Full ROS/install/legacy acceptance, corrective commit identity, branch push and
exact final-head CI are owned by the root review and remain required for acceptance.

## Additional new complete case and second confirmed finding

After the initial review checkpoint, an entirely new analytic asymmetric route
was generated without reading any existing fixture geometry. It exposed a P2
false-negative across an exact shared cap: opposite edge orientations evaluated
mathematically identical roots with different floating operation order, leaving
an artificial 3.15e-15 m normal-interval gap. This caused failure after the first
damped QP shift. Independent seed A05 already passed. The original failed normal,
full polygons, exact rational oracle, stage instrumentation, every failed/discarded
attempt and corrected complete pipeline are preserved in `novel/`.

The minimal edge-orientation correction preserves strict contact/gap handling and
all original margins/tolerances. Stable corrected verification passes two fresh
complete new-route pipelines; a separate no-production-import Decimal/GEOS/
QUADPACK oracle finds zero violations. See `novel/REVIEW.md` for commands, precise
identities, numbers and limitations. The route is now a permanent regression;
this is a deliberate four-line W1 numerical-primitive correction beyond the
initial byte-preservation snapshot, not an unnoticed alteration of earlier fixes.
