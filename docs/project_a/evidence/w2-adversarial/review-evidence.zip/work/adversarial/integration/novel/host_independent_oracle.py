"""No production imports: Decimal geometry + GEOS + QUADPACK novel-route oracle."""
from decimal import Decimal, localcontext
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path
import sys

import numpy as np
import scipy
from scipy.integrate import quad
import shapely
from shapely.geometry import Polygon
from shapely.ops import unary_union

route_path, report_path, output_path = map(Path, sys.argv[1:])
route = json.loads(route_path.read_bytes())
report = json.loads(report_path.read_bytes())
coefficients = report['optimizer']['coefficients']
q = report['optimizer']['q']
owners = report['optimizer']['owners']
profile = report['retimer']['profile']
metadata = report['retimer']['metadata']
regions = route['occurrences']
polygons = [Polygon(o['right'] + list(reversed(o['left']))) for o in regions]
supports = [Polygon(p['support']) for p in route['transitions']]
unions = [unary_union((polygons[i], polygons[(i + 1) % len(polygons)]))
          .intersection(supports[i]) for i in range(len(polygons))]
ends = [0.]
for occurrence in regions:
    ends.append(ends[-1] + math.fsum(math.dist(a, b) for a, b in
                                   zip(occurrence['seed'], occurrence['seed'][1:])))


def derivative(c, t, order):
    values = np.asarray(c)
    if order == 0:
        return values[:, 0] + t * (values[:, 1] + t * (values[:, 2] + t * values[:, 3]))
    if order == 1:
        return values[:, 1] + t * (2 * values[:, 2] + 3 * t * values[:, 3])
    if order == 2:
        return 2 * values[:, 2] + 6 * t * values[:, 3]
    return 6 * values[:, 3]


def arc(c, low, high):
    value, error = quad(lambda t: math.hypot(*derivative(c, t, 1)), low, high,
                        epsabs=2e-13, epsrel=2e-13)
    assert error < 1e-10
    return value


def rectangle_decimal(c, parameter):
    t = Decimal.from_float(float(parameter))
    values = [[Decimal.from_float(float(v)) for v in row] for row in c]
    point = [row[0] + t * (row[1] + t * (row[2] + t * row[3])) for row in values]
    first = [row[1] + t * (2 * row[2] + 3 * t * row[3]) for row in values]
    norm = sum(v * v for v in first).sqrt()
    tangent = [v / norm for v in first]
    normal = [-tangent[1], tangent[0]]
    front = Decimal.from_float(.1)
    width = Decimal.from_float(.12) / 2
    return Polygon([[float(point[j] + x * tangent[j] + y * normal[j]) for j in range(2)]
                    for x, y in ((front, width), (-front, width),
                                 (-front, -width), (front, -width))])


minimum_clearance, geometry_bad, geometry_samples = math.inf, [], 0
maximum_curvature = 0.
with localcontext() as ctx:
    ctx.prec = 80
    for index, c in enumerate(coefficients):
        owner = next(i for i, occurrence in enumerate(regions) if occurrence['id'] == owners[index][0])
        for parameter in np.linspace(0., 1., 23):
            geometry_samples += 1
            body = rectangle_decimal(c, parameter)
            local_q = float(Fraction(q[index]) + Fraction(float(parameter)) *
                            (Fraction(q[index + 1]) - Fraction(q[index])))
            domains = [polygons[owner]]
            for i, portal in enumerate(route['transitions']):
                if owners[index][0] not in (portal['from'], portal['to']):
                    continue
                delta = local_q - ends[i + 1]
                if i + 1 == len(polygons) and local_q < ends[-1] / 2:
                    delta = local_q
                if -portal['before_m'] - 1e-11 <= delta <= portal['after_m'] + 1e-11:
                    domains.append(unions[i])
            clearance = max((p.boundary.distance(body) for p in domains if p.covers(body)),
                            default=-math.inf)
            minimum_clearance = min(minimum_clearance, clearance)
            if clearance < .01 - 2e-10:
                geometry_bad.append([index, float(parameter), clearance])

knots = profile['knots']
distances, times, time_errors, acceleration_errors = [], [], [], []
max_diamond = max_motor = max_lateral = max_angle = max_rate = 0.
max_cap_ratio = 0.
model_samples = 0
for index, first in enumerate(knots):
    following = knots[(index + 1) % len(knots)]
    high = following['t'] if following['segment'] == first['segment'] else 1.
    c = coefficients[first['segment']]
    distance = arc(c, first['t'], high)
    acceleration = (following['u'] - first['u']) / (2 * distance)
    distances.append(distance)
    times.append(2 * distance / (math.sqrt(first['u']) + math.sqrt(following['u'])))
    acceleration_errors.append(abs(acceleration - metadata['acceleration_mps2'][index]))
    edge_certificate = report['dynamics']['edges'][index]
    assert edge_certificate['distance_lower_m'] <= distance <= edge_certificate['distance_upper_m']
    owner = next(i for i, occurrence in enumerate(regions)
                 if occurrence['id'] == owners[first['segment']][0])
    for parameter in np.linspace(first['t'], high, 17):
        model_samples += 1
        fraction = arc(c, first['t'], float(parameter)) / distance
        u = first['u'] + (following['u'] - first['u']) * fraction
        d, dd, third = derivative(c, parameter, 1), derivative(c, parameter, 2), derivative(c, parameter, 3)
        g = d @ d
        cross = d[0] * dd[1] - d[1] * dd[0]
        curvature = abs(cross) / g ** 1.5
        maximum_curvature = max(maximum_curvature, curvature)
        cp, gp = d[0] * third[1] - d[1] * third[0], 2 * (d @ dd)
        curvature_rate = abs((2 * cp * g - 3 * cross * gp) / (2 * g ** 3))
        drive = acceleration + .02 * u
        lateral = curvature * u / 4.
        max_lateral = max(max_lateral, lateral)
        max_diamond = max(max_diamond, drive / 2. + lateral, -drive / 3. + lateral)
        max_motor = max(max_motor, drive / 2.5)
        max_angle = max(max_angle, math.atan(.3 * curvature))
        max_rate = max(max_rate, .3 * curvature_rate * math.sqrt(u) /
                       (1 + (.3 * curvature) ** 2))
        local_q = (1 - parameter) * q[first['segment']] + parameter * q[first['segment'] + 1]
        local_q -= ends[owner]
        cap = 4.
        if owner == 1 and 1.37 - 1e-10 <= local_q <= 1.87 + 1e-10:
            cap = 1.
        max_cap_ratio = max(max_cap_ratio, math.sqrt(u) / cap)

result = {'production_imports': False, 'decimal_precision': 80,
          'environment': {'python': sys.version, 'numpy': np.__version__,
                          'scipy': scipy.__version__, 'shapely': shapely.__version__,
                          'geos': shapely.geos_version_string},
          'route_file_sha256': hashlib.sha256(route_path.read_bytes()).hexdigest(),
          'candidate_report_sha256': hashlib.sha256(report_path.read_bytes()).hexdigest(),
          'geometry_samples': geometry_samples, 'model_samples': model_samples,
          'sampled_geometry_violations': geometry_bad,
          'sampled_minimum_body_boundary_clearance_m': minimum_clearance,
          'sampled_maximum_abs_curvature': maximum_curvature,
          'independent_quad_length_m': math.fsum(distances),
          'independent_quad_time_s': math.fsum(times),
          'production_lap_time_s': profile['lap_time_s'],
          'production_time_enclosure': [report['dynamics']['lap_time_lower_s'],
                                        report['dynamics']['lap_time_upper_s']],
          'maximum_acceleration_metadata_error_mps2': max(acceleration_errors),
          'sampled_diamond_utilization_max': max_diamond,
          'sampled_motor_utilization_max': max_motor,
          'sampled_lateral_utilization_max': max_lateral,
          'sampled_steering_angle_max_rad': max_angle,
          'sampled_steering_rate_max_radps': max_rate,
          'sampled_static_cap_speed_ratio_max': max_cap_ratio}
output_path.write_text(json.dumps(result, indent=2, allow_nan=False))
print(json.dumps(result, indent=2, allow_nan=False))
assert not geometry_bad
assert max_diamond <= 1 + 1e-8 and max_motor <= 1 + 1e-8
assert max_angle <= .7 + 1e-10 and max_rate <= 3. + 1e-8
assert max_cap_ratio <= 1 + 1e-8
assert report['dynamics']['lap_time_lower_s'] <= math.fsum(times) <= \
    report['dynamics']['lap_time_upper_s']
assert max(acceleration_errors) < 1e-8
