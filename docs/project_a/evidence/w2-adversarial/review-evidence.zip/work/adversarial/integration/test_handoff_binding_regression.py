"""Failing-first P1 independent A04 handoff binding, before any mutation."""
from dataclasses import replace
import json
import math
from pathlib import Path
import sys

sys.path.insert(0, '/src/work/adversarial/integration')
from test_integration_adversarial import load, model, BODY, constant_profile
from global_planner.cyclic_retime import curve_digest, retime
from global_planner.route_corridor import OrderedCurve
from global_planner.route_input import validate_route
from global_planner.route_validate import validate_geometry
from global_planner.route_validate_dynamics import validate_dynamics


def test_missing_independent_handoff_authority_cannot_receive_pass():
    approved = load()
    supplied = model(approved.route)
    profile = constant_profile(approved, supplied)
    geometry = validate_geometry(approved, approved.route, BODY)
    dynamics = validate_dynamics(approved, profile, supplied)
    observed = {'geometry': [geometry.status, geometry.reason],
                'dynamics': [dynamics.status, dynamics.reason]}
    Path('/work/handoff-missing-authority.json').write_text(json.dumps(observed, indent=2))
    assert geometry.status == dynamics.status == 'INCONCLUSIVE', observed


def test_rehashed_monotone_q_warp_fails_against_independent_original_handoff():
    base = load()
    raw = base.route.payload
    raw['occurrences'][0]['caps'] = [
        {'at_m': 0., 'max_speed_mps': 4.},
        {'at_m': 3., 'max_speed_mps': .1},
        {'at_m': 3.01, 'max_speed_mps': 4.}]
    route = validate_route(raw)
    approved = OrderedCurve(route, base.curve, base.q)
    # Capture this once at the trusted boundary, before downstream mutation.
    expected = curve_digest(approved)
    q = tuple(v + 1.5 * math.sin(math.pi * (v - 1.) / 7.) ** 2
              if 1. < v < 8. else v for v in approved.q)
    altered = OrderedCurve(route, approved.curve, q)
    supplied = model(route)
    supplied = replace(supplied, steering=None, regions=tuple(
        replace(r, limits=replace(r.limits, ax_pos_mps2=1000., ax_neg_mps2=1000.,
                                 ay_mps2=1000., motor_mps2=1000., drag_over_mass=0.))
        for r in supplied.regions))
    # Fully regenerate the profile and self-consistent candidate hashes after
    # q tampering. Those self-hashes cannot substitute for original authority.
    result = retime(altered, supplied)
    assert result.status == 'CANDIDATE', result.message
    assert result.profile.curve_digest != expected
    geometry = validate_geometry(altered, route, BODY, expected_curve_digest=expected)
    dynamics = validate_dynamics(altered, result.profile, supplied,
                                expected_curve_digest=expected)
    assert geometry.status == dynamics.status == 'FAIL', (geometry, dynamics)
    assert 'authority' in geometry.reason.lower() and 'authority' in dynamics.reason.lower()
