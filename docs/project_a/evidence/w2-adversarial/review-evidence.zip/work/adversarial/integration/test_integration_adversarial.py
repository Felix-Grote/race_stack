"""Independent W2 curve-representation and authority-fault campaign."""
from dataclasses import asdict, replace
import copy
import gzip
import hashlib
import json
import math
from pathlib import Path
from types import SimpleNamespace

import numpy as np
from scipy.integrate import quad

from global_planner.cyclic_retime import (
    DynamicsModel, ModelRegion, RegionLimits, SpeedKnot, SpeedProfile,
    SteeringLimits, curve_digest, model_digest, retime)
from global_planner.route_corridor import OrderedCurve
from global_planner.route_input import load_route, validate_route
from global_planner.route_reference import Curve, NumericPolicy
from global_planner.route_validate import Footprint, GeometryValidationPolicy, validate_geometry
from global_planner.route_validate_dynamics import DynamicsValidationPolicy, validate_dynamics

ROOT = Path('/src')
FIX = ROOT / 'planner/global_planner/test/fixtures/project_a'
BODY = Footprint(.1, .1, .12, .01)
OUT = Path('/work')


def load(name='s0_route'):
    raw = (FIX / 'w2_a04_candidates.json.gz').read_bytes()
    assert hashlib.sha256(raw).hexdigest() == (
        '2a506953026b75fc5be4defb1b018577faa46cebdbdfcd767c0103e733b2279b')
    rec = json.loads(gzip.decompress(raw))['candidates'][name]
    route = load_route(FIX / (name + '.json'))
    return OrderedCurve(route, Curve(rec['coefficients'], rec['owners']), rec['q'])


def model(route, scale=1.):
    # Similarity law with unchanged speed: distances/time scale by scale;
    # accelerations, curvature and drag coefficient scale by 1/scale.
    limits = RegionLimits(.05, 4., 2. / scale, 3. / scale, 4. / scale,
                          3. / scale, .02 / scale, 'independent similarity oracle')
    regions = tuple(ModelRegion(o.id, o.surface_id, limits) for o in route.occurrences)
    return DynamicsModel(regions, 'independent W2 integration campaign',
                         SteeringLimits(.3 * scale, .7, 3. / scale))


def independent_arc(coeff):
    # QUADPACK is distinct from production's bounded fixed Gauss32 panels.
    # This is an oracle comparison, never the certificate authorizing PASS.
    c = np.asarray(coeff, dtype=float)
    def speed(t):
        d = c[:, 1] + t * (2 * c[:, 2] + 3 * t * c[:, 3])
        return math.hypot(*d)
    val, err = quad(speed, 0., 1., epsabs=2e-13, epsrel=2e-13)
    assert err < 1e-11
    return val


def constant_profile(ordered, supplied, speed=.5):
    length = math.fsum(independent_arc(c) for c in ordered.curve.coefficients)
    return SpeedProfile(tuple(SpeedKnot(i, 0., speed * speed)
                              for i in range(len(ordered.curve.segments))),
                        curve_digest(ordered), model_digest(supplied), length / speed)


def transform(base, scale=1., turn=False, shift=(0., 0.)):
    def point(p):
        x, y = p
        if turn:
            x, y = -y, x
        return [scale * x + shift[0], scale * y + shift[1]]
    payload = base.route.payload
    for occurrence in payload['occurrences']:
        for key in ('seed', 'left', 'right'):
            occurrence[key] = [point(p) for p in occurrence[key]]
        for cap in occurrence['caps']:
            cap['at_m'] *= scale
    for portal in payload['transitions']:
        for key in ('gate', 'support'):
            portal[key] = [point(p) for p in portal[key]]
        portal['before_m'] *= scale
        portal['after_m'] *= scale
    payload['initialization']['zone'] = [point(p) for p in payload['initialization']['zone']]
    payload['initialization']['seed_interval_m'] = [
        v * scale for v in payload['initialization']['seed_interval_m']]
    route = validate_route(payload)
    coefficients = []
    for old in base.curve.coefficients:
        old = np.asarray(old)
        new = old.copy()
        if turn:
            new = np.vstack((-old[1], old[0]))
        new *= scale
        new[:, 0] += shift
        coefficients.append(new.tolist())
    # Recomputed polyline end anchors differ by roundoff after translation.
    # Transport every interior q within its original occurrence, preserving all
    # exact newly approved anchors and inherited order.
    old_ends, new_ends = [0.], [0.]
    for before, after in zip(base.route.occurrences, route.occurrences):
        old_ends.append(old_ends[-1] + before.length)
        new_ends.append(new_ends[-1] + after.length)
    q = []
    for value in base.q:
        j = min(np.searchsorted(old_ends, value, side='right') - 1, len(old_ends) - 2)
        if value == old_ends[j]:
            q.append(new_ends[j])
        elif value == old_ends[-1]:
            q.append(new_ends[-1])
        else:
            q.append(new_ends[j] + (value - old_ends[j]) *
                     (new_ends[j + 1] - new_ends[j]) / (old_ends[j + 1] - old_ends[j]))
    return OrderedCurve(route, Curve(coefficients, base.curve.owners), q)


def subdivide(base):
    # Restrict r(t) exactly to two parameter halves algebraically, with the
    # binary64 coefficients as the resulting new authority. No spline refit.
    coefficients, owners, q = [], [], [base.q[0]]
    for i, old in enumerate(base.curve.coefficients):
        c = np.asarray(old)
        for a, h in ((0., .5), (.5, .5)):
            coefficients.append(np.column_stack((
                c[:, 0] + a * (c[:, 1] + a * (c[:, 2] + a * c[:, 3])),
                h * (c[:, 1] + a * (2 * c[:, 2] + 3 * a * c[:, 3])),
                h * h * (c[:, 2] + 3 * a * c[:, 3]), h ** 3 * c[:, 3])).tolist())
            owners.append(base.curve.owners[i])
            q.append((base.q[i] + base.q[i + 1]) / 2 if a == 0 else base.q[i + 1])
    return OrderedCurve(base.route, Curve(coefficients, owners), q)


def test_similarity_and_exact_subdivision_certify_same_geometric_authority():
    records = []
    for name in ('s0_route', 's3_notch_route'):
        base = load(name)
        reference_length = math.fsum(independent_arc(c) for c in base.curve.coefficients)
        variants = [('quarter_turn', transform(base, turn=True), 1.),
                    ('subdivide_half', subdivide(base), 1.)]
        if name == 's0_route':
            variants += [('translate_2pow14', transform(base, shift=(2. ** 14, -2. ** 14)), 1.),
                         ('scale_one_eighth', transform(base, scale=.125), .125),
                         ('scale_sixteen', transform(base, scale=16.), 16.)]
        for label, changed, scale in variants:
            body = Footprint(BODY.front_m * scale, BODY.rear_m * scale,
                             BODY.width_m * scale, BODY.margin_m * scale)
            supplied = model(changed.route, scale)
            geometric = validate_geometry(changed, changed.route, body,
                GeometryValidationPolicy(max_curvature=1. / scale))
            profile = constant_profile(changed, supplied)
            dynamic = validate_dynamics(changed, profile, supplied)
            actual_length = profile.lap_time_s * .5
            record = {'fixture': name, 'case': label, 'scale': scale,
                      'geometry_status': geometric.status, 'geometry_reason': geometric.reason,
                      'dynamics_status': dynamic.status, 'dynamics_reason': dynamic.reason,
                      'coefficient_segments': len(changed.curve.segments),
                      'route_digest': changed.route.digest,
                      'curve_digest': profile.curve_digest,
                      'length_oracle_m': actual_length,
                      'length_similarity_error_m': actual_length - scale * reference_length,
                      'lap_time_oracle_s': profile.lap_time_s,
                      'lap_time_lower_s': dynamic.lap_time_lower_s,
                      'lap_time_upper_s': dynamic.lap_time_upper_s,
                      'continuous_geometry_leaves': len(geometric.intervals),
                      'continuous_dynamics_edges': len(dynamic.edges)}
            records.append(record)
            (OUT / 'integration-metamorphic.json').write_text(json.dumps(records, indent=2))
            assert geometric.status == 'PASS', record
            assert dynamic.status == 'PASS', record
            assert dynamic.lap_time_lower_s <= profile.lap_time_s <= dynamic.lap_time_upper_s
            assert abs(actual_length - scale * reference_length) < max(1e-9, 1e-9 * scale)


def test_cross_authority_fault_matrix_cannot_receive_combined_pass():
    base = load()
    supplied = model(base.route)
    profile = constant_profile(base, supplied)
    geometric = validate_geometry(base, base.route, BODY)
    dynamic = validate_dynamics(base, profile, supplied)
    assert geometric.status == dynamic.status == 'PASS'
    faults = []

    # A valid but different original route may be internally consistent; an
    # independent original authority is still mandatory at the geometry gate.
    raw = base.route.payload
    raw['provenance']['revision'] = 'independent-unapproved-change'
    other = OrderedCurve(validate_route(raw), base.curve, base.q)
    faults.append(('changed_route_rehash_profile', other, base.route,
                   replace(profile, curve_digest=curve_digest(other)), supplied,
                   GeometryValidationPolicy(), DynamicsValidationPolicy()))

    curve = copy.deepcopy(base.curve)
    owner = list(curve.owners)
    owner[0] = ('o2', 'forged-deck')
    object.__setattr__(curve, 'owners', tuple(owner))
    forged = SimpleNamespace(route=base.route, curve=curve, q=base.q)
    faults.append(('forged_owner_rehash_profile', forged, base.route,
                   replace(profile, curve_digest=curve_digest(forged)), supplied,
                   GeometryValidationPolicy(), DynamicsValidationPolicy()))

    curve = copy.deepcopy(base.curve)
    object.__setattr__(curve, 'policy', replace(NumericPolicy(), join_abs=10.))
    forged = SimpleNamespace(route=base.route, curve=curve, q=base.q)
    faults.append(('relaxed_candidate_policy_rehash_profile', forged, base.route,
                   replace(profile, curve_digest=curve_digest(forged)), supplied,
                   GeometryValidationPolicy(), DynamicsValidationPolicy()))

    q = list(base.q)
    q[-1] = math.nextafter(q[-1], math.inf)
    forged = SimpleNamespace(route=base.route, curve=base.curve, q=q)
    faults.append(('q_period_nextafter_rehash_profile', forged, base.route,
                   replace(profile, curve_digest=curve_digest(forged)), supplied,
                   GeometryValidationPolicy(), DynamicsValidationPolicy()))

    bad = replace(supplied, regions=(replace(supplied.regions[0], limits=replace(
        supplied.regions[0].limits, speed_max_mps=.2)),) + supplied.regions[1:])
    faults.append(('lower_model_cap_rehash_profile', base, base.route,
                   replace(profile, model_digest=model_digest(bad)), bad,
                   GeometryValidationPolicy(), DynamicsValidationPolicy()))

    knots = list(profile.knots)
    knots[-1] = replace(knots[-1], u=100.)
    faults.append(('closing_brake_forgery', base, base.route,
                   replace(profile, knots=tuple(knots)), supplied,
                   GeometryValidationPolicy(), DynamicsValidationPolicy()))
    faults.append(('geometry_inconclusive_dynamic_pass', base, base.route, profile, supplied,
                   GeometryValidationPolicy(max_intervals=0), DynamicsValidationPolicy()))
    faults.append(('geometry_pass_dynamic_inconclusive', base, base.route, profile, supplied,
                   GeometryValidationPolicy(), DynamicsValidationPolicy(max_intervals=0)))
    faults.append(('geometry_pass_dynamic_unsupported', base, base.route, profile, None,
                   GeometryValidationPolicy(), DynamicsValidationPolicy()))

    records = []
    for name, candidate, approved, speed, limits, gp, dp in faults:
        geometry = validate_geometry(candidate, approved, BODY, gp)
        dynamics = validate_dynamics(candidate, speed, limits, dp)
        combined = geometry.status == dynamics.status == 'PASS'
        record = {'case': name, 'geometry_status': geometry.status,
                  'geometry_reason': geometry.reason, 'dynamics_status': dynamics.status,
                  'dynamics_reason': dynamics.reason, 'combined_pass': combined}
        records.append(record)
        (OUT / 'integration-faults.json').write_text(json.dumps(records, indent=2))
        assert not combined, record


def test_retimer_candidates_after_similarity_and_subdivision_need_actual_both_pass():
    records = []
    base = load()
    for name, changed in [('quarter_turn', transform(base, turn=True)),
                          ('subdivide_half', subdivide(base))]:
        supplied = model(changed.route)
        geometry = validate_geometry(changed, changed.route, BODY)
        result = retime(changed, supplied, spacing_m=.47)
        assert result.status == 'CANDIDATE', (name, result.status, result.message)
        dynamics = validate_dynamics(changed, result.profile, supplied, metadata=result.metadata)
        records.append({'case': name, 'geometry_status': geometry.status,
                        'retimer_status': result.status, 'dynamics_status': dynamics.status,
                        'dynamics_reason': dynamics.reason, 'lap_time_s': result.profile.lap_time_s,
                        'knots': len(result.profile.knots),
                        'max_lp_residual': result.max_lp_residual})
        (OUT / 'integration-retimed.json').write_text(json.dumps(records, indent=2))
        assert geometry.status == dynamics.status == 'PASS', records[-1]
