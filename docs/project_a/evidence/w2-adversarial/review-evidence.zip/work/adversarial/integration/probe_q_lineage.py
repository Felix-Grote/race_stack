"""Distinguish an alternative q map from externally established lineage provenance."""
from dataclasses import replace
import json
import math
from pathlib import Path
import sys
sys.path.insert(0, '/src/work/adversarial/integration')
from test_integration_adversarial import load, model, BODY
from global_planner.cyclic_retime import curve_digest, retime
from global_planner.route_corridor import OrderedCurve
from global_planner.route_input import validate_route
from global_planner.route_validate import validate_geometry
from global_planner.route_validate_dynamics import validate_dynamics

base = load()
payload = base.route.payload
payload['occurrences'][0]['caps'] = [
    {'at_m': 0., 'max_speed_mps': 4.},
    {'at_m': 3., 'max_speed_mps': .1},
    {'at_m': 3.01, 'max_speed_mps': 4.}]
route = validate_route(payload)
canonical = OrderedCurve(route, base.curve, base.q)
q = tuple(v + 1.5 * math.sin(math.pi * (v - 1.) / 7.) ** 2
          if 1. < v < 8. else v for v in base.q)
warped = OrderedCurve(route, base.curve, q)
supplied = model(route)
supplied = replace(supplied, steering=None, regions=tuple(
    replace(r, limits=replace(r.limits, ax_pos_mps2=1000., ax_neg_mps2=1000.,
                             ay_mps2=1000., motor_mps2=1000., drag_over_mass=0.))
    for r in supplied.regions))
geometry = validate_geometry(warped, route, BODY)
timed = retime(warped, supplied)
if timed.status != 'CANDIDATE':
    raise RuntimeError((timed.status, timed.message))
dynamics = validate_dynamics(warped, timed.profile, supplied, metadata=timed.metadata)
compared = validate_dynamics(canonical, replace(timed.profile,
                            curve_digest=curve_digest(canonical)), supplied)
record = {'geometry_with_alternate_q': [geometry.status, geometry.reason],
          'dynamics_with_alternate_q': [dynamics.status, dynamics.reason],
          'same_coefficients_profile_checked_with_original_q':
              [compared.status, compared.reason, compared.offending_edge],
          'canonical_q': canonical.q, 'alternate_q': warped.q,
          'same_coefficient_authority': canonical.curve == warped.curve,
          'canonical_curve_digest': curve_digest(canonical),
          'alternate_curve_digest': curve_digest(warped),
          'interpretation': 'Standalone validator verifies consistency of supplied q authority; '
              'original optimizer history cannot be inferred from a displaced curve. '
              'Externally approved provenance/immutable artifact must bind the intended q map.'}
Path('/work/q-lineage-boundary.json').write_text(json.dumps(record, indent=2))
print(json.dumps({key: value for key, value in record.items()
                  if key not in ('canonical_q', 'alternate_q')}, indent=2))
