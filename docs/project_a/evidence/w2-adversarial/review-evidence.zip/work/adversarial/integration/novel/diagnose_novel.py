from dataclasses import asdict
import json
from pathlib import Path
import sys
import math
sys.path.insert(0, '/src/work/adversarial/integration/novel')
from test_novel_complete_pipeline import BODY, sampled_oracle
import global_planner.iqp_route_adapter as adapter
from global_planner.route_input import load_route
from global_planner.route_corridor import seed_curve
from global_planner._route_geometry import line_intervals, inside
from global_planner.cyclic_retime import curve_digest
from global_planner.route_validate import validate_geometry

route = load_route('/src/work/adversarial/integration/novel/run1/approved-route.json')
original = adapter.normal_interval
report = {}
def observed(ordered, sample):
    try:
        return original(ordered, sample)
    except Exception as exc:
        ends = [0.]
        for occurrence in route.occurrences:
            ends.append(ends[-1] + occurrence.length)
        n = (-sample.tangent[1], sample.tangent[0])
        record = {'sample': asdict(sample), 'ends': ends,
                  'normal': n, 'error': str(exc), 'polygons': [], 'portals': []}
        for occurrence in route.occurrences:
            try:
                intervals = line_intervals(sample.xy, n, occurrence.polygon)
            except Exception as interval_exc:
                intervals = str(interval_exc)
            record['polygons'].append({'id': occurrence.id,
                'inside': inside(sample.xy, occurrence.polygon), 'line_intervals': intervals})
        for i, portal in enumerate(route.portals):
            delta = (sample.q - ends[i + 1] + ordered.period / 2) % ordered.period
            delta -= ordered.period / 2
            record['portals'].append({'id': portal.id, 'q_delta': delta,
                                     'inside_support': inside(sample.xy, portal.support, False),
                                     'support_intervals': line_intervals(sample.xy, n, portal.support),
                                     'gate': portal.gate})
        report['failure'] = record
        raise
adapter.normal_interval = observed
result = adapter.optimize(route)
report['optimizer_status'] = result.status
report['optimizer_reason'] = result.reason
report['iterations_completed'] = len(result.traces)
seed = seed_curve(route)
geometry = validate_geometry(seed, route, BODY, expected_curve_digest=curve_digest(seed))
report['seed_geometry_status'] = geometry.status
report['seed_geometry_reason'] = geometry.reason
report['seed_geometry_leaves'] = len(geometry.intervals)
Path('/work/diagnostic.json').write_text(json.dumps(report, indent=2, allow_nan=False))
print(json.dumps(report, indent=2, allow_nan=False))
