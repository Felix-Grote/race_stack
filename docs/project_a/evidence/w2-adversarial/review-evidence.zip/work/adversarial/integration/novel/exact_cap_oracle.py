from fractions import Fraction
import json
from pathlib import Path
p=Path('/src/work/adversarial/integration/novel/diagnostic/diagnostic.json')
record=json.loads(p.read_text())['failure']
xy=tuple(map(Fraction,record['sample']['xy']))
n=tuple(map(Fraction,record['normal']))
gate=record['portals'][1]['gate']
def cross(a,b):return a[0]*b[1]-a[1]*b[0]
def root(a,b):
    a,b=tuple(map(Fraction,a)),tuple(map(Fraction,b))
    v=(b[0]-a[0],b[1]-a[1]); w=(a[0]-xy[0],a[1]-xy[1])
    return cross(w,v)/cross(n,v)
a,b=gate
first,last=root(a,b),root(b,a)
result={'exact_directed_cap_roots_equal':first==last,
        'root_directed':str(first), 'root_reversed':str(last),
        'exact_root_float':float(first),
        'production_first_float_root':record['polygons'][1]['line_intervals'][0][1],
        'production_second_float_root':record['polygons'][2]['line_intervals'][0][0]}
Path('/work/exact-cap-oracle.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
assert first==last
