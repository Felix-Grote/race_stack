import hashlib
import json
from pathlib import Path
import global_planner.iqp_route_adapter as adapter
import global_planner.route_corridor as corridor
from global_planner.route_input import load_route

source_path = Path('/src/work/adversarial/integration/novel/old_route_geometry.py')
namespace = {}
exec(compile(source_path.read_text(), str(source_path), 'exec'), namespace)
# Read-only process-local replay of the original reviewed numerical primitive.
corridor.line_intervals = namespace['line_intervals']
original_geometry, original_qp = adapter._geometry, adapter.solve_qp
calls = {'geometry_calls': 0, 'qp_calls': 0}
def observed_geometry(*args, **kwargs):
    calls['geometry_calls'] += 1
    try:
        return original_geometry(*args, **kwargs)
    except Exception as exc:
        calls['failing_geometry_call'] = calls['geometry_calls']
        calls['error'] = str(exc)
        raise
def observed_qp(*args, **kwargs):
    calls['qp_calls'] += 1
    return original_qp(*args, **kwargs)
adapter._geometry, adapter.solve_qp = observed_geometry, observed_qp
route = load_route('/src/work/adversarial/integration/novel/run1/approved-route.json')
result = adapter.optimize(route)
calls['status'] = result.status
calls['completed_iteration_traces'] = len(result.traces)
calls['old_primitive_sha256'] = hashlib.sha256(source_path.read_bytes()).hexdigest()
calls['actual_reviewed_source_blob'] = 'f1899d9'
calls['interpretation'] = 'geometry call1 is reference, geometry call2 is first damped shifted fit'
Path('/work/failure-stage.json').write_text(json.dumps(calls, indent=2))
print(json.dumps(calls, indent=2))
assert calls['qp_calls'] == 1 and calls['failing_geometry_call'] == 2
