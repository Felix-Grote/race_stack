# New independently generated complete case and P2 shared-cap finding

## Independent construction

No existing route fixture is read by the generator. The centerline is an ellipse
with semiaxes 9.7 m / 4.6 m, rotated 0.37 radians and translated by
(19.25,-7.5) m. Original owned borders follow analytic unit normals with left
width `0.7+0.1*cos(3*theta)` m and right width `0.55+0.1*sin(2*theta)` m.
Four directed occurrences contain 32 seed intervals each. A single global point
array supplies all exact shared caps, and the closing endpoint reuses point zero.
Original portal supports and 0.3 m before/after progress brackets are explicit.
The second occurrence has a separately supplied 1 m/s cap from local q=1.37 m
to 1.87 m; other static caps are 4 m/s. Synthetic physical-map coverage is unknown.

Canonical generated route/file SHA256:
`742b03fa77cef8bfab9f203787ac8dd5435e479a6fddf9449ac4138e83c5a0aa`.

The complete original generated JSON, generator, failed attempt and corrected
attempts are preserved. No legal polygon, support domain, margin, model limit,
solver tolerance or resource policy was changed between failure and success.
The active harness received only a logging serialization correction: it stores
actual optimizer coefficients/q/traces rather than recursively serializing
`OptimizationResult.ordered.route.encoded` bytes. The original harness is retained
in `run1/`.

## Confirmed P2: an exact shared cap gets two different floating intersections

The initial default A04 invocation returns GEOMETRY_FAILURE with
“reference outside/ambiguous connected legal interval”. Independent continuous
A05 validation of the original seed passes with 137 leaves, proving the approved
seed/footprint is geometrically feasible. A read-only process-local replay of the
old primitive confirms one QP completed and the failure occurs during geometry
call 2, the first damped shifted fit, before any completed iteration trace is
appended (`diagnostic/failure-stage.json`). An earlier inference from `traces=[]`
that no QP had executed was incorrect; this instrumented stage record is definitive.

The affected line has reference
`p=(10.346273849151595,-10.953427375385925)` and left normal
`n=(0.9350684075601509,0.3544673090468617)`. It crosses the exact shared cap
between e1 and e2. The two polygons contain the same binary64 cap endpoints in
opposite directed order. Floating subtraction/cross-product evaluation produces
source interval `[-0.6995568208233919,-7.56631403522638e-14]` and target interval
`[-7.25105095042528e-14,0.45021452984136284]`, creating an artificial gap of about
3.15e-15 m. Strict open-interior merging correctly refuses to bridge this reported
gap; the origin-containing chart then fails its original 1e-9 m inward policy.

Independent exact rational arithmetic gives the SAME root for both cap directions:
`-6493513456432416/89282567569951896214720469081`, approximately
`-7.272991394814918e-14`. There is no gap in the original approved geometry.
`minimal-failed-normal.json` contains complete original source/target polygons,
cap, support mask, sample and observed/expected component information.

The root/geometry reviewer corrected this by canonicalizing each undirected edge's
endpoint order before line-intersection arithmetic. This makes the identical
shared edge use identical floating operations. It introduces no tolerance-based
gap merging and preserves strict F1 boundary-contact handling and inward EPS.
The geometry review owns its minimal failing-first and 49-control regression
campaign, including positive gaps and original F1 tangent cases.

## Corrected complete pipeline and independent oracle

Permanent regression and exact canonical fixture:
`planner/global_planner/test/test_route_w2_novel_pipeline.py` and
`planner/global_planner/test/fixtures/project_a/novel_varying_ellipse_route.json`.
The permanent regression runs the default A04, captures the expected complete
curve digest once, and passes the same independent authority through A05,
retiming and dynamics certification. Independent QUADPACK edge/time and sampled
residual comparisons plus independent A04 trace replay are included.

Command:

```
scripts/project_a/unit.sh work/adversarial/integration/novel/run3-stable work/adversarial/integration/novel/test_novel_complete_pipeline.py planner/global_planner/test/test_route_w2_novel_pipeline.py
```

Result: **2 passed in 31.13 s**, exit 0, all source/fixture/harness hashes unchanged.
An earlier corrected run had 2 functional passes but its whole-run source guard
correctly discarded it because the shared-cap test file was being indented
concurrently. That discarded run remains in `run2-corrected/`; acceptance uses
`run3-stable/` only.

Both freshly generated and static canonical-fixture cases produce a complete
consistent accepted synthetic planar pipeline. Actual result:

- 3 A04 iterations; 129 exact final cubic segments.
- Whole-lap A05 PASS; 330 continuous leaves and 4 directed gates.
- Minimum continuous certificate slack 2.0883471786084165e-4 m.
- A06 CANDIDATE and independent dynamics PASS; 221 cyclic speed knots.
- Maximum LP residual 1.7726931034189874e-12.
- Curve length 46.242835799711905 m; lap time 13.75921322560354 s.
- Expected full curve digest:
  `e8023c26bd60d12d3bbf42a6b4627468eba49dc2220e77d1971705079e0a2666`.
- Model digest:
  `d5e8b0af3f3b46e6b5232ec72818973b56e133b6fedeaf97c2ee92cbbf3a5b03`.

Independent external command:

```
work/adversarial/geometry/oracle-venv/bin/python work/adversarial/integration/novel/host_independent_oracle.py work/adversarial/integration/novel/run3-stable/approved-route.json work/adversarial/integration/novel/run3-stable/novel-report.json work/adversarial/integration/novel/run3-stable/host-independent-oracle.json
```

Result: **exit 0**. The oracle imports no production module. It uses 80-digit
Decimal coefficient evaluation/normalization, Shapely 2.1.2 / GEOS 3.13.1 polygon
union/containment/distance, and distinct SciPy QUADPACK arc/time integration.
Its separate Python 3.12.14 environment is an external mathematical regression
oracle, not a claim of pinned ROS production acceptance.

At 2,967 body poses, no independent geometry violation is observed; minimum full
body boundary clearance is 0.08830955971564132 m. At 3,757 dynamic sample points,
maximum normalized diamond utilization is 0.9999921634171196, motor 0.7889209381672765,
lateral 0.8844398884195922, steering angle 0.09386536337169575 rad, steering rate
1.6160869220823628 rad/s (<3), and original static-cap speed ratio approximately1.
Independent true-arc/time values are 46.242835799711905 m and 13.759213225603533 s;
the latter lies inside the independently certified enclosure
[13.759213225499257,13.759213225707809] s. Maximum acceleration metadata discrepancy
is 4.7406523151494184e-14 m/s². Sampling and oracle agreement remain regression
controls; A05/A06 continuous bounds authorize the actual PASS.

No remaining defect was demonstrated by this new case after the primitive repair.
Root owns final complete ROS/install/legacy replay, commits, normal push and
independent exact-head GitHub CI before a final acceptance verdict.
