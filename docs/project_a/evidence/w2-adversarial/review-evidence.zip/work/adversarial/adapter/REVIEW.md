# Independent A04 adversarial review (Phase I)

Reviewed repository `Felix-Grote/race_stack`, branch `project-a/w2-optimization`,
initial SHA `e852641849b2497efea51dfca5ead38ad4476235`, corrected W1 baseline
`9440c2ce68e3dee549de7efacff1cf723fe830df`. This subreview made no implementation
edits or commits. It does not issue the overall W2 acceptance verdict.

## Independently inspected inventory

Read scoped AGENTS.md, EXECUTION_PLAN, W2_NUMERICS, STATUS, RESULTS, DECISIONS,
canonical architecture/roadmap, A04 full baseline diff, actual adapter/corridor/
reference source, A04 and whole-pipeline tests, seven complete stored iteration
histories, and the actual installed pinned TPH source. Actual TPH source copies
are under `helper-source/`, with hashes:

- opt_min_curv.py: `a2ce75c33498426a5276e5b3455f2059040e8c5e5e54734aee3dde0436bef46d`
- calc_splines.py: `2943a4cb0c614a541551a8c6d031cf43b18b81b701221ac02ae51337fbf075a8`
- iqp_handler.py: `b764ff805fd5585a6dfb30e23b1c0b3ef667c91d66129dca78d9b37a356f65ae`

Adapter source references at initial SHA:

| Contract | Actual mechanism and review result |
|---|---|
| Original borders | `iqp_route_adapter.py:183` calls normal_interval for current coefficient knots before each QP and after each shifted fit (`:404`). Original ownership is supplied by exact inherited route q, never nearest XY. Full-width Jacobian and same-occurrence chart overlap checks remain enabled. These nodal preparation checks do not replace A05. |
| q and exact spline authority | `:380–386` obtains source segment/t/q from metric remeshing, retains occurrence/cap/portal anchors, and passes diff(q) to the helper's existing distance-scaling equations (`:224`). `:401–415` returns the final shifted TUM coefficients verbatim. |
| Signs and damping | Track columns are x,y,right,left (`:391`); helper alpha follows right normal. Derived right normal is checked against actual coefficient derivatives (`:388–390`). Stock early damping is retained, and the applied damped step is separately checked against eroded original bounds (`:394–400`). |
| Solver numerical checks | Actual quadprog primal rows are observed (`:241–265`); finite offsets, actual violation, linear curvature and matrix condition are checked (`:332–347`). Candidate success is a raw linearization-error condition, not true-objective convergence. |
| Bounded execution | Fits and QPs run in fresh children with address-space and CPU limits set before numerical imports (`:274–298`), subprocess timeout kills the direct numerical child, point/event preflight occurs before metric remeshing (`:362–379`), and geometry loops check the cooperative whole-driver deadline. Native libraries do not launch child processes in this pinned execution. Driver phases can overshoot a cooperative deadline; this is already declared. |
| Failure behavior | Resource, solver, geometry and convergence failures expose no final curve (`:417–421`). Existing source tests cover exceptions/nonfinite/residual/offset failures, real subprocess timeout/memory/condition/infeasibility, and nonconvergence. Independent resource test below confirms early failure on a competition-length input. |

No verified A04 P0/P1 implementation defect was established in this subreview.
The separate final-authority q/digest trust-boundary finding belongs to the
combined acceptance review; see its discussion below.

## Actual curvature objective: independently confirmed limitation

`quality_oracle.py` imports no production planner code. It integrates actual
coefficients with adaptive QUADPACK, constructs floating polynomial stationary
curvature equations, and uses direct polynomial projection controls. This differs
from the adapter's fixed 48-point Gaussian diagnostic and from the validators'
exact rational Bernstein bounds. The numerical oracle is a regression control,
not a continuous acceptance certificate. All seven stored final curvature
energies agree with the recorded diagnostics to floating arithmetic precision.

A fresh pinned run independently confirms S0 seed energy 1.0471975680989947 /m
and final energy 1.162781872642269 /m (+11.04%). The analytic radius-six circle
has 2*pi/6 = 1.0471975511965976 /m. Iterations increase actual energy
1.0471975681 -> 1.0858573260 -> 1.1477757015 -> 1.1627818726, while raw QP
linearization errors decrease .0434333 -> .0305152 -> .0112783 /m.

This has a direct mathematical explanation independent of implementation tests.
For a circular reference radius r0, frozen tangent derivative d0=r0*e_theta and a
concentric shifted radius r give frozen curvature
cross(d0,r'')/|d0|^3 = r/r0^2. Its square decreases when r contracts; actual
geometric curvature energy 2*pi/r increases. Consequently, the preserved
frozen-derivative surrogate need not have the correct descent direction for
actual integrated curvature. Changing a scalar QP normalization alone cannot
repair this direction. Right-positive offsets in the actual CCW example are
negative throughout the measured steps, consistent with contraction; there is
no demonstrated adapter sign reversal or damping error.

The requested architecture explicitly preserves this pinned TUM surrogate and
already disclaims monotonic exact energy. No quality threshold, new backend, or
surrogate modification is justified by the current W2 contract. W3 must retain
actual energy, peak curvature and model-time measurements and must not label the
numerical termination criterion as exact-objective optimality or mesh convergence.

## Cyclic origin and remeshing: measured consequences

A changed starting occurrence leaves exactly permuted fixed-mesh algebra
invariant within the predeclared 1e-8 m offset tolerance: an independently built
17-knot cyclic permutation gives maximum alpha difference 3.09216008354e-9 m.
The unchanged remesher (`route_corridor.py:159–181`) phases its uniform metric grid
at s=0 and then inserts exact semantic events. Changing origin changes the
physical positions of uniform samples unless the origin offset is an integer
multiple of the mesh step. The mesh and local surrogate consequently change.

The preserved full histories and the fresh run agree:

| Quantity | Original origin | Changed origin |
|---|---:|---:|
| Iterations | 3 | 3 |
| Final length, m | 34.3689501974305 | 34.3689501974190 |
| Actual energy, /m | 1.162781872642269 | 1.162781872649986 |
| Actual peak abs curvature, /m | .209266684447123 | .209266685160346 |
| Synthetic model lap time, s | 8.593509770179757 | 8.593509770331961 |
| Geometry / dynamics | PASS / PASS | PASS / PASS |

8192 independent q-correspondence probes find maximum position difference
1.546390 mm, maximum tangential component 1.527003 mm and maximum normal component
1.262704 mm. Actual polynomial nearest-curve projection controls find maximum
shape discrepancy about 1.262685 mm. Thus the effect includes a physical
remeshing ripple, not solely a change in q parameterization. Matching condition
numbers and linearization errors, unchanged energy/length and stable three-step
convergence give no evidence of numerical instability or broken correspondence.
No exact-origin-invariance threshold was specified for different meshes.

A fresh refinement from .4 m to .2 m changes actual energy to 1.15989095762 /m
(-.25%), peak abs curvature to .29378987281 /m (+40.4%) and synthetic model time
to 8.89808722728 s (+3.54%). Both independent validators PASS. Finer remeshing is
therefore not a demonstrated quality improvement. An optional future correction
for exact origin invariance would phase metric samples at a stable approved
semantic occurrence anchor rather than at the current serialization seam; this
must be specified and tested as a new quality policy, not retroactively imposed
as a W2 acceptance threshold.

The seed's synthetic model time is 9.42477788473 s. Its dynamics check PASSes, but
geometry reports FAIL at directed gate p2 (strict coefficient-endpoint passage
ambiguity); this seed is not a combined accepted reference. The initial audit
mistakenly expected seed geometry PASS; that failed experiment is preserved in
`runtime-quality/run.log`. The corrected audit records this verdict and still
requires both validators PASS on every final optimized candidate.

## Independent arc/time and residual controls

`profile_time_oracle.py` recomputes each profile edge's physical arc directly
from actual coefficients with adaptive quadrature, including closure, computes
acceleration from squared-speed differences and recomputes the analytic affine-u
edge time. Differences from reported times are -3.55e-15, 0 and -8.88e-15 s for
base/origin/remeshed. All recomputed times lie inside the independent checker
reported time enclosures. Distinct 17-point per-edge residual controls have no
positive acceleration/braking/motor normalized violation; the tightest observed
sampled acceleration residual is -1.326e-9 in the refined case. These controls
supplement, and do not replace, the complete whole-edge certificates.

## Independent q ancestry audit and handoff trust boundary

The final coefficients do not determine a unique original-seed correspondence
q. Monotone occurrence-aligned q alone cannot prove the claimed optimization
history. `trace_replay.py` independently reconstructs the original seed and
periodic reference/shifted fits with a cyclic second-derivative linear system,
without calling production Curve.interpolate, TUM calc_splines or candidate
hash functions. It verifies:

- Trusted seed q and occurrence anchors; each complete source_q chain.
- Source segment/t evaluation, inherited q formula, exact semantic-anchor
  membership and the declared half-open endpoint convention.
- Original owner at each inherited q, source-point -> reference interpolation,
  coefficient-derived right normal, damping and eroded nodal interval.
- Applied points -> shifted coefficients, then exact final coefficient/q identity.

All seven complete committed histories pass. Maximum source-point error is
8.88e-16 m; maximum independently reconstructed reference/shifted coefficient
difference is 8.70e-14 / 5.82e-14; maximum normal difference is 3.33e-16. These
numerical reconstruction tolerances are audit controls, not relaxed legality
margins. Deliberately mutating final q without modifying history is rejected by
exact final handoff identity. The initial assumption that every semantic q must
survive a floating t inverse/forward roundtrip exactly was false; its failed
experiment is retained in `trace-runtime/failed-exact-roundtrip.log`. Exact
approved anchors use the direct inverse-parameter formula instead.

An independently supplied expected final authority digest is an appropriate
bounded protection against corruption after a trusted A04 handoff: candidate q,
coefficients or policy edits cannot redefine the expected hash. That expected
value must come from the actual trusted producer/result or an independent replay,
not be recomputed from an attacker-replaced candidate. Digest agreement alone
does not establish arbitrary untrusted optimization ancestry; future immutable
artifact workflows must preserve that trust boundary explicitly.

## W3 resource prerequisite: measured limit, not a full benchmark

Scaling S0 legal geometry/seed/caps/support parameters by 6.4 produces a
241.274313849015 m periodic curve. Default A04 immediately returns RESOURCE_LIMIT,
`point budget exhausted before remeshing`, with no traces or final candidate.
This is the declared default guard at adapter line 370: .4 m * 512 points =
204.8 m, before counting semantic anchors. It is a measured default-policy
incompatibility with ~240 m S6, not evidence that larger valid policies or the
architecture cannot work. W3 must choose and measure a justified solver mesh/
point/child memory/time budget; raising a limit without measuring dense matrix
conditioning, memory and cubic algebra cost would not establish scalability.
No W3 implementation or full-course scaling campaign was performed.

## Reproducible commands and evidence

Pinned runtime uses `project-a-humble:w0`, Python 3.10 and declared locked
numerical dependencies. The focused runner records image ID, runtime identity,
dependency versions, exact source/fixture hashes, unchanged before/after hashes,
XML and command. Host-only independent numerical controls have their separate
Python/NumPy/SciPy versions recorded in `oracle-host-environment.txt`.

```
python work/adversarial/adapter/quality_oracle.py
scripts/project_a/unit.sh work/adversarial/adapter/runtime-quality-final \
  work/adversarial/adapter/test_independent_adapter.py -x
python work/adversarial/adapter/profile_time_oracle.py
PROJECT_A_OUTPUT=/workspace/race_stack/work/adversarial/adapter/trace-runtime \
PROJECT_A_UID=1000 PROJECT_A_GID=1000 \
docker --host=unix:///var/run/docker.sock compose -p project-a-adapter-trace \
  -f docker-compose.test.yaml run --rm -T --entrypoint /bin/bash test -c \
  'export PYTHONPATH=/src/planner/global_planner; python /src/work/adversarial/adapter/trace_replay.py'
```

Final focused suite: exit 0, **2 passed in 57.78 s**. Independent coefficient
quality, arc/time and trace replay commands: exit 0. Intermediate seed-control
failure, initial exact-roundtrip replay failure, and successful v2 experiment
are preserved. No production source, tolerance, fixture, model margin, backend,
optimizer submodule or hardware file was changed by this subreview.

## Phase II follow-up: permanent independent ancestry regression

After the root reviewer released the initial source freeze, the independent
history oracle was promoted to
`planner/global_planner/test/test_route_w2_trace_oracle.py`, callable
`verify_trace_lineage(route, traces, final_coefficients, final_q, policy)`.
It has no pytest test functions, hardcoded filesystem paths or production helper
imports. An additional exact half-open source-q interval check rejects choosing
the previous source segment at an exact semantic anchor. The integration owner
reuses all seven fresh pipeline results for permanent regression coverage without
running a second optimizer campaign. Promotion verification: strict flake8 with
99-column limit and all seven preserved-history replays exit 0. Frozen helper
SHA256: `6fee1b2ec1728a99d49ce1d68ca407f3ec8da73a80f7e726b2051b1659b937a6`.
Raw promotion logs/results are under `promoted-final/`. Root review owns final
commits, full verification and CI; this subreview does not independently claim
those later outcomes.

## Post-F2 read-only confirmation on corrected source

Repeated the fresh seed/base/changed-origin/.2 m quality campaign and 241 m
resource guard against the frozen F2 source committed as
`37b36ccc1f33300ce50e6c120c886147db11b4a7`. Only migrated scratch copies changed;
original scripts and all original results remain preserved. Both validators
receive the independently retained trusted A04 authority digest.

```
scripts/project_a/unit.sh work/adversarial/adapter/f2-quality/runtime \
  work/adversarial/adapter/f2-quality/test_independent_adapter.py -x
python work/adversarial/adapter/f2-quality/profile_time_oracle.py
python work/adversarial/adapter/f2-quality/compare_quality.py
```

Focused runner exits 0: **2 passed in 49.10 s**. Source/fixture hashes remain
unchanged across the run. Fresh final base/origin/refined candidates all receive
geometry and dynamics PASS. Independent adaptive arc/time controls agree within
3.56e-15 s and lie inside all checker enclosures; sampled residuals remain
nonpositive.

The base coefficients, q, actual energy/peak curvature and model time are
bit-identical to the initial campaign. Changed-origin and refined final
coefficient changes are at most 3.77e-9 m and 5.77e-10 m, respectively. Their
energy changes are below 1.52e-11 /m and peak-curvature changes below 6.50e-10 /m.
The refined model time is now 8.898074718327077 s (12.51 microseconds below the
initial result); changed-origin model time is 8.593509770211897 s, 3.21e-11 s
above the unchanged base. All earlier quality conclusions remain supported.
The model's conservative bound/LP discretization can change slightly when
coefficients change, so this confirmation does not assert bitwise profile parity.

Updated dense cyclic controls find 1.54639026392 mm maximum q-correspondence
position difference and approximately 1.26268499320 mm projected shape
variation. Neither degradation, cyclic-origin ripple nor the measured declared
241 m default point-budget rejection was removed or hidden by F2. Raw new
inputs, results, profile controls and before/after comparisons are preserved
under `f2-quality/`.
