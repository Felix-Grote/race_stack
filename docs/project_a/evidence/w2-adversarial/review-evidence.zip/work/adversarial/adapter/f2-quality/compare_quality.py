"""Read-only comparison of independent quality campaigns before/after F2."""
import hashlib
import json
import math
from pathlib import Path

import numpy as np
from quality_oracle import at_q, projection_control

OUT = Path(__file__).resolve().parent
FRESH = OUT/'runtime/independent-quality.json'
PREVIOUS = OUT.parent/'runtime-quality-final/independent-quality.json'


def main():
    fresh, previous = json.loads(FRESH.read_text()), json.loads(PREVIOUS.read_text())
    report = {'source_sha256': {str(p):hashlib.sha256(p.read_bytes()).hexdigest()
                               for p in (FRESH,PREVIOUS)}, 'before_after': {}}
    for name in ('base','changed_origin','remeshed'):
        a,b=fresh[name],previous[name]
        coefficient_delta=np.max(np.abs(np.array(a['coefficients'])-b['coefficients']))
        report['before_after'][name]={
            'coefficient_max_abs_difference_m':float(coefficient_delta),
            'q_max_abs_difference_m':float(np.max(np.abs(np.array(a['q'])-b['q']))),
            'metric_differences':{k:a['metric'][k]-b['metric'][k] for k in a['metric']},
            'model_lap_time_difference_s':a['lap_time_s']-b['lap_time_s'],
            'geometry':a['geometry']['status'],'dynamics':a['dynamics']['status']}
    base,shifted=fresh['base'],fresh['changed_origin']
    cb,qb=base['coefficients'],base['q']
    cs,qs=shifted['coefficients'],shifted['q']
    delta,tangential,normal=[],[],[]
    for q in np.linspace(0,qs[-1],8192,endpoint=False):
        q0=(q+qb[-1]/2)%qb[-1]
        point=at_q(cb,qb,q0)
        derivative=at_q(cb,qb,q0,1)
        tangent=derivative/math.hypot(*derivative)
        z=at_q(cs,qs,q)-point
        delta.append(math.hypot(*z))
        tangential.append(abs(float(z@tangent)))
        normal.append(abs(float(tangent[0]*z[1]-tangent[1]*z[0])))
    report['cyclic_origin']={
        'max_q_position_difference_m':max(delta),
        'max_q_tangential_difference_m':max(tangential),
        'max_q_normal_difference_m':max(normal),
        'projected_shape_discrepancy_control_m':max(projection_control(cb,cs),
                                                  projection_control(cs,cb)),
        'model_time_difference_s':shifted['lap_time_s']-base['lap_time_s']}
    (OUT/'comparison.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__':
    main()
