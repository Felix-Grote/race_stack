"""Independent adaptive arc/time and sampled residual controls for A04 quality."""
import hashlib
import json
import math
from pathlib import Path

import numpy as np
from scipy.integrate import quad
from quality_oracle import curvature, val

OUT = Path(__file__).resolve().parent
SOURCE = OUT/'runtime-quality-final/independent-quality.json'


def arc(c,a,b):
    return quad(lambda t: math.hypot(*val(c,t,1)),a,b,epsabs=2e-13,epsrel=2e-13)[0]


def main():
    source = json.loads(SOURCE.read_text())
    report = {'source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
              'scope':'numerical independent controls; dense residuals do not certify'}
    for name in ('base','changed_origin','remeshed'):
        item = source[name]
        coeff = item['coefficients']
        knots = item['profile']['knots']
        time, residuals = [], []
        for index,a in enumerate(knots):
            b = knots[(index+1)%len(knots)]
            if b['segment'] == a['segment']:
                assert b['t'] > a['t']
                ds = arc(coeff[a['segment']],a['t'],b['t'])
                end = b['t']
            else:
                assert b['segment'] == (a['segment']+1)%len(coeff)
                assert b['t'] == 0
                ds = arc(coeff[a['segment']],a['t'],1.)
                end = 1.
            u,v = a['u'],b['u']
            acceleration = (v-u)/(2*ds)
            time.append(2*ds/(math.sqrt(u)+math.sqrt(v)))
            for t in np.linspace(a['t'],end,17):
                partial = arc(coeff[a['segment']],a['t'],t)
                squared = u+(v-u)*partial/ds
                k = abs(curvature(coeff[a['segment']],t))
                force = acceleration+.02*squared
                residuals.append((force/2+k*squared/4-1,
                                  -force/3+k*squared/4-1,force/2.5-1))
        recomputed = math.fsum(time)
        lower,upper = item['dynamics']['lap_time_lower_s'],item['dynamics']['lap_time_upper_s']
        report[name] = {'quad_lap_time_s':recomputed,
                        'reported_lap_time_s':item['lap_time_s'],
                        'difference_s':recomputed-item['lap_time_s'],
                        'checker_lap_time_enclosure_s':[lower,upper],
                        'oracle_inside_reported_enclosure':lower<=recomputed<=upper,
                        'sampled_max_normalized_constraint_residuals':
                            np.max(np.asarray(residuals),axis=0).tolist(),
                        'edges':len(knots)}
        assert lower <= recomputed <= upper
        assert max(report[name]['sampled_max_normalized_constraint_residuals']) <= 1e-8
    (OUT/'profile_time_oracle.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__ == '__main__':
    main()
