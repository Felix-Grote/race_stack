"""Independent A04 quality/metamorphic experiments, final authority checked A05/A06."""
from dataclasses import asdict, replace
import hashlib
import inspect
import json
from pathlib import Path

import numpy as np
import trajectory_planning_helpers as tph

from global_planner.cyclic_retime import (
    DynamicsModel, ModelRegion, RegionLimits, SteeringLimits, curve_digest, retime)
from global_planner.iqp_route_adapter import SolverPolicy, optimize, solve_qp
from global_planner.route_corridor import seed_curve
from global_planner.route_input import load_route, validate_route
from global_planner.route_validate import Footprint, validate_geometry
from global_planner.route_validate_dynamics import validate_dynamics

from quality_oracle import metrics

ROOT = Path('/src')
FIX = ROOT / 'planner/global_planner/test/fixtures/project_a'
BODY = Footprint(front_m=.1, rear_m=.1, width_m=.12, margin_m=.01)


def model_for(route):
    return DynamicsModel(
        regions=tuple(ModelRegion(o.id, o.surface_id, RegionLimits(
            speed_min_mps=.05, speed_max_mps=4., ax_pos_mps2=2., ax_neg_mps2=3.,
            ay_mps2=4., motor_mps2=2.5, drag_over_mass=.02,
            provenance='independent explicit synthetic planar audit')) for o in route.occurrences),
        provenance='independent explicit synthetic planar audit',
        steering=SteeringLimits(wheelbase_m=.3, angle_max_rad=.7, rate_max_radps=3.))


def pipeline(ordered, require_geometry=True):
    route = ordered.route
    trusted_digest = curve_digest(ordered)
    geometry = validate_geometry(ordered, route, BODY, expected_curve_digest=trusted_digest)
    model = model_for(route)
    timed = retime(ordered, model, spacing_m=.5)
    if require_geometry:
        assert geometry.status == 'PASS', geometry.reason
    assert timed.status == 'CANDIDATE', timed.message
    dynamics = validate_dynamics(ordered, timed.profile, model, metadata=timed.metadata,
                                 expected_curve_digest=trusted_digest)
    assert dynamics.status == 'PASS', dynamics.reason
    return {'geometry': asdict(geometry), 'dynamics': asdict(dynamics),
            'lap_time_s': timed.profile.lap_time_s,
            'lap_time_enclosure_s': timed.metadata.lap_time_enclosure_s
            if hasattr(timed.metadata, 'lap_time_enclosure_s') else None,
            'profile': asdict(timed.profile), 'metadata': asdict(timed.metadata),
            'metric': metrics(ordered.curve.coefficients)}


def test_fresh_circle_origin_remeshing_and_true_integrated_objectives():
    route = load_route(FIX/'s0_route.json')
    shifted = route.payload
    shifted['occurrences'] = shifted['occurrences'][2:]+shifted['occurrences'][:2]
    shifted['transitions'] = shifted['transitions'][2:]+shifted['transitions'][:2]
    shifted['gate_sequence'] = [p['id'] for p in shifted['transitions']]
    shifted['finish'] = shifted['gate_sequence'][-1]
    shifted['initialization']['occurrence_id'] = shifted['occurrences'][0]['id']
    shifted['initialization']['zone'] = shifted['transitions'][-1]['support']
    routes = {'base': route, 'changed_origin': validate_route(shifted)}
    results, evidence = {}, {'scope': 'synthetic planar; numerical quality diagnostic'}
    evidence['seed'] = pipeline(seed_curve(route), require_geometry=False)
    for name, current, spacing in (
            ('base', routes['base'], .4), ('changed_origin', routes['changed_origin'], .4),
            ('remeshed', routes['base'], .2)):
        result = optimize(current, SolverPolicy(spacing_m=spacing))
        assert result.status == 'CANDIDATE', (name, result.status, result.reason)
        results[name] = result
        evidence[name] = pipeline(result.ordered)
        evidence[name].update(
            route_sha256=current.digest, spacing_m=spacing,
            iterations=[{'n': t.number, 'condition': t.qp.condition,
                         'curvature_error': t.qp.curvature_error,
                         'max_violation': t.qp.max_violation,
                         'alpha_min_m': min(t.qp.alpha), 'alpha_max_m': max(t.qp.alpha),
                         'source_energy': t.source_curvature_energy,
                         'shifted_energy': t.shifted_curvature_energy,
                         'mesh_points': len(t.q)-1} for t in result.traces],
            coefficients=result.ordered.curve.coefficients, q=result.ordered.q)
    # Control actual algebra under exact cyclic permutation of the same mesh,
    # independently constructing matrices from the retained helper source.
    t = results['base'].traces[0]
    track = np.array([s.xy+(c.right,c.left) for s,c in zip(t.samples,t.corridors)])
    shift = 17
    shifted_track = np.roll(track, shift, axis=0)
    lengths = np.roll(np.diff(t.q), shift)
    _,_,matrix,normals = tph.calc_splines.calc_splines(
        np.vstack((shifted_track[:,:2],shifted_track[0,:2])),
        el_lengths=lengths,use_dist_scaling=True)
    control = solve_qp(shifted_track,normals,matrix)
    difference = float(np.max(np.abs(control.alpha-np.roll(t.qp.alpha,shift))))
    evidence['fixed_mesh_cyclic_qp_max_alpha_difference_m'] = difference
    assert difference < 1e-8
    evidence['helper_sha256'] = {name:hashlib.sha256(
        Path(inspect.getfile(getattr(tph,name))).read_bytes()).hexdigest()
        for name in ('opt_min_curv','calc_splines','iqp_handler')}
    Path('/work/independent-quality.json').write_text(json.dumps(evidence,indent=2)+'\n')


def test_competition_length_default_point_limit_precedes_numerical_solve():
    raw = load_route(FIX/'s0_route.json').payload
    scale = 6.4
    for occurrence in raw['occurrences']:
        for key in ('seed','left','right'):
            occurrence[key] = [[scale*x,scale*y] for x,y in occurrence[key]]
        for cap in occurrence['caps']:
            cap['at_m'] *= scale
    for portal in raw['transitions']:
        for key in ('gate','support'):
            portal[key] = [[scale*x,scale*y] for x,y in portal[key]]
        portal['before_m'] *= scale
        portal['after_m'] *= scale
    init = raw['initialization']
    init['zone'] = [[scale*x,scale*y] for x,y in init['zone']]
    init['seed_interval_m'] = [scale*x for x in init['seed_interval_m']]
    route = validate_route(raw)
    seed = seed_curve(route)
    result = optimize(route)
    assert seed.curve.length > 240
    assert result.status == 'RESOURCE_LIMIT', result.reason
    assert result.ordered is None and result.traces == ()
    Path('/work/resource-preflight.json').write_text(json.dumps({
        'route_sha256':route.digest,'length_m':seed.curve.length,
        'status':result.status,'reason':result.reason,'policy':asdict(result.policy),
        'scope':'measured declared default limit, not a full S6 scaling experiment'},indent=2)+'\n')
