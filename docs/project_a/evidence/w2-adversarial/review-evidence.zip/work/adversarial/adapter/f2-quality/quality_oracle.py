"""Independent numerical quality audit; sampling/projection do not certify legality.

Adaptive QUADPACK integrals and polynomial stationary roots differ from adapter's
fixed Gaussian diagnostic and validators' exact rational Bernstein machinery.
This script reads preserved evidence only and imports no production planner code.
"""
import bisect
import gzip
import hashlib
import json
import math
from pathlib import Path

import numpy as np
from scipy.integrate import quad
from scipy.spatial import cKDTree

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
CANDIDATES = ROOT / 'docs/project_a/evidence/w2-a04/a04-candidates.json.gz'
ORIGIN = ROOT / 'docs/project_a/evidence/w2-a04/a04-origin-shift.json'


def val(c, t, order=0):
    c = np.asarray(c)
    if order == 0:
        return c[:, 0] + t * (c[:, 1] + t * (c[:, 2] + t * c[:, 3]))
    if order == 1:
        return c[:, 1] + t * (2 * c[:, 2] + 3 * t * c[:, 3])
    return 2 * c[:, 2] + 6 * t * c[:, 3]


def curvature(c, t):
    d, dd = val(c, t, 1), val(c, t, 2)
    return np.cross(d, dd).item() / math.hypot(*d)**3


def metrics(coefficients):
    lengths, energies, errs, peaks = [], [], [], []
    for c in coefficients:
        c = np.asarray(c)
        length, el = quad(lambda t: math.hypot(*val(c, t, 1)), 0, 1,
                          epsabs=2e-13, epsrel=2e-13)
        energy, ee = quad(lambda t: curvature(c, t)**2 * math.hypot(*val(c, t, 1)),
                          0, 1, epsabs=2e-13, epsrel=2e-13)
        lengths.append(length)
        energies.append(energy)
        errs.append((el, ee))
        # Stationary kappa: 2*c'*g - 3*c*g'=0, computed independently
        # in binary64 polynomial algebra and checked with dense controls.
        dx, dy = c[0, 1:] * (1, 2, 3), c[1, 1:] * (1, 2, 3)
        poly = np.polynomial.Polynomial
        x, y = poly(dx), poly(dy)
        g, cross = x*x+y*y, x*y.deriv()-y*x.deriv()
        f = 2*cross.deriv()*g-3*cross*g.deriv()
        critical = [0., 1.] + [r.real for r in f.roots()
                              if abs(r.imag) < 1e-8 and 0 < r.real < 1]
        peak = max(abs(curvature(c, t)) for t in critical)
        assert peak + 1e-12 >= max(abs(curvature(c, t)) for t in np.linspace(0, 1, 65))
        peaks.append(peak)
    return {'length_m': math.fsum(lengths), 'energy_per_m': math.fsum(energies),
            'max_abs_curvature_per_m': max(peaks),
            'quad_error_estimate_length_m': math.fsum(x[0] for x in errs),
            'quad_error_estimate_energy_per_m': math.fsum(x[1] for x in errs)}


def at_q(coefficients, q, parameter, derivative=0):
    i = min(max(0, bisect.bisect_right(q, parameter)-1), len(coefficients)-1)
    t = (parameter-q[i])/(q[i+1]-q[i])
    return val(coefficients[i], t, derivative)


def projection_control(source, target, count=2048):
    # Dense index finds candidate segments; polynomial stationary roots then
    # project onto those actual cubics. This is a numerical regression oracle.
    dense = np.array([val(c, t) for c in target for t in np.linspace(0, 1, 33)])
    tree = cKDTree(dense)
    worst = 0.
    poly = np.polynomial.Polynomial
    for c in source:
        for t in np.linspace(0, 1, max(5, math.ceil(count/len(source)))):
            p = val(c, t)
            _, index = tree.query(p, k=8)
            ids = set((int(i)//33+j) % len(target) for i in index for j in (-1, 0, 1))
            best = math.inf
            for j in ids:
                d = np.array(target[j], copy=True)
                d[:, 0] -= p
                fx, fy = poly(d[0]), poly(d[1])
                roots = (fx*fx.deriv()+fy*fy.deriv()).roots()
                values = [0., 1.] + [r.real for r in roots if abs(r.imag) < 1e-8 and 0 < r.real < 1]
                best = min(best, *(math.dist(p, val(target[j], v)) for v in values))
            worst = max(worst, best)
    return worst


def main():
    evidence = json.loads(gzip.decompress(CANDIDATES.read_bytes()))
    shifted = json.loads(ORIGIN.read_text())
    report = {'inputs_sha256': {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                               for p in (CANDIDATES, ORIGIN)},
              'scope': 'independent numerical quality control; no continuous certificate',
              's0_circle_analytic_seed_energy_per_m': 2*math.pi/6,
              'candidates': {name: metrics(candidate['final_coefficients'])
                             for name, candidate in evidence.items()}}
    base = evidence['s0_route']
    target = shifted['traces'][-1]
    report['cyclic_origin'] = {'base': metrics(base['final_coefficients']),
                              'shifted': metrics(target['shifted_coefficients'])}
    cb, qb = base['final_coefficients'], base['final_q']
    cs, qs = target['shifted_coefficients'], target['q']
    # Half-lap occurrence shift in preserved test; q remains inherited seed q.
    offset = qb[-1]/2
    delta, tangential, normal = [], [], []
    for q in np.linspace(0, qs[-1], 8192, endpoint=False):
        p = at_q(cb, qb, (q+offset)%qb[-1])
        d = at_q(cb, qb, (q+offset)%qb[-1], 1)
        tangent = d/math.hypot(*d)
        z = at_q(cs, qs, q)-p
        delta.append(math.hypot(*z))
        tangential.append(abs(float(z@tangent)))
        normal.append(abs(float(np.cross(tangent, z))))
    report['cyclic_origin'].update(
        max_q_position_difference_m=max(delta),
        max_q_tangential_difference_m=max(tangential),
        max_q_normal_difference_m=max(normal),
        projected_shape_discrepancy_control_m=max(projection_control(cb, cs),
                                                  projection_control(cs, cb)),
        base_iterations=len(base['traces']), shifted_iterations=len(shifted['traces']),
        base_conditions=[t['qp']['condition'] for t in base['traces']],
        shifted_conditions=[t['qp']['condition'] for t in shifted['traces']],
        base_qp_errors=[t['qp']['curvature_error'] for t in base['traces']],
        shifted_qp_errors=[t['qp']['curvature_error'] for t in shifted['traces']])
    report['s0_iteration_offsets'] = [{
        'iteration': t['number'], 'alpha_min_m': min(t['qp']['alpha']),
        'alpha_max_m': max(t['qp']['alpha']),
        'reference': metrics(t['coefficients']), 'shifted': metrics(t['shifted_coefficients'])}
        for t in base['traces']]
    (OUT/'quality_oracle.json').write_text(json.dumps(report, indent=2, allow_nan=False)+'\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
