"""A04 history control independent of candidate hashes and spline helper matrices.

Direct periodic second-derivative equations reconstruct interpolation. Point and
coefficient comparisons are numerical audit controls, never geometry acceptance.
Final coefficient/q identity and source lineage q relationships are exact.
"""
import bisect
import gzip
import hashlib
import json
import math
from pathlib import Path

import numpy as np

from global_planner.route_input import load_route

ROOT = Path('/src')
FIX = ROOT/'planner/global_planner/test/fixtures/project_a'


def spline(points,q):
    points = np.asarray(points,float)
    h = np.diff(q)
    n = len(points)
    matrix = np.zeros((n,n))
    rhs = np.zeros((n,2))
    for i in range(n):
        before,after = (i-1)%n,(i+1)%n
        matrix[i,before] += h[before]
        matrix[i,i] += 2*(h[before]+h[i])
        matrix[i,after] += h[i]
        rhs[i] = 6*((points[after]-points[i])/h[i]-(points[i]-points[before])/h[before])
    second = np.linalg.solve(matrix,rhs)
    answer = []
    for i in range(n):
        after=(i+1)%n
        a=points[i]
        b=points[after]-points[i]-h[i]**2*(2*second[i]+second[after])/6
        c=h[i]**2*second[i]/2
        d=h[i]**2*(second[after]-second[i])/6
        answer.append(np.stack((a,b,c,d),axis=1))
    return np.asarray(answer)


def evaluate(coeff,t,derivative=0):
    c=np.asarray(coeff)
    if derivative:
        return c[:,1]+2*t*c[:,2]+3*t*t*c[:,3]
    return c[:,0]+t*(c[:,1]+t*(c[:,2]+t*c[:,3]))


def seed(route):
    points,q,ends=[],[],[0.]
    for o in route.occurrences:
        local=0.
        for a,b in zip(o.seed,o.seed[1:]):
            points.append(a)
            q.append(ends[-1]+local)
            local += math.hypot(b[0]-a[0],b[1]-a[1])
        ends.append(ends[-1]+o.length)
    q.append(ends[-1])
    return spline(points,q),q,ends


def replay(route,traces,final_coefficients,final_q,policy):
    source,source_q,ends=seed(route)
    anchors=set(ends[:-1])
    for i,o in enumerate(route.occurrences):
        anchors.update(ends[i]+cap[0] for cap in o.caps)
        anchors.add(ends[i+1]-route.portals[i].before)
        anchors.add(ends[(i+1)%len(route.occurrences)]+route.portals[i].after)
    maxima={'reference_point_error_m':0.,'reference_coefficient_error':0.,
            'normal_error':0.,'shifted_coefficient_error':0.}
    for iteration,trace in enumerate(traces,1):
        assert trace['number']==iteration
        assert source_q==trace['source_q'],'source q chain differs from trusted seed/history'
        lineage,q=trace['lineage'],trace['q']
        assert all(a<b for a,b in zip(q,q[1:])) and q[0]==0 and q[-1]==ends[-1]
        assert len(lineage)==len(q)-1==len(trace['samples'])
        assert all(anchor in q for anchor in ends),'occurrence anchor lost'
        points=[]
        for j,(segment,t,inherited) in enumerate(lineage):
            assert type(segment) is int and 0<=segment<len(source) and 0<=t<=1
            expected=(1-t)*source_q[segment]+t*source_q[segment+1]
            assert inherited==q[j],'stored lineage and output q disagree'
            if inherited in anchors:
                assert t==(inherited-source_q[segment])/(source_q[segment+1]-source_q[segment]),'semantic anchor parameter changed'
            else:
                expected=max(source_q[segment],min(expected,math.nextafter(source_q[segment+1],source_q[segment])))
                assert inherited==expected,'lineage q formula changed'
            point=evaluate(source[segment],t)
            points.append(point)
            sample=trace['samples'][j]
            owner=route.occurrences[min(bisect.bisect_right(ends,q[j])-1,len(ends)-2)]
            assert (sample['occurrence_id'],sample['surface_id'])==(owner.id,owner.surface_id)
            assert sample['q']==q[j]
            error=float(np.max(np.abs(point-sample['xy'])))
            maxima['reference_point_error_m']=max(maxima['reference_point_error_m'],error)
            assert error<1e-10,'reference point does not descend from source curve'
        reference=np.asarray(trace['coefficients'])
        error=float(np.max(np.abs(spline(points,q)-reference)))
        maxima['reference_coefficient_error']=max(maxima['reference_coefficient_error'],error)
        assert error<1e-10,'reference fit does not interpolate inherited source points'
        moved=[]
        factor=min(1.,iteration/policy['min_iterations'])
        for j,(normal,alpha,applied,corridor) in enumerate(zip(
                trace['normals_right'],trace['qp']['alpha'],trace['applied_alpha'],trace['corridors'])):
            d=evaluate(reference[j],0.,1)
            expected=np.array((d[1],-d[0]))/math.hypot(*d)
            error=float(np.max(np.abs(expected-normal)))
            maxima['normal_error']=max(maxima['normal_error'],error)
            assert error<1e-12
            assert applied==alpha*factor,'damped step changed'
            assert -corridor['left']+policy['vehicle_width_m']/2-policy['offset_tolerance']<=applied
            assert applied<=corridor['right']-policy['vehicle_width_m']/2+policy['offset_tolerance']
            moved.append(reference[j,:,0]+applied*np.asarray(normal))
        shifted=np.asarray(trace['shifted_coefficients'])
        error=float(np.max(np.abs(spline(moved,q)-shifted)))
        maxima['shifted_coefficient_error']=max(maxima['shifted_coefficient_error'],error)
        assert error<1e-10,'shifted coefficients are not the actual applied nodal fit'
        source,source_q=shifted,list(q)
    assert source_q==list(final_q),'final q handoff differs from checked history'
    assert np.array_equal(source,final_coefficients),'final coefficients differ from checked history'
    return maxima


def main():
    data=json.loads(gzip.decompress((ROOT/'docs/project_a/evidence/w2-a04/a04-candidates.json.gz').read_bytes()))
    result={}
    for name,candidate in data.items():
        route=load_route(FIX/(name+'.json'))
        # Corridors serialize dataclass bounds, whereas their convenience left/
        # right properties are deliberately recomputed here with declared signs.
        for trace in candidate['traces']:
            for corridor in trace['corridors']:
                corridor['left']=corridor['upper']
                corridor['right']=-corridor['lower']
        result[name]=replay(route,candidate['traces'],candidate['final_coefficients'],
                            candidate['final_q'],candidate['policy'])
    candidate=data['s0_route']
    corrupt=list(candidate['final_q'])
    corrupt[3]=(corrupt[2]+corrupt[4])/2
    try:
        replay(load_route(FIX/'s0_route.json'),candidate['traces'],
               candidate['final_coefficients'],corrupt,candidate['policy'])
    except AssertionError as exc:
        result['corrupt_final_q_rejected']=str(exc)
    else:
        raise AssertionError('q mutation survived independent history audit')
    Path('/work/trace-replay.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    main()
