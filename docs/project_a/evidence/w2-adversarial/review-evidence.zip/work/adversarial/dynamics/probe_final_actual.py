"""High-precision external oracle for freshly produced final W2 records.

No production numerical, geometry, support, hash or retimer helper is imported.
These independent numerical controls supplement the continuous certificates.
"""
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path
import platform
import sys
import time
import unicodedata

sys.path.insert(0, str(Path(__file__).resolve().parent / 'deps'))
import mpmath as mp

mp.mp.dps = 70
_GL = {n: mp.gauss_quadrature(n, 'legendre') for n in (24, 40)}
ROOT = Path('/src')
FIX = ROOT / 'planner/global_planner/test/fixtures/project_a'
NAMES = ('s0_route', 's0_reverse_route', 's0_rotated_route', 's2_upper_route',
         's2_lower_route', 's3_surfaces_route', 's3_notch_route')


def rational_mp(value):
    if isinstance(value, Fraction):
        return mp.mpf(value.numerator) / value.denominator
    return mp.mpf(value)


def frame(coefficients, parameter):
    c = [[mp.mpf(x) for x in row] for row in coefficients]
    t = rational_mp(parameter)
    d = [row[1] + 2 * row[2] * t + 3 * row[3] * t * t for row in c]
    dd = [2 * row[2] + 6 * row[3] * t for row in c]
    ddd = [6 * row[3] for row in c]
    speed = mp.sqrt(sum(x * x for x in d))
    cross = d[0] * dd[1] - d[1] * dd[0]
    curvature = cross / speed ** 3
    rate = ((d[0] * ddd[1] - d[1] * ddd[0]) / speed ** 3 -
            3 * cross * sum(a * b for a, b in zip(d, dd)) / speed ** 5) / speed
    return speed, curvature, rate


def arc(coefficients, first, last, order=24):
    roots, weights = _GL[order]
    c = [[mp.mpf(x) for x in row] for row in coefficients]
    half = (rational_mp(last) - rational_mp(first)) / 2
    mid = (rational_mp(last) + rational_mp(first)) / 2
    values = []
    for root, weight in zip(roots, weights):
        t = mid + half * root
        d = [row[1] + 2 * row[2] * t + 3 * row[3] * t * t for row in c]
        values.append(weight * mp.sqrt(sum(x * x for x in d)))
    return half * mp.fsum(values)


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                     allow_nan=False).encode()).hexdigest()


def normalize_route(value):
    if type(value) is dict:
        return {unicodedata.normalize('NFC', k): normalize_route(v) for k, v in value.items()}
    if type(value) is list:
        return [normalize_route(v) for v in value]
    if type(value) is str:
        return unicodedata.normalize('NFC', value)
    number = float(value)
    return int(number) if number.is_integer() else number


def route_digest(route):
    encoded = json.dumps(normalize_route(route), sort_keys=True, separators=(',', ':'),
                         ensure_ascii=False, allow_nan=False).encode()
    return hashlib.sha256(encoded).hexdigest()


def event_intervals(route, model):
    """Build a separate circular event-overlay oracle from original route JSON."""
    ends = [0.]
    for occurrence in route['occurrences']:
        seed = occurrence['seed']
        # q inherits the route's declared binary64 seed-polyline metric, rather
        # than the final optimized curve's high-precision arc metric.
        length = 0.
        for a, b in zip(seed, seed[1:]):
            length += math.hypot(b[0] - a[0], b[1] - a[1])
        ends.append(ends[-1] + length)
    qends = list(map(Fraction, ends))
    regions = {(r['occurrence_id'], r['surface_id']): r['limits'] for r in model['regions']}
    model_spans, cap_spans = [], []
    for index, occurrence in enumerate(route['occurrences']):
        key = occurrence['id'], occurrence['surface_id']
        model_spans.append((qends[index], qends[index + 1], key))
        caps = occurrence['caps']
        for j, entry in enumerate(caps):
            left = qends[index] + Fraction(entry['at_m'])
            right = (qends[index] + Fraction(caps[j + 1]['at_m']) if j + 1 < len(caps)
                     else qends[index + 1])
            cap_spans.append((left, right, entry['max_speed_mps'], index))
    # Add portal overlays independently of individual profile edge subdivision.
    # Each overlay spans the circular portal support and carries two models plus
    # the minimum static cap over its declared two source progress brackets.
    for index, portal in enumerate(route['transitions']):
        target = (index + 1) % len(route['occurrences'])
        before = Fraction(portal['before_m'])
        after = Fraction(portal['after_m'])
        left, right = qends[index + 1] - before, qends[index + 1] + after
        source_span = (qends[index + 1] - before, qends[index + 1])
        target_span = (qends[target], qends[target] + after)
        caps = [cap for a, b, cap, owner in cap_spans
                if ((owner == index and a <= source_span[1] and b >= source_span[0]) or
                    (owner == target and a <= target_span[1] and b >= target_span[0]))]
        cap = min(caps)
        for shift in (-qends[-1], Fraction(0), qends[-1]):
            for owner in (index, target):
                occurrence = route['occurrences'][owner]
                model_spans.append((left + shift, right + shift,
                                    (occurrence['id'], occurrence['surface_id'])))
            cap_spans.append((left + shift, right + shift, cap, -1))
    return qends, model_spans, cap_spans, regions


def check_scenario(name, record):
    route_path = FIX / (name + '.json')
    route_bytes = route_path.read_bytes()
    route = json.loads(route_bytes)
    assert route_digest(route) == record['route_sha256']
    actual_identity = digest({'coefficients': record['coefficients'], 'owners': record['owners'],
                              'q': record['q'], 'route_digest': record['route_sha256'],
                              'numeric_policy': record['numeric_policy']})
    profile = record['retimer']['profile']
    metadata = record['retimer']['metadata']
    assert actual_identity == record['expected_curve_digest'] == profile['curve_digest']
    assert actual_identity == metadata['curve_digest'] == record['geometry']['curve_digest']
    assert actual_identity == record['dynamics']['curve_digest']
    assert digest(record['model']) == profile['model_digest'] == record['dynamics']['model_digest']
    assert record['geometry']['status'] == record['dynamics']['status'] == 'PASS'
    assert record['retimer']['status'] == 'CANDIDATE'
    qends, model_spans, cap_spans, regions = event_intervals(route, record['model'])
    q = list(map(Fraction, record['q']))
    assert qends[-1] == q[-1]
    knots, certificates = profile['knots'], record['dynamics']['edges']
    assert len(knots) == len(certificates)
    anchors = [(knot['segment'], Fraction(knot['t'])) for knot in knots]
    assert anchors[0] == (0, 0)
    assert all(first < second for first, second in zip(anchors, anchors[1:]))
    assert all((index, Fraction(0)) in anchors for index in range(len(record['coefficients'])))
    worst = {}
    samples = 0
    times, details = [], []
    largest_quadrature_difference = mp.mpf(0)
    stations = [mp.mpf(0)]
    for coefficient in record['coefficients'][:-1]:
        stations.append(stations[-1] + arc(coefficient, 0, 1, 40))
    for index, knot in enumerate(knots):
        following = knots[(index + 1) % len(knots)]
        assert following['segment'] in (knot['segment'],
                                         (knot['segment'] + 1) % len(record['coefficients']))
        first = Fraction(knot['t'])
        last = Fraction(following['t']) if following['segment'] == knot['segment'] else Fraction(1)
        coefficient = record['coefficients'][knot['segment']]
        distance, crosscheck = arc(coefficient, first, last), arc(coefficient, first, last, 40)
        difference = abs(distance - crosscheck)
        largest_quadrature_difference = max(largest_quadrature_difference, difference)
        assert difference < mp.mpf('1e-45')
        certificate = certificates[index]
        assert certificate['distance_lower_m'] <= distance <= certificate['distance_upper_m']
        ui, uj = mp.mpf(knot['u']), mp.mpf(following['u'])
        assert min(ui, uj) > 0
        acceleration = (uj - ui) / (2 * distance)
        assert certificate['acceleration_lower_mps2'] <= acceleration
        assert acceleration <= certificate['acceleration_upper_mps2']
        edge_time = 2 * distance / (mp.sqrt(ui) + mp.sqrt(uj))
        assert certificate['time_lower_s'] <= edge_time <= certificate['time_upper_s']
        times.append(edge_time)
        station = stations[knot['segment']] + arc(coefficient, 0, first, 40)
        assert abs(station - metadata['stations_m'][index]) < mp.mpf('1e-7')
        assert abs(mp.sqrt(ui) - metadata['velocity_mps'][index]) < mp.mpf('1e-7')
        assert abs(acceleration - metadata['acceleration_mps2'][index]) < mp.mpf('1e-7')
        for j in range(9):
            parameter = first + (last - first) * Fraction(j, 8)
            partial = arc(coefficient, first, parameter) if j else mp.mpf(0)
            u = ui + (uj - ui) * partial / distance
            progress = q[knot['segment']] + parameter * (q[knot['segment'] + 1] - q[knot['segment']])
            active = {key for left, right, key in model_spans if left <= progress <= right}
            cap = min(cap for left, right, cap, _ in cap_spans if left <= progress <= right)
            _, curvature, rate = frame(coefficient, parameter)
            assert abs(curvature) <= certificate['curvature_upper']
            assert abs(rate) <= certificate['curvature_rate_upper']
            moving_floor_squared = mp.mpf(1e-6) ** 2
            values = {'static_speed': u / mp.mpf(cap) ** 2 - 1,
                      'moving_speed': (moving_floor_squared - u) / moving_floor_squared}
            for key in active:
                limits = regions[key]
                drive = acceleration + mp.mpf(limits['drag_over_mass']) * u
                checks = {'model_speed': u / mp.mpf(limits['speed_max_mps']) ** 2 - 1,
                          'minimum_speed': mp.mpf(limits['speed_min_mps']) ** 2 - u,
                          'motor': drive / limits['motor_mps2'] - 1,
                          'positive': drive / limits['ax_pos_mps2'] +
                          abs(curvature) * u / limits['ay_mps2'] - 1,
                          'negative': -drive / limits['ax_neg_mps2'] +
                          abs(curvature) * u / limits['ay_mps2'] - 1,
                          'lateral': abs(curvature) * u / limits['ay_mps2'] - 1}
                for field, value in checks.items():
                    values[field] = max(values.get(field, mp.ninf), value)
            steering = record['model']['steering']
            if steering:
                b = mp.mpf(steering['wheelbase_m'])
                values['steering_angle_rad'] = abs(mp.atan(b * curvature)) - steering['angle_max_rad']
                actual_rate = b * rate * mp.sqrt(u) / (1 + (b * curvature) ** 2)
                values['steering_rate'] = actual_rate ** 2 / mp.mpf(steering['rate_max_radps']) ** 2 - 1
            for field, value in values.items():
                worst[field] = max(worst.get(field, mp.ninf), value)
                allowance = mp.mpf('1e-10') if field == 'steering_angle_rad' else mp.mpf('1e-8')
                assert value <= allowance, (name, index, str(parameter), field, str(value))
            samples += 1
        details.append({'edge': index, 'distance_m': str(distance),
                        'acceleration_mps2': str(acceleration), 'time_s': str(edge_time)})
    time_oracle = mp.fsum(times)
    assert record['dynamics']['lap_time_lower_s'] <= time_oracle <= record['dynamics']['lap_time_upper_s']
    assert abs(time_oracle - profile['lap_time_s']) < mp.mpf('1e-7')
    return {'name': name, 'status': 'PASS', 'curve_digest': actual_identity,
            'model_digest': profile['model_digest'], 'route_sha256': record['route_sha256'],
            'fixture_file_sha256': hashlib.sha256(route_bytes).hexdigest(),
            'edges': len(knots), 'independent_dynamic_samples': samples,
            'max_sampled_residuals': {field: str(value) for field, value in worst.items()},
            'oracle_lap_time_s': str(time_oracle),
            'lap_time_enclosure_s': [record['dynamics']['lap_time_lower_s'],
                                     record['dynamics']['lap_time_upper_s']],
            'maximum_24_40_quadrature_difference_m': str(largest_quadrature_difference),
            'edge_details': details}


def run(source, output):
    began = time.monotonic()
    data = source.read_bytes()
    records = json.loads(data)
    assert tuple(records['scenarios']) == NAMES
    results = []
    for name in NAMES:
        results.append(check_scenario(name, records['scenarios'][name]))
        print(name, results[-1]['edges'], results[-1]['independent_dynamic_samples'], 'PASS', flush=True)
    sources = ['route_reference.py', 'route_validate.py', 'route_validate_dynamics.py',
               'iqp_route_adapter.py', '_route_geometry.py', 'cyclic_retime.py']
    evidence = {'status': 'PASS', 'scope': 'Fresh actual final W2 pipeline independent numerical controls',
                'limitations': 'Sampled residual controls supplement the continuous rational certificates.',
                'oracle_script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                'reviewed_implementation_sha': '37b36ccc1f33300ce50e6c120c886147db11b4a7',
                'source_pipeline': str(source), 'source_pipeline_sha256': hashlib.sha256(data).hexdigest(),
                'python': sys.version, 'platform': platform.platform(), 'mpmath': mp.__version__,
                'decimal_digits': mp.mp.dps, 'elapsed_s': time.monotonic() - began,
                'source_hashes': {name: hashlib.sha256((ROOT / 'planner/global_planner/global_planner' /
                                                       name).read_bytes()).hexdigest() for name in sources},
                'scenarios': results}
    output.write_text(json.dumps(evidence, indent=2))
    return evidence
