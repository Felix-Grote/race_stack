"""Verify retained final outputs and compare functional/legacy mathematical records."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path


def _mathematical_payload(record):
    value = copy.deepcopy(record)
    for scenario in value['scenarios'].values():
        for trace in scenario['solver_iterations']:
            del trace['qp']['peak_rss_bytes']
            del trace['qp']['elapsed_seconds']
            del trace['reference_fit_resources']
            del trace['shifted_fit_resources']
    return value


def _differences(first, second, path=''):
    assert type(first) is type(second), path
    if isinstance(first, dict):
        assert first.keys() == second.keys(), path
        for key in first:
            yield from _differences(first[key], second[key], path + '/' + key)
    elif isinstance(first, list):
        assert len(first) == len(second), path
        for index, (left, right) in enumerate(zip(first, second)):
            yield from _differences(left, right, path + '/' + str(index))
    elif first != second:
        yield {'path': path, 'functional': first, 'retained': second}


def test_final_retained_actual_pipeline_and_exact_mathematical_equivalence():
    base = Path(__file__).parent
    functional_bytes = (base / 'final-actual-functional-pipeline.json').read_bytes()
    retained_bytes = (base / 'final-actual-retained-pipeline.json').read_bytes()
    functional_hash = hashlib.sha256(functional_bytes).hexdigest()
    retained_hash = hashlib.sha256(retained_bytes).hexdigest()
    assert functional_hash == '886a5ae3f048db79bebad842eb24c24f4c1ce4893d35c1ce313555e65afbbf83'
    assert retained_hash == 'fb42f757f888a524be7e8912ba2bb77e9b87f584c59c26cac0e513643bc3f862'
    live = Path('/src/work/adversarial/final-full/w2-pipeline.json').read_bytes()
    assert hashlib.sha256(live).hexdigest() == retained_hash
    functional, retained = json.loads(functional_bytes), json.loads(retained_bytes)
    left, right = _mathematical_payload(functional), _mathematical_payload(retained)
    assert left == right, 'functional and retained mathematical records changed'
    canonical = json.dumps(left, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()
    differences = list(_differences(functional, retained))
    assert len(differences) == 126
    for difference in differences:
        path = difference['path']
        assert ('/solver_iterations/' in path and
                (path.endswith('/qp/peak_rss_bytes') or path.endswith('/qp/elapsed_seconds') or
                 '/reference_fit_resources/' in path or '/shifted_fit_resources/' in path)), path
    evidence = {
        'status': 'PASS', 'functional_snapshot_sha256': functional_hash,
        'retained_snapshot_sha256': retained_hash,
        'complete_math_payload_equal': True,
        'common_math_payload_sha256': hashlib.sha256(canonical).hexdigest(),
        'excluded_resource_fields': ['solver_iterations[*].qp.peak_rss_bytes',
                                     'solver_iterations[*].qp.elapsed_seconds',
                                     'solver_iterations[*].reference_fit_resources',
                                     'solver_iterations[*].shifted_fit_resources'],
        'scalar_resource_differences': differences}
    Path('/work/functional-retained-equivalence.json').write_text(json.dumps(evidence, indent=2))
    path = base / 'probe_final_actual.py'
    spec = importlib.util.spec_from_file_location('final_retained_oracle', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    report = module.run(base / 'final-actual-retained-pipeline.json',
                        Path('/work/final-retained-independent-oracle.json'))
    assert report['status'] == 'PASS'
