"""Read-only Phase I runtime control for a novel retiming mesh."""
from pathlib import Path
import gzip
import json

from global_planner.cyclic_retime import DynamicsModel, ModelRegion, RegionLimits, retime
from global_planner.route_corridor import OrderedCurve
from global_planner.route_input import load_route
from global_planner.route_reference import Curve


def test_novel_retiming_mesh():
    fix = Path('/src/planner/global_planner/test/fixtures/project_a')
    records = json.loads(gzip.decompress((fix / 'w2_a04_candidates.json.gz').read_bytes()))
    output = {}
    for name, record in records['candidates'].items():
        route = load_route(fix / (name + '.json'))
        ordered = OrderedCurve(route, Curve(record['coefficients'], record['owners']), record['q'])
        limits = RegionLimits(.05, 4., 2., 3., 4., 3., .02, 'independent numerical probe')
        model = DynamicsModel(tuple(ModelRegion(o.id, o.surface_id, limits)
                                    for o in route.occurrences), 'independent numerical probe')
        result = retime(ordered, model, spacing_m=.613)
        output[name] = result.status, result.message
    Path('/work/mesh-results.json').write_text(json.dumps(output, indent=2))
    assert all(value[0] == 'CANDIDATE' for value in output.values()), output
