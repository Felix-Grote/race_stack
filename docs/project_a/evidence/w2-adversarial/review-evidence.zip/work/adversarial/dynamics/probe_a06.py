"""Independent A06 probes: high precision geometry, integrals and model arithmetic.

Exploratory oracle: high precision sampled residuals cannot establish acceptance.
This file deliberately avoids the production interval/arc/support helpers in its
oracle. Retimer/checker are exercised separately before comparison.
"""
from dataclasses import asdict, replace
from fractions import Fraction
import gzip
import hashlib
import json
import math
from pathlib import Path
import platform
import random
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parent / 'deps'))
import mpmath as mp
import numpy as np
import scipy

from global_planner.cyclic_retime import (
    DynamicsModel, ModelRegion, RegionLimits, SpeedKnot, SpeedProfile,
    SteeringLimits, curve_digest, model_digest, retime)
from global_planner.route_corridor import OrderedCurve
from global_planner.route_input import load_route, validate_route
from global_planner.route_reference import Curve
from global_planner.route_validate import BoundUncertain, interval_bounds
from global_planner.route_validate_dynamics import validate_dynamics

ROOT = Path(__file__).resolve().parents[3]
FIX = ROOT / 'planner/global_planner/test/fixtures/project_a'
OUT = Path(__file__).resolve().parent
mp.mp.dps = 70
GL = {n: mp.gauss_quadrature(n, 'legendre') for n in (24, 40)}


def frame(coeff, t):
    c = [[mp.mpf(x) for x in row] for row in coeff]
    d = [row[1] + 2 * row[2] * t + 3 * row[3] * t * t for row in c]
    dd = [2 * row[2] + 6 * row[3] * t for row in c]
    ddd = [6 * row[3] for row in c]
    speed = mp.sqrt(sum(x * x for x in d))
    cross = d[0] * dd[1] - d[1] * dd[0]
    curvature = cross / speed ** 3
    # Differentiate signed curvature directly, then divide by ds/dt.
    dcurvature = ((d[0] * ddd[1] - d[1] * ddd[0]) / speed ** 3 -
                 3 * cross * sum(a * b for a, b in zip(d, dd)) / speed ** 5) / speed
    return speed, curvature, dcurvature


def arc(coeff, a, b, order=24):
    roots, weights = GL[order]
    c = [[mp.mpf(x) for x in row] for row in coeff]
    half, mid = (mp.mpf(b) - a) / 2, (mp.mpf(b) + a) / 2
    values = []
    for root, weight in zip(roots, weights):
        t = mid + half * root
        d = [row[1] + 2 * row[2] * t + 3 * row[3] * t * t for row in c]
        values.append(weight * mp.sqrt(sum(x * x for x in d)))
    return half * mp.fsum(values)


def candidate(name):
    path = FIX / 'w2_a04_candidates.json.gz'
    record = json.loads(gzip.decompress(path.read_bytes()))['candidates'][name]
    route = load_route(FIX / (name + '.json'))
    return OrderedCurve(route, Curve(record['coefficients'], record['owners']), record['q'])


def model_for(ordered):
    limits = RegionLimits(.05, 4., 2., 3., 4., 3., .02,
                          'independent A06 adversarial synthetic budget')
    return DynamicsModel(tuple(ModelRegion(o.id, o.surface_id, limits)
                               for o in ordered.route.occurrences),
                         'independent adversarial A06 model', SteeringLimits(.3, .7, 3.))


def retiming_oracle(name):
    ordered = candidate(name)
    expected = curve_digest(ordered)
    model = model_for(ordered)
    timed = retime(ordered, model, spacing_m=.613)
    assert timed.status == 'CANDIDATE', (name, timed.message)
    report = validate_dynamics(ordered, timed.profile, model, metadata=timed.metadata,
                               expected_curve_digest=expected)
    assert report.status == 'PASS', (name, report.reason)
    limits, steering = model.regions[0].limits, model.steering
    results = []
    time_oracle = mp.mpf(0)
    sampled_residual = mp.mpf(-1)
    max_arc_difference = mp.mpf(0)
    for i, knot in enumerate(timed.profile.knots):
        following = timed.profile.knots[(i + 1) % len(timed.profile.knots)]
        b = following.t if following.segment == knot.segment else 1.
        coeff = ordered.curve.coefficients[knot.segment]
        ds = arc(coeff, knot.t, b)
        ds2 = arc(coeff, knot.t, b, 40)
        max_arc_difference = max(max_arc_difference, abs(ds - ds2))
        assert abs(ds - ds2) < mp.mpf('1e-50')
        certificate = report.edges[i]
        assert mp.mpf(certificate.distance_lower_m) <= ds <= certificate.distance_upper_m
        a = (mp.mpf(following.u) - knot.u) / (2 * ds)
        edge_time = 2 * ds / (mp.sqrt(knot.u) + mp.sqrt(following.u))
        assert mp.mpf(certificate.time_lower_s) <= edge_time <= certificate.time_upper_s
        time_oracle += edge_time
        for j in range(9):
            parameter = mp.mpf(knot.t) + (mp.mpf(b) - knot.t) * j / 8
            travelled = arc(coeff, knot.t, parameter) if j else mp.mpf(0)
            u = mp.mpf(knot.u) + (mp.mpf(following.u) - knot.u) * travelled / ds
            _, curvature, rate = frame(coeff, parameter)
            assert abs(curvature) <= certificate.curvature_upper
            assert abs(rate) <= certificate.curvature_rate_upper
            # All oracle models have equal limits on every owner, so support
            # selection is immaterial here and no production support code is used.
            drive = a + mp.mpf(limits.drag_over_mass) * u
            bsteer = mp.mpf(steering.wheelbase_m)
            residual = max(drive / limits.ax_pos_mps2 +
                           abs(curvature) * u / limits.ay_mps2 - 1,
                           -drive / limits.ax_neg_mps2 +
                           abs(curvature) * u / limits.ay_mps2 - 1,
                           drive / limits.motor_mps2 - 1,
                           abs(mp.atan(bsteer * curvature)) / steering.angle_max_rad - 1,
                           abs(bsteer * rate * mp.sqrt(u) /
                               (1 + (bsteer * curvature) ** 2)) / steering.rate_max_radps - 1)
            sampled_residual = max(sampled_residual, residual)
        results.append({'edge': i, 'oracle_arc_m': str(ds),
                        'oracle_acceleration_mps2': str(a),
                        'oracle_time_s': str(edge_time)})
    assert sampled_residual <= mp.mpf('1e-8')
    assert mp.mpf(report.lap_time_lower_s) <= time_oracle <= report.lap_time_upper_s
    mutations = {
        'curve_digest': replace(timed.profile, curve_digest='f' * 64),
        'model_digest': replace(timed.profile, model_digest='f' * 64),
        'time': replace(timed.profile, lap_time_s=timed.profile.lap_time_s + .01),
        'closing_profile': replace(timed.profile, knots=timed.profile.knots[:-1]),
        'negative_speed': replace(timed.profile, knots=(replace(timed.profile.knots[0], u=-1.),)
                                  + timed.profile.knots[1:]),
        'interior_overspeed': replace(timed.profile, knots=(
            replace(timed.profile.knots[0], u=100.),) + timed.profile.knots[1:]),
    }
    mutation_statuses = {}
    for key, profile in mutations.items():
        checked = validate_dynamics(ordered, profile, model,
                                    expected_curve_digest=expected)
        assert checked.status != 'PASS', (name, key)
        mutation_statuses[key] = checked.status, checked.reason
    return {'name': name, 'curve_digest': curve_digest(ordered),
            'model_digest': model_digest(model), 'route_digest': ordered.route.digest,
            'knots': len(timed.profile.knots), 'retimer': timed.status, 'checker': report.status,
            'oracle_lap_time_s': str(time_oracle),
            'time_enclosure_s': [report.lap_time_lower_s, report.lap_time_upper_s],
            'max_sampled_residual': str(sampled_residual),
            'max_24_40_gauss_difference_m': str(max_arc_difference),
            'mutation_statuses': mutation_statuses, 'edges': results}


def bound_oracle():
    rng = random.Random(9642017)
    counts = {'input_boxes': 0, 'uncertain_boxes': 0, 'certified_boxes': 0, 'points': 0}
    for _ in range(400):
        scale = 10 ** rng.uniform(-5, 5)
        coeff = [[rng.uniform(-1, 1) * scale for _ in range(4)] for _ in range(2)]
        a = rng.randrange(0, 1024) / 1024
        b = min(1., a + 2. ** -rng.randrange(0, 14))
        counts['input_boxes'] += 1
        try:
            bounds = interval_bounds(coeff, a, b)
        except BoundUncertain:
            counts['uncertain_boxes'] += 1
            continue
        counts['certified_boxes'] += 1
        for j in range(33):
            parameter = mp.mpf(a) + (mp.mpf(b) - a) * j / 32
            speed, curvature, rate = frame(coeff, parameter)
            assert bounds.speed_lower <= speed <= bounds.speed_upper
            assert abs(curvature) <= bounds.curvature_upper
            assert abs(rate) <= bounds.curvature_rate_upper
            counts['points'] += 1
    return counts


def analytic_oracles():
    base = candidate('s0_route')
    base_expected = curve_digest(base)
    length = mp.fsum(arc(c, 0., 1., 40) for c in base.curve.coefficients)
    controls = {}
    for label, top, motor, drag, expected in (
            ('constant_speed', 2.3, 100., 0., mp.mpf(2.3) ** 2),
            ('motor_drag_cycle', 4., .7, .23, mp.mpf(.7) / mp.mpf(.23))):
        limits = RegionLimits(.05, top, 1e8, 1e8, 1e12, motor, drag,
                              'independent analytic cyclic budget')
        model = DynamicsModel(tuple(ModelRegion(o.id, o.surface_id, limits)
                                    for o in base.route.occurrences), label)
        timed = retime(base, model, spacing_m=.731)
        assert timed.status == 'CANDIDATE', timed.message
        checked = validate_dynamics(base, timed.profile, model, metadata=timed.metadata,
                                    expected_curve_digest=base_expected)
        assert checked.status == 'PASS', checked.reason
        error = max(abs(mp.mpf(k.u) - expected) for k in timed.profile.knots)
        assert error < mp.mpf('1e-7')
        controls[label] = {'squared_speed_optimum': str(expected),
                           'max_node_error': str(error),
                           'true_curve_length_m': str(length),
                           'analytic_lap_time_s': str(length / mp.sqrt(expected)),
                           'retimed_lap_time_s': timed.profile.lap_time_s,
                           'checker': checked.status}
    # Two unequal cap pulses and asymmetric acceleration/braking yield a closed
    # directed distance-cone envelope. Pulse locations are well outside portals.
    payload = base.route.payload
    for occurrence in payload['occurrences']:
        occurrence['caps'] = [{'at_m': 0., 'max_speed_mps': 3.7}]
    pulses = [(0, 1.473, 2.663, .89), (1, 3.112, 4.456, 1.25)]
    for owner, first, last, cap in pulses:
        payload['occurrences'][owner]['caps'].extend([
            {'at_m': first, 'max_speed_mps': cap},
            {'at_m': last, 'max_speed_mps': 3.7}])
    ordered = OrderedCurve(validate_route(payload), base.curve, base.q)
    expected = curve_digest(ordered)
    limits = RegionLimits(.05, 5., 1.3, .7, 1e12, 1e8, 0., 'asymmetric distance cones')
    model = DynamicsModel(tuple(ModelRegion(o.id, o.surface_id, limits)
                                for o in ordered.route.occurrences), 'two novel cap pulses')
    timed = retime(ordered, model, spacing_m=.731)
    assert timed.status == 'CANDIDATE', timed.message
    checked = validate_dynamics(ordered, timed.profile, model, metadata=timed.metadata,
                                expected_curve_digest=expected)
    assert checked.status == 'PASS', checked.reason
    ends = [0.]
    for occurrence in ordered.route.occurrences:
        ends.append(ends[-1] + occurrence.length)
    pulse_intervals = [(Fraction(ends[i]) + Fraction(a),
                        Fraction(ends[i]) + Fraction(b), cap) for i, a, b, cap in pulses]
    edges, caps = [], []
    knots = timed.profile.knots
    for index, knot in enumerate(knots):
        following = knots[(index + 1) % len(knots)]
        b = following.t if following.segment == knot.segment else 1.
        edges.append(arc(ordered.curve.coefficients[knot.segment], knot.t, b, 40))
        q0, q1 = map(Fraction, ordered.q[knot.segment:knot.segment + 2])
        low = q0 + Fraction(knot.t) * (q1 - q0)
        high = q0 + Fraction(b) * (q1 - q0)
        applicable = [cap for first, last, cap in pulse_intervals
                      if first <= high and last >= low]
        caps.append(mp.mpf(min([3.7] + applicable)) ** 2)
    node_caps = [min(caps[i - 1], caps[i]) for i in range(len(knots))]
    stations = [mp.mpf(0)]
    for distance in edges[:-1]:
        stations.append(stations[-1] + distance)
    lap = mp.fsum(edges)
    errors = []
    for i, station in enumerate(stations):
        envelope = min(node_caps[j] + min(2 * mp.mpf(limits.ax_pos_mps2) *
                                          ((station - anchor) % lap),
                                          2 * mp.mpf(limits.ax_neg_mps2) *
                                          ((anchor - station) % lap))
                       for j, anchor in enumerate(stations))
        errors.append(abs(mp.mpf(knots[i].u) - envelope))
    assert max(errors) < mp.mpf('1e-7')
    controls['two_pulse_asymmetric_cycle'] = {'knots': len(knots),
                                              'max_envelope_error': str(max(errors)),
                                              'checker': checked.status,
                                              'pulses_original_seed_metric': pulses}
    return controls


def main():
    began = time.monotonic()
    names = ('s0_route', 's0_reverse_route', 's0_rotated_route', 's2_upper_route',
             's2_lower_route', 's3_surfaces_route', 's3_notch_route')
    results = []
    for name in names:
        result = retiming_oracle(name)
        results.append(result)
        print(name, result['knots'], result['checker'], flush=True)
    bounds = bound_oracle()
    analytics = analytic_oracles()
    output = {'scope': 'Independent high precision adversarial regression; sampled tests are not proofs',
              'python': sys.version, 'platform': platform.platform(),
              'numpy': np.__version__, 'scipy': scipy.__version__, 'mpmath': mp.__version__,
              'precision_decimal_digits': mp.mp.dps, 'elapsed_s': time.monotonic() - began,
              'fixture_sha256': hashlib.sha256((FIX / 'w2_a04_candidates.json.gz').read_bytes()).hexdigest(),
              'bounds': bounds, 'retimings': results, 'analytic_oracles': analytics}
    (OUT / 'independent-oracle.json').write_text(json.dumps(output, indent=2))
    print(bounds, 'elapsed', output['elapsed_s'])


if __name__ == '__main__':
    main()
