# Independent A06 verification of final actual pipeline records

Reviewed implementation: **37b36ccc1f33300ce50e6c120c886147db11b4a7**.
This run consumes the freshly generated final full-verification records; it
does not retime old frozen fixture coefficients or substitute a new profile.

Command from the repository root:

```
scripts/project_a/unit.sh work/adversarial/dynamics/final-actual-37b36ccc work/adversarial/dynamics/test_final_actual.py -x -s
```

Result: **exit 0; one test passed in 16.78 seconds**, pinned Python 3.10.12,
mpmath 1.3.0, 70 decimal digits. Before/after production and fixture hashes are
identical. All unit-run environment, dependency, source, fixture and image
identities are retained in `final-actual-37b36ccc`.

Input is `work/adversarial/final-full/w2-pipeline.json`, 7,465,572 bytes,
SHA256 `886a5ae3f048db79bebad842eb24c24f4c1ce4893d35c1ce313555e65afbbf83`.
The full snapshot is included in the separate final actual evidence archive.

The new standalone oracle imports no production numerical, geometry, support,
hash or retimer helper. It independently normalizes approved-route JSON and
recomputes route, model and complete curve identities, including q/owners and
the independent expected handoff digest. A separate circular event-overlay
implementation derives active original static caps and occurrence/portal
models from the original route files. It directly differentiates the actual
coefficients and independently generates 24/40-point high-precision Gaussian
rules for true arc distance, u interpolation, acceleration and traversal time.

All seven actual coefficient/profile/model records pass: **1,267 edges** and
**11,403 independent dynamic sample points**, including every closing edge.
The per-scenario knot counts are 166/166/166/155/151/231/232. All independently
computed edge arc, acceleration and time values lie within their recorded
certificate enclosures; the high-precision total lap times lie inside the
recorded lap enclosures. The maximum 24/40-rule discrepancy is below 8.58e-55 m.
The closest sampled motor/diamond/lateral/steering normalized residual is
approximately -1.00233e-9. Lap enclosure widths range from 1.70e-10 to 2.33e-10 s.
Exported stations, velocity and right-hand acceleration agree independently.

| Scenario | Independent lap time (s; abbreviated) |
|---|---:|
| S0 | 8.593509770179753391 |
| S0 reversed | 8.593509770196429996 |
| S0 rotated | 8.593509770233525232 |
| S2 upper | 9.411623852760156260 |
| S2 lower | 8.587343724788766448 |
| S3 surfaces | 16.419262763707429148 |
| S3 notch | 16.419182801564939908 |

These independent sampled controls supplement the rational whole-interval
certificates and the source-level sufficiency argument. They are not substituted
for continuous acceptance or physical vehicle evidence. The root's final
exact-head local/installed/hosted verification remains the project release gate.

A harness dry run on the prior complete pipeline is retained separately in
`final-actual-harness-dry`; it is not final exact-head acceptance evidence.
All original Phase I and F1 oracle sources/results remain unchanged.
