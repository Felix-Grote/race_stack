"""Read-only independent final freshly generated pipeline verification."""
import importlib.util
from pathlib import Path


def test_actual_final_profiles_with_distinct_high_precision_oracle():
    path = Path(__file__).with_name('probe_final_actual.py')
    spec = importlib.util.spec_from_file_location('final_actual_oracle', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    source = Path('/src/work/adversarial/final-full/w2-pipeline.json')
    report = module.run(source, Path('/work/final-actual-independent-oracle.json'))
    assert report['status'] == 'PASS'
