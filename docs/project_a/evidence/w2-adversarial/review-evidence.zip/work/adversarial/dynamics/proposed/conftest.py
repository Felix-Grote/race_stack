"""Exercise the proposed checker without changing the Phase I source checkout."""
import importlib.util
from pathlib import Path
import sys

import global_planner

path = Path(__file__).with_name('route_validate_dynamics.py')
spec = importlib.util.spec_from_file_location('global_planner.route_validate_dynamics', path)
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
global_planner.route_validate_dynamics = module
