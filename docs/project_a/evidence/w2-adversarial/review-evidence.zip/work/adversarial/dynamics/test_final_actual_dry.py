"""Harness dry run on the prior complete pipeline; no final verdict evidence."""
import importlib.util
from pathlib import Path


def test_actual_profile_oracle_harness():
    path = Path(__file__).with_name('probe_final_actual.py')
    spec = importlib.util.spec_from_file_location('final_actual_oracle_dry', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    source = Path('/src/work/adversarial/corrected-full/w2-pipeline.json')
    report = module.run(source, Path('/work/dry-run-independent-oracle.json'))
    assert report['status'] == 'PASS'
