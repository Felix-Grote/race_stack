# Independent A06 investigation at e852641849b2497efea51dfca5ead38ad4476235

Implementation files and existing tests were read without changes before this
report. This review also read the package AGENTS, execution plan, W2 numerics,
status/results/decisions, and canonical architecture/roadmap. The original A06
implementation is not accepted merely because its authors' tests passed.

## Re-derived mathematical contract

For an edge of true arc distance D, the profile defines
u(s)=u_i+(u_j-u_i)(s-s_i)/D. Consequently acceleration a=du/ds/2 is constant,
including last-to-first. With nonnegative drag coefficient c, the tire/motor
drive term is a+c*u; braking uses its negative and the independent negative
axis. The sufficient diamond inequalities are affine in a and u after replacing
absolute curvature by a whole-edge upper bound K. Endpoint u and both distance
extremes enclose the required rectangle in (a,u). This establishes sufficiency
even though a and u are physically correlated. The extra lateral inequality in
the checker is redundant because both longitudinal signs are checked.

The independent derivation of curvature rate is
(2*cprime*g-3*c*gprime)/(2*g^3), where c=cross(rprime,rsecond) and
g=dot(rprime,rprime). This agrees with production. Steering has
absolute rate b*abs(kappa_s)*sqrt(u)/(1+(b*kappa)^2). Dropping the denominator to
one is conservative; neither retimer nor checker enlarges that denominator
using an upper curvature bound. Exact edge time is
2*D/(sqrt(u_i)+sqrt(u_j)), also at equal endpoint speeds.

CSV minima cover the full declared speed interval, including interior knots.
Every linear piece attains a minimum at an endpoint. Exact rational
interpolation and inward conversion therefore give conservative constants.
The byte snapshot supplying parsed values also supplies the recorded SHA256;
the model intentionally makes no unprovided physical tire/contact claim.

## Executed independent controls

All commands were executed from /workspace/race_stack. Production code remained
unchanged. Pinned tests used Python 3.10.12, NumPy 1.26.4, SciPy 1.11.4 and the
isolated project-a-humble:w0 image. Each run retains runtime/source/fixture/image
identities and full output in its named output directory.

1. `scripts/project_a/unit.sh work/adversarial/dynamics/pinned-mesh work/adversarial/dynamics/test_runtime_mesh.py -x`
   exited 0, one test, 6.08 seconds. All seven actual frozen coefficient
   candidates retimed at the novel 0.613 m requested mesh.
2. `scripts/project_a/unit.sh work/adversarial/dynamics/pinned-oracle-analytic work/adversarial/dynamics/test_independent_oracle.py -x -s`
   exited 0, one test, 36.09 seconds. The independent oracle uses mpmath 1.3.0
   at 70 decimal digits, separately generated 24/40-order Gauss quadrature, and
   direct derivative/model arithmetic. It consumes no production arc,
   interval-bound, support, LP-row or residual helpers in its oracle arithmetic.
   Its source and copied pure-Python dependency are in this scratch directory.
3. `scripts/project_a/unit.sh work/adversarial/dynamics/pinned-shared-kernel work/adversarial/dynamics/test_shared_metric_fault.py -x`
   exited 0, one test, 1.79 seconds. This intentionally injects a violation of
   the trusted W1 arithmetic model; it is a dependency experiment, not a source
   defect or an accepted profile.

The seven fresh retimings contain 154/154/154/143/139/213/214 knots. All pass the
unchanged checker. For every edge, the independent arc and analytic edge time
lie inside the checker's outward enclosures; independent total lap time lies
inside its lap enclosure. Widths are approximately 1.57e-10 to 1.88e-10 seconds.
At nine independently evaluated true-arc positions per edge, no positive model
residual is observed; the closest sampled residual is approximately -1.003e-9.
All 42 deliberate digest, time, missing-boundary, negative-speed and overspeed
mutations are rejected. These samples supplement the mathematical argument;
they are not being substituted for continuous certification.

Across 400 deterministic random coefficient/parameter boxes spanning scales
1e-5 to 1e5, four boxes correctly remain uncertain. All 13,068 independently
evaluated points in the 396 certifiable boxes satisfy the returned speed,
absolute curvature and absolute curvature-rate bounds.

Independent analytic controls on a new 0.731 m requested mesh establish:

- Constant maximum speed 2.3 m/s: u=2.3^2, maximum node error 9.24e-16.
- Cyclic motor/drag limit M=0.7, c=0.23: integrating acceleration around a
  closed lap gives integral(u ds)<=M*L/c. Constant u=M/c attains the global
  optimum; maximum node difference is 3.0435e-9, consistent with the declared
  normalized 1e-9 inward LP margin.
- Two unequal short cap pulses, with positive/negative axes 1.3/0.7, produce a
  148-knot profile. An independent directed-cycle distance-cone envelope agrees
  to 1.2933e-8 in squared speed. Actual arc distances, not q or station-prefix
  subtraction, supply that oracle.

## Observed trust boundaries and limitations

The retimer and checker independently assemble constraints and support logic,
but share W1 arc integration and A05 polynomial bounds. Injecting a 1% common
arc overestimate makes both agree on PASS while the separate high-precision
oracle measures absolute acceleration 1.0099999989845 against an axis of 1.
This demonstrates correlated dependency failure. No such numerical defect in
the actual kernel was demonstrated by this investigation; the 1% injection
explicitly violates its declared error model. Distinct high-precision controls
must remain part of future changes to those shared primitives.

An independent integration investigation demonstrated that a monotone internal
q-map warp can move a narrow source cap. Rehashing all supplied authorities
makes both validators agree, while the same profile checked against the
original q-map fails. The arithmetic certificate proves consistency of the
supplied (coefficients,q) authority; a hash alone does not prove original
optimizer history. Under the user's explicit intermediate-corruption scope,
the root reviewer has classified the missing independently bound final-handoff
identity as requiring remediation. The bounded correction will require a
separately supplied expected final-curve digest captured at the trusted A04
handoff. It must not claim to authenticate optimization history from hashes.

Host Python 3.12 exploratory runs returned INCONCLUSIVE at all tested spacings
because a near-ulp semantic interval had uncertainty exceeding its arc. The
same source and mesh pass in the supported pinned Python 3.10 runtime. The
failed host attempt remains in oracle-run.log and is not treated as supported
acceptance evidence or hidden by widening a tolerance.

No production A06 false-positive numerical certificate was otherwise
demonstrated. This is a Phase I component report, not the final project verdict.
