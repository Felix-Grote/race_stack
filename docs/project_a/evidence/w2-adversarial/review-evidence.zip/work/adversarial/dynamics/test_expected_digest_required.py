"""Failing-first API regression: no independently supplied final identity."""
import json
from pathlib import Path
import runpy

from global_planner.route_validate_dynamics import validate_dynamics


def test_missing_independent_final_identity_cannot_certify_pass():
    helpers = runpy.run_path('/src/planner/global_planner/test/test_route_validate_dynamics.py')
    ordered = helpers['load_candidate']()
    model = helpers['model_for'](ordered.route)
    profile = helpers['profile_for'](ordered, model, [1.] * len(ordered.curve.segments))
    report = validate_dynamics(ordered, profile, model)
    Path('/work/missing-identity-result.json').write_text(json.dumps({
        'actual_status': report.status, 'actual_reason': report.reason,
        'expected_status': 'INCONCLUSIVE',
        'reason': 'Caller supplied no independently trusted final-curve handoff identity.'}, indent=2))
    assert report.status == 'INCONCLUSIVE', (report.status, report.reason)
