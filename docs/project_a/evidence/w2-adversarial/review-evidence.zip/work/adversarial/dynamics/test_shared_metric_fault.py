"""Demonstrate the declared shared-kernel trust boundary using fault injection.

This is not a discovered implementation defect. The injected one-percent arc
error intentionally violates W1's error model; independent high precision
integration detects it while two consumers of the corrupted kernel agree.
"""
from dataclasses import replace
import importlib.util
import json
from pathlib import Path

from global_planner.cyclic_retime import DynamicsModel, ModelRegion, RegionLimits, curve_digest, retime
from global_planner.route_corridor import OrderedCurve
from global_planner.route_input import validate_route
from global_planner.route_reference import CubicSegment
from global_planner.route_validate_dynamics import validate_dynamics


def test_shared_metric_fault_requires_distinct_oracle(monkeypatch):
    path = Path(__file__).with_name('probe_a06.py')
    spec = importlib.util.spec_from_file_location('fault_oracle', path)
    oracle = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(oracle)
    original = CubicSegment._integrate

    def corrupt_arc(self, t):
        nominal, error = original(self, t)
        return nominal * 1.01, error

    monkeypatch.setattr(CubicSegment, '_integrate', corrupt_arc)
    base = oracle.candidate('s0_route')
    payload = base.route.payload
    payload['occurrences'][0]['caps'] = [
        {'at_m': 0., 'max_speed_mps': 4.},
        {'at_m': 3., 'max_speed_mps': .5},
        {'at_m': 3.1, 'max_speed_mps': 4.}]
    route = validate_route(payload)
    ordered = OrderedCurve(route, base.curve, base.q)
    limits = RegionLimits(.05, 4., 1., 1., 1e12, 1e8, 0., 'deliberate kernel fault')
    model = DynamicsModel(tuple(ModelRegion(o.id, o.surface_id, limits)
                                for o in route.occurrences), 'deliberate kernel fault')
    result = retime(ordered, model, spacing_m=.731)
    assert result.status == 'CANDIDATE', result.message
    checked = validate_dynamics(ordered, result.profile, model, metadata=result.metadata,
                                 expected_curve_digest=curve_digest(ordered))
    assert checked.status == 'PASS', checked.reason
    actual_accelerations = []
    knots = result.profile.knots
    for index, knot in enumerate(knots):
        following = knots[(index + 1) % len(knots)]
        b = following.t if following.segment == knot.segment else 1.
        ds = oracle.arc(ordered.curve.coefficients[knot.segment], knot.t, b, 40)
        actual_accelerations.append((oracle.mp.mpf(following.u) - knot.u) / (2 * ds))
    worst = max(abs(a) for a in actual_accelerations)
    assert worst > oracle.mp.mpf('1.009')
    Path('/work/shared-kernel-fault.json').write_text(json.dumps({
        'finding_class': 'deliberate fault injection; shared dependency limitation',
        'injected_arc_multiplier': 1.01, 'retimer': result.status,
        'checker': checked.status, 'true_max_absolute_acceleration': str(worst),
        'supplied_positive_negative_axes': [1., 1.],
        'independent_oracle': '70-digit 40-point Gauss integration of exact input coefficients',
        'interpretation': 'Independent constraint assembly does not independently verify W1 arc kernel.'
    }, indent=2))
