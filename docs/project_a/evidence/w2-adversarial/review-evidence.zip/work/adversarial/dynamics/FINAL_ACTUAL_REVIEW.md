# Independent A06 verification of final actual pipeline records

Reviewed implementation: **37b36ccc1f33300ce50e6c120c886147db11b4a7**.
This run consumes the freshly generated final full-verification records; it
does not retime old frozen fixture coefficients or substitute a new profile.

The original functional-stage command from the repository root:

```
scripts/project_a/unit.sh work/adversarial/dynamics/final-actual-37b36ccc work/adversarial/dynamics/test_final_actual.py -x -s
```

Result: **exit 0; one test passed in 16.78 seconds**, pinned Python 3.10.12,
mpmath 1.3.0, 70 decimal digits. Before/after production and fixture hashes are
identical. All unit-run environment, dependency, source, fixture and image
identities are retained in `final-actual-37b36ccc`.

Input is `work/adversarial/final-full/w2-pipeline.json`, 7,465,572 bytes,
SHA256 `886a5ae3f048db79bebad842eb24c24f4c1ce4893d35c1ce313555e65afbbf83`.
The full snapshot is included in the separate final actual evidence archive.

The new standalone oracle imports no production numerical, geometry, support,
hash or retimer helper. It independently normalizes approved-route JSON and
recomputes route, model and complete curve identities, including q/owners and
the independent expected handoff digest. A separate circular event-overlay
implementation derives active original static caps and occurrence/portal
models from the original route files. It directly differentiates the actual
coefficients and independently generates 24/40-point high-precision Gaussian
rules for true arc distance, u interpolation, acceleration and traversal time.

All seven actual coefficient/profile/model records pass: **1,267 edges** and
**11,403 independent dynamic sample points**, including every closing edge.
The per-scenario knot counts are 166/166/166/155/151/231/232. All independently
computed edge arc, acceleration and time values lie within their recorded
certificate enclosures; the high-precision total lap times lie inside the
recorded lap enclosures. The maximum 24/40-rule discrepancy is below 8.58e-55 m.
The closest sampled motor/diamond/lateral/steering normalized residual is
approximately -1.00233e-9. Lap enclosure widths range from 1.70e-10 to 2.33e-10 s.
Exported stations, velocity and right-hand acceleration agree independently.

| Scenario | Independent lap time (s; abbreviated) |
|---|---:|
| S0 | 8.593509770179753391 |
| S0 reversed | 8.593509770196429996 |
| S0 rotated | 8.593509770233525232 |
| S2 upper | 9.411623852760156260 |
| S2 lower | 8.587343724788766448 |
| S3 surfaces | 16.419262763707429148 |
| S3 notch | 16.419182801564939908 |

These independent sampled controls supplement the rational whole-interval
certificates and the source-level sufficiency argument. They are not substituted
for continuous acceptance or physical vehicle evidence. The root's final
exact-head local/installed/hosted verification remains the project release gate.

A harness dry run on the prior complete pipeline is retained separately in
`final-actual-harness-dry`; it is not final exact-head acceptance evidence.
All original Phase I and F1 oracle sources/results remain unchanged.

## Recheck of the final retained output after the legacy aggregate

The full verification later reran the same pipeline tests in its legacy
aggregate and overwrote `/work/w2-pipeline.json` with another complete fresh
run. The retained final snapshot has SHA256
`fb42f757f888a524be7e8912ba2bb77e9b87f584c59c26cac0e513643bc3f862`.
The original functional snapshot is preserved separately as
`final-actual-functional-pipeline.json`; the retained snapshot is
`final-actual-retained-pipeline.json`. The original functional review is also
preserved unchanged as `FINAL_ACTUAL_FUNCTIONAL_REVIEW.md` and in its original
evidence archive.

Exact full-payload comparison finds **126 scalar differences**, all resource
measurements from 7 scenarios × 3 iterations: QP peak RSS/time, reference-fit
peak RSS/time, and shifted-fit peak RSS/time. Removing precisely these four
named fields per trace gives **identical complete mathematical payloads**,
including every curve coefficient, q/owner/route/policy, model, speed profile,
metadata, A04 numerical history and both complete certificates. The common
canonical mathematical-payload SHA256 is
`aef04784288e6c0718db106bfac672cf9e0bd692942f2d9b6466b27d0e2e354e`.
No numerical tolerance is used for this equality comparison.

The final retained records were additionally rechecked from scratch:

```
scripts/project_a/unit.sh work/adversarial/dynamics/final-actual-retained-37b36ccc work/adversarial/dynamics/test_final_retained.py -x -s
```

Result: **exit 0; one test passed in 17.73 seconds**, unchanged production and
fixture hashes. All seven retained records again pass the full 70-digit oracle
over 1,267 edges and 11,403 true-arc sample points, with the same independent
lap times and residuals reported above. Machine-readable scalar differences
and equality proof are in `functional-retained-equivalence.json`; retained
numerical results are in `final-retained-independent-oracle.json`, both under
`final-actual-retained-37b36ccc`.

To replay after extracting the separate combined evidence archive into an exact
reviewed checkout, restore the retained live snapshot if the full-run directory
does not already exist:

```
mkdir -p work/adversarial/final-full
cp work/adversarial/dynamics/final-actual-retained-pipeline.json work/adversarial/final-full/w2-pipeline.json
```

Use a fresh output directory for each repeat of the pinned unit command.
