"""Pinned-runtime invocation of the high precision independent A06 oracle."""
import importlib.util
from pathlib import Path


def test_independent_a06_oracle():
    path = Path(__file__).with_name('probe_a06.py')
    spec = importlib.util.spec_from_file_location('independent_a06_oracle', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.OUT = Path('/work')
    module.main()
