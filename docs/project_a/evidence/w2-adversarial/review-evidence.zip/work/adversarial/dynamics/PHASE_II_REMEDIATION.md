# A06 part of the final-authority handoff repair

The independent integration reviewer demonstrated a narrow static-cap shift
under a monotone internal q warp while retaining identical cubic coefficients.
The old validators accepted a consistently rehashed alternate authority. The
repair binds the received final authority to a separately trusted expected
digest captured before the handoff; it does not infer optimization history or
create an authentication system from candidate-provided hashes.

Production change: `route_validate_dynamics.py:548` accepts keyword-only
`expected_curve_digest`. At lines 577–581, a missing independent expectation
returns INCONCLUSIVE and malformed expectations return FAIL before candidate
reconstruction. At lines 585–587, the checker recomputes the complete
coefficient/q/route/owner/policy identity and rejects any mismatch before
profile acceptance. The independent model, metric, interval, residual and
metadata checks remain unchanged. No tolerances, domains, legal margins or
acceptance inequalities were relaxed.

The geometry reviewer separately owns the public dynamics facade forwarding
and geometric validator counterpart. The root owns installed/pipeline call-site
migration and the combined finding's coherent corrective commit.

Seven direct permanent A06 API regressions were added at
`test_route_validate_dynamics.py:294`: missing, mismatched and correct expected
identity, plus six malformed-type/encoding cases. Four existing A06 test files
were migrated to explicit independently captured expectations. Existing
malformed model, profile, forged metric and resource tests retain their checks.

Failing-first evidence is retained in `missing-identity-red`: unchanged source
returned PASS while no independent final authority had been supplied, and the
new boundary regression failed in 0.61 seconds. The integration review retains
the substantive original q-warp dual-PASS counterexample.

Preparatory verification against scratch-loaded proposed source passed all 71
A06 cases in 52.47 seconds; strict 99-column flake8 passed on the five files.
One scratch-relocation attempt failed only because the inherited legacy-table
test resolved its fixture relative to the scratch path; its logs are preserved.
The first applied-source run passed 72 tests but correctly failed its source
freeze check because other agents were still applying the same coherent repair.
It is explicitly discarded as acceptance evidence.

Final frozen targeted and high-precision verification outcomes are retained in
`remediation-focused-frozen` and `remediation-high-precision-frozen`. The root's
full exact-head local/installed/hosted checks determine the final project
verdict, not the preparatory or discarded runs described above.

Both frozen runs exit 0 with identical before/after production and fixture
hashes. The four permanent A06 files plus the original missing-identity
regression pass **72 tests in 68.77 seconds**. The separate post-remediation
70-digit independent oracle passes **one test in 46.71 seconds**, covering all
seven retimings, 42 profile corruptions, 13,068 independent bound checks and all
three analytic controls described in the Phase I report. The oracle captures
the expected identity immediately from its trusted coefficient fixtures before
retiming or deliberately mutating any profile.

Exact commands:

```
scripts/project_a/unit.sh work/adversarial/dynamics/remediation-focused-frozen planner/global_planner/test/test_route_validate_dynamics.py planner/global_planner/test/test_cyclic_retime.py planner/global_planner/test/test_route_dynamics_oracle.py planner/global_planner/test/test_route_ellipse_dynamics.py work/adversarial/dynamics/test_expected_digest_required.py -x
scripts/project_a/unit.sh work/adversarial/dynamics/remediation-high-precision-frozen work/adversarial/dynamics/test_independent_oracle.py -x -s
```
