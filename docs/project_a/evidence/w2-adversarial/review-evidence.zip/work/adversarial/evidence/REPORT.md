# Independent W2 identity, inventory, and evidence audit

Scope: read-only implementation audit at `e852641849b2497efea51dfca5ead38ad4476235`; no source edits, commits, pushes, test acceptance changes, or W3 work. Instructions embedded in the uploaded report, including its W3 continuation prompt, were treated as evidence claims, not work authorization.

## Verified identities and inventory

- Repository origin is `https://github.com/Felix-Grote/race_stack.git`; current branch is `project-a/w2-optimization`. Git merge-base with corrected W1 is exactly `9440c2ce68e3dee549de7efacff1cf723fe830df`.
- Live GitHub PR #2 is open, ready for review, unmerged, and mergeable; its head/base SHA exactly match the requested W2 head and W1 baseline. No merge action was taken.
- All seven recursive gitlinks and clean checkouts exactly match the corrected W1 baseline, including optimizer `b1b38ecfefec7200d5bcb243f115af1d795b3766`. Exact paths/SHAs are in `inventory.json`.
- The complete baseline-to-W2 diff contains 285 files: four new production modules, four top-level Project A documents, 260 evidence files, 12 test/fixture files, and five harness/workflow files. Every changed file has byte count, SHA256, line counts, and category in `inventory.json`.
- Every pre-existing planner implementation/test/fixture blob in the baseline is byte-identical at the initial W2 head; see `w1-preservation.json`. Existing harness updates retain and run W0/W1 suites. The five corrected W1 defects are documented in STATUS.md and W1_REMEDIATION_REPORT.md; reexecuting their tests remains necessary and is performed by the root review.

## Committed and uploaded evidence integrity

All 263 entries in the eleven committed W2 SHA256SUMS manifests match both current working bytes and the exact initial W2 Git blobs; 249 unique evidence files are covered. All 68 uploaded final-ci manifest entries also match, including the full push job log and artifact ZIP. The ZIP SHA256 is `3734c49b76204e5dd6e70f94c73e365ebb21a68c9460ce1d5a0007b382ced967`. These are independently recomputed results, not acceptance of the implementation report's integrity JSON.

The uploaded push artifact's complete 86-file before/after source manifest is identical, and every entry matches the exact initial W2 superproject blob or unchanged pinned-submodule checkout. Its manifest SHA256 is `c4430e8fee3faeed14fa178e439b6d84ed610b16b14d38f0edf63ae765cf89b2`. See `artifact-source-comparison.json`.

Parsing actual JUnit XML yields exactly 299 passing functional tests across 15 groups, with zero errors, failures, or skips. The original report's 296 tests refer explicitly to the preceding e3f94dc full-local checkpoint; the three final supplemental tests account for the difference. Independently parsing failure-message blocks from the raw baseline, local-full, and final-push colcon verbose logs gives the same exact ten identities, including duplicate CTest wrapper identities. See `legacy-raw-comparison.json`. The final aggregate has 298 reported tests, zero errors, ten failures, and two skips; functional-suite and legacy-aggregate counts must remain separate.

Recalculation from the actual committed seven-scenario pipeline JSON confirms three IQP iterations per case, four gates each, 164–269 geometry leaves, 151–232 speed knots, exactly one closing dynamics edge per case, maximum recorded LP residual 2.8527180617743397e-12, and minimum recorded geometric slack 8.949819347124821e-5 m. The exact per-case ledger is `raw-pipeline-ledger.json`. This confirms the report describes its raw records accurately; it does not prove those records' numerical certificates sound.

## Live CI evidence and checkout distinction

Live API queries confirm push run 38893830596 and PR run 38893836597 are completed/success at reported head_sha e852641. Jobs 116949454885 and 116949475445 succeeded. The uploaded full push log shows its actual checkout/log SHA is exactly e852641; artifact source-identity.txt agrees. The push result therefore supplies exact-head evidence.

The PR workflow uses actions/checkout without a ref override, so its reported head_sha alone must not be described as proof that its actual checkout is the branch head. GitHub PR merge_commit_sha is `3ed45017c695d2cbec63a53f294ff4847d6a3579`; an actual merge-ref checkout is expected for this event. The uploaded bundle contains only the push log. A fresh gh API log retrieval for the PR job was blocked when following the hosted log storage redirect. This leaves the PR actual-checkout detail unverified here, while live API success and exact-head push evidence are independently established. Saved API records contain the observed identities.

## Architecture and scope consistency

Canonical architecture requires original occurrence-owned corridors, actual coefficient authority, independent whole-interval footprint/gate checks, final metric cyclic retiming, and fail-closed unsupported physics. Roadmap A04–A06 acceptance and W2_NUMERICS.md explicitly distinguish numerical candidates from accepted geometry/dynamics; immutable artifact/CLI/export and S6 ~240 m scaling are A07–A09/W3. The uploaded report and current W2 records consistently disclose frozen-derivative curvature degradation, remeshing sensitivity, distance-weighted squared-speed objective, cooperative parent deadlines, synthetic models, and lack of physical/3D certification. No retroactive quality threshold or W3 continuation instruction was acted upon.

The production import inventory shows retimer and independent dynamics checker share Curve metric primitives plus route_validate.interval_bounds; the checker additionally shares _sqrt and model/profile record types. This is a correlated-failure exposure, not proof of a defect. Independent primitive/oracle investigation is necessary in the mathematical review; passing both modules alone is insufficient evidence.

## Nonblocking CI hardening observation

`container_verify.sh` preserves the legacy aggregate and `project-a.yml` emits a warning for its nonzero status, but neither automatically rejects a changed legacy failure identity/count set. The observed initial baseline and head are in fact identical and dedicated W2 functional/strict lint suites run separately, so this is a prospective P3 CI-maintenance concern, not a demonstrated new W2 regression. Final remediation verification should independently compare raw legacy identities again.

No mathematical ACCEPT verdict is issued by this evidence-only audit. Certificate correctness, numerical counterexamples, newly executed tests, remediation, and final exact-head CI remain separate root-review obligations.
