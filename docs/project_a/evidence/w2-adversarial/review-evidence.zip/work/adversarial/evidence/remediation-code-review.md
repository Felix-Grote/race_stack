# Independent Phase II remediation code review

Verdict: **code-review PASS for the F1 authority-binding repair and migrations**, conditional on the root review completing fresh frozen-source tests, full isolated verification, commitment, and exact-head CI. This is not a final W2 acceptance verdict. No implementation files were edited by this reviewer.

## Reviewed source identity

The complete current diffs of both validators, all migrated test modules, source/installed pipelines, runner, W2_NUMERICS.md, and the three new handoff/trace/numerical oracle modules were read. `remediation-code-review-inventory.json` records SHA256 and byte counts for all reviewed source/test files. The inventory also records AST comparisons of production helper bodies and migrated assertions.

## F1 authority binding

`route_validate.validate_geometry`, `route_validate_dynamics.validate_dynamics`, and the public lazy `route_validate.validate_dynamics` facade now accept and forward keyword-only `expected_curve_digest`. There is no fallback to the profile, metadata, optimizer success, candidate-stored checksum, or a freshly generated expectation inside either validator. A missing digest exits INCONCLUSIVE; only a plain string of 64 lowercase hexadecimal characters is accepted; malformed/mismatching digests exit FAIL.

A05 first reconstructs the approved original route and actual Curve, checks candidate equality, independent NumericPolicy equality, exact q shape/order/anchors and owners, and then independently hashes coefficients, all q, owners, validated route digest, and NumericPolicy. Its full actual digest is exposed in every report after computation. A06 independently reconstructs actual route/curve/q, reuses its existing independently implemented identity calculation, compares actual versus retained expectation, and retains actual-versus-profile/model checks. A matching digest never skips the mathematical validator. No entry path reaching PASS lacks the authority comparison.

The source pipeline freezes its expected identity immediately after a successful fresh A04 result and passes the same value to both independent validators. It asserts geometry.curve_digest == dynamics.curve_digest == expected and profile.curve_digest == metadata.curve_digest == expected. The installed-package test does the same through the public facade and records the expectation. These comparisons prevent two distinct individually validated authorities from being combined by status alone.

## Failing exploit and regression quality

The new handoff fixture is loaded from the independently SHA256-pinned original candidate fixture and captures the expected full identity before downstream mutation. The coordinated-q-warp regression changes a monotone internal q map, independently supplies a cap/model, reruns the retimer to regenerate a self-consistent profile/metadata, and passes the pristine separately retained expectation to both validators. Both must FAIL for authority mismatch. The regression therefore does not conceal the original exploit by checking only a stale self-hash. A separate two-curve case demonstrates geometry PASS cannot complete with dynamics from a different q authority. Missing/malformed/incorrect expectation and the lazy facade forwarding are directly covered.

The A05-specific test additionally monkeypatches the retimer's curve_digest helper to falsely return the retained hash; the geometry validator must still report the independently computed altered hash and FAIL. This challenges accidental reliance on the optimizer's identity helper.

The original failing-first Phase I dual-PASS observation remains separately preserved in the review evidence. This code review does not substitute API TypeError on an older implementation for that mathematical/semantic reproduction.

## Mathematical checks and original assertions preserved

AST comparison confirms all 28 A05 mathematical/helper function bodies and all 21 independent-dynamics helper bodies remain identical to the pre-repair source. Policy classes/defaults, legal margins, curvature/regularity/residual criteria, interval subdivision, root isolation, arc/time enclosures, model constraints and tolerance constants are not changed. The source diff adds entry guards, full-hash reporting, and facade forwarding only.

After removing only the newly supplied expected_curve_digest keywords from AST calls, every pre-existing assertion in geometry, dynamics, retimer, dynamics-oracle, ellipse, and installed tests remains identical. The only nonidentical old source-pipeline assertion is strengthened from profile digest == metadata digest to profile digest == metadata digest == independently retained expected. No test tolerance or original oracle was weakened or removed. Tests intentionally supplying mathematically invalid geometry retain their own explicitly approved test authority so their pre-existing geometric rejection paths still run, rather than being replaced by an early hash mismatch.

## Independent trace and numerical oracles

The new trace oracle reconstructs the original seed from approved route records and solves a periodic cubic system in knot second derivatives, using equations distinct from production TUM derivative fitting. It does not call optimizer, corridor resampling/refitting, reference interpolation, or a candidate hash helper. Every iteration checks source q equality, exact interpolation ancestry from source segment/t, monotonic progress and semantic anchors, independently evaluated source points, reference coefficients, owners, right normals, damping, eroded nodal bounds, shifted coefficients, and exact final authority linkage. Fresh source-pipeline cases run it for all seven optimizer traces; an altered final q is required to fail. Numerical fit comparisons are explicitly regression controls with their own small comparison budgets, not production acceptance certificates.

The additional primitive controls compare sqrt outputs to exact rational squares, rectangle normalization to 110-digit independently derived frames, and the shared arc kernel to a closed high-precision antiderivative. They add distinct regression evidence for shared numerical assumptions; they do not replace rigorous production bounds with sampling. Cases where the production kernel reports resource/regularity uncertainty are not counted as accepted certificate examples.

## Fresh initial baseline and legacy comparison

The independently rerun `work/adversarial/baseline-full` source manifests match before/after and the command exit is 0. Parsing raw failure-message blocks reproduces exactly the same ordered ten inherited failure identities as the uploaded final-push raw legacy results. `fresh-baseline-legacy-comparison.json` records raw file hashes, identities and source stability. Host source-identity reports Debian/Python 3.12, while runtime acceptance executes inside the separately recorded pinned Humble/Python 3.10 container; those identities must not be conflated.

## Nonblocking migration note and trust boundary

The two frozen historical scripts under `docs/project_a/evidence/w2-a05-independent` and `w2-supplemental/independent-zero-motion` retain the old API calls without the new expectation. Preserving these historical evidence bytes is appropriate. Reproducing their original assertions now requires their original SHA or a separately retained scratch-copy API migration that supplies the intended expected authority; the final report should state that compatibility consequence explicitly.

This repair binds an already trusted A04 return across a later handoff. It cannot establish an arbitrary candidate's historical lineage from a self-supplied hash, authenticate arbitrary Python code, or authenticate separately replaced trusted models. The documentation correctly discloses this and independently audits actual A04 traces. No new W3 artifact framework, backend, physical claim, or production tolerance relaxation is introduced.
