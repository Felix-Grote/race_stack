# Independent F2 shared-cap repair code review

Verdict: **code-review PASS**, conditional on targeted green tests, full final local/installed verification, commitment and final exact-head hosted CI. No implementation edits or test executions were made by this reviewer; the root owns frozen execution.

Reviewed current diff from F1 checkpoint `6b778519de74b09a7b66be2ac89e12d687226c9d`: `_route_geometry.py`, two newly added test modules, the independently generated exact fixture, runner additions, and associated numerical contract/decision records. `f2-code-review-inventory.json` records exact reviewed SHA256 values and AST/source-preservation results.

## Production correction and preservation

The sole existing numerical function changed is `_route_geometry.line_intervals`. Inside its polygon-edge loop, before `sub`, `cross`, `hypot`, `dot`, division, or any other floating edge arithmetic, it sorts the two endpoint coordinate pairs lexicographically. The undirected line segment is mathematically identical; exact reversed shared edges now execute identical binary64 operations and therefore yield exactly identical cuts. Existing endpoint-parameter admissibility is symmetric under reversal. Collinearity checks use the same absolute denominator and allowed_caps accepts either endpoint order already.

Removing only this new two-statement if/swap node yields an AST exactly identical to the old entire line_intervals function. Every other private geometry helper is AST-identical. EPS remains 1e-9, and neither open-interval coalescing, `_merge`'s strict positive-gap refusal, shared-cap approval, point-in-polygon handling, legal widths or margins is modified. No new approximate cap equality or EPS gap bridging is introduced.

Comparing all baseline ordinary planner source/test/fixture files shows exactly one intentionally changed W1 path: `_route_geometry.py`. The other 22 ordinary files are byte-identical, and the separately recorded optimizer gitlink remains unchanged. This clarifies the earlier inventory's 24 entries: they comprise 23 ordinary blobs plus one optimizer gitlink, rather than 24 ordinary files. All three original W1 test modules and their bodies remain byte-identical; no old assertion or tolerance is changed. Both F1 validators are byte-identical to the approved F1 checkpoint, so mandatory external binding and all mathematical checks remain intact.

## Regression quality

`test_route_w2_shared_cap.py` contains 49 parameterized cases: one exact minimal two-quadrilateral shared-cap case, twelve rotation/translation/polygon-reversal cases, twenty-four real-gap cases spanning 1e-10 to 1e-6 m, and twelve original F1 tangent-contact cases. The independent Fraction oracle proves both edge directions have exactly the same rational intersection before checking production root equality. The gap tests exercise actual corridor normal geometry and independently assert `_merge` refuses positive gaps even below EPS. Tangent cases preserve the original boundary contact cut while distinguishing a genuinely moved-away tip. These tests do not create a helper that automatically approves unrelated caps in production.

`test_route_w2_novel_pipeline.py` pins the complete originally failing generated fixture SHA256 `742b03fa77cef8bfab9f203787ac8dd5435e479a6fddf9449ac4138e83c5a0aa`. It does not repair input geometry, widen widths, change default optimizer limits, lower the supplied margin or eliminate the interior cap. It requires actual A04 CANDIDATE, captures expected digest immediately at trusted return, requires A05/A06 exact PASS on that same digest, and independently replays full A04 lineage history. Distinct QUADPACK integration reconstructs every metric edge/acceleration/time; each distance must be inside certified enclosures and total time inside the lap enclosure. Direct coefficient differentiation additionally samples lateral/diamond/motor residuals as regression controls. Production acceptance continues to use rigorous certificates.

The runner explicitly executes both new test files and includes their XML in its complete summary. Existing strict glob lint includes these test_route files and the changed helper. No new source-loading shim or oracle replacement is introduced.

## F1-only full verification checkpoint

The completed `corrected-full` run at 6b778519 is independently parsed: exit0, identical before/after source manifests, 323 functional tests across17 groups, all zero failures/errors/skips, plus separately recorded legacy322 tests/0 errors/10 failures/2 skips. Raw ten identities exactly equal the independent initial baseline. Source-manifest SHA256 is `4bd3731da3c65064c43292a4c983dc8548d8517d1b5482ab5fe6196b0e2ad81b`. `f1-full-checkpoint.json` preserves the detailed parsed ledger. This is valid F1 checkpoint evidence and explicitly does not verify the later F2 source.

No source-level correctness objection remains to the bounded F2 fix. The final report must name its separate corrective commit, targeted red/green evidence, novel full-pipeline outcome, complete final source/installed verification and actual final publication exact-head CI before acceptance.
