# Independent challenge of proposed q-authority remediation

The retained Phase I q-warp record shows unchanged coefficients and monotone, occurrence-compatible q can produce geometry PASS and dynamics PASS after retiming, while checking the same profile against the original q produces a demonstrated original static/model speed violation at edge 14. The externally intended q map cannot be reconstructed from the final displaced polynomial alone. This is a provenance/authority defect at the post-A04 handoff.

## Minimal sound contract

Require keyword-only `expected_curve_digest=None` in both independent validators and the public lazy dynamics facade. No independently supplied expectation means INCONCLUSIVE, never PASS. Malformed or mismatching expectation means FAIL. A well-formed expectation is a strict plain string containing exactly 64 lowercase SHA256 hex characters.

The expected value must be captured from the final trusted A04 result immediately at the handoff, before downstream candidate transformations, and stored separately. It must bind every coefficient, all q entries, every owner, the original route digest, and the complete NumericPolicy. Each validator independently recomputes the actual identity from the reconstructed authority; no candidate profile digest, metadata digest, or stored candidate claim may become the expectation. All existing structural, route, policy, coefficient, gate, regularity, interval and dynamics checks remain necessary after identity matching.

Both PASS reports should expose their full actual curve identity. Combined acceptance must require geometry.status == dynamics.status == PASS and geometry.curve_digest == dynamics.curve_digest == the same frozen expected identity. A05's existing coefficients_sha256 does not identify q, owners, route or policy. Preserve that existing field for continuity, and add the full identity separately.

The seven fresh pipeline and installed-package paths should capture one expectation before A05/retime and pass it unchanged to both validators. Fault-injection tests must freeze the expectation from the pristine candidate BEFORE mutating q/owners/coefficients/policy. A test wrapper that recomputes the expectation from its supplied candidate immediately before every validator call would reopen the defect and conceal it.

## Evasions considered

- A q-warp with a re-solved profile and regenerated profile.curve_digest cannot match the pristine external digest.
- Keeping the original profile digest while mutating q fails actual-versus-expected and actual-versus-profile comparisons.
- Changing route/gates, owners, coefficients, or numerical policy changes the full hash; route/policy reconstruction checks still independently reject forged internal records.
- Calling A05 on one curve and A06 on another cannot yield combined acceptance under the same expected identity; the reports' full digests provide explicit review evidence.
- Replacing or omitting the expected token cannot grant PASS; neither profile nor metadata supplies a fallback.
- JSON tuple/list equivalence does not undermine the contract because it represents the same ordered values; actual reconstructed authority validation still enforces supported values and shapes.

## Limits and separation of scope

This does not independently prove the history of q if the trusted A04 implementation itself returns incorrect lineage; its trace/source audit remains necessary. It is authority binding under an explicitly trusted caller handoff, not authentication against arbitrary Python code, a forged trusted expected value, SHA256 collision attacks, or mutation before the handoff.

Models, footprint and validation policies remain separately supplied independent authorities. Binding the curve does not establish authenticity of a jointly replaced model and its regenerated profile/model hash. If downstream model transport is considered untrusted, capture an independent expected model digest at its trusted handoff too; otherwise retain the existing clearly stated trusted-model parameter contract. No W3 storage/publication layer is necessary to repair the demonstrated post-A04 q mutation.

The canonical digest helper already exists publicly in cyclic_retime.py and the dynamics checker independently reproduces its fields. A small explicit identity computation in A05 is sufficient; no generic authority framework or artifact class is needed. Avoid introducing a geometry-to-retimer module-load dependency merely to hash values.

Conclusion: the proposed mandatory external digest closes the demonstrated post-A04 intermediate-tamper defect soundly within the stated trust boundary, provided all call paths use one frozen token and combined acceptance compares both full report identities. This advisory is read-only; it does not claim the proposed implementation or regressions have yet passed.
