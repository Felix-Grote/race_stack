`package_final_evidence.py` packages explicit, completed evidence inputs without changing raw files. It reads no environment variables, Git credentials, or Docker state, never executes payloads, never extracts archives, and opens input file/directory components with `O_NOFOLLOW`.

Use `--completed-attempt LABEL=PATH` for a finished attempt with a recorded `exit-code.txt`; this mode retains the integer return code and always labels the archive as an attempt, never final acceptance. The dirty-source attempt stopped before ordinary build, installed/ROS tests, legacy comparison, and source-free runtime because the mounted Git worktree metadata points outside `/src`. Its 593 passing source tests do not establish installed acceptance.

Use `--completed-gate LABEL=PATH` only after full all+sourcefree success. PATH can be the verification directory, or a fresh wrapper containing `verification/`. This mode requires recorded zero verification/fresh/source-free exit codes, complete `W0_THROUGH_A09` summary, nonempty passing source-free JUnit, identical before/after source inventories, passing legacy identity comparison, original Python-package root `pytest.xml`, and legacy XML from each selected package. It cannot package an ongoing or failed gate as final acceptance.

Example for the later completed fresh gate (choose a fresh output directory outside every input tree):

```sh
python3 work/independent-review/installed-final/package_final_evidence.py \
  --completed-gate cleanfresh=work/independent-review/installed-final/cleanfresh \
  --evidence legacy-audit=work/independent-review/installed-final/legacy-audit \
  --output-dir work/independent-review/release-handoff/package-cleanfresh \
  --archive-name cleanfresh-independent.tar.gz
```

Repeat `--completed-gate`, `--completed-attempt`, or `--evidence LABEL=PATH` to add distinct named roots or individual files. Additional evidence inputs receive no fabricated completion verdict. Labels, source bytes, selected paths and exclusion reasons determine archive bytes; absolute machine paths and wall-clock time are omitted. Existing nonempty output directories are rejected.

Selection retains all regular gate output files, source/runtime/dependency inventories, JUnit, logs, reports/history, complete immutable references and exports, command outputs, the source-free harness, and optimizer wheels up to 16 MiB (configurable by `--max-wheel-bytes`). It prunes checkout trees, executable `a09-harness-tmp` Git fixtures, Git/cache metadata, and top-level verification `src`, `install`, `python`, `colcon`, and `colcon-scratch`. The verification `build` tree retains only exact original `build/{f110_msgs,frenet_conversion,global_planner}/pytest.xml` files and regular `build/<package>/test_results/**/*.xml`; all other build content is excluded. Exact JUnit paths and bytes remain in the archive, including original skip messages. Regular colcon `log` and `legacy-log` command outputs remain; their convenience symlinks are skipped with reasons. Other selected symlinks and special files are fatal errors. A snapshot explicitly supplied as evidence keeps source/harness bytes; source files are not pruned merely because an immutable reference or snapshot contains a directory named `src`.

The archive uses regular-file USTAR entries in lexical order with mode 0644, zero uid/gid/mtime, empty owner/group names, and gzip filename empty/mtime zero. The script hashes input bytes, reads back every archive member with exact size/SHA256 and normalized-metadata checks, rescans selections and rehashes unchanged sources, and checks completion again. Long names that USTAR cannot represent fail rather than silently changing formats.

Each output directory contains the archive, `MANIFEST.json` (payload hashes, selection policy, completion verdicts and exclusions), `member-inventory.json` (SHA256/size for every archive member including the manifest), `selection.json`, and `receipt.json` binding the archive, manifest, and full member inventory.

Tiny fixture verification ran with:

```sh
python3 work/independent-review/installed-final/package_final_evidence.py \
  --self-test work/independent-review/installed-final/archive-determinism-fixture
```

The two archives and receipts remained byte-identical after fixture source mtimes and modes changed. Exact build XML survived, a build object and executable A09 fixture directory were excluded, and an excluded dangling symlink was never followed. `archive-determinism-fixture/determinism.json` records the result. No application suites or Docker runs are part of this check.
