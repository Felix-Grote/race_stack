#!/usr/bin/env python3
"""Independently compare final legacy output to the immutable original W0 report.

Only diagnostic enumeration order may vary. Full diagnostic lines, multiplicities,
failure-block membership, and every other failure-message line remain exact.
This scratch audit never writes its input reports or JUnit XML files.
"""
import argparse
from collections import Counter
import difflib
import gzip
import hashlib
import json
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET


W0_SHA256 = '324448f3a61e312fb784e495aa7a219a6b3b966d17c32a38e5ce519edb3b5d55'
EXPECTED_IDENTITIES = [
    'lint_cmake',
    'xmllint',
    'f110_msgs.lint_cmake whitespace/mismatch (CMakeLists.txt:29)',
    'f110_msgs.lint_cmake whitespace/eol (CMakeLists.txt:42)',
    'f110_msgs.lint_cmake whitespace/indent (CMakeLists.txt:45)',
    'f110_msgs.xmllint package.xml',
    'frenet_conversion.test.test_flake8 test_flake8',
    'frenet_conversion.test.test_pep257 test_pep257',
    'global_planner.test.test_flake8 test_flake8',
    'global_planner.test.test_pep257 test_pep257',
]
EXPECTED_SKIPS = [
    ('frenet_conversion.test.test_copyright test_copyright',
     'No copyright header has been placed in the generated source file.'),
    ('global_planner.test.test_copyright test_copyright',
     'No copyright header has been placed in the generated source file.'),
]
BLOCK = re.compile(r'^- ([^\n]+)\n  <<< failure message\n(.*?)^  >>>(?:\n|\Z)',
                   re.MULTILINE | re.DOTALL)
DIAGNOSTIC = re.compile(r'      \./[^:\r\n]+:[0-9]+:[0-9]+: [A-Z][0-9]{3} [^\r\n]+(?:\n|\Z)')
SUMMARY = re.compile(
    r'^Summary: (\d+) tests?, (\d+) errors?, (\d+) failures?, (\d+) skipped[ \t]*$',
    re.MULTILINE)


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def canonical_counter(counter):
    return [{'text': line, 'multiplicity': count}
            for line, count in sorted(counter.items())]


def counter_sha256(counter):
    return sha256(json.dumps(canonical_counter(counter), ensure_ascii=False,
                             separators=(',', ':')).encode())


def parse_report(path):
    data = path.read_bytes()
    text = (gzip.decompress(data) if path.suffix == '.gz' else data).decode('utf-8')
    blocks = []
    diagnostic_total = Counter()
    for match in BLOCK.finditer(text):
        lines = match.group(2).splitlines(keepends=True)
        diagnostics = Counter(line for line in lines if DIAGNOSTIC.fullmatch(line))
        nondiagnostics = [line for line in lines if not DIAGNOSTIC.fullmatch(line)]
        diagnostic_total.update(diagnostics)
        blocks.append({'identity': match.group(1), 'body': match.group(2),
                       'diagnostics': diagnostics, 'nondiagnostics': nondiagnostics})
    all_diagnostics = Counter(line for line in text.splitlines(keepends=True)
                              if DIAGNOSTIC.fullmatch(line))
    identities = [block['identity'] for block in blocks]
    markers = {
        'failure_labels': len(re.findall(r'^- [^\n]+$', text, re.MULTILINE)),
        'open_delimiters': len(re.findall(r'^  <<< failure message$', text, re.MULTILINE)),
        'close_delimiters': len(re.findall(r'^  >>>$', text, re.MULTILINE)),
        'parsed_blocks': len(blocks),
    }
    summary = [tuple(map(int, match)) for match in SUMMARY.findall(text)]
    return {
        'path': str(path), 'raw_file_sha256': sha256(data),
        'raw_file_bytes': len(data), 'decoded_text_sha256': sha256(text.encode()),
        'identities': identities, 'markers': markers,
        'summary': summary, 'blocks': blocks,
        'diagnostics': diagnostic_total,
        'diagnostics_outside_failure_blocks': all_diagnostics - diagnostic_total,
        'input_bytes': data,
    }


def report_metadata(report):
    return {key: report[key] for key in (
        'path', 'raw_file_sha256', 'raw_file_bytes', 'decoded_text_sha256',
        'identities', 'markers', 'summary') } | {
        'diagnostic_count': sum(report['diagnostics'].values()),
        'diagnostic_unique_count': len(report['diagnostics']),
        'diagnostic_counter_sha256': counter_sha256(report['diagnostics']),
        'diagnostics_outside_failure_blocks': canonical_counter(
            report['diagnostics_outside_failure_blocks']),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline', type=Path, required=True)
    parser.add_argument('--actual', type=Path, required=True)
    xml_source = parser.add_mutually_exclusive_group(required=True)
    xml_source.add_argument('--build-root', type=Path,
                            help='Contains PACKAGE/pytest.xml for both Python packages')
    xml_source.add_argument('--junit-dir', type=Path,
                            help='Contains frenet_conversion.xml and global_planner.xml')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    errors = []
    baseline = parse_report(args.baseline)
    actual = parse_report(args.actual)
    for name, report in [('baseline', baseline), ('actual', actual)]:
        if report['identities'] != EXPECTED_IDENTITIES:
            errors.append(name + ': expected exact 10 ordered failure identities')
        if any(value != 10 for value in report['markers'].values()):
            errors.append(name + ': expected exactly 10 complete failure blocks and delimiters')
        if len(set(report['identities'])) != len(report['identities']):
            errors.append(name + ': duplicate failure identity')
        if sum(report['diagnostics'].values()) != 1173:
            errors.append(name + ': expected exactly 1173 emitted diagnostics')
        if report['diagnostics_outside_failure_blocks']:
            errors.append(name + ': diagnostic emitted outside parsed failure blocks')
    if baseline['raw_file_sha256'] != W0_SHA256:
        errors.append('baseline: compressed file does not match immutable original W0 SHA256')
    if baseline['summary'] != [(12, 0, 10, 2)]:
        errors.append('baseline: original W0 summary changed')
    if len(actual['summary']) != 1 or actual['summary'][0][1:] != (0, 10, 2):
        errors.append('actual: expected one summary with 0 errors, 10 failures, 2 skipped')
    comparisons = []
    for index, expected_block in enumerate(baseline['blocks']):
        if index >= len(actual['blocks']):
            break
        observed_block = actual['blocks'][index]
        diagnostics_equal = expected_block['diagnostics'] == observed_block['diagnostics']
        nondiagnostics_equal = expected_block['nondiagnostics'] == observed_block['nondiagnostics']
        if not diagnostics_equal:
            errors.append(expected_block['identity'] + ': diagnostic Counter changed')
        if not nondiagnostics_equal:
            errors.append(expected_block['identity'] + ': nondiagnostic lines/order changed')
        comparisons.append({
            'index': index, 'baseline_identity': expected_block['identity'],
            'actual_identity': observed_block['identity'],
            'diagnostic_counter_equal': diagnostics_equal,
            'nondiagnostic_lines_equal_in_order': nondiagnostics_equal,
            'raw_failure_body_equal': expected_block['body'] == observed_block['body'],
            'baseline_raw_body_sha256': sha256(expected_block['body'].encode()),
            'actual_raw_body_sha256': sha256(observed_block['body'].encode()),
            'baseline_diagnostic_count': sum(expected_block['diagnostics'].values()),
            'actual_diagnostic_count': sum(observed_block['diagnostics'].values()),
            'baseline_diagnostic_counter_sha256': counter_sha256(expected_block['diagnostics']),
            'actual_diagnostic_counter_sha256': counter_sha256(observed_block['diagnostics']),
            'baseline_nondiagnostic_sha256': sha256(''.join(expected_block['nondiagnostics']).encode()),
            'actual_nondiagnostic_sha256': sha256(''.join(observed_block['nondiagnostics']).encode()),
            'diagnostics_missing': canonical_counter(expected_block['diagnostics'] - observed_block['diagnostics']),
            'diagnostics_added': canonical_counter(observed_block['diagnostics'] - expected_block['diagnostics']),
            'nondiagnostic_diff': list(difflib.unified_diff(
                expected_block['nondiagnostics'], observed_block['nondiagnostics'],
                fromfile='original-W0', tofile='actual')),
        })
    skips = []
    junit_metadata = []
    junit_inputs = []
    for package in ('frenet_conversion', 'global_planner'):
        path = (args.build_root / package / 'pytest.xml' if args.build_root
                else args.junit_dir / (package + '.xml'))
        data = path.read_bytes()
        junit_inputs.append((path, data))
        junit_metadata.append({'path': str(path), 'raw_file_sha256': sha256(data),
                               'raw_file_bytes': len(data)})
        for case in ET.fromstring(data).iter('testcase'):
            for skipped in case.findall('skipped'):
                skips.append((str(case.get('classname')) + ' ' + str(case.get('name')),
                              skipped.get('message')))
    skips_equal = Counter(skips) == Counter(EXPECTED_SKIPS)
    if not skips_equal:
        errors.append('actual: copyright skip identity/reason Counter changed')
    # An unfinished producer must never lead to a report about mismatched snapshots.
    for path, original_data in ([(args.baseline, baseline['input_bytes']),
                                  (args.actual, actual['input_bytes'])] + junit_inputs):
        if path.read_bytes() != original_data:
            errors.append('input changed while auditing: ' + str(path))
    result = {
        'passed': not errors,
        'method': ('For each exact ordered failure identity compare every nondiagnostic '
                   'message line in order, including whitespace and newlines; compare '
                   'complete emitted diagnostic lines as a Counter within that block. '
                   'Only diagnostic enumeration order may differ. No omissions.'),
        'diagnostic_selector': DIAGNOSTIC.pattern,
        'baseline': report_metadata(baseline), 'actual': report_metadata(actual),
        'all_diagnostic_text_and_multiplicities_equal': baseline['diagnostics'] == actual['diagnostics'],
        'blocks': comparisons, 'junit': junit_metadata,
        'expected_skips': EXPECTED_SKIPS, 'actual_skips': skips,
        'skip_identities_and_reasons_equal': skips_equal,
        'actual_test_total_policy': 'Recorded; may grow beyond original W0 total of 12.',
        'errors': errors,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'passed': result['passed'], 'output': str(args.output),
                      'actual_summary': actual['summary'],
                      'actual_diagnostic_count': result['actual']['diagnostic_count'],
                      'errors': errors}, indent=2))
    return 0 if result['passed'] else 1


if __name__ == '__main__':
    sys.exit(main())
