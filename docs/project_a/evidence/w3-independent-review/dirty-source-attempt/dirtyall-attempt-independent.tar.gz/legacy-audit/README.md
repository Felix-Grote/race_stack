# Independent final legacy audit

`audit_legacy.py` compares a completed raw aggregate report and its original JUnit
XML files to the immutable W0 report. It writes only the requested JSON report.

```sh
python work/independent-review/installed-final/legacy-audit/audit_legacy.py \
  --baseline docs/project_a/evidence/pinned-run/legacy-results.txt.gz \
  --actual work/independent-review/installed-final/verification/legacy-results.txt \
  --build-root work/independent-review/installed-final/verification/build \
  --output work/independent-review/installed-final/legacy-audit/current-verification-comparison.json
```

For archived JUnit files named `frenet_conversion.xml` and `global_planner.xml`,
replace `--build-root` with `--junit-dir PATH`.

The comparison pins W0 SHA256
`324448f3a61e312fb784e495aa7a219a6b3b966d17c32a38e5ce519edb3b5d55`,
requires exactly the ten ordered failure identities and complete block delimiters,
and compares all 1,173 diagnostic lines as full-text Counters **within each failure
block**, including multiplicities. Every other failure-message line must match in
order, including whitespace, blank lines, and the CMake diagnostics. Only diagnostic
enumeration order can differ. The actual summary must have zero errors, ten failures,
and two skips; the total test count is recorded because functional coverage grows.
Both exact copyright skip identities and their `message` reasons are checked from
the JUnit XML, preserving multiplicity.

`calibration-retained.json` confirms the prior retained W3 report passes.
`calibration-summary.json` records a second positive case with reversed diagnostic
enumeration and eight correctly rejected negative cases: changed diagnostic text,
duplication, removal, nondiagnostic order, identity, block delimiter, diagnostic
transfer between blocks, and skip reason. Each mutated raw input and its full JSON
comparison remains under `calibration/`; the retained source evidence was untouched.
