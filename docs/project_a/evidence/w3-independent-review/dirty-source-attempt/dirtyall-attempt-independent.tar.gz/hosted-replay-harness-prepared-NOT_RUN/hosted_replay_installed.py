"""Replay authenticated unchanged hosted products using only an ordinary install."""
from dataclasses import asdict
import hashlib
import json
import math
import os
from pathlib import Path
import random
import re
import socket
import struct
import sys
import time

import global_planner.route_artifact as artifact
from ament_index_python.packages import get_package_share_directory


EXPECTED_CASES = {
    's0_route', 's0_reverse_route', 's0_rotated_route', 's2_lower_route',
    's2_upper_route', 's3_notch_route', 's3_surfaces_route', 's4_repeated_route',
    's6_competition_route',
}


def main():
    products = Path(sys.argv[1]).resolve()
    catalog_path = Path(sys.argv[2]).resolve()
    output = Path(sys.argv[3]).resolve()
    output.mkdir(parents=True, exist_ok=True)
    catalog_bytes = catalog_path.read_bytes()
    catalog = json.loads(catalog_bytes)
    if isinstance(catalog, dict):
        catalog = catalog['products']
    assert {item['case'] for item in catalog} == EXPECTED_CASES
    assert len(catalog) == len(EXPECTED_CASES)
    assert os.getuid() != 0
    assert [name for _, name in socket.if_nameindex()] == ['lo']
    status = Path('/proc/self/status').read_text().splitlines()
    process = dict(line.split(':', 1) for line in status if ':' in line)
    assert int(process['CapEff'].strip(), 16) == 0
    assert process['NoNewPrivs'].strip() == '1'
    for location in ('/', '/work/install', '/work/python', '/hosted-products',
                     '/runtime-harness', '/trusted-catalog'):
        assert os.statvfs(location).f_flag & os.ST_RDONLY, location
    for location in ('/src', '/work/src', '/work/build'):
        assert not Path(location).exists(), location
    module_path = Path(artifact.__file__).resolve()
    assert module_path.is_relative_to(Path('/work/install'))
    build_path = Path(get_package_share_directory('global_planner')) / 'project_a/build_identity.json'
    assert build_path.resolve().is_relative_to(Path('/work/install'))
    build = json.loads(build_path.read_text())
    assert build['source_commit'] == os.environ['PROJECT_A_EXPECTED_COMMIT']
    assert build['source_dirty'] is False
    records = []
    identity = {
        'scope': 'Installed-only unchanged authenticated hosted-product replay',
        'catalog_sha256': hashlib.sha256(catalog_bytes).hexdigest(),
        'installed_source_commit': build['source_commit'],
        'installed_source_dirty': build['source_dirty'],
        'artifact_module': str(module_path),
        'uid': os.getuid(), 'interfaces': socket.if_nameindex(),
        'cap_eff': process['CapEff'].strip(),
        'no_new_privs': process['NoNewPrivs'].strip(),
    }
    (output / 'runtime-identity.json').write_text(json.dumps(identity, indent=2) + '\n')
    for item in catalog:
        assert re.fullmatch(r'[a-z0-9_]+', item['case'])
        path = products / item['case'] / 'reference.json'
        assert path.resolve().is_relative_to(products)
        before = path.read_bytes()
        expected_bytes = item['reference_sha256']
        assert hashlib.sha256(before).hexdigest() == expected_bytes
        payload = json.loads(before)['payload']
        began = time.monotonic()
        record = {'case': item['case'], 'H': item['H'],
                  'C': item['curve_digest'], 'reference_sha256': expected_bytes}
        try:
            ref = artifact.load_reference(
                path, expected_H=item['H'],
                validation_context=artifact.ValidationContext())
            assert path.read_bytes() == before
            assert ref.H == item['H']
            assert ref.payload['approved_curve_digest'] == item['curve_digest']
            assert ref.geometry_report.status == 'PASS'
            assert ref.dynamics_report.status == 'PASS'
            exact_pairs = (
                (ref.ordered.curve.coefficients, payload['curve']['coefficients']),
                (ref.ordered.q, payload['curve']['q']),
                (asdict(ref.model), payload['model']),
                (asdict(ref.profile), payload['speed_profile']),
                (asdict(ref.policies), payload['policies']),
            )
            for actual, expected in exact_pairs:
                assert artifact.canonical_bytes(actual) == artifact.canonical_bytes(expected)
            historical = payload['validation']['dynamics']
            assert struct.pack('>d', ref.lap_time_s) == struct.pack(
                '>d', historical['lap_time_s'])
            assert historical['lap_time_lower_s'] <= ref.lap_time_s <= historical[
                'lap_time_upper_s']
            assert ref.dynamics_report.lap_time_lower_s <= ref.lap_time_s <= ref.dynamics_report.lap_time_upper_s
            assert ref._times[-1] == ref.dynamics_report.lap_time_s
            rng = random.Random(20261017)
            indices = sorted({0, len(ref.profile.knots) - 1,
                              *[rng.randrange(len(ref.profile.knots)) for _ in range(20)]})
            for index in indices:
                knot = ref.profile.knots[index]
                sample = ref.sample(ref._stations[index])
                follow = ref.profile.knots[(index + 1) % len(ref.profile.knots)]
                assert sample.speed_mps == math.sqrt(knot.u)
                assert sample.time_s == ref._times[index]
                assert sample.acceleration_mps2 == (follow.u - knot.u) / (2 * ref._edge_lengths[index])
            record.update({
                'status': 'PASS', 'geometry': ref.geometry_report.status,
                'dynamics': ref.dynamics_report.status,
                'authority_values_unchanged': True, 'product_bytes_unchanged': True,
                'immutable_main_time_unchanged_binary64': True,
                'main_time_s': ref.lap_time_s,
                'fresh_replay_nominal_s': ref.dynamics_report.lap_time_s,
                'historical_dynamics_differ': artifact.canonical_bytes(
                    asdict(ref.dynamics_report)) != artifact.canonical_bytes(historical),
                'numerical_query_prefix_total_s': ref._times[-1],
                'queried_profile_knots': len(indices),
                'wall_seconds': time.monotonic() - began,
            })
            (output / (item['case'] + '-fresh-geometry.json')).write_text(
                json.dumps(asdict(ref.geometry_report), indent=2) + '\n')
            (output / (item['case'] + '-fresh-dynamics.json')).write_text(
                json.dumps(asdict(ref.dynamics_report), indent=2) + '\n')
        except BaseException as error:
            record.update({'status': 'FAIL', 'error_type': type(error).__name__,
                           'error': str(error), 'wall_seconds': time.monotonic() - began})
            records.append(record)
            (output / 'hosted-replay-summary.json').write_text(json.dumps(records, indent=2) + '\n')
            print(json.dumps(record), flush=True)
            raise
        records.append(record)
        (output / 'hosted-replay-summary.json').write_text(json.dumps(records, indent=2) + '\n')
        print(json.dumps(record), flush=True)
    assert catalog_path.read_bytes() == catalog_bytes


if __name__ == '__main__':
    main()
