#!/usr/bin/env python3
"""Package completed verification evidence; never modify or dereference inputs."""
import argparse
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import tarfile
import xml.etree.ElementTree as ET


PACKAGES = ('f110_msgs', 'frenet_conversion', 'global_planner')
CACHES = {'.git', '__pycache__', '.pytest_cache', '.mypy_cache'}
SCRATCH = {'install', 'python', 'src', 'colcon', 'colcon-scratch'}
FORMAT = ('POSIX USTAR tar; lexical member order; regular files only; mode=0644; '
          'uid=gid=mtime=0; uname=gname empty; '
          'gzip filename empty, mtime=0, compression level=9')


def canonical(value):
    return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=False) + '\n').encode()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def fingerprint(info):
    return (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns)


def absolute(path):
    # abspath normalizes lexical paths without resolving/dereferencing symlinks.
    return Path(os.path.abspath(path))


def open_regular(path):
    """Open each absolute component with O_NOFOLLOW, then require a regular file."""
    path = absolute(path)
    directory = os.open('/', os.O_RDONLY | os.O_DIRECTORY)
    try:
        for component in path.parts[1:-1]:
            child = os.open(component, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW,
                            dir_fd=directory)
            os.close(directory)
            directory = child
        fd = os.open(path.name, os.O_RDONLY | os.O_NOFOLLOW, dir_fd=directory)
    finally:
        os.close(directory)
    if not stat.S_ISREG(os.fstat(fd).st_mode):
        os.close(fd)
        raise RuntimeError('Not a regular file: ' + str(path))
    return os.fdopen(fd, 'rb')


def open_directory(path):
    directory = os.open('/', os.O_RDONLY | os.O_DIRECTORY)
    try:
        for component in absolute(path).parts[1:]:
            child = os.open(component, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW,
                            dir_fd=directory)
            os.close(directory)
            directory = child
        return directory
    except BaseException:
        os.close(directory)
        raise


def has_entry(path):
    try:
        path.lstat()
        return True
    except FileNotFoundError:
        return False


def read(path):
    with open_regular(path) as source:
        before = fingerprint(os.fstat(source.fileno()))
        data = source.read()
        if fingerprint(os.fstat(source.fileno())) != before:
            raise RuntimeError('Input changed while reading: ' + str(path))
        return data


def inspect_file(path):
    with open_regular(path) as source:
        before = fingerprint(os.fstat(source.fileno()))
        hasher, size = hashlib.sha256(), 0
        while chunk := source.read(1024 * 1024):
            hasher.update(chunk)
            size += len(chunk)
        if fingerprint(os.fstat(source.fileno())) != before or size != before[2]:
            raise RuntimeError('Input changed while hashing: ' + str(path))
        return size, hasher.hexdigest(), before


def require_zero(path):
    value = read(path).decode().strip()
    if value != '0':
        raise RuntimeError('Completed acceptance gate requires exit code 0: ' + str(path))
    return 0


def gate_status(item):
    root = item['source']
    wrapper = root / 'verification'
    gate = wrapper if has_entry(wrapper) and stat.S_ISDIR(wrapper.lstat().st_mode) else root
    item['gate_prefix'] = gate.relative_to(root).parts
    exit_code = int(read(gate / 'exit-code.txt').decode().strip())
    status = {'label': item['label'], 'verification_exit_code': exit_code,
              'mode': item['mode'], 'acceptance': False}
    fresh = root / 'fresh-exit-code.txt'
    if has_entry(fresh):
        status['fresh_exit_code'] = int(read(fresh).decode().strip())
    if item['mode'] == 'completed-attempt':
        status['verdict'] = 'COMPLETED_ATTEMPT_ONLY; not final acceptance'
        return status
    require_zero(gate / 'exit-code.txt')
    if has_entry(fresh):
        require_zero(fresh)
    summary = json.loads(read(gate / 'summary.json'))
    if summary.get('scope') != 'W0_THROUGH_A09':
        raise RuntimeError('Gate lacks complete all+sourcefree summary: ' + str(gate))
    sourcefree = summary.get('w3-source-free', {})
    if sourcefree.get('container_exit_code') != 0:
        raise RuntimeError('Source-free summary lacks exit code 0: ' + str(gate))
    require_zero(gate / 'source-free/exit-code.txt')
    xml = ET.fromstring(read(gate / 'source-free/results/w3-source-free.xml'))
    suites = [xml] if xml.tag == 'testsuite' else list(xml.findall('testsuite'))
    if not suites or sum(int(s.get('tests', '0')) for s in suites) <= 0:
        raise RuntimeError('No source-free JUnit tests: ' + str(gate))
    if any(int(s.get(key, '0')) for s in suites for key in ('failures', 'errors')):
        raise RuntimeError('Source-free JUnit failures/errors: ' + str(gate))
    if read(gate / 'source-hashes-before.json') != read(gate / 'source-hashes-after.json'):
        raise RuntimeError('Source inventories changed: ' + str(gate))
    if not json.loads(read(gate / 'legacy-identity-comparison.json')).get('identities_equal'):
        raise RuntimeError('Legacy identity comparison did not pass: ' + str(gate))
    # Exact root pytest XML records preserve original copyright skip reasons.
    for package in PACKAGES[1:]:
        read(gate / 'build' / package / 'pytest.xml')
    status.update(acceptance=True, verdict='COMPLETED_ALL_AND_SOURCEFREE_GATE',
                  summary_scope=summary['scope'], source_free_exit_code=0)
    return status


def build_selection(parts, is_directory):
    """Only exact legacy JUnit locations survive the reconstructible build tree."""
    if not parts:
        return None if is_directory else 'Reconstructible build file'
    if parts[0] not in PACKAGES:
        return 'Reconstructible build content outside selected legacy JUnit packages'
    if len(parts) == 1:
        return None if is_directory else 'Reconstructible build file'
    if parts[1] == 'test_results':
        return None if is_directory or parts[-1].endswith('.xml') else 'Non-XML build content'
    if len(parts) == 2 and parts[1] == 'pytest.xml' and not is_directory:
        return None
    return 'Reconstructible build content; exact root pytest.xml and test_results XML retained'


def exclusion(item, relative, is_directory, info, max_wheel_bytes):
    parts = relative.parts
    name = parts[-1] if parts else ''
    if name in CACHES or (not is_directory and name.endswith(('.pyc', '.pyo'))):
        return 'Reconstructible Git/cache/bytecode metadata'
    if name == 'checkout' or name == 'a09-harness-tmp':
        return 'Reconstructible checkout or executable A09 Git fixture tree'
    prefix = item.get('gate_prefix')
    if prefix is not None and parts[:len(prefix)] == prefix:
        rest = parts[len(prefix):]
        if rest and rest[0] in SCRATCH:
            return 'Reconstructible verification source/build/install/python/colcon scratch'
        if rest and rest[0] == 'build':
            return build_selection(rest[1:], is_directory)
    if stat.S_ISLNK(info.st_mode) and any(p in ('log', 'legacy-log') for p in parts[:-1]):
        return 'Colcon convenience symlink; regular command/log outputs retained'
    if not is_directory and name.endswith('.whl') and info.st_size > max_wheel_bytes:
        return 'Wheel exceeds explicit modest-wheel retention limit of %d bytes' % max_wheel_bytes
    return None


def scan(inputs, max_wheel_bytes):
    selected, excluded = [], []
    for item in inputs:
        root, label = item['source'], item['label']
        # Check all root components, including directory roots, without dereferencing.
        for candidate in (root, *root.parents):
            if candidate.is_symlink():
                raise RuntimeError('Input root contains a symlink: ' + str(candidate))
        def visit(path, relative):
            info = path.lstat()
            is_directory = stat.S_ISDIR(info.st_mode)
            name = label + ('/' + relative.as_posix() if relative.parts else '')
            reason = exclusion(item, relative, is_directory, info, max_wheel_bytes)
            if reason:
                excluded.append({'path': name + ('/' if is_directory else ''), 'reason': reason})
                return
            if is_directory:
                directory_fd = open_directory(path)
                try:
                    with os.scandir(directory_fd) as entries:
                        children = sorted(entry.name for entry in entries)
                finally:
                    os.close(directory_fd)
                for child in children:
                    visit(path / child, relative / child)
            elif stat.S_ISREG(info.st_mode):
                selected.append((name, path))
            else:
                raise RuntimeError('Selected symlink or special file rejected: ' + name)
        visit(root, PurePosixPath())
    return sorted(selected), sorted(excluded, key=lambda row: row['path'])


def tar_info(name, size):
    member = tarfile.TarInfo(name)
    member.type = tarfile.REGTYPE
    member.size, member.mode = size, 0o644
    member.uid = member.gid = member.mtime = 0
    member.uname = member.gname = ''
    member.pax_headers = {}
    return member


def package(inputs, output, archive_name, max_wheel_bytes, fixture_only=False):
    output = absolute(output)
    if any(path.is_symlink() for path in (output, *output.parents)):
        raise RuntimeError('Output directory components may not be symlinks')
    for item in inputs:
        source = item['source']
        if output == source or source in output.parents:
            raise RuntimeError('Output must be outside every input tree: ' + str(output))
    statuses = [gate_status(item) for item in inputs if item['mode'] != 'evidence']
    if not statuses and not fixture_only:
        raise RuntimeError('Use --completed-gate or --completed-attempt; evidence alone is not completion')
    selected, excluded = scan(inputs, max_wheel_bytes)
    names = {name for name, _ in selected}
    for item in inputs:
        if item['mode'] == 'completed-gate':
            prefix = '/'.join((item['label'], *item['gate_prefix'], 'build')) + '/'
            for package_name in PACKAGES:
                if not any(name.startswith(prefix + package_name + '/') and name.endswith('.xml')
                           for name in names):
                    raise RuntimeError('Completed gate lacks exact legacy JUnit XML: ' + prefix + package_name)
    records, identities = [], {}
    for name, path in selected:
        size, sha, identity = inspect_file(path)
        records.append({'path': name, 'size_bytes': size, 'sha256': sha})
        identities[name] = identity
    manifest = {'schema_version': 1,
                'scope': 'FIXTURE_ONLY' if fixture_only else 'Completed verification evidence',
                'completion_records': statuses,
                'archive_format': FORMAT,
                'inputs': [{'label': row['label'], 'mode': row['mode']} for row in inputs],
                'selection_policy': ('Preserve all selected raw files unchanged. Prune gate source/build/'
                                     'install/python/colcon scratch, checkouts, executable A09 Git fixtures, '
                                     'Git/cache metadata. Preserve exact build package root pytest.xml and '
                                     'test_results/**/*.xml, regular colcon logs, all other evidence trees, '
                                     'and wheels within the stated limit. Reject other selected symlinks/'
                                     'special files; never dereference symlinks.'),
                'max_wheel_bytes': max_wheel_bytes,
                'excluded_paths': excluded, 'payload_file_count': len(records),
                'payload_bytes': sum(row['size_bytes'] for row in records),
                'files': records,
                'manifest_self_hash': 'MANIFEST.json SHA256/size appear in external member-inventory.json and receipt.json.'}
    manifest_data = canonical(manifest)
    inventory = sorted(records + [{'path': 'MANIFEST.json', 'size_bytes': len(manifest_data),
                                    'sha256': digest(manifest_data)}], key=lambda row: row['path'])
    expected = {row['path']: row for row in inventory}
    paths = dict(selected)
    if output.exists() and any(output.iterdir()):
        raise RuntimeError('Use a fresh/empty output directory; existing evidence is never overwritten')
    output.mkdir(parents=True, exist_ok=True)
    partial = output / (archive_name + '.partial')
    with partial.open('xb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, compresslevel=9, mtime=0) as zipped:
            with tarfile.open(fileobj=zipped, mode='w|', format=tarfile.USTAR_FORMAT) as archive:
                for row in inventory:
                    name = row['path']
                    if name == 'MANIFEST.json':
                        archive.addfile(tar_info(name, row['size_bytes']), io.BytesIO(manifest_data))
                    else:
                        with open_regular(paths[name]) as source:
                            if fingerprint(os.fstat(source.fileno())) != identities[name]:
                                raise RuntimeError('Input changed before packing: ' + name)
                            archive.addfile(tar_info(name, row['size_bytes']), source)
                            if fingerprint(os.fstat(source.fileno())) != identities[name]:
                                raise RuntimeError('Input changed while packing: ' + name)
    seen, readback_bytes = [], 0
    with tarfile.open(partial, 'r:gz') as archive:
        for member in archive:
            name = member.name
            pure = PurePosixPath(name)
            if (not member.isfile() or name in seen or pure.is_absolute()
                    or '..' in pure.parts or name not in expected):
                raise RuntimeError('Unsafe, duplicate, special, or unexpected archive member: ' + name)
            if (member.mode != 0o644 or any((member.uid, member.gid, member.mtime))
                    or member.uname or member.gname):
                raise RuntimeError('Archive metadata was not normalized: ' + name)
            body, hasher, size = archive.extractfile(member), hashlib.sha256(), 0
            while chunk := body.read(1024 * 1024):
                hasher.update(chunk)
                size += len(chunk)
            row = expected[name]
            if size != row['size_bytes'] or member.size != size or hasher.hexdigest() != row['sha256']:
                raise RuntimeError('Readback hash/size mismatch: ' + name)
            seen.append(name)
            readback_bytes += size
    if seen != sorted(expected):
        raise RuntimeError('Archive member set/order mismatch')
    if scan(inputs, max_wheel_bytes) != (selected, excluded):
        raise RuntimeError('Input selection changed during packaging')
    for row in records:
        size, sha, identity = inspect_file(paths[row['path']])
        if (size, sha, identity) != (row['size_bytes'], row['sha256'], identities[row['path']]):
            raise RuntimeError('Input changed before completion: ' + row['path'])
    if statuses != [gate_status(item) for item in inputs if item['mode'] != 'evidence']:
        raise RuntimeError('Completion status changed during packaging')
    archive_path = output / archive_name
    partial.rename(archive_path)
    archive_size, archive_sha, _ = inspect_file(archive_path)
    inventory_data = canonical({'schema_version': 1, 'files': inventory})
    receipt = {'schema_version': 1, 'archive': archive_name,
               'archive_size_bytes': archive_size, 'archive_sha256': archive_sha,
               'manifest_size_bytes': len(manifest_data), 'manifest_sha256': digest(manifest_data),
               'member_inventory_size_bytes': len(inventory_data),
               'member_inventory_sha256': digest(inventory_data),
               'archive_member_count': len(seen), 'payload_file_count': len(records),
               'payload_bytes': manifest['payload_bytes'], 'readback_uncompressed_bytes': readback_bytes,
               'completion_records': statuses, 'fixture_only': fixture_only,
               'readback_result': 'PASS: full member hashes/sizes, safe paths, regular files, sorted order, normalized metadata; source inventory and bytes rechecked; no extraction or input mutation.'}
    (output / 'MANIFEST.json').write_bytes(manifest_data)
    (output / 'member-inventory.json').write_bytes(inventory_data)
    (output / 'selection.json').write_bytes(canonical({'inputs': manifest['inputs'],
        'included_paths': [row['path'] for row in records], 'excluded_paths': excluded}))
    (output / 'receipt.json').write_bytes(canonical(receipt))
    return receipt


def input_spec(value, mode):
    if '=' not in value:
        raise argparse.ArgumentTypeError('Expected LABEL=PATH')
    label, path = value.split('=', 1)
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*', label) or label == 'MANIFEST.json':
        raise argparse.ArgumentTypeError('LABEL must be a safe single path component, not MANIFEST.json')
    return {'label': label, 'source': absolute(path), 'mode': mode}


def self_test(output):
    output = absolute(output)
    if output.exists():
        raise RuntimeError('Self-test output must be absent')
    source = output / 'fixture'
    for relative, data in [('run.log', b'fixture log\n'), ('build/global_planner/pytest.xml', b'<testsuite/>\n'),
                           ('build/f110_msgs/test_results/lint.xml', b'<testsuite/>\n'),
                           ('build/global_planner/object.o', b'exclude\n'),
                           ('source-free/harness/runtime_verify.sh', b'#!/bin/sh\nexit 0\n'),
                           ('source-free/results/reference/manifest.json', b'{"fixture":true}\n'),
                           ('wheels/optimizer.whl', b'fixture-wheel\n')]:
        path = source / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
    (source / 'a09-harness-tmp').mkdir()
    (source / 'a09-harness-tmp/never-follow').symlink_to('/does-not-exist')
    item = {'label': 'fixture', 'source': source, 'mode': 'evidence', 'gate_prefix': ()}
    first = package([item], output / 'first', 'fixture.tar.gz', 16 * 1024 * 1024, True)
    for path in source.rglob('*'):
        if path.is_file() and not path.is_symlink():
            os.chmod(path, 0o700)
            os.utime(path, (123456789, 123456789))
    second = package([item], output / 'second', 'fixture.tar.gz', 16 * 1024 * 1024, True)
    if first != second or read(output / 'first/fixture.tar.gz') != read(output / 'second/fixture.tar.gz'):
        raise RuntimeError('Determinism self-test failed')
    result = {'passed': True, 'archive_sha256': first['archive_sha256'],
              'payload_file_count': first['payload_file_count'],
              'demonstration': 'Byte-identical archive and receipts after source mtime/mode changes; exact build XML retained; build objects and executable A09 fixture tree excluded; dangling excluded symlink never followed.'}
    (output / 'determinism.json').write_bytes(canonical(result))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--completed-gate', action='append', default=[], metavar='LABEL=PATH',
                        help='Completed all+sourcefree exit-0 gate, or fresh wrapper containing verification/')
    parser.add_argument('--completed-attempt', action='append', default=[], metavar='LABEL=PATH',
                        help='Completed attempt with recorded exit-code.txt; explicitly never final acceptance')
    parser.add_argument('--evidence', action='append', default=[], metavar='LABEL=PATH',
                        help='Additional regular file/directory: inventories, immutable references, source/harness snapshots')
    parser.add_argument('--output-dir', type=Path)
    parser.add_argument('--archive-name', default='verification-evidence.tar.gz')
    parser.add_argument('--max-wheel-bytes', type=int, default=16 * 1024 * 1024)
    parser.add_argument('--self-test', type=Path, metavar='ABSENT_SCRATCH_DIRECTORY')
    args = parser.parse_args()
    if args.self_test:
        if args.completed_gate or args.completed_attempt or args.evidence or args.output_dir:
            parser.error('--self-test cannot be combined with packaging arguments')
        result = self_test(args.self_test)
    else:
        if not args.output_dir or not (args.completed_gate or args.completed_attempt):
            parser.error('--output-dir and a completed gate/attempt are required')
        if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*\.tar\.gz', args.archive_name):
            parser.error('--archive-name must be a safe basename ending in .tar.gz')
        if args.max_wheel_bytes < 0:
            parser.error('--max-wheel-bytes must be nonnegative')
        inputs = []
        for mode, values in [('completed-gate', args.completed_gate),
                             ('completed-attempt', args.completed_attempt), ('evidence', args.evidence)]:
            inputs.extend(input_spec(value, mode) for value in values)
        inputs.sort(key=lambda row: row['label'])
        if len({item['label'] for item in inputs}) != len(inputs):
            parser.error('Input labels must be unique')
        result = package(inputs, args.output_dir, args.archive_name, args.max_wheel_bytes)
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
