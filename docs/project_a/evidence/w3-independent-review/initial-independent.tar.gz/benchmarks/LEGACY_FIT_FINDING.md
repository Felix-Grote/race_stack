# P2: initial legacy fit escapes bounded numerical failure classification

Initial SHA: `17e4ec4e8fedfa736467d02f6204b04e8552decb`.
Location: `scripts/project_a/w3_benchmark_support.py:461`.

The first `fit()` call in `legacy_candidate` lies outside its existing
`except (adapter.OptimizationError, ValueError)` block. Consequently an actual
bounded fit timeout raises through the comparator and is reclassified as
`HARNESS_FAILURE` by `benchmark_w3.run_worker`, despite having a precise
`RESOURCE_LIMIT` status. The partial legacy evidence is lost from the returned
worker report. Later fit/QP failures are already classified by the existing
handler. This violates the benchmark's distinction between bounded numerical
rejections and implementation/harness failures. It does not grant acceptance to
any failed path and does not change the historical 96-job counts.

Minimal input: unchanged frozen S0-circle route, repaired comparator, original
SolverPolicy except an explicit `qp_wall_seconds=0.001`. The actual numerical
child times out during startup/fit; no mock is involved. The expected outcome
is a retained legacy result with status RESOURCE_LIMIT, no candidate, zero
completed QPs and an explicit fit timeout reason. Actual outcome is
HARNESS_FAILURE with an OptimizationError traceback from line461.

The frozen job and initial source hashes are in `legacy-first-fit-limit-red/`.
Pinned image: `sha256:72059c0caff2aa71e7ee9ff85d718c2e1761488d144857a42167de36ff74d246`.
Actual successful reproducer execution (container already has reviewed mounts,
nonroot user, no network, one CPU and 4GiB memory):

```
docker exec --user 1000:1000 w3-independent-s6-probes-retry1 python /src/scripts/project_a/benchmark_w3.py --worker /work/legacy-first-fit-limit-red/job.json
```

The command exits0 as a worker and writes the failing result
`legacy-first-fit-limit.json.gz`; `exec-run.log` records HARNESS_FAILURE and the
exact traceback is inside the saved result. An earlier attempt to create an
extra container failed before numerical execution with Docker125/ENOSPC; its
separate `run.log` is retained and is not the numerical reproducer.

Minimal correction: move the initial fit into the existing exception boundary,
without changing fitting equations, limits or any successful-path values.
Regression: call the comparator on the same actual bounded timeout and require
its structured RESOURCE_LIMIT result. This can land after the immutable-source
S6 probe batch completes. Historical manifests remain unchanged; their helper
bytes remain recoverable at the initial exact Git SHA. The runbook must state
that a current-source rerun has amended helper source identity.
