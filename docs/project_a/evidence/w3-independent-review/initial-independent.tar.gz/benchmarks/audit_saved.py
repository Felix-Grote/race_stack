"""Independent A08 frozen-ledger, provenance, and adaptive-quadrature audit."""
import collections
import gzip
import hashlib
import json
import math
from pathlib import Path
from fractions import Fraction
import subprocess

import numpy as np
from scipy.integrate import quad

ROOT = Path(__file__).resolve().parents[3]
EVIDENCE = ROOT / 'docs/project_a/evidence/w3-benchmarks'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def metric_report(report):
    """Integrate saved polynomials with adaptive QUADPACK, no planner imports."""
    coefficients = np.asarray(report['coefficients'], dtype=float)

    def speed(index, t):
        c = coefficients[index]
        vx, vy = c[:, 1] + t * (2 * c[:, 2] + t * 3 * c[:, 3])
        return math.hypot(vx, vy)

    lengths, energies, curvature_maxima = [], [], []
    for index, c in enumerate(coefficients):
        lengths.append(quad(lambda t: speed(index, t), 0, 1,
                            epsabs=1e-12, epsrel=1e-12)[0])

        def energy(t):
            dx, dy = c[:, 1] + t * (2 * c[:, 2] + t * 3 * c[:, 3])
            ddx, ddy = 2 * c[:, 2] + t * 6 * c[:, 3]
            return (dx * ddy - dy * ddx) ** 2 / math.hypot(dx, dy) ** 5

        energies.append(quad(energy, 0, 1, epsabs=1e-13, epsrel=1e-12)[0])
        px = c[0, 1:] * np.arange(1, 4)
        py = c[1, 1:] * np.arange(1, 4)
        pol = np.polynomial.polynomial
        cross = pol.polysub(pol.polymul(px, pol.polyder(py)),
                           pol.polymul(py, pol.polyder(px)))
        speed2 = pol.polyadd(pol.polymul(px, px), pol.polymul(py, py))
        critical = pol.polysub(2 * pol.polymul(pol.polyder(cross), speed2),
                               3 * pol.polymul(cross, pol.polyder(speed2)))
        candidates = [0., 1.] + [root.real for root in pol.polyroots(critical)
                                  if abs(root.imag) < 1e-8 and 0 <= root.real <= 1]
        curvature_maxima.append(max(abs(pol.polyval(t, cross)) /
                                    pol.polyval(t, speed2) ** 1.5 for t in candidates))
    cumulative = [0.]
    for length in lengths:
        cumulative.append(math.fsum((cumulative[-1], length)))
    knots = report['retime']['profile']['knots']
    stations = [cumulative[k['segment']] + quad(
        lambda t: speed(k['segment'], t), 0, k['t'],
        epsabs=1e-12, epsrel=1e-12)[0] for k in knots]
    ds = [b - a for a, b in zip(stations, stations[1:] + [math.fsum(lengths)])]
    assert all(x > 0 for x in ds)
    us = [k['u'] for k in knots]
    times = [2 * length / (math.sqrt(a) + math.sqrt(b))
             for length, a, b in zip(ds, us, us[1:] + us[:1])]
    # Fresh arithmetic is checked against stored independent distance bounds.
    distance_violations = []
    for index, (length, edge) in enumerate(zip(ds, report['dynamics']['edges'])):
        if not edge['distance_lower_m'] <= length <= edge['distance_upper_m']:
            distance_violations.append(index)
    assert not distance_violations, (report['id'], distance_violations)
    exact_time = math.fsum(times)
    duration = report['dynamics']['lap_time_s']
    assert report['dynamics']['lap_time_lower_s'] <= exact_time <= report[
        'dynamics']['lap_time_upper_s'], report['id']
    return {'id': report['id'], 'segments': len(coefficients),
            'length_m': math.fsum(lengths), 'energy_per_m': math.fsum(energies),
            'max_abs_curvature_per_m': max(curvature_maxima),
            'time_s': exact_time,
            'length_error_m': abs(math.fsum(lengths) - report['length_m']),
            'energy_error_per_m': abs(math.fsum(energies) -
                                      report['curvature_energy_final_per_m']),
            'profile_time_error_s': abs(exact_time - report['lap_time_s']),
            'producer_time_error_s': abs(exact_time - duration)}


def composition_check(report):
    """Bound raw-to-adapted coefficient changes with rational arithmetic."""
    legacy = report['legacy']
    raw = legacy['actual_final_coefficients']
    q = legacy['actual_final_q']
    period = report['q'][-1]
    declarations = legacy['algebraic_subdivision']
    ordered = sorted(declarations, key=lambda item: item['source_q_interval'][0] -
                     math.floor(sum(item['source_q_interval']) / (2 * period)) * period)
    assert len(ordered) == len(report['coefficients'])
    errors = []
    for declared, adapted in zip(ordered, report['coefficients']):
        source_index = declared['source_segment']
        source = raw[source_index]
        lower, upper = map(Fraction, q[source_index:source_index + 2])
        first, last = map(Fraction, declared['source_q_interval'])
        start, step = (first - lower) / (upper - lower), (last - first) / (upper - lower)
        total_error = Fraction(0)
        for axis in (0, 1):
            for degree in range(4):
                exact = sum(Fraction(source[axis][k]) * math.comb(k, degree) *
                            start ** (k - degree) * step ** degree for k in range(degree, 4))
                total_error += abs(Fraction(adapted[axis][degree]) - exact)
        assert total_error <= Fraction(declared['coordinate_composition_roundoff_bound_m']), (
            report['id'], source_index)
        errors.append(float(total_error))
    return {'id': report['id'], 'adapted_pieces': len(ordered),
            'max_exact_coordinate_error_bound_m': max(errors)}


def main():
    raw_checksums = (EVIDENCE / 'SHA256SUMS').read_text().splitlines()
    for line in raw_checksums:
        expected, filename = line.split('  ', 1)
        assert sha((EVIDENCE / filename).read_bytes()) == expected, filename
    rows, reports, profiles, compositions = [], [], [], []
    manifest_checks = []
    for campaign in ('primary', 'matched-coarse'):
        directory = EVIDENCE / campaign
        manifest = json.loads((directory / 'manifest.json').read_bytes())
        original_source = '17e4ec4e8fedfa736467d02f6204b04e8552decb'
        for filename, field in (('benchmark_w3.py', 'script_sha256'),
                                ('w3_benchmark_support.py', 'support_sha256')):
            committed = subprocess.check_output([
                'git', '-C', str(ROOT), 'show',
                original_source + ':scripts/project_a/' + filename])
            assert manifest[field] == sha(committed), filename
        ledger = [json.loads(row) for row in (directory / 'attempts.jsonl').read_bytes().splitlines()]
        jobs = {j['id']: j for j in manifest['jobs']}
        assert len(jobs) == len(ledger) == len(manifest['jobs'])
        assert set(jobs) == {r['id'] for r in ledger}
        for row in ledger:
            payload = (directory / row['result_file']).read_bytes()
            assert sha(payload) == row['result_sha256'], row['id']
            report = json.loads(gzip.decompress(payload))
            job = jobs[row['id']]
            assert report['solver_policy'] == job['solver_policy'] == row['solver_policy']
            assert report['worker_script_sha256'] == manifest['script_sha256']
            assert report['worker_support_sha256'] == manifest['support_sha256']
            assert report['status'] == row['status']
            route_file = directory / 'inputs' / Path(job['route']).name
            assert sha(route_file.read_bytes()) == report['route_sha256']
            if row['status'] == 'PASS':
                assert report['geometry_status'] == report['dynamics_status'] == 'PASS'
                assert 'legacy_ros_export_without_refit' in {p['name'] for p in report['phases']}
                assert report['H'] == row['H'] and report['expected_curve_digest'] == row[
                    'expected_curve_digest']
                if row['variant'] == 'repaired':
                    legacy = report['legacy']
                    assert legacy['raw_legacy_geometry_authorization']['status'] == 'UNSUPPORTED'
                    assert len(legacy['actual_final_coefficients']) != 0
                    assert legacy['actual_final_q'] != report['q']
                    assert legacy['sources']['create_raceline.py'] == manifest[
                        'helper_source_sha256']['create_raceline.py']
                    compositions.append(composition_check(report))
                profiles.append(metric_report(report))
                reports.append(report)
            rows.append(row)
        manifest_checks.append({'campaign': campaign, 'jobs': len(ledger),
                                'manifest_sha256': sha((directory / 'manifest.json').read_bytes()),
                                'historical_source_sha': original_source,
                                'current_worker_matches': manifest['script_sha256'] == sha(
                                    (ROOT / 'scripts/project_a/benchmark_w3.py').read_bytes()),
                                'current_support_matches': manifest['support_sha256'] == sha(
                                    (ROOT / 'scripts/project_a/w3_benchmark_support.py').read_bytes())})
    statuses = dict(collections.Counter(r['status'] for r in rows))
    assert statuses == {'PASS': 58, 'STOCK_PREPARATION_FAILURE': 28,
                        'RESOURCE_LIMIT': 8, 'SOLVER_FAILURE': 2}, statuses
    for group, pair in __import__('itertools').groupby(
            sorted(reports, key=lambda r: (r['scenario'], r['variant'], r['solver_policy']['spacing_m'])),
            key=lambda r: (r['scenario'], r['variant'], r['solver_policy']['spacing_m'])):
        pair = list(pair)
        assert len(pair) == 2, group
        for field in ('coefficients', 'q', 'owners', 'model', 'retime', 'geometry', 'dynamics',
                      'H', 'expected_curve_digest'):
            assert pair[0][field] == pair[1][field], (group, field)
    output = {'checksum_files_verified': len(raw_checksums), 'manifests': manifest_checks,
              'statuses': statuses, 'accepted_repeated_authority_pairs': len(reports) // 2,
              'adaptive_quad_reports': profiles,
              'independent_rational_composition_reports': compositions,
              'max_errors': {field: max(p[field] for p in profiles) for field in
                             ('length_error_m', 'energy_error_per_m', 'profile_time_error_s',
                              'producer_time_error_s')}}
    destination = Path(__file__).with_name('saved-audit.json')
    destination.write_text(json.dumps(output, indent=2, sort_keys=True) + '\n')
    print(json.dumps({k: v for k, v in output.items() if k not in
                      ('adaptive_quad_reports', 'independent_rational_composition_reports')},
                     indent=2))


if __name__ == '__main__':
    main()
