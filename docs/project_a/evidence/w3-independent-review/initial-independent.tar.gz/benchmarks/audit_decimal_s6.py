"""Independent 60-digit adaptive-Simpson check of frozen S6 polynomial authority."""
from decimal import Decimal, localcontext
import gzip
import json
from pathlib import Path


def integrate(function, tolerance=Decimal('1e-22')):
    a, b = Decimal(0), Decimal(1)
    mid = (a + b) / 2
    fa, fm, fb = function(a), function(mid), function(b)
    initial = (fa + 4 * fm + fb) / 6

    def refine(left, right, first, center, last, estimate, epsilon, depth):
        middle = (left + right) / 2
        q1, q3 = (left + middle) / 2, (middle + right) / 2
        fq1, fq3 = function(q1), function(q3)
        e1 = (middle - left) * (first + 4 * fq1 + center) / 6
        e2 = (right - middle) * (center + 4 * fq3 + last) / 6
        difference = e1 + e2 - estimate
        if abs(difference) <= 15 * epsilon:
            return e1 + e2 + difference / 15
        if depth <= 0:
            raise ArithmeticError('independent quadrature budget exhausted')
        return refine(left, middle, first, fq1, center, e1, epsilon / 2, depth - 1) + refine(
            middle, right, center, fq3, last, e2, epsilon / 2, depth - 1)

    return refine(a, b, fa, fm, fb, initial, tolerance, 20)


def main():
    root = Path(__file__).resolve().parents[3]
    path = root / 'docs/project_a/evidence/w3-benchmarks/primary/S6-240m-new-0.52-r1.json.gz'
    report = json.loads(gzip.decompress(path.read_bytes()))
    with localcontext() as context:
        context.prec = 60
        lengths, energies = [], []
        for segment in report['coefficients']:
            c = [[Decimal.from_float(float(value)) for value in axis] for axis in segment]

            def derivatives(t):
                v = [axis[1] + t * (2 * axis[2] + t * 3 * axis[3]) for axis in c]
                a = [2 * axis[2] + t * 6 * axis[3] for axis in c]
                return v, a

            def speed(t):
                velocity, _ = derivatives(t)
                return (velocity[0] ** 2 + velocity[1] ** 2).sqrt()

            def energy(t):
                velocity, acceleration = derivatives(t)
                determinant = velocity[0] * acceleration[1] - velocity[1] * acceleration[0]
                square = velocity[0] ** 2 + velocity[1] ** 2
                return determinant ** 2 / (square ** 2 * square.sqrt())

            lengths.append(integrate(speed))
            energies.append(integrate(energy))
        length, energy_value = sum(lengths), sum(energies)
        output = {'id': report['id'], 'decimal_digits': 60, 'segments': len(lengths),
                  'absolute_adaptive_simpson_target_per_integral': '1e-22',
                  'length_m': str(length), 'energy_per_m': str(energy_value),
                  'length_delta_from_saved_binary64_m': str(
                      length - Decimal.from_float(report['length_m'])),
                  'energy_delta_from_saved_binary64_per_m': str(
                      energy_value - Decimal.from_float(report['curvature_energy_final_per_m'])),
                  'scope': 'Independent numerical diagnostic; Simpson error criterion is '
                           'not a substitute for the continuous software certificates.'}
    destination = Path(__file__).with_name('decimal-s6-audit.json')
    destination.write_text(json.dumps(output, indent=2, sort_keys=True) + '\n')
    print(json.dumps(output, indent=2))


if __name__ == '__main__':
    main()
