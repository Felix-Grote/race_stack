# Independent A08 phase-I record

Reviewed W3 source: `17e4ec4e8fedfa736467d02f6204b04e8552decb`.
No production implementation edits were made in this investigation.

`audit_saved.py` imports no planner code and independently checks all frozen
campaign ledgers against manifests, gzip result hashes and route-byte hashes.
All 966 campaign checksum entries match. The primary manifest SHA256 is
`a0ac91282fa72287d98c1c986c4b66be7082b5d1731dc1fc844d7c4e2f1706bf`;
the matched supplement manifest SHA256 is
`b51896f8e9e044bc767a529f97da75bb87afe99e1cb05f6064803f98ef95fcf5`.
The manifests predeclare exactly 92 + 4 jobs. The ledger counts are exactly
58 PASS, 28 STOCK_PREPARATION_FAILURE, 8 RESOURCE_LIMIT, 2 SOLVER_FAILURE.
Every accepted row has both continuous PASS reports and the completed ROS
export phase. All 29 repeated accepted pairs have equal exact coefficients,
q, owners, model, retime, independent geometry/dynamics reports, H and C.

The source-authenticated comparator scalarizes only the inherited SciPy
parameter defect, adds bounded fresh fit/QP processes, and records all q
lineage. Actual final `create_raceline` coefficient arrays are preserved as raw
authority. Their geometry authorization is explicitly UNSUPPORTED. Separate
algebraic binary64 subdivision and seam rotation produce the authority passed
to both common validators and the common retimer. Rational composition-error
bounds are retained. I found no transfer of the adapted certificate to raw
legacy coefficients. The .52/.53 repaired supplement is actually mesh-matched;
the .5 repaired row is not the scientific comparison for new .52.

An independent adaptive QUADPACK oracle on actual polynomial coefficients and
profile knots checks all 58 accepted outputs. It does not call the planner's
arc kernel, validators, Gaussian quadrature oracle, curvature-energy helper,
or metadata reconstruction. Each cyclic edge time is independently derived
from affine squared speed as `2 ds / (sqrt(u0)+sqrt(u1))`. All recomputed edge
distances lie in their saved independent distance enclosures. Maximum errors:
length 3.552713678800501e-15 m, energy 4.440892098500626e-16 /m, retimer
nominal time 7.105427357601002e-14 s, producer nominal time
1.4210854715202004e-14 s. Polynomial derivative critical roots provide a
separate diagnostic for actual maximum curvature, retained per result.

The documented actual-curvature-energy increase on circle fixtures is real;
convergence is not minimum-curvature or minimum-time optimality. The S6
preferred .52 fixture instead decreases energy from 0.1965416075975774 /m
to 0.1899228018103858 /m. This is an objective diagnostic, not a performance
claim about a physical vehicle.

Fresh numerical sensitivity inputs are frozen before execution in
`s6-probes/manifest.json` (SHA256
`c775c22657548df9f976a3d176016514196de56066c5ff2dabaa79e79235c1b3`).
Nine jobs cover baseline .52 m, .519/.521/.525 m meshes, quarter-lap cyclic
origin, .995/1.005 geometric scaling, and half/double seed knot counts while
retaining original legal boundaries. Every nonspacing solver/proof/resource
limit remains unchanged. All failures and retries will remain in append-only
ledgers. Baseline includes publication/query/ROS export; remaining probes
exercise numerical production and independent geometry/dynamics. Pinned
container build is being handled by the installed-verification reviewer.

Commands already executed:

```
OPENBLAS_NUM_THREADS=1 /workspace/race_stack_setup/venv/bin/python work/independent-review/benchmarks/audit_saved.py
PYTHONPATH=planner/global_planner /workspace/race_stack_setup/venv/bin/python work/independent-review/benchmarks/prepare_probes.py
```

These independent saved-output checks establish integrity and numerical
consistency, not fresh numerical compilation or independent physical approval.
No blocking A08 defect is demonstrated at this point; fresh S6 probes remain.
