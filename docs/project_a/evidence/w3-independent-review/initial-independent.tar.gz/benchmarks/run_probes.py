"""Run all frozen independent S6 jobs serially with external hard bounds."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import sys
import time

directory = Path(os.environ.get('S6_PROBE_DIR', '/work/s6-probes'))
manifest = json.loads((directory / 'manifest.json').read_bytes())
worker = Path('/src/scripts/project_a/benchmark_w3.py')
for source, digest in manifest['source_hashes'].items():
    assert hashlib.sha256((Path('/src') / source).read_bytes()).hexdigest() == digest
outer = manifest['bounds']
bootstrap = ('import resource,runpy;'
             f"resource.setrlimit(resource.RLIMIT_AS,({outer['address_space_bytes']},)*2);"
             f"resource.setrlimit(resource.RLIMIT_CPU,({outer['cpu_seconds']},)*2);"
             f'runpy.run_path({str(worker)!r},run_name="__main__")')
selected = sys.argv[1:] or [j['id'] for j in manifest['jobs']]
for job in manifest['jobs']:
    if job['id'] not in selected:
        continue
    identity = job['id']
    result = directory / (identity + '.json.gz')
    assert not result.exists(), 'never overwrite attempts'
    route = Path(job['route'])
    assert hashlib.sha256(route.read_bytes()).hexdigest() == job['route_sha256']
    start = time.perf_counter()
    before = resource.getrusage(resource.RUSAGE_CHILDREN)
    process = subprocess.Popen([sys.executable, '-c', bootstrap, '--worker',
                                str(directory / (identity + '.job.json'))],
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                               start_new_session=True)
    timeout = False
    try:
        stdout, stderr = process.communicate(timeout=outer['wall_seconds'])
    except subprocess.TimeoutExpired:
        timeout = True
        os.killpg(process.pid, signal.SIGKILL)
        stdout, stderr = process.communicate()
    after = resource.getrusage(resource.RUSAGE_CHILDREN)
    (directory / (identity + '.stdout')).write_bytes(stdout)
    (directory / (identity + '.stderr')).write_bytes(stderr)
    complete = False
    if result.exists() and process.returncode == 0:
        try:
            report = json.loads(gzip.decompress(result.read_bytes()))
            complete = True
        except (ValueError, OSError, EOFError):
            pass
    if complete:
        summary = {field: report.get(field) for field in
                   ('id', 'status', 'reason', 'iterations', 'segments', 'length_m',
                    'expected_curve_digest', 'H', 'geometry_status', 'dynamics_status',
                    'curvature_energy_initial_per_m', 'curvature_energy_final_per_m',
                    'lap_time_s', 'qp_condition_max', 'qp_primal_residual_max',
                    'qp_peak_rss_bytes', 'parent_peak_rss_bytes', 'child_peak_rss_bytes')}
    else:
        summary = {'id': identity, 'status': 'RESOURCE_LIMIT' if timeout else 'HARNESS_FAILURE',
                   'reason': 'external wall limit' if timeout else 'worker failed/incomplete result'}
    summary.update(worker_exit_code=process.returncode, external_wall_s=time.perf_counter()-start,
                   external_child_cpu_s=(after.ru_utime + after.ru_stime - before.ru_utime -
                                         before.ru_stime), timeout=timeout,
                   result_sha256=hashlib.sha256(result.read_bytes()).hexdigest()
                   if result.exists() else None)
    with (directory / 'attempts.jsonl').open('a') as ledger:
        ledger.write(json.dumps(summary, sort_keys=True) + '\n')
        ledger.flush()
        os.fsync(ledger.fileno())
    print(json.dumps(summary), flush=True)
