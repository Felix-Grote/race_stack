"""Transport frozen H/C unchanged and reload fresh S6 in a new process."""
from bisect import bisect_right
from dataclasses import asdict
import gzip
import hashlib
import json
import math
from pathlib import Path
import struct
import time

from scipy.integrate import quad

from global_planner.route_artifact import ArtifactError, ValidationContext, load_reference

OLD_H = '72e7f5449d7ec61c88f3ef71339544dd46c32a3bcc74385801075c8463caf024'
OLD_C = '5246eda31c757ae728c7ba9deb03a40569590dd296a941aaacbaf15af2ac58da'


def same_numbers(first, second):
    if isinstance(first, (tuple, list)):
        return len(first) == len(second) and all(same_numbers(a, b) for a, b in zip(first, second))
    return struct.pack('>d', first) == struct.pack('>d', second)


def same_report(current, historical):
    return json.dumps(asdict(current), sort_keys=True) == json.dumps(historical, sort_keys=True)


def query_oracle(reference, report):
    coefficients = report['coefficients']

    def speed(segment, t):
        x, y = coefficients[segment]
        return math.hypot(x[1] + 2 * x[2] * t + 3 * x[3] * t ** 2,
                          y[1] + 2 * y[2] * t + 3 * y[3] * t ** 2)

    lengths = [quad(lambda t: speed(index, t), 0, 1, epsabs=1e-12, epsrel=1e-12)[0]
               for index in range(len(coefficients))]
    starts = [0.]
    for length in lengths:
        starts.append(math.fsum((starts[-1], length)))
    knots = report['retime']['profile']['knots']
    stations = [starts[k['segment']] + quad(lambda t: speed(k['segment'], t), 0, k['t'],
                                           epsabs=1e-12, epsrel=1e-12)[0] for k in knots]
    ds = [b - a for a, b in zip(stations, stations[1:] + [math.fsum(lengths)])]
    us = [k['u'] for k in knots]
    duration = [2 * distance / (math.sqrt(a) + math.sqrt(b))
                for distance, a, b in zip(ds, us, us[1:] + us[:1])]
    errors = []
    for progress in (-.1, 0., .1, .123 * reference.length, .501 * reference.length,
                     .9 * reference.length, reference.length, 2 * reference.length + .1):
        actual = reference.sample(progress)
        station = starts[actual.segment] + quad(lambda t: speed(actual.segment, t), 0, actual.t,
                                                epsabs=1e-12, epsrel=1e-12)[0]
        edge = bisect_right(stations, actual.s) - 1
        first, last = us[edge], us[(edge + 1) % len(us)]
        fraction = (actual.s - stations[edge]) / ds[edge]
        square = (1 - fraction) * first + fraction * last
        acceleration = (last - first) / (2 * ds[edge])
        local_time = 2 * (actual.s - stations[edge]) / (math.sqrt(first) + math.sqrt(square))
        elapsed = math.fsum(duration[:edge]) + local_time
        delta = {'progress_m': progress, 'metric_residual_m': abs(station - actual.s),
                 'squared_speed_error': abs(square - actual.speed_mps ** 2),
                 'acceleration_error_mps2': abs(acceleration - actual.acceleration_mps2),
                 'elapsed_time_error_s': abs(elapsed - actual.time_s)}
        assert delta['metric_residual_m'] < 1e-8, delta
        assert delta['squared_speed_error'] < 1e-8, delta
        assert delta['acceleration_error_mps2'] < 1e-7, delta
        assert delta['elapsed_time_error_s'] < 1e-8, delta
        errors.append(delta)
    return errors


def main():
    root = Path('/src/docs/project_a/evidence/w3-benchmarks/primary')
    original_report = json.loads(gzip.decompress((root / 'S6-240m-new-0.52-r1.json.gz').read_bytes()))
    compressed = root / 'artifacts/S6-240m-new-0.52-r1' / OLD_H / 'reference.json.gz'
    original_bytes = gzip.decompress(compressed.read_bytes())
    directory = Path('/work/old-s6-transport') / OLD_H
    directory.mkdir(parents=True, exist_ok=True)
    destination = directory / 'reference.json'
    if destination.exists():
        assert destination.read_bytes() == original_bytes
    else:
        destination.write_bytes(original_bytes)
    final = Path('/work/corrected-final/S6-corrected-baseline.json.gz')
    fresh_report = json.loads(gzip.decompress(final.read_bytes()))
    cases = [('historical_unchanged_transport', destination, OLD_H, OLD_C, original_report),
             ('new_process_corrected_reference', Path(fresh_report['artifact_path']),
              fresh_report['H'], fresh_report['expected_curve_digest'], fresh_report)]
    output = []
    for name, path, expected_h, expected_c, report in cases:
        before = hashlib.sha256(path.read_bytes()).hexdigest()
        start = time.perf_counter()
        try:
            reference = load_reference(path, expected_H=expected_h,
                                       validation_context=ValidationContext())
        except ArtifactError as exc:
            # The frozen primary predates changes to source-hashed A07 modules.
            # Exact H/C cannot authorize a different implementation identity.
            if name != 'historical_unchanged_transport':
                raise
            assert exc.status == 'UNSUPPORTED'
            assert str(exc) == 'unsupported or changed kernel/checker/dependency identity'
            output.append({'case': name, 'H': expected_h, 'C': expected_c,
                           'status': 'UNSUPPORTED_IMPLEMENTATION_VERSION',
                           'reference_sha256': before, 'reason': str(exc),
                           'scope': 'Old primary producer0c2d7c3 source hashes differ. '
                                    'This is expected version rejection, not same-version '
                                    'numerical portability evidence.'})
            continue
        elapsed = time.perf_counter() - start
        assert reference.H == expected_h and reference.profile.curve_digest == expected_c
        assert reference.geometry_report.status == reference.dynamics_report.status == 'PASS'
        assert same_numbers(reference.ordered.curve.coefficients, report['coefficients'])
        assert same_numbers(reference.ordered.q, report['q'])
        producer = report['dynamics']['lap_time_s']
        assert same_numbers(reference.lap_time_s, producer)
        assert reference.dynamics_report.lap_time_lower_s <= producer <= reference.dynamics_report.lap_time_upper_s
        errors = query_oracle(reference, report)
        after = hashlib.sha256(path.read_bytes()).hexdigest()
        assert before == after
        output.append({'case': name, 'H': expected_h, 'C': expected_c, 'reference_sha256': before,
                       'wall_seconds': elapsed, 'producer_main_time_s': reference.lap_time_s,
                       'fresh_nominal_time_s': reference.dynamics_report.lap_time_s,
                       'fresh_time_enclosure_s': [reference.dynamics_report.lap_time_lower_s,
                                                  reference.dynamics_report.lap_time_upper_s],
                       'geometry_report_identical': same_report(reference.geometry_report, report['geometry']),
                       'dynamics_report_identical': same_report(reference.dynamics_report, report['dynamics']),
                       'authority_binary64_unchanged': True, 'query_oracle': errors})
    result = Path('/work/saved-s6-replay.json')
    result.write_text(json.dumps(output, indent=2, sort_keys=True) + '\n')
    print(json.dumps(output, indent=2))


if __name__ == '__main__':
    main()
