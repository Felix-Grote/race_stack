"""Freeze independent S6 sensitivity inputs before any numerical attempt."""
import copy
import hashlib
import json
from pathlib import Path

from global_planner.route_input import validate_route

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent / 's6-probes'
OUT.mkdir(exist_ok=True)
(OUT / 'inputs').mkdir(exist_ok=True)
original = ROOT / 'docs/project_a/evidence/w3-benchmarks/primary'
base = json.loads((original / 'inputs/S6-240m.json').read_bytes())
primary = json.loads((original / 'manifest.json').read_bytes())
policy = copy.deepcopy(primary['jobs'][0]['solver_policy'])
policy['spacing_m'] = .52
variants = [('baseline', .52, copy.deepcopy(base)),
            ('mesh-0.519', .519, copy.deepcopy(base)),
            ('mesh-0.521', .521, copy.deepcopy(base)),
            ('mesh-0.525', .525, copy.deepcopy(base))]
p = copy.deepcopy(base)
p['occurrences'] = p['occurrences'][1:] + p['occurrences'][:1]
p['transitions'] = p['transitions'][1:] + p['transitions'][:1]
p['gate_sequence'] = p['gate_sequence'][1:] + p['gate_sequence'][:1]
p['finish'] = p['gate_sequence'][-1]
p['initialization']['occurrence_id'] = p['occurrences'][0]['id']
p['initialization']['zone'] = copy.deepcopy(p['transitions'][-1]['support'])
variants.append(('origin-quarter-lap', .52, p))
for factor in (.995, 1.005):
    p = copy.deepcopy(base)
    for occurrence in p['occurrences']:
        for side in ('seed', 'left', 'right'):
            occurrence[side] = [[factor * x, factor * y] for x, y in occurrence[side]]
        for cap in occurrence['caps']:
            cap['at_m'] *= factor
    for portal in p['transitions']:
        for key in ('gate', 'support'):
            portal[key] = [[factor * x, factor * y] for x, y in portal[key]]
        portal['before_m'] *= factor
        portal['after_m'] *= factor
    p['initialization']['zone'] = [[factor * x, factor * y]
                                   for x, y in p['initialization']['zone']]
    p['initialization']['seed_interval_m'] = [factor * x for x in
                                             p['initialization']['seed_interval_m']]
    variants.append((f'scale-{factor}', .52, p))
for mode in ('half', 'double'):
    p = copy.deepcopy(base)
    for occurrence in p['occurrences']:
        seed = occurrence['seed']
        if mode == 'half':
            occurrence['seed'] = seed[::2]
        else:
            occurrence['seed'] = [point for a, b in zip(seed, seed[1:])
                                  for point in (a, [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2])]
            occurrence['seed'].append(seed[-1])
    variants.append(('seed-' + mode, .52, p))
jobs = []
for name, spacing, payload in variants:
    route = validate_route(payload)
    route_file = OUT / 'inputs' / (name + '.json')
    route_file.write_bytes(route.encoded)
    current_policy = {**policy, 'spacing_m': spacing}
    jobs.append({'id': name, 'scenario': 'S6-independent', 'variant': 'new', 'repeat': 1,
                 'route': '/work/s6-probes/inputs/' + route_file.name,
                 'solver_policy': current_policy, 'output': '/work/s6-probes',
                 'artifacts': name == 'baseline', 'export_ros': name == 'baseline',
                 'route_sha256': route.digest})
manifest = {'initial_sha': '17e4ec4e8fedfa736467d02f6204b04e8552decb',
            'jobs': jobs, 'bounds': primary['outer_policy_predeclared'],
            'source_hashes': {str(file.relative_to(ROOT)): hashlib.sha256(file.read_bytes()).hexdigest()
                              for file in [ROOT / 'scripts/project_a/benchmark_w3.py',
                                           ROOT / 'scripts/project_a/w3_benchmark_support.py',
                                           ROOT / 'planner/global_planner/global_planner/iqp_route_adapter.py']},
            'interpretation': 'All attempts retained. Geometric scale also scales legal borders; '
                              'seed variants preserve original legal borders. Mesh policies vary '
                              'spacing only. Same proof/resource/body/model settings. '
                              'Only baseline is timed as isolated if possible; others descriptive.'}
(OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
for job in jobs:
    (OUT / (job['id'] + '.job.json')).write_text(json.dumps(job, sort_keys=True) + '\n')
print(json.dumps({'jobs': len(jobs), 'manifest_sha256': hashlib.sha256(
    (OUT / 'manifest.json').read_bytes()).hexdigest()}))
