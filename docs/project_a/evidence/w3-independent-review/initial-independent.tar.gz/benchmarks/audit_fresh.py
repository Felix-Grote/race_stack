"""Apply independent mathematical checks to every fresh completed PASS report."""
import collections
import gzip
import json
from pathlib import Path

from audit_saved import composition_check, metric_report


def main():
    root = Path(__file__).resolve().parent
    summaries, metrics, composition = [], [], []
    for name in ('s6-controls', 's6-probes-retry1', 's6-followup', 'corrected-final'):
        directory = root / name
        ledger = [json.loads(row) for row in (directory / 'attempts.jsonl').read_text().splitlines()]
        for row in ledger:
            report = json.loads(gzip.decompress((directory / (row['id'] + '.json.gz')).read_bytes()))
            assert row['status'] == report['status']
            summary = {key: report.get(key) for key in
                       ('id', 'status', 'reason', 'iterations', 'segments', 'length_m',
                        'curvature_energy_initial_per_m', 'curvature_energy_final_per_m',
                        'lap_time_s', 'qp_condition_max', 'qp_peak_rss_bytes', 'geometry_leaves',
                        'retime_edges', 'dynamic_bound_intervals', 'H', 'expected_curve_digest')}
            summary.update(external_wall_s=row['external_wall_s'],
                           external_child_cpu_s=row['external_child_cpu_s'], campaign=name)
            failed = [phase['failed_input_matrix_condition'] for phase in report['phases']
                      if 'failed_input_matrix_condition' in phase]
            if failed:
                summary['failed_input_matrix_condition'] = failed[-1]
            summaries.append(summary)
            if report['status'] == 'PASS':
                checked = metric_report(report)
                checked['campaign'] = name
                metrics.append(checked)
                if report['variant'] == 'repaired':
                    composition.append(composition_check(report))
    output = {'completed_report_count': len(summaries),
              'statuses': dict(collections.Counter(row['status'] for row in summaries)),
              'oracled_pass_count': len(metrics), 'rows': summaries, 'metrics': metrics,
              'rational_composition': composition,
              'note': 'Initial disk-failed S6 attempt and direct failing-first legacy worker '
                      'are preserved separately and excluded from this completed-ledger count.'}
    (root / 'fresh-audit.json').write_text(json.dumps(output, indent=2, sort_keys=True) + '\n')
    print(json.dumps({key: value for key, value in output.items()
                      if key not in ('rows', 'metrics', 'rational_composition')}, indent=2))


if __name__ == '__main__':
    main()
