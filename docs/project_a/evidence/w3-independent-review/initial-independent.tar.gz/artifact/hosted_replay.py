"""Replay independently authenticated exact-head hosted products on this host."""
from dataclasses import asdict
import json
import math
from pathlib import Path
import random
import struct
import time

from global_planner.route_artifact import ValidationContext, canonical_bytes, load_reference

root = Path(__file__).resolve().parent
catalog = json.loads((root/'controlled-hosted-catalog.json').read_text())
records = []
for item in catalog:
    path = root/'hosted'/item['case']/'reference.json'
    before = path.read_bytes()
    payload = json.loads(before)['payload']
    began = time.monotonic()
    ref = load_reference(path, expected_H=item['H'], validation_context=ValidationContext())
    assert path.read_bytes() == before
    assert ref.H == item['H']
    assert ref.payload['approved_curve_digest'] == item['curve_digest']
    assert canonical_bytes(ref.ordered.curve.coefficients) == canonical_bytes(payload['curve']['coefficients'])
    assert canonical_bytes(ref.ordered.q) == canonical_bytes(payload['curve']['q'])
    assert canonical_bytes(asdict(ref.model)) == canonical_bytes(payload['model'])
    assert canonical_bytes(asdict(ref.profile)) == canonical_bytes(payload['speed_profile'])
    assert canonical_bytes(asdict(ref.policies)) == canonical_bytes(payload['policies'])
    assert struct.pack('>d',ref.lap_time_s) == struct.pack('>d',payload['validation']['dynamics']['lap_time_s'])
    historical = payload['validation']['dynamics']
    assert historical['lap_time_lower_s'] <= ref.lap_time_s <= historical['lap_time_upper_s']
    assert ref.dynamics_report.lap_time_lower_s <= ref.lap_time_s <= ref.dynamics_report.lap_time_upper_s
    assert ref._times[-1] == ref.dynamics_report.lap_time_s
    rng = random.Random(20261017)
    for index in sorted(set([0,len(ref.profile.knots)-1]+[rng.randrange(len(ref.profile.knots)) for _ in range(20)])):
        knot = ref.profile.knots[index]
        sample = ref.sample(ref._stations[index])
        assert sample.speed_mps == math.sqrt(knot.u)
        assert sample.time_s == ref._times[index]
        follow = ref.profile.knots[(index+1)%len(ref.profile.knots)]
        assert sample.acceleration_mps2 == (follow.u-knot.u)/(2*ref._edge_lengths[index])
    records.append(dict(case=item['case'],H=ref.H,C=item['curve_digest'],
                        geometry=ref.geometry_report.status,dynamics=ref.dynamics_report.status,
                        main_time_s=ref.lap_time_s,replay_nominal_s=ref.dynamics_report.lap_time_s,
                        historical_dynamics_differ=canonical_bytes(asdict(ref.dynamics_report)) != canonical_bytes(historical),
                        numerical_query_prefix_total=ref._times[-1],wall_seconds=time.monotonic()-began))
    print(json.dumps(records[-1]), flush=True)
(root/'hosted-replay-summary.json').write_text(json.dumps(records,indent=2)+'\n')
