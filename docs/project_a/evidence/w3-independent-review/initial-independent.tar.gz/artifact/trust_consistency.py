"""Independent bounded consistency regressions using a controlled hosted product."""
import copy
from dataclasses import asdict
import json
from pathlib import Path
import tempfile

from global_planner import route_artifact as a

root=Path(__file__).resolve().parent
entry=json.loads((root/'controlled-hosted-catalog.json').read_text())[0]
original=json.loads((root/'hosted'/entry['case']/'reference.json').read_bytes())['payload']
context=a.ValidationContext()
records=[]

def check(kind, change, original_trust=True):
    payload=copy.deepcopy(original)
    change(payload)
    incoming=a.artifact_identity(payload)
    expectation=entry['H'] if original_trust else incoming
    with tempfile.TemporaryDirectory() as directory:
        path=Path(directory)/'reference.json'
        path.write_bytes(a.canonical_bytes({'schema_version':1,'H':incoming,'payload':payload}))
        try:
            a.load_reference(path,expected_H=expectation,validation_context=context)
        except a.ArtifactError as exc:
            records.append(dict(case=kind,trust='original_H' if original_trust else 'independently_selected_new_H',status=exc.status,reason=exc.reason))
        else:
            raise AssertionError('expected rejection of '+kind)

changes={
 'coefficient':lambda p:p['curve']['coefficients'][0][0].__setitem__(0,p['curve']['coefficients'][0][0][0]+0.01),
 'q':lambda p:p['curve']['q'].__setitem__(1,p['curve']['q'][1]+0.0001),
 'owner':lambda p:p['curve']['owners'][0].__setitem__(1,'incorrect_surface'),
 'cap':lambda p:p['approved_route']['occurrences'][0]['caps'][0].__setitem__('max_speed_mps',0.01),
 'profile':lambda p:p['speed_profile']['knots'][0].__setitem__('u',10000.),
 'model':lambda p:p['model']['regions'][0]['limits'].__setitem__('speed_max_mps',0.01),
 'footprint':lambda p:p['footprint'].__setitem__('front_m',10.),
 'margin':lambda p:p['footprint'].__setitem__('margin_m',10.),
 'policy':lambda p:p['policies']['geometry'].__setitem__('max_curvature',2.),
 'implementation':lambda p:p['implementation']['module_sha256'].__setitem__('route_validate','0'*64),
 'historical_status':lambda p:p['validation']['geometry'].__setitem__('status','FAIL'),
 'historical_coverage':lambda p:p['validation']['geometry']['coverage'].append('physical_race_approval'),
}
for kind,change in changes.items():
    check(kind,change)
for kind in ('coefficient','q','owner','cap','profile','footprint','margin','policy','implementation','historical_status','historical_coverage'):
    check(kind,changes[kind],False)
(root/'trust-consistency-summary.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps(records,indent=2))
