"""Independent bounded parser/numeric probes; no implementation monkeypatches."""
import argparse
import hashlib
import json
import math
import random
import resource
import struct
import time

from global_planner import route_artifact as a

p = argparse.ArgumentParser()
p.add_argument('--stress', choices=('bytes', 'nodes', 'excess_nodes'))
args = p.parse_args()
start = time.monotonic()
if args.stress:
    if args.stress == 'bytes':
        # Reach the exact encoded file budget with legal short strings and whitespace.
        raw = b'{"x":0}' + b' ' * (a.MAX_ARTIFACT_BYTES - 7)
        expected = 'accept'
    else:
        count = a.MAX_JSON_NODES - 3 + (args.stress == 'excess_nodes')
        raw = b'{"x":[' + b','.join([b'12345678901234567890123456789012'] * count) + b']}'
        expected = 'reject' if args.stress == 'excess_nodes' else 'accept'
    try:
        value = a._parse_json(raw)
        outcome = 'accept'
        reason = None
        assert expected == outcome
        if args.stress == 'nodes':
            assert len(value['x']) == count
    except a.ArtifactError as exc:
        outcome, reason = 'reject', exc.reason
        assert expected == outcome
    print(json.dumps({'case': args.stress, 'raw_bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
                      'outcome': outcome, 'reason': reason, 'wall_seconds': time.monotonic()-start,
                      'peak_rss_bytes': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024}))
else:
    # Exact binary64 bit preservation, including negative zero and subnormal boundaries.
    fixed = [0.0, -0.0, float.fromhex('0x0.0000000000001p-1022'),
             float.fromhex('0x0.fffffffffffffp-1022'), float.fromhex('0x1p-1022'),
             float.fromhex('0x1.fffffffffffffp+1023'), math.nextafter(1.0, 0.0),
             1.0, math.nextafter(1.0, math.inf)]
    rng = random.Random(20261017)
    values = fixed[:]
    while len(values) < 10009:
        value = struct.unpack('>d', rng.randbytes(8))[0]
        if math.isfinite(value):
            values.append(value)
    encoded = a.canonical_bytes({'values': values, 'integer': 1, 'boolean': True})
    decoded = a._parse_json(encoded)
    assert all(struct.pack('>d', x) == struct.pack('>d', y)
               for x, y in zip(values, decoded['values']))
    assert type(decoded['integer']) is int and type(decoded['boolean']) is bool
    malformed = {
        'nested_duplicate': b'{"a":{"b":1,"b":2}}',
        'escaped_duplicate': b'{"a":1,"\\u0061":2}',
        'nan': b'{"a":NaN}', 'inf': b'{"a":Infinity}',
        'magnitude': b'{"a":1e999}', 'utf8': b'{"a":"\xc0\x80"}',
        'utf8_surrogate': b'{"a":"\xed\xa0\x80"}', 'escaped_surrogate': b'{"a":"\\ud800"}',
        'truncated': b'{"a":[1,2', 'depth': b'{"a":'+b'['*33+b']'*33+b'}',
        'integer_bits': b'{"a":'+str(2**1024).encode()+b'}',
        'long_text': json.dumps({'a': '\u00e9' * 32769}, ensure_ascii=False).encode(),
    }
    rejected = {}
    for name, raw in malformed.items():
        try:
            a._parse_json(raw)
        except a.ArtifactError as exc:
            rejected[name] = exc.reason
        else:
            raise AssertionError('accepted malformed input '+name)
    print(json.dumps({'finite_binary64_exact_roundtrips': len(values),
                      'canonical_sha256': hashlib.sha256(encoded).hexdigest(),
                      'malformed_rejections': rejected, 'wall_seconds': time.monotonic()-start,
                      'peak_rss_bytes': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024}, sort_keys=True))
