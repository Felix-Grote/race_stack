"""Independently authenticate catalog-selected hosted references, without loader."""
import hashlib
import json
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parent
bundle = root / 'original-push-artifact.zip'
assert hashlib.sha256(bundle.read_bytes()).hexdigest() == '5ba01962bd2cd39ce8f9742d3a2464d1f5d086cd42ad06448c6bf5bb7fe4a180'
catalog = json.loads((root / 'controlled-hosted-catalog.json').read_text())
records = []
with zipfile.ZipFile(bundle) as archive:
    for entry in catalog:
        raw = archive.read('source-free/results/' + entry['relative_artifact'])
        envelope = json.loads(raw)
        payload = envelope['payload']
        encoded = json.dumps(payload, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode('utf-8')
        assert hashlib.sha256(encoded).hexdigest() == envelope['H'] == entry['H']
        assert payload['approved_curve_digest'] == entry['curve_digest']
        sources = {}
        for name, digest in payload['implementation']['module_sha256'].items():
            source = Path('planner/global_planner/global_planner') / (name+'.py')
            assert hashlib.sha256(source.read_bytes()).hexdigest() == digest
            sources[name] = digest
        directory = root / 'hosted' / entry['case']
        directory.mkdir(parents=True, exist_ok=True)
        (directory/'reference.json').write_bytes(raw)
        records.append(dict(entry, raw_bytes=len(raw), raw_sha256=hashlib.sha256(raw).hexdigest(),
                            main_time_s=payload['validation']['dynamics']['lap_time_s'],
                            coefficients=len(payload['curve']['coefficients']),
                            knots=len(payload['speed_profile']['knots']), source_hashes_verified=len(sources)))
print(json.dumps({'zip_sha256':hashlib.sha256(bundle.read_bytes()).hexdigest(), 'verified':records}, indent=2))
