"""Failing-first Linux publication adversary; production proofs run unchanged.

Run in pinned project-a-humble:w0 with the checkout available at /src, for
example using /opt/project-a/bin/python. No geometry or trust checks are mocked.
The hook models the deterministic scheduler boundary before renameat2. Attacker
operations are ordinary Linux rename/mkdir/open operations against an output
directory which the API currently permits to be mode 0777.
"""
from pathlib import Path
import json
import os
import sys
import tempfile

sys.path.insert(0, str(Path(__file__).resolve().parents[3] / 'planner/global_planner/test'))
sys.path.insert(0, str(Path(__file__).resolve().parents[3] / 'planner/global_planner'))
from test_route_artifact import inputs
import global_planner.route_artifact as artifact
from global_planner.cyclic_retime import curve_digest


def main():
    payload, context, ordered, _, _ = inputs()
    trusted_h = artifact.artifact_identity(payload)
    trusted_c = curve_digest(ordered)
    output = Path(tempfile.mkdtemp(prefix='w3-publication-attack-'))
    output.chmod(0o777)
    real_rename = artifact._rename_noreplace

    def substitute(source, target, parent):
        # A different uid with write/execute on the non-sticky parent can make
        # these same entry operations without opening the private stage itself.
        os.rename(source, '.attacker-moved-validated-stage', src_dir_fd=parent,
                  dst_dir_fd=parent)
        os.mkdir(source, 0o755, dir_fd=parent)
        replacement = os.open(source, os.O_RDONLY | os.O_DIRECTORY, dir_fd=parent)
        try:
            file_fd = os.open('reference.json', os.O_CREAT | os.O_WRONLY, 0o644,
                              dir_fd=replacement)
            try:
                os.write(file_fd, b'{"attacker":"not an artifact"}')
            finally:
                os.close(file_fd)
        finally:
            os.close(replacement)
        return real_rename(source, target, parent)

    artifact._rename_noreplace = substitute
    reference = artifact.publish_reference(
        payload, output, expected_H=trusted_h, expected_curve_digest=trusted_c,
        validation_context=context)
    artifact._rename_noreplace = real_rename
    result = {'publisher_returned_success': True, 'H': trusted_h, 'C': trusted_c,
              'reference_path': str(reference.path),
              'published_bytes': reference.path.read_text(),
              'output_mode': oct(output.stat().st_mode & 0o777)}
    try:
        artifact.load_reference(reference.path, expected_H=trusted_h,
                                validation_context=context)
    except artifact.ArtifactError as exc:
        result['fresh_load'] = {'status': 'REJECT', 'reason': str(exc)}
    else:
        result['fresh_load'] = {'status': 'PASS'}
    print(json.dumps(result, indent=2))
    assert result['fresh_load']['status'] == 'REJECT', result


if __name__ == '__main__':
    main()
