#!/usr/bin/env python3
"""Verify retained final-evidence bytes and archive ledgers without extracting."""
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import subprocess
import tarfile
import zipfile

REF = 'origin/w3-evidence-17e4ec4'
PREFIX = 'docs/project_a/evidence/w3-final-verification/'
OUT = Path(__file__).resolve().parent


def read(path):
    return subprocess.check_output(['git', 'show', REF + ':' + PREFIX + path])


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


ledger = json.loads(read('files-sha256.json'))
failures = []
for path, expected in ledger['files'].items():
    actual = digest(read(path))
    if actual != expected:
        failures.append({'path': path, 'expected': expected, 'actual': actual})

publication = json.loads(read('publication-index.json'))
for path, record in publication['files'].items():
    raw = read(path)
    if len(raw) != record['bytes'] or digest(raw) != record['sha256']:
        failures.append({'path': path, 'error': 'publication receipt mismatch'})

archive_results = {}
for name in ('fresh-17e4ec4e.tar.gz', 'portability-17e4ec4e.tar.gz',
             'benchmarks/final-functional-17e4ec4e.tar.gz'):
    with tarfile.open(fileobj=io.BytesIO(read(name)), mode='r:gz') as archive:
        members = {}
        special = []
        directories = 0
        for member in archive.getmembers():
            path = PurePosixPath(member.name)
            if member.isdir():
                directories += 1
            if path.is_absolute() or '..' in path.parts or not (member.isfile() or member.isdir()):
                special.append({'path': member.name, 'kind': member.type.decode()})
            if member.isfile():
                if member.name in members:
                    failures.append({'archive': name, 'duplicate_member': member.name})
                raw = archive.extractfile(member).read()
                members[member.name] = {'bytes': len(raw), 'sha256': digest(raw), 'raw': raw}
        result = {'files': len(members), 'raw_bytes': sum(m['bytes'] for m in members.values()),
                  'unsafe_or_special_members': special, 'directory_members': directories,
                  'checks': 0,
                  'failures': []}
        if name.startswith('fresh-'):
            expected_members = json.loads(read('fresh-archive.json'))['members']
            for path, expected in expected_members.items():
                result['checks'] += 1
                actual = members.get(path)
                if actual is None or any(actual[k] != expected[k] for k in ('bytes', 'sha256')):
                    result['failures'].append({'path': path, 'error': 'member ledger mismatch'})
            result['unlisted_members'] = sorted(set(members) - set(expected_members))
        else:
            checksum_paths = [p for p in members if p.endswith('SHA256SUMS') or
                              p.endswith('files-sha256.json') or p.endswith('/files.json')]
            result['internal_ledgers'] = checksum_paths
            for ledger_path in checksum_paths:
                if ledger_path.endswith('SHA256SUMS'):
                    entries = dict((line.split(maxsplit=1)[1].lstrip('*'), line.split()[0])
                                   for line in members[ledger_path]['raw'].decode().splitlines()
                                   if line.strip())
                else:
                    entries = json.loads(members[ledger_path]['raw'])
                    if isinstance(entries, dict):
                        entries = entries.get('files', entries)
                    if not isinstance(entries, dict):
                        continue
                parent = PurePosixPath(ledger_path).parent
                for path, expected in entries.items():
                    if isinstance(expected, dict):
                        expected = expected.get('sha256')
                    if not isinstance(expected, str):
                        continue
                    path = str(parent / path)
                    result['checks'] += 1
                    if path not in members or members[path]['sha256'] != expected:
                        result['failures'].append({'path': path, 'error': 'checksum mismatch'})
        archive_results[name] = result

raw_zip = read('ci/original-push-artifact.zip')
with zipfile.ZipFile(io.BytesIO(raw_zip)) as archive:
    bad = archive.testzip()
    zip_result = {'sha256': digest(raw_zip), 'bytes': len(raw_zip),
                  'members': len(archive.infolist()), 'bad_crc_member': bad,
                  'uncompressed_bytes': sum(m.file_size for m in archive.infolist())}
result = {'companion_sha': subprocess.check_output(['git', 'rev-parse', REF], text=True).strip(),
          'implementation_sha': ledger['implementation_sha'], 'outer_ledger_checks': len(ledger['files']),
          'publication_checks': len(publication['files']), 'failures': failures,
          'archives': archive_results, 'hosted_zip': zip_result}
(OUT / 'companion-integrity-audit.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
