# Independent W3 repository/evidence audit

The review read exact Git objects at initial W3
`17e4ec4e8fedfa736467d02f6204b04e8552decb`, against accepted W2 merge
`9fae5faed6ca62e0c943b6290babc50638477d9b`. The separate evidence branch resolves
to `326aa3783ac2d757b6e714eadd14fdba96f595fd`. No evidence or implementation
file was removed, rewritten, committed or published by this audit.

Reproduction from the repository root:

```
python work/independent-review/hygiene/audit.py
python work/independent-review/hygiene/companion_audit.py
```

The machine-readable outputs preserve definitions, module/test paths, largest
files, exact duplicate groups, manifest coverage and archive verification.
Gitlinks are excluded from blob counts. LOC is physical file lines, including
comments/docstrings; Git diff additions use `git diff --numstat` and its binary
classification. These two definitions are explicit, rather than equating PR
line totals with code complexity.

| W2→initial W3 category | Files changed | Tracked bytes at W3 | Added/deleted lines |
| --- | ---: | ---: | ---: |
| New production Python modules | 3 | 83,008 | +1,685 / −0 |
| Test Python | 7 | 132,156 | +2,595 / −0 |
| Verification/benchmark harness | 11 | 86,802 | +1,451 / −43 |
| Installed fixture/model/policy inputs | 22 | 349,800 | +14,311 / −0 |
| Documentation outside evidence | 8 | 186,052 | +1,317 / −1 |
| Other integration | 4 | 9,978 | +116 / −3 |
| Evidence | 1,771 | 119,063,375 | +695,389 / −0 |
| Total | 1,826 | 119,911,171 | +716,864 / −47 |

Evidence accounts for 97.00% of added diff lines and 96.99% of changed files.
The three production files are `route_artifact.py` (1,006 LOC),
`route_compile.py` (382 LOC), and `route_legacy_export.py` (297 LOC), collectively
1,516 nonblank lines. All eleven Project A production modules at initial W3,
including inherited W0–W2 modules, total 5,389 LOC / 4,794 nonblank lines /
257,153 bytes. All thirty planner/harness Python test files total 6,620 LOC /
5,815 nonblank lines / 329,379 bytes; seven W3 additions account for 2,595 LOC.
The full production/test path lists are in `git-size-audit.json`.

W2 already retained 583 evidence files / 30,259,017 bytes. Initial W3 retains
2,354 / 149,322,392 bytes. The companion adds thirty files / 47,128,222 bytes;
its archive structure is substantially more compact than A09's loose outputs.

## Integrity and provenance results

All six W3 checksum ledgers match their exact tracked bytes, without any missing
entry or hash mismatch: A07 11 entries, A07-CI 11, baseline 59, benchmarks 966,
A09 530, portability 186. Of 1,771 new evidence files, 1,763 are covered by
these explicit ledgers. The eight exclusions are six ledger files themselves
and the two A09 publication receipt/documentation files; Git binds these bytes.
No uncovered numerical output or failed-run result was found.

The companion outer ledger verifies all 29 listed files, and its six explicit
publication records match archive byte sizes and SHA256. Reading compressed
archives without extraction verifies:

| Bundle | Regular files | Uncompressed bytes | Per-member checks | Failures |
| --- | ---: | ---: | ---: | ---: |
| Final fresh | 405 | 49,450,565 | 405 | 0 |
| Final portability | 64 | 10,804,387 | 63 (ledger excludes itself) | 0 |
| Final benchmark | 1,056 | 72,500,481 | 1,055 (ledger excludes itself) | 0 |

No archive symlink, hardlink, absolute path, traversal component, duplicate
regular filename or unexpected special file was observed. The benchmark archive
also contains 247 ordinary directory entries. Original hosted push artifact
`12067848728` is 9,327,825 bytes, SHA256
`5ba01962bd2cd39ce8f9742d3a2464d1f5d086cd42ad06448c6bf5bb7fe4a180`;
all 295 ZIP members pass CRC. Its retained run metadata identifies the requested
literal SHA and push CI `38945204845`, with success. These checks establish
integrity/provenance of the retained evidence; they do not independently repeat
the mathematical or installed-runtime acceptance checks.

The technical docs consistently distinguish raw and algebraically adapted legacy
geometry, exclude development probes from final acceptance/performance claims,
retain failed attempts, and explicitly reserve independent W3 acceptance and
physical vehicle approval. The benchmark reproduction guide's `files.json`
description means the per-run `primary/files.json`, `matched-coarse/files.json`,
etc.; there is no top-level file by that name. This is an optional clarity fix.

## Evidence disposition

**P3 maintainability finding:** evidence retention is justified; its loose-tree
representation is excessive for production review. `w3-a09` alone contributes
531 files / 62,233,617 bytes / 651,248 decoded text lines. Two generated numerical
files contain 422,952 lines (59.00% of all W3 added lines):

| File | Original bytes | Lines | Deterministic gzip estimate |
| --- | ---: | ---: | ---: |
| `w3-a09/verification/w2-pipeline.json` | 7,465,624 | 251,743 | 1,224,721 bytes |
| `w3-a09/verification/a04-candidates.json` | 4,514,153 | 171,209 | 879,499 bytes |

Byte-identical duplicate groups account for 12,495,943 redundant *working-tree*
bytes across W3 evidence. Git already stores identical blobs once; this figure
must not be described as guaranteed Git pack savings. It also omits near-equal
copies such as compile receipts repeated in stdout with a trailing newline and
original ZIP members also extracted as loose files.

Retain version-controlled production code, tests, route/model/policy fixtures,
source-hashed legacy repair/oracle source, execution protocols, exact source and
dependency identities, trusted artifact H/C catalogs, compact summaries,
red/green reproducers and file ledgers. Preserve raw results, failures, full proof
reports, full histories, CI logs, full installed products and lossy exports in
checksummed archives. Full histories are necessary to challenge certificate and
quality claims, but need not be 422,952 review-visible JSON lines.

A bounded first correction can losslessly gzip the two largest JSONs, preserve
raw SHA256/size and original names in a compact map, record stored SHA256/size,
and supply exact decompression instructions. Verify decompression hashes against
the original Git blobs before removal and update the containing integrity
ledger. This reduces checkout bulk/review line count while preserving the only
important numerical bytes; no acceptance runner consumes those historical
paths. A full A09 tar archive plus the original index/README and per-file manifest
is also reasonable, but is a larger structural correction.

For durable downloadable archives, publish the original bytes to a maintained
release/object store, verify download independently, and then retain immutable
download URLs, SHA256/size, member inventories, implementation SHA, trust catalogs,
reproduction commands and retention ownership in Git before replacing raw files.
GitHub Actions artifacts alone expire (the retained final artifact expires
2027-01-14), so they are not adequate sole archival storage. The companion branch
currently provides a Git-retained copy; deleting implementation evidence merely
because related final evidence exists would lose historical experiments.

Compression/removal in later commits does not eliminate already committed Git
history. If main-branch clone size is a release concern, perform a later supervised
integration: preserve/tag the reviewed branch and full archives, prepare a clean
integration branch at accepted W2 containing final source/tests/docs and compact
manifests, retain downloadable archive copies, replay acceptance on its exact SHA,
and integrate by an explicitly approved squash or replacement PR. Do not rewrite
or force-push this reviewed branch.
