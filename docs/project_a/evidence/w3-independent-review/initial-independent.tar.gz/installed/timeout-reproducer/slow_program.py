#!/usr/bin/env python3
import time,sys
print("partial stdout",flush=True)
print("partial stderr",file=sys.stderr,flush=True)
time.sleep(10)
