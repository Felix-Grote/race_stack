"""Run the real installed-test helper against a bounded slow process."""
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

helper, destination = map(Path, sys.argv[1:])
destination.mkdir(exist_ok=False)
spec = importlib.util.spec_from_file_location('reviewed_installed_helper', helper)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
program = destination / 'slow_program.py'
program.write_text('#!/usr/bin/env python3\nimport time,sys\n'
                   'print("partial stdout",flush=True)\n'
                   'print("partial stderr",file=sys.stderr,flush=True)\n'
                   'time.sleep(10)\n')
program.chmod(0o755)
real_run = subprocess.run
module.subprocess.run = lambda *args, **kwargs: real_run(
    *args, **{**kwargs, 'timeout': .25})
state = {'executable': program, 'output': destination, 'commands': []}
try:
    module._invoke(state, 'probe', ('validate',))
except subprocess.TimeoutExpired as error:
    outcome = {
        'helper': str(helper), 'timeout_s': error.timeout,
        'captured_stdout': (error.stdout or b'').decode(),
        'captured_stderr': (error.stderr or b'').decode(),
        'retained_stdout': (destination / 'probe.stdout.txt').exists(),
        'retained_stderr': (destination / 'probe.stderr.txt').exists(),
        'retained_timeout_report': (destination / 'probe.timeout.json').exists(),
        'retained_command_count': len(state['commands']),
        'instrumentation': 'Only subprocess timeout is shortened; real helper and process execute.',
    }
    (destination / 'outcome.json').write_text(json.dumps(outcome, indent=2) + '\n')
    print(json.dumps(outcome, indent=2))
else:
    raise AssertionError('Expected a real subprocess timeout')
