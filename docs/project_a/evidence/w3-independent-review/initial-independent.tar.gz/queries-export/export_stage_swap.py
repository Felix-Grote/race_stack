"""Fault injection proving export rename can publish a substituted stage."""
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace

from global_planner import route_artifact, route_legacy_export as export

# Bypass numerical projection ONLY; test the production filesystem transaction.
# A valid accepted reference cannot affect the later name/descriptor race.
view = SimpleNamespace(H='1' * 64, length_m=40., lap_time_s=20.,
                       legacy_lap_time_float32_s=20., waypoints=(None,))
export.waypoint_view = lambda reference, step_m: view

def checked_product(view, stage):
    (stage / 'global_waypoints.json').write_text('{"validated":"original"}')
export._write_ros_product = checked_product
actual_rename = route_artifact._rename_noreplace

with tempfile.TemporaryDirectory() as temporary:
    parent = Path(temporary)
    target = parent / 'accepted-export'
    def swap_then_rename(source, destination, parent_fd):
        stage = parent / source
        stage.rename(parent / 'displaced-original-stage')
        stage.mkdir()
        (stage / 'global_waypoints.json').write_text('{"corrupted":"not validated"}')
        actual_rename(source, destination, parent_fd)
    route_artifact._rename_noreplace = swap_then_rename
    receipt = export.export_waypoints(object(), step_m=1., output_dir=target)
    actual = (target / 'global_waypoints.json').read_text()
    print(json.dumps({'source_sha':'17e4ec4e8fedfa736467d02f6204b04e8552decb',
                      'receipt_status':receipt.status, 'published':actual,
                      'missing_receipt':not (target/'export.json').exists(),
                      'original_verified_bytes':(parent/'displaced-original-stage'/'global_waypoints.json').read_text()}))
