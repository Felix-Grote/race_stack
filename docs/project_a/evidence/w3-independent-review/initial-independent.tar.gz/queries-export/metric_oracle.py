"""Independent 60-digit query oracle; direct valid authorities, no artifact bypass claim."""
from bisect import bisect_right
from dataclasses import asdict
import copy
from fractions import Fraction
import gzip
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import sys

import mpmath as mp

from global_planner.cyclic_retime import (
    DynamicsModel, ModelRegion, RegionLimits, RetimePolicy, SpeedKnot, SpeedProfile,
    curve_digest, model_digest)
from global_planner.iqp_route_adapter import SolverPolicy
from global_planner.route_artifact import PolicySet, _reference
from global_planner.route_corridor import OrderedCurve, _layout
from global_planner.route_input import load_route, validate_route
from global_planner.route_legacy_export import waypoint_view
from global_planner.route_reference import Curve, NumericPolicy
from global_planner.route_validate import Footprint, GeometryValidationPolicy, validate_geometry
from global_planner.route_validate_dynamics import DynamicsValidationPolicy, validate_dynamics

mp.mp.dps = 60
root = Path(os.environ.get('PROJECT_A_REVIEW_REPO', Path(__file__).resolve().parents[3]))
fixtures = root / 'planner/global_planner/test/fixtures/project_a'
archive = json.loads(gzip.decompress((fixtures / 'w2_a04_candidates.json.gz').read_bytes()))


def true_arc(coeff, lo, hi):
    c = [[mp.mpf(v) for v in row] for row in coeff]
    def f(t):
        d = [row[1] + 2 * t * row[2] + 3 * t * t * row[3] for row in c]
        return mp.sqrt(sum(v * v for v in d))
    return mp.quad(f, [mp.mpf(lo), mp.mpf(hi)])


def ray_distance(point, direction, chain):
    """Exact rational line/segment intersections, separate from production charts."""
    p, d = tuple(map(Fraction, point)), tuple(map(Fraction, direction))
    def cross(a, b):
        return a[0] * b[1] - a[1] * b[0]
    distances = []
    for a, b in zip(chain, chain[1:]):
        edge = (Fraction(b[0]) - Fraction(a[0]), Fraction(b[1]) - Fraction(a[1]))
        offset = (Fraction(a[0]) - p[0], Fraction(a[1]) - p[1])
        determinant = cross(d, edge)
        if determinant:
            along, fraction = cross(offset, edge) / determinant, cross(offset, d) / determinant
            if along > 0 and 0 <= fraction <= 1:
                distances.append(along)
    assert distances
    return float(min(distances))


def check(name):
    item = copy.deepcopy(archive['candidates']['s0_route' if name == 'independent_s4' else name])
    route = load_route(fixtures / (('s0_route' if name == 'independent_s4' else name) + '.json'))
    if name == 'independent_s4':
        p = route.payload
        copies = copy.deepcopy(p['occurrences'])
        for occurrence in copies:
            occurrence['id'] = 'again-' + occurrence['id']
            occurrence['surface_id'] = 'again-deck'
        surface = copy.deepcopy(p['surfaces'][0])
        surface.update(id='again-deck', kind='bridge')
        p['surfaces'].append(surface)
        p['occurrences'].extend(copies)
        second_transitions = copy.deepcopy(p['transitions'])
        p['transitions'][-1]['to'] = copies[0]['id']
        for transition in second_transitions:
            for field in ('id', 'from', 'to'):
                transition[field] = 'again-' + transition[field]
        second_transitions[-1]['to'] = p['occurrences'][0]['id']
        p['transitions'].extend(second_transitions)
        p['gate_sequence'] = [t['id'] for t in p['transitions']]
        p['finish'] = p['gate_sequence'][-1]
        p['route_id'] = 'independent_s4'
        route = validate_route(p)
        count = len(item['coefficients'])
        item['coefficients'] *= 2
        item['owners'].extend([['again-' + owner, 'again-deck']
                               for owner, _ in item['owners'][:count]])
        period = item['q'][-1]
        item['q'] = item['q'][:-1] + [period + q for q in item['q']]
    q = list(item['q'])
    ends = _layout(route)
    # This is a newly approved math-test fixture, never a portability replay.
    # Python 3.12 hypot changes seed-length ulps, so replace ONLY exact occurrence
    # anchors before taking this test fixture's approval digest.
    if platform.python_version() != '3.10.12' or name == 'independent_s4':
        for boundary, following in zip(ends[1:], range(1, len(ends))):
            if following == len(route.occurrences):
                q[-1] = boundary
            else:
                next_owner = route.occurrences[following].id
                first = next(i for i, owner in enumerate(item['owners']) if owner[0] == next_owner)
                q[first] = boundary
    ordered = OrderedCurve(route, Curve(item['coefficients'], item['owners']), q)
    curve = ordered.curve
    approval = curve_digest(ordered)
    body = Footprint(.1, .1, .12, .01)
    limits = RegionLimits(0., 3., 2., 3., 4., 2.5, .02, 'Independent synthetic oracle')
    model = DynamicsModel(tuple(ModelRegion(o.id, o.surface_id, limits)
                                for o in ordered.route.occurrences), 'Independent query oracle')
    geometry = validate_geometry(ordered, ordered.route, body, expected_curve_digest=approval)
    assert geometry.status == 'PASS', geometry
    knots = []
    for i in range(len(curve.segments)):
        # Unequal t steps also imply unequal actual metric steps.
        for t in (0., .137, .791):
            phase = (i + t) / len(curve.segments)
            u = 1. + .13 * math.sin(2 * math.pi * phase)
            knots.append(SpeedKnot(i, t, u))
    def edge(i):
        k, nxt = knots[i], knots[(i + 1) % len(knots)]
        end = nxt.t if nxt.segment == k.segment else 1.
        return curve.segments[k.segment].arc(end) - curve.segments[k.segment].arc(k.t)
    times = [2 * edge(i) / (math.sqrt(k.u) + math.sqrt(knots[(i + 1) % len(knots)].u))
             for i, k in enumerate(knots)]
    profile = SpeedProfile(tuple(knots), approval, model_digest(model), math.fsum(times))
    dynamics = validate_dynamics(ordered, profile, model, expected_curve_digest=approval)
    assert dynamics.status == 'PASS', dynamics
    policies = PolicySet(NumericPolicy(), SolverPolicy(), RetimePolicy(),
                         GeometryValidationPolicy(), DynamicsValidationPolicy())
    # Call the production cache/query path after both actual independent checkers.
    # Artifact trust/publication is deliberately outside this mathematical probe.
    ref = _reference('0' * 64, None, ordered, profile, model, body, policies,
                     geometry, dynamics, {'validation': {'dynamics': {
                         'lap_time_s': dynamics.lap_time_s}}})
    if name == 'independent_s4':
        a, b = ref.sample(.537), ref.sample(.537 + ref.length / 2)
        assert math.dist(a.xy, b.xy) < 1e-8
        assert abs(a.heading - b.heading) < 1e-8
        assert a.occurrence_id != b.occurrence_id and a.surface_id != b.surface_id
    true_segments = [true_arc(c, 0., 1.) for c in curve.coefficients]
    true_edges = []
    for i, k in enumerate(knots):
        nxt = knots[(i + 1) % len(knots)]
        true_edges.append(true_arc(curve.coefficients[k.segment], k.t,
                                   nxt.t if nxt.segment == k.segment else 1.))
    true_times = [2 * d / (mp.sqrt(k.u) + mp.sqrt(knots[(i + 1) % len(knots)].u))
                  for i, (k, d) in enumerate(zip(knots, true_edges))]
    stations = [curve.station(k.segment, k.t) for k in knots]
    requests = [0., -0.137, .137, curve.length, 2 * curve.length + .137,
                math.nextafter(0., -math.inf), math.nextafter(curve.length, 0.)]
    for j in range(0, len(stations), max(1, len(stations) // 18)):
        event = stations[j]
        requests.extend((math.nextafter(event, -math.inf), event,
                         math.nextafter(event, math.inf), event + .019))
    for i, occurrence in enumerate(ordered.route.occurrences):
        events = [ends[i]] + [ends[i] + local for local, _ in occurrence.caps]
        portal = ordered.route.portals[i]
        events.extend((ends[i + 1] - portal.before,
                       ends[(i + 1) % len(ordered.route.occurrences)] + portal.after))
        for q in events:
            event = ordered.station_at_q(q)
            requests.extend((math.nextafter(event, -math.inf), event,
                             math.nextafter(event, math.inf)))
    maxima = {key: 0. for key in ('arc', 'u', 'acceleration', 'time', 'heading', 'curvature')}
    for requested in requests:
        sample = ref.sample(requested)
        i = bisect_right(stations, sample.s) - 1
        k, nxt = knots[i], knots[(i + 1) % len(knots)]
        c = [[mp.mpf(v) for v in row] for row in curve.coefficients[sample.segment]]
        t = mp.mpf(sample.t)
        d = [row[1] + 2 * t * row[2] + 3 * t * t * row[3] for row in c]
        dd = [2 * row[2] + 6 * t * row[3] for row in c]
        station_true = mp.fsum(true_segments[:sample.segment]) + true_arc(
            curve.coefficients[sample.segment], 0., sample.t)
        local = true_arc(curve.coefficients[k.segment], k.t, sample.t)
        u = mp.mpf(k.u) + (mp.mpf(nxt.u) - mp.mpf(k.u)) * local / true_edges[i]
        acceleration = (mp.mpf(nxt.u) - mp.mpf(k.u)) / (2 * true_edges[i])
        elapsed = mp.fsum(true_times[:i]) + 2 * local / (mp.sqrt(k.u) + mp.sqrt(u))
        curvature = (d[0] * dd[1] - d[1] * dd[0]) / mp.power(sum(v * v for v in d), mp.mpf('1.5'))
        errors = {'arc': abs(station_true - sample.s),
                  'u': abs(u - sample.speed_mps ** 2),
                  'acceleration': abs(acceleration - sample.acceleration_mps2),
                  'time': abs(elapsed - sample.time_s),
                  'heading': abs(mp.atan2(d[1], d[0]) - sample.heading),
                  'curvature': abs(curvature - sample.curvature)}
        for key, value in errors.items():
            maxima[key] = max(maxima[key], float(value))
        assert float(errors['arc']) <= 1e-8, (requested, errors)
        assert max(float(errors[k]) for k in ('u', 'acceleration', 'time')) < 2e-8
        assert max(float(errors[k]) for k in ('heading', 'curvature')) < 2e-12
        expected_owner = curve.owners[sample.segment]
        assert (sample.occurrence_id, sample.surface_id) == expected_owner
        assert ref.sample(requested, occurrence_id=expected_owner[0]) == sample
    view = waypoint_view(ref, step_m=.831)
    owners = {o.id: o for o in ordered.route.occurrences}
    side_error, side_checks = 0., 0
    for point in view.waypoints[::max(1, len(view.waypoints) // 30)]:
        if point.portal_support:
            continue
        sample = ref.sample(point.s_m)
        owner = owners[point.occurrence_id]
        for actual, sign, chain in ((point.d_left, 1, owner.left),
                                    (point.d_right, -1, owner.right)):
            distance = ray_distance(sample.xy, tuple(sign * v for v in sample.left_normal), chain)
            error = abs(actual - (distance - 1e-9))
            side_error = max(side_error, error)
            assert error < 2e-9, (name, point.s_m, actual, distance)
            side_checks += 1
    assert view.waypoints[-1].time_s == ref.lap_time_s
    assert view.waypoints[-1].s_m == ref.length
    assert all(getattr(view.waypoints[0], k) == getattr(view.waypoints[-1], k)
               for k in ('x_m', 'y_m', 'psi_rad', 'kappa_radpm', 'vx_mps', 'ax_mps2'))
    assert [p.id for p in view.waypoints] == list(range(len(view.waypoints)))
    assert abs(float(mp.fsum(true_times)) - float(ref.lap_time_s)) < 2e-8
    assert dynamics.lap_time_lower_s <= mp.fsum(true_times) <= dynamics.lap_time_upper_s
    return {'case': name, 'queries': len(requests), 'speed_knots': len(knots),
            'export_waypoints': len(view.waypoints), 'maximum_absolute_errors': maxima,
            'independent_side_checks': side_checks, 'maximum_side_error_m': side_error,
            'time_enclosure': [dynamics.lap_time_lower_s, float(mp.fsum(true_times)),
                               dynamics.lap_time_upper_s],
            'geometry': geometry.status, 'dynamics': dynamics.status}


if __name__ == '__main__':
    names = sys.argv[1:] or ['s0_route', 's0_reverse_route', 's0_rotated_route',
                           's3_surfaces_route', 'independent_s4']
    cases = []
    for name in names:
        result = check(name)
        cases.append(result)
        print(json.dumps(result), flush=True)
    report = {'scope': 'Independent direct query path, not installed/artifact acceptance',
              'source_sha': '17e4ec4e8fedfa736467d02f6204b04e8552decb',
              'source_state': os.environ.get('PROJECT_A_REVIEW_SOURCE_STATE', 'initial exact SHA'),
              'production_sources': {name: hashlib.sha256((root / 'planner/global_planner/global_planner' / name).read_bytes()).hexdigest()
                                     for name in ('route_artifact.py', 'route_legacy_export.py',
                                                  'route_reference.py', 'route_corridor.py')},
              'python': platform.python_version(), 'oracle': 'mpmath 60-digit coefficient integration',
              'fixture_sha256': hashlib.sha256((fixtures / 'w2_a04_candidates.json.gz').read_bytes()).hexdigest(),
              'cases': cases}
    destination = Path(os.environ.get('PROJECT_A_REVIEW_OUTPUT',
                                     Path(__file__).with_name('metric-results.json')))
    destination.write_text(json.dumps(report, indent=2) + '\n')
